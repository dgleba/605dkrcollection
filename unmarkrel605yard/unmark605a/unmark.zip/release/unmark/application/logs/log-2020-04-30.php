<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-04-30 15:03:01 --> Config Class Initialized
INFO - 2020-04-30 15:03:01 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:03:01 --> Hooks Class Initialized
INFO - 2020-04-30 15:03:01 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:03:01 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:03:01 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:03:01 --> Utf8 Class Initialized
INFO - 2020-04-30 15:03:01 --> URI Class Initialized
DEBUG - 2020-04-30 15:03:01 --> No URI present. Default controller set.
INFO - 2020-04-30 15:03:01 --> Router Class Initialized
INFO - 2020-04-30 15:03:01 --> Plain_Router Class Initialized
INFO - 2020-04-30 15:03:01 --> Output Class Initialized
INFO - 2020-04-30 15:03:01 --> Security Class Initialized
DEBUG - 2020-04-30 15:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 15:03:01 --> Input Class Initialized
INFO - 2020-04-30 15:03:01 --> Language Class Initialized
INFO - 2020-04-30 15:03:01 --> Loader Class Initialized
INFO - 2020-04-30 15:03:01 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 15:03:01 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 15:03:01 --> Helper loaded: data_helper
INFO - 2020-04-30 15:03:01 --> Helper loaded: hash_helper
INFO - 2020-04-30 15:03:01 --> Helper loaded: validation_helper
INFO - 2020-04-30 15:03:01 --> Helper loaded: view_helper
INFO - 2020-04-30 15:03:01 --> Helper loaded: url_helper
INFO - 2020-04-30 15:03:01 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 15:04:56 --> Config Class Initialized
INFO - 2020-04-30 15:04:56 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:04:56 --> Hooks Class Initialized
INFO - 2020-04-30 15:04:56 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:04:56 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:04:56 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:04:56 --> Utf8 Class Initialized
INFO - 2020-04-30 15:04:56 --> URI Class Initialized
DEBUG - 2020-04-30 15:04:56 --> No URI present. Default controller set.
INFO - 2020-04-30 15:04:56 --> Router Class Initialized
INFO - 2020-04-30 15:04:56 --> Plain_Router Class Initialized
INFO - 2020-04-30 15:04:56 --> Output Class Initialized
INFO - 2020-04-30 15:04:56 --> Security Class Initialized
DEBUG - 2020-04-30 15:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 15:04:56 --> Input Class Initialized
INFO - 2020-04-30 15:04:56 --> Language Class Initialized
INFO - 2020-04-30 15:04:56 --> Loader Class Initialized
INFO - 2020-04-30 15:04:56 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 15:04:56 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 15:04:56 --> Helper loaded: data_helper
INFO - 2020-04-30 15:04:56 --> Helper loaded: hash_helper
INFO - 2020-04-30 15:04:56 --> Helper loaded: validation_helper
INFO - 2020-04-30 15:04:56 --> Helper loaded: view_helper
INFO - 2020-04-30 15:04:56 --> Helper loaded: url_helper
INFO - 2020-04-30 15:04:56 --> Database Driver Class Initialized
ERROR - 2020-04-30 15:04:56 --> Unable to connect to the database
DEBUG - 2020-04-30 15:04:56 --> Language file loaded: language/english/db_lang.php
INFO - 2020-04-30 15:04:56 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 15:06:20 --> Config Class Initialized
INFO - 2020-04-30 15:06:20 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:06:20 --> Hooks Class Initialized
INFO - 2020-04-30 15:06:20 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:06:20 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:06:20 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:06:20 --> Utf8 Class Initialized
INFO - 2020-04-30 15:06:20 --> URI Class Initialized
DEBUG - 2020-04-30 15:06:20 --> No URI present. Default controller set.
INFO - 2020-04-30 15:06:20 --> Router Class Initialized
INFO - 2020-04-30 15:06:20 --> Plain_Router Class Initialized
INFO - 2020-04-30 15:06:20 --> Output Class Initialized
INFO - 2020-04-30 15:06:20 --> Security Class Initialized
DEBUG - 2020-04-30 15:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 15:06:20 --> Input Class Initialized
INFO - 2020-04-30 15:06:20 --> Language Class Initialized
INFO - 2020-04-30 15:06:20 --> Loader Class Initialized
INFO - 2020-04-30 15:06:20 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 15:06:20 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 15:06:20 --> Helper loaded: data_helper
INFO - 2020-04-30 15:06:20 --> Helper loaded: hash_helper
INFO - 2020-04-30 15:06:20 --> Helper loaded: validation_helper
INFO - 2020-04-30 15:06:20 --> Helper loaded: view_helper
INFO - 2020-04-30 15:06:20 --> Helper loaded: url_helper
INFO - 2020-04-30 15:06:20 --> Database Driver Class Initialized
INFO - 2020-04-30 15:15:06 --> Config Class Initialized
INFO - 2020-04-30 15:15:06 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:15:06 --> Hooks Class Initialized
INFO - 2020-04-30 15:15:06 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:15:06 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:15:06 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:15:06 --> Utf8 Class Initialized
INFO - 2020-04-30 15:15:06 --> URI Class Initialized
DEBUG - 2020-04-30 15:15:06 --> No URI present. Default controller set.
INFO - 2020-04-30 15:15:06 --> Router Class Initialized
INFO - 2020-04-30 15:15:06 --> Plain_Router Class Initialized
INFO - 2020-04-30 15:15:06 --> Output Class Initialized
INFO - 2020-04-30 15:15:06 --> Security Class Initialized
DEBUG - 2020-04-30 15:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 15:15:06 --> Input Class Initialized
INFO - 2020-04-30 15:15:06 --> Language Class Initialized
INFO - 2020-04-30 15:15:06 --> Loader Class Initialized
INFO - 2020-04-30 15:15:06 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 15:15:06 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 15:15:06 --> Helper loaded: data_helper
INFO - 2020-04-30 15:15:06 --> Helper loaded: hash_helper
INFO - 2020-04-30 15:15:06 --> Helper loaded: validation_helper
INFO - 2020-04-30 15:15:06 --> Helper loaded: view_helper
INFO - 2020-04-30 15:15:06 --> Helper loaded: url_helper
INFO - 2020-04-30 15:15:06 --> Database Driver Class Initialized
ERROR - 2020-04-30 15:15:06 --> Unable to connect to the database
DEBUG - 2020-04-30 15:15:06 --> Language file loaded: language/english/db_lang.php
INFO - 2020-04-30 15:15:06 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 15:15:42 --> Config Class Initialized
INFO - 2020-04-30 15:15:42 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:15:42 --> Hooks Class Initialized
INFO - 2020-04-30 15:15:42 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:15:43 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:15:43 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:15:43 --> Utf8 Class Initialized
INFO - 2020-04-30 15:15:43 --> URI Class Initialized
DEBUG - 2020-04-30 15:15:43 --> No URI present. Default controller set.
INFO - 2020-04-30 15:15:43 --> Router Class Initialized
INFO - 2020-04-30 15:15:43 --> Plain_Router Class Initialized
INFO - 2020-04-30 15:15:43 --> Output Class Initialized
INFO - 2020-04-30 15:15:43 --> Security Class Initialized
DEBUG - 2020-04-30 15:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 15:15:43 --> Input Class Initialized
INFO - 2020-04-30 15:15:43 --> Language Class Initialized
INFO - 2020-04-30 15:15:43 --> Loader Class Initialized
INFO - 2020-04-30 15:15:43 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 15:15:43 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 15:15:43 --> Helper loaded: data_helper
INFO - 2020-04-30 15:15:43 --> Helper loaded: hash_helper
INFO - 2020-04-30 15:15:43 --> Helper loaded: validation_helper
INFO - 2020-04-30 15:15:43 --> Helper loaded: view_helper
INFO - 2020-04-30 15:15:43 --> Helper loaded: url_helper
INFO - 2020-04-30 15:15:43 --> Database Driver Class Initialized
INFO - 2020-04-30 15:15:43 --> Controller Class Initialized
INFO - 2020-04-30 15:15:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 15:15:43 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-04-30 15:15:43 --> The "english" language file has been loaded.
DEBUG - 2020-04-30 15:15:43 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-04-30 15:15:43 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-04-30 15:15:43 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-04-30 15:15:43 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-04-30 15:15:43 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-04-30 15:15:43 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-04-30 15:15:43 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-04-30 15:15:43 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-04-30 15:15:43 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-04-30 15:15:43 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-04-30 15:15:43 --> Final output sent to browser
DEBUG - 2020-04-30 15:15:43 --> Total execution time: 0.6562
INFO - 2020-04-30 15:51:08 --> Config Class Initialized
INFO - 2020-04-30 15:51:08 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:51:08 --> Hooks Class Initialized
INFO - 2020-04-30 15:51:08 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:51:08 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:51:08 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:51:08 --> Utf8 Class Initialized
INFO - 2020-04-30 15:51:08 --> URI Class Initialized
DEBUG - 2020-04-30 15:51:09 --> No URI present. Default controller set.
INFO - 2020-04-30 15:51:09 --> Router Class Initialized
INFO - 2020-04-30 15:51:09 --> Plain_Router Class Initialized
INFO - 2020-04-30 15:51:09 --> Output Class Initialized
INFO - 2020-04-30 15:51:09 --> Security Class Initialized
DEBUG - 2020-04-30 15:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 15:51:09 --> Input Class Initialized
INFO - 2020-04-30 15:51:09 --> Language Class Initialized
INFO - 2020-04-30 15:51:09 --> Loader Class Initialized
INFO - 2020-04-30 15:51:09 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 15:51:09 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 15:51:09 --> Helper loaded: data_helper
INFO - 2020-04-30 15:51:09 --> Helper loaded: hash_helper
INFO - 2020-04-30 15:51:09 --> Helper loaded: validation_helper
INFO - 2020-04-30 15:51:09 --> Helper loaded: view_helper
INFO - 2020-04-30 15:51:09 --> Helper loaded: url_helper
INFO - 2020-04-30 15:51:09 --> Database Driver Class Initialized
INFO - 2020-04-30 15:51:09 --> Controller Class Initialized
INFO - 2020-04-30 15:51:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 15:51:09 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-04-30 15:51:09 --> The "english" language file has been loaded.
DEBUG - 2020-04-30 15:51:09 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-04-30 15:51:09 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-04-30 15:51:09 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-04-30 15:51:09 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-04-30 15:51:09 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-04-30 15:51:09 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-04-30 15:51:09 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-04-30 15:51:09 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-04-30 15:51:09 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-04-30 15:51:09 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-04-30 15:51:09 --> Final output sent to browser
DEBUG - 2020-04-30 15:51:09 --> Total execution time: 0.7452
INFO - 2020-04-30 15:51:11 --> Config Class Initialized
INFO - 2020-04-30 15:51:11 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:51:11 --> Hooks Class Initialized
INFO - 2020-04-30 15:51:11 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:51:11 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:51:11 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:51:11 --> Utf8 Class Initialized
INFO - 2020-04-30 15:51:11 --> URI Class Initialized
DEBUG - 2020-04-30 15:51:11 --> Validating request for /controllers/Custom.php
INFO - 2020-04-30 15:51:11 --> Plain_Exceptions Class Initialized
ERROR - 2020-04-30 15:51:11 --> 404 Page Not Found: custom
INFO - 2020-04-30 15:53:59 --> Config Class Initialized
INFO - 2020-04-30 15:53:59 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:53:59 --> Hooks Class Initialized
INFO - 2020-04-30 15:53:59 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:53:59 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:53:59 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:53:59 --> Utf8 Class Initialized
INFO - 2020-04-30 15:53:59 --> URI Class Initialized
DEBUG - 2020-04-30 15:53:59 --> Validating request for /controllers/Install.php
INFO - 2020-04-30 15:53:59 --> Router Class Initialized
INFO - 2020-04-30 15:53:59 --> Plain_Router Class Initialized
INFO - 2020-04-30 15:53:59 --> Output Class Initialized
INFO - 2020-04-30 15:53:59 --> Security Class Initialized
DEBUG - 2020-04-30 15:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 15:53:59 --> Input Class Initialized
INFO - 2020-04-30 15:53:59 --> Language Class Initialized
INFO - 2020-04-30 15:53:59 --> Loader Class Initialized
INFO - 2020-04-30 15:53:59 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 15:53:59 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 15:53:59 --> Helper loaded: data_helper
INFO - 2020-04-30 15:53:59 --> Helper loaded: hash_helper
INFO - 2020-04-30 15:53:59 --> Helper loaded: validation_helper
INFO - 2020-04-30 15:53:59 --> Helper loaded: view_helper
INFO - 2020-04-30 15:53:59 --> Helper loaded: url_helper
INFO - 2020-04-30 15:53:59 --> Database Driver Class Initialized
INFO - 2020-04-30 15:53:59 --> Controller Class Initialized
DEBUG - 2020-04-30 15:53:59 --> The "english" language file has been loaded.
DEBUG - 2020-04-30 15:53:59 --> Plain Migrations class initialized
DEBUG - 2020-04-30 15:53:59 --> Language file loaded: language/english/migration_lang.php
INFO - 2020-04-30 15:53:59 --> Database Forge Class Initialized
DEBUG - 2020-04-30 15:54:00 --> Making backup before migrating failed.
DEBUG - 2020-04-30 15:54:00 --> Migrating up from version 0 to version 001
DEBUG - 2020-04-30 15:54:00 --> Migrating up from version 001 to version 002
DEBUG - 2020-04-30 15:54:00 --> Migrating up from version 002 to version 003
DEBUG - 2020-04-30 15:54:00 --> Migrating up from version 003 to version 004
DEBUG - 2020-04-30 15:54:00 --> Migrating up from version 004 to version 005
DEBUG - 2020-04-30 15:54:01 --> Migrating up from version 005 to version 006
DEBUG - 2020-04-30 15:54:01 --> Migrating up from version 006 to version 007
DEBUG - 2020-04-30 15:54:02 --> Migrating up from version 007 to version 008
DEBUG - 2020-04-30 15:54:02 --> Migrating up from version 008 to version 009
DEBUG - 2020-04-30 15:54:02 --> Migrating up from version 009 to version 010
DEBUG - 2020-04-30 15:54:02 --> Migrating up from version 010 to version 2014022801
DEBUG - 2020-04-30 15:54:02 --> Migrating up from version 2014022801 to version 2014112501
DEBUG - 2020-04-30 15:54:02 --> Finished migrating to 2014112501
DEBUG - 2020-04-30 15:54:02 --> Making backup before migrating failed.
INFO - 2020-04-30 15:54:02 --> Config Class Initialized
INFO - 2020-04-30 15:54:02 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:54:02 --> Hooks Class Initialized
INFO - 2020-04-30 15:54:02 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:54:02 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:54:02 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:54:02 --> Utf8 Class Initialized
INFO - 2020-04-30 15:54:03 --> URI Class Initialized
DEBUG - 2020-04-30 15:54:03 --> Validating request for /controllers/Register.php
INFO - 2020-04-30 15:54:03 --> Router Class Initialized
INFO - 2020-04-30 15:54:03 --> Plain_Router Class Initialized
INFO - 2020-04-30 15:54:03 --> Output Class Initialized
INFO - 2020-04-30 15:54:03 --> Security Class Initialized
DEBUG - 2020-04-30 15:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 15:54:03 --> Input Class Initialized
INFO - 2020-04-30 15:54:03 --> Language Class Initialized
INFO - 2020-04-30 15:54:03 --> Loader Class Initialized
INFO - 2020-04-30 15:54:03 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 15:54:03 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 15:54:03 --> Helper loaded: data_helper
INFO - 2020-04-30 15:54:03 --> Helper loaded: hash_helper
INFO - 2020-04-30 15:54:03 --> Helper loaded: validation_helper
INFO - 2020-04-30 15:54:03 --> Helper loaded: view_helper
INFO - 2020-04-30 15:54:03 --> Helper loaded: url_helper
INFO - 2020-04-30 15:54:03 --> Database Driver Class Initialized
INFO - 2020-04-30 15:54:03 --> Controller Class Initialized
INFO - 2020-04-30 15:54:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 15:54:03 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-04-30 15:54:03 --> The "english" language file has been loaded.
DEBUG - 2020-04-30 15:54:03 --> The phrase "Unmark : User Registration" could not be found in the language file.
DEBUG - 2020-04-30 15:54:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-04-30 15:54:03 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-04-30 15:54:03 --> The phrase "Password Again" could not be found in the language file.
DEBUG - 2020-04-30 15:54:03 --> The phrase "Terms of Use" could not be found in the language file.
DEBUG - 2020-04-30 15:54:03 --> The phrase "Have An Account? Sign In Here" could not be found in the language file.
INFO - 2020-04-30 15:54:03 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-04-30 15:54:03 --> File loaded: /var/www/html/application/views/register/index.php
INFO - 2020-04-30 15:54:03 --> Final output sent to browser
DEBUG - 2020-04-30 15:54:03 --> Total execution time: 0.4922
INFO - 2020-04-30 15:54:04 --> Config Class Initialized
INFO - 2020-04-30 15:54:04 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:54:04 --> Hooks Class Initialized
INFO - 2020-04-30 15:54:04 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:54:04 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:54:04 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:54:04 --> Utf8 Class Initialized
INFO - 2020-04-30 15:54:04 --> URI Class Initialized
DEBUG - 2020-04-30 15:54:05 --> Validating request for /controllers/Custom.php
INFO - 2020-04-30 15:54:05 --> Plain_Exceptions Class Initialized
ERROR - 2020-04-30 15:54:05 --> 404 Page Not Found: custom
INFO - 2020-04-30 15:54:17 --> Config Class Initialized
INFO - 2020-04-30 15:54:17 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:54:17 --> Hooks Class Initialized
INFO - 2020-04-30 15:54:17 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:54:17 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:54:17 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:54:17 --> Utf8 Class Initialized
INFO - 2020-04-30 15:54:17 --> URI Class Initialized
DEBUG - 2020-04-30 15:54:17 --> Validating request for /controllers/Register.php
INFO - 2020-04-30 15:54:17 --> Router Class Initialized
INFO - 2020-04-30 15:54:17 --> Plain_Router Class Initialized
INFO - 2020-04-30 15:54:17 --> Output Class Initialized
INFO - 2020-04-30 15:54:17 --> Security Class Initialized
DEBUG - 2020-04-30 15:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 15:54:17 --> Input Class Initialized
INFO - 2020-04-30 15:54:17 --> Language Class Initialized
INFO - 2020-04-30 15:54:17 --> Loader Class Initialized
INFO - 2020-04-30 15:54:17 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 15:54:17 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 15:54:17 --> Helper loaded: data_helper
INFO - 2020-04-30 15:54:17 --> Helper loaded: hash_helper
INFO - 2020-04-30 15:54:17 --> Helper loaded: validation_helper
INFO - 2020-04-30 15:54:17 --> Helper loaded: view_helper
INFO - 2020-04-30 15:54:17 --> Helper loaded: url_helper
INFO - 2020-04-30 15:54:18 --> Database Driver Class Initialized
INFO - 2020-04-30 15:54:18 --> Controller Class Initialized
INFO - 2020-04-30 15:54:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 15:54:18 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-04-30 15:54:18 --> The "english" language file has been loaded.
INFO - 2020-04-30 15:54:18 --> Plain_Model class loaded
INFO - 2020-04-30 15:54:18 --> Model "Users_model" initialized
INFO - 2020-04-30 15:54:18 --> Helper loaded: http_build_url_helper
INFO - 2020-04-30 15:54:18 --> Model "Marks_model" initialized
INFO - 2020-04-30 15:54:18 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 15:54:18 --> The phrase "Just Now" could not be found in the language file.
DEBUG - 2020-04-30 15:54:18 --> The phrase "Just Now" could not be found in the language file.
DEBUG - 2020-04-30 15:54:18 --> The phrase "Just Now" could not be found in the language file.
INFO - 2020-04-30 15:54:18 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-04-30 15:54:18 --> Final output sent to browser
DEBUG - 2020-04-30 15:54:18 --> Total execution time: 0.8979
INFO - 2020-04-30 15:54:21 --> Config Class Initialized
INFO - 2020-04-30 15:54:21 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:54:21 --> Hooks Class Initialized
INFO - 2020-04-30 15:54:21 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:54:21 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:54:21 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:54:21 --> Utf8 Class Initialized
INFO - 2020-04-30 15:54:21 --> URI Class Initialized
DEBUG - 2020-04-30 15:54:21 --> No URI present. Default controller set.
INFO - 2020-04-30 15:54:21 --> Router Class Initialized
INFO - 2020-04-30 15:54:21 --> Plain_Router Class Initialized
INFO - 2020-04-30 15:54:21 --> Output Class Initialized
INFO - 2020-04-30 15:54:21 --> Security Class Initialized
DEBUG - 2020-04-30 15:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 15:54:21 --> Input Class Initialized
INFO - 2020-04-30 15:54:21 --> Language Class Initialized
INFO - 2020-04-30 15:54:21 --> Loader Class Initialized
INFO - 2020-04-30 15:54:21 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 15:54:21 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 15:54:21 --> Helper loaded: data_helper
INFO - 2020-04-30 15:54:21 --> Helper loaded: hash_helper
INFO - 2020-04-30 15:54:21 --> Helper loaded: validation_helper
INFO - 2020-04-30 15:54:21 --> Helper loaded: view_helper
INFO - 2020-04-30 15:54:21 --> Helper loaded: url_helper
INFO - 2020-04-30 15:54:21 --> Database Driver Class Initialized
INFO - 2020-04-30 15:54:21 --> Controller Class Initialized
INFO - 2020-04-30 15:54:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 15:54:21 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-04-30 15:54:21 --> The "english" language file has been loaded.
INFO - 2020-04-30 15:54:21 --> Config Class Initialized
INFO - 2020-04-30 15:54:21 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:54:21 --> Hooks Class Initialized
INFO - 2020-04-30 15:54:21 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:54:21 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:54:21 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:54:21 --> Utf8 Class Initialized
INFO - 2020-04-30 15:54:21 --> URI Class Initialized
DEBUG - 2020-04-30 15:54:21 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 15:54:21 --> Router Class Initialized
INFO - 2020-04-30 15:54:21 --> Plain_Router Class Initialized
INFO - 2020-04-30 15:54:21 --> Output Class Initialized
INFO - 2020-04-30 15:54:21 --> Security Class Initialized
DEBUG - 2020-04-30 15:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 15:54:21 --> Input Class Initialized
INFO - 2020-04-30 15:54:21 --> Language Class Initialized
INFO - 2020-04-30 15:54:21 --> Loader Class Initialized
INFO - 2020-04-30 15:54:21 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 15:54:21 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 15:54:21 --> Helper loaded: data_helper
INFO - 2020-04-30 15:54:21 --> Helper loaded: hash_helper
INFO - 2020-04-30 15:54:21 --> Helper loaded: validation_helper
INFO - 2020-04-30 15:54:21 --> Helper loaded: view_helper
INFO - 2020-04-30 15:54:21 --> Helper loaded: url_helper
INFO - 2020-04-30 15:54:21 --> Database Driver Class Initialized
INFO - 2020-04-30 15:54:21 --> Controller Class Initialized
INFO - 2020-04-30 15:54:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 15:54:21 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 15:54:21 --> Plain_Model class loaded
INFO - 2020-04-30 15:54:22 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 15:54:22 --> The "english" language file has been loaded.
INFO - 2020-04-30 15:54:22 --> Model "Labels_model" initialized
INFO - 2020-04-30 15:54:22 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 15:54:22 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 15:54:22 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 15:54:22 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 15:54:22 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 15:54:22 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 15:54:22 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 15:54:22 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 15:54:22 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 15:54:29 --> Config Class Initialized
INFO - 2020-04-30 15:54:29 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:54:29 --> Hooks Class Initialized
INFO - 2020-04-30 15:54:29 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:54:29 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:54:29 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:54:29 --> Utf8 Class Initialized
INFO - 2020-04-30 15:54:29 --> URI Class Initialized
DEBUG - 2020-04-30 15:54:29 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 15:54:29 --> Router Class Initialized
INFO - 2020-04-30 15:54:29 --> Plain_Router Class Initialized
INFO - 2020-04-30 15:54:29 --> Output Class Initialized
INFO - 2020-04-30 15:54:29 --> Security Class Initialized
DEBUG - 2020-04-30 15:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 15:54:29 --> Input Class Initialized
INFO - 2020-04-30 15:54:29 --> Language Class Initialized
INFO - 2020-04-30 15:54:29 --> Loader Class Initialized
INFO - 2020-04-30 15:54:29 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 15:54:29 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 15:54:29 --> Helper loaded: data_helper
INFO - 2020-04-30 15:54:29 --> Helper loaded: hash_helper
INFO - 2020-04-30 15:54:29 --> Helper loaded: validation_helper
INFO - 2020-04-30 15:54:29 --> Helper loaded: view_helper
INFO - 2020-04-30 15:54:29 --> Helper loaded: url_helper
INFO - 2020-04-30 15:54:29 --> Database Driver Class Initialized
INFO - 2020-04-30 15:54:29 --> Controller Class Initialized
INFO - 2020-04-30 15:54:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 15:54:29 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 15:54:29 --> Plain_Model class loaded
INFO - 2020-04-30 15:54:29 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 15:54:29 --> The "english" language file has been loaded.
INFO - 2020-04-30 15:54:29 --> Model "Labels_model" initialized
INFO - 2020-04-30 15:54:29 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 15:54:29 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 15:54:29 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 15:54:29 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 15:54:29 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 15:54:29 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 15:54:29 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 15:54:30 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 15:54:30 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 15:55:55 --> Config Class Initialized
INFO - 2020-04-30 15:55:55 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:55:55 --> Hooks Class Initialized
INFO - 2020-04-30 15:55:55 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:55:55 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:55:55 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:55:55 --> Utf8 Class Initialized
INFO - 2020-04-30 15:55:55 --> URI Class Initialized
DEBUG - 2020-04-30 15:55:55 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 15:55:55 --> Router Class Initialized
INFO - 2020-04-30 15:55:55 --> Plain_Router Class Initialized
INFO - 2020-04-30 15:55:55 --> Output Class Initialized
INFO - 2020-04-30 15:55:55 --> Security Class Initialized
DEBUG - 2020-04-30 15:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 15:55:55 --> Input Class Initialized
INFO - 2020-04-30 15:55:55 --> Language Class Initialized
INFO - 2020-04-30 15:55:55 --> Loader Class Initialized
INFO - 2020-04-30 15:55:55 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 15:55:55 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 15:55:55 --> Helper loaded: data_helper
INFO - 2020-04-30 15:55:55 --> Helper loaded: hash_helper
INFO - 2020-04-30 15:55:55 --> Helper loaded: validation_helper
INFO - 2020-04-30 15:55:55 --> Helper loaded: view_helper
INFO - 2020-04-30 15:55:55 --> Helper loaded: url_helper
INFO - 2020-04-30 15:55:55 --> Database Driver Class Initialized
INFO - 2020-04-30 15:55:55 --> Controller Class Initialized
INFO - 2020-04-30 15:55:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 15:55:55 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 15:55:55 --> Plain_Model class loaded
INFO - 2020-04-30 15:55:55 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 15:55:55 --> The "english" language file has been loaded.
INFO - 2020-04-30 15:55:55 --> Model "Labels_model" initialized
INFO - 2020-04-30 15:55:55 --> Model "Labels_model" initialized
INFO - 2020-04-30 15:55:55 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 15:55:56 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 15:55:56 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 15:55:56 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 15:55:56 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 15:55:56 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 15:55:56 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 15:55:56 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 15:55:56 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 15:55:58 --> Config Class Initialized
INFO - 2020-04-30 15:55:58 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:55:58 --> Hooks Class Initialized
INFO - 2020-04-30 15:55:58 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:55:58 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:55:58 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:55:58 --> Utf8 Class Initialized
INFO - 2020-04-30 15:55:58 --> URI Class Initialized
DEBUG - 2020-04-30 15:55:58 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 15:55:58 --> Router Class Initialized
INFO - 2020-04-30 15:55:58 --> Plain_Router Class Initialized
INFO - 2020-04-30 15:55:58 --> Output Class Initialized
INFO - 2020-04-30 15:55:58 --> Security Class Initialized
DEBUG - 2020-04-30 15:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 15:55:58 --> Input Class Initialized
INFO - 2020-04-30 15:55:58 --> Language Class Initialized
INFO - 2020-04-30 15:55:58 --> Loader Class Initialized
INFO - 2020-04-30 15:55:58 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 15:55:58 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 15:55:58 --> Helper loaded: data_helper
INFO - 2020-04-30 15:55:58 --> Helper loaded: hash_helper
INFO - 2020-04-30 15:55:58 --> Helper loaded: validation_helper
INFO - 2020-04-30 15:55:58 --> Helper loaded: view_helper
INFO - 2020-04-30 15:55:58 --> Helper loaded: url_helper
INFO - 2020-04-30 15:55:58 --> Database Driver Class Initialized
INFO - 2020-04-30 15:55:58 --> Controller Class Initialized
INFO - 2020-04-30 15:55:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 15:55:58 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 15:55:58 --> Plain_Model class loaded
INFO - 2020-04-30 15:55:58 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 15:55:58 --> The "english" language file has been loaded.
INFO - 2020-04-30 15:55:58 --> Model "Labels_model" initialized
INFO - 2020-04-30 15:55:58 --> Model "Labels_model" initialized
INFO - 2020-04-30 15:55:59 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 15:55:59 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 15:55:59 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 15:55:59 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 15:55:59 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 15:55:59 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 15:55:59 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 15:55:59 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 15:55:59 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 15:56:00 --> Config Class Initialized
INFO - 2020-04-30 15:56:00 --> Plain_Config Class Initialized
INFO - 2020-04-30 15:56:00 --> Hooks Class Initialized
INFO - 2020-04-30 15:56:00 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 15:56:00 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 15:56:00 --> UTF-8 Support Disabled
INFO - 2020-04-30 15:56:00 --> Utf8 Class Initialized
INFO - 2020-04-30 15:56:01 --> URI Class Initialized
DEBUG - 2020-04-30 15:56:01 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 15:56:01 --> Router Class Initialized
INFO - 2020-04-30 15:56:01 --> Plain_Router Class Initialized
INFO - 2020-04-30 15:56:01 --> Output Class Initialized
INFO - 2020-04-30 15:56:01 --> Security Class Initialized
DEBUG - 2020-04-30 15:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 15:56:01 --> Input Class Initialized
INFO - 2020-04-30 15:56:01 --> Language Class Initialized
INFO - 2020-04-30 15:56:01 --> Loader Class Initialized
INFO - 2020-04-30 15:56:01 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 15:56:01 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 15:56:01 --> Helper loaded: data_helper
INFO - 2020-04-30 15:56:01 --> Helper loaded: hash_helper
INFO - 2020-04-30 15:56:01 --> Helper loaded: validation_helper
INFO - 2020-04-30 15:56:01 --> Helper loaded: view_helper
INFO - 2020-04-30 15:56:01 --> Helper loaded: url_helper
INFO - 2020-04-30 15:56:01 --> Database Driver Class Initialized
INFO - 2020-04-30 15:56:01 --> Controller Class Initialized
INFO - 2020-04-30 15:56:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 15:56:01 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 15:56:01 --> Plain_Model class loaded
INFO - 2020-04-30 15:56:01 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 15:56:01 --> The "english" language file has been loaded.
INFO - 2020-04-30 15:56:01 --> Model "Labels_model" initialized
INFO - 2020-04-30 15:56:01 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 15:56:01 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 15:56:01 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 15:56:01 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 15:56:01 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 15:56:01 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 15:56:01 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 15:56:01 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 15:56:01 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 16:00:07 --> Config Class Initialized
INFO - 2020-04-30 16:00:07 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:00:07 --> Hooks Class Initialized
INFO - 2020-04-30 16:00:07 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:00:07 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:00:07 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:00:07 --> Utf8 Class Initialized
INFO - 2020-04-30 16:00:07 --> URI Class Initialized
DEBUG - 2020-04-30 16:00:07 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:00:07 --> Router Class Initialized
INFO - 2020-04-30 16:00:07 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:00:07 --> Output Class Initialized
INFO - 2020-04-30 16:00:07 --> Security Class Initialized
DEBUG - 2020-04-30 16:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:00:07 --> Input Class Initialized
INFO - 2020-04-30 16:00:07 --> Language Class Initialized
INFO - 2020-04-30 16:00:07 --> Loader Class Initialized
INFO - 2020-04-30 16:00:07 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:00:07 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:00:07 --> Helper loaded: data_helper
INFO - 2020-04-30 16:00:07 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:00:07 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:00:07 --> Helper loaded: view_helper
INFO - 2020-04-30 16:00:07 --> Helper loaded: url_helper
INFO - 2020-04-30 16:00:07 --> Database Driver Class Initialized
INFO - 2020-04-30 16:00:07 --> Controller Class Initialized
INFO - 2020-04-30 16:00:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:00:07 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:00:07 --> Plain_Model class loaded
INFO - 2020-04-30 16:00:07 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:00:07 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:00:07 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:00:07 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 16:00:08 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 16:00:08 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 16:00:08 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 16:00:08 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 16:00:08 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 16:00:08 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 16:00:08 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 16:00:08 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 16:00:23 --> Config Class Initialized
INFO - 2020-04-30 16:00:23 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:00:23 --> Hooks Class Initialized
INFO - 2020-04-30 16:00:23 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:00:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:00:23 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:00:23 --> Utf8 Class Initialized
INFO - 2020-04-30 16:00:23 --> URI Class Initialized
DEBUG - 2020-04-30 16:00:23 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:00:23 --> Router Class Initialized
INFO - 2020-04-30 16:00:23 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:00:23 --> Output Class Initialized
INFO - 2020-04-30 16:00:23 --> Security Class Initialized
DEBUG - 2020-04-30 16:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:00:23 --> Input Class Initialized
INFO - 2020-04-30 16:00:23 --> Language Class Initialized
INFO - 2020-04-30 16:00:23 --> Loader Class Initialized
INFO - 2020-04-30 16:00:23 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:00:23 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:00:23 --> Helper loaded: data_helper
INFO - 2020-04-30 16:00:23 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:00:23 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:00:23 --> Helper loaded: view_helper
INFO - 2020-04-30 16:00:23 --> Helper loaded: url_helper
INFO - 2020-04-30 16:00:23 --> Database Driver Class Initialized
INFO - 2020-04-30 16:00:23 --> Controller Class Initialized
INFO - 2020-04-30 16:00:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:00:23 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:00:23 --> Plain_Model class loaded
INFO - 2020-04-30 16:00:23 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:00:24 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:00:24 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:00:24 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:00:24 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 16:00:24 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 16:00:24 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 16:00:24 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 16:00:24 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 16:00:24 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 16:00:24 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 16:00:24 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 16:00:24 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 16:18:54 --> Config Class Initialized
INFO - 2020-04-30 16:18:54 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:18:54 --> Hooks Class Initialized
INFO - 2020-04-30 16:18:54 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:18:54 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:18:54 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:18:54 --> Utf8 Class Initialized
INFO - 2020-04-30 16:18:54 --> URI Class Initialized
DEBUG - 2020-04-30 16:18:54 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:18:54 --> Router Class Initialized
INFO - 2020-04-30 16:18:54 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:18:54 --> Output Class Initialized
INFO - 2020-04-30 16:18:54 --> Security Class Initialized
DEBUG - 2020-04-30 16:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:18:54 --> Input Class Initialized
INFO - 2020-04-30 16:18:54 --> Language Class Initialized
INFO - 2020-04-30 16:18:54 --> Loader Class Initialized
INFO - 2020-04-30 16:18:54 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:18:54 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:18:54 --> Helper loaded: data_helper
INFO - 2020-04-30 16:18:54 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:18:54 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:18:54 --> Helper loaded: view_helper
INFO - 2020-04-30 16:18:54 --> Helper loaded: url_helper
INFO - 2020-04-30 16:18:54 --> Database Driver Class Initialized
INFO - 2020-04-30 16:18:54 --> Controller Class Initialized
INFO - 2020-04-30 16:18:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:18:55 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:18:55 --> Plain_Model class loaded
INFO - 2020-04-30 16:18:55 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:18:55 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:18:55 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:18:55 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:18:55 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 16:18:55 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 16:18:55 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 16:18:55 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 16:18:55 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 16:18:55 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 16:18:55 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 16:18:55 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 16:18:55 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 16:18:57 --> Config Class Initialized
INFO - 2020-04-30 16:18:57 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:18:57 --> Hooks Class Initialized
INFO - 2020-04-30 16:18:57 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:18:57 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:18:57 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:18:57 --> Utf8 Class Initialized
INFO - 2020-04-30 16:18:57 --> URI Class Initialized
DEBUG - 2020-04-30 16:18:57 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:18:57 --> Router Class Initialized
INFO - 2020-04-30 16:18:57 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:18:57 --> Output Class Initialized
INFO - 2020-04-30 16:18:57 --> Security Class Initialized
DEBUG - 2020-04-30 16:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:18:57 --> Input Class Initialized
INFO - 2020-04-30 16:18:57 --> Language Class Initialized
INFO - 2020-04-30 16:18:57 --> Loader Class Initialized
INFO - 2020-04-30 16:18:57 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:18:57 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:18:57 --> Helper loaded: data_helper
INFO - 2020-04-30 16:18:57 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:18:57 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:18:57 --> Helper loaded: view_helper
INFO - 2020-04-30 16:18:57 --> Helper loaded: url_helper
INFO - 2020-04-30 16:18:57 --> Database Driver Class Initialized
INFO - 2020-04-30 16:18:57 --> Controller Class Initialized
INFO - 2020-04-30 16:18:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:18:57 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:18:57 --> Plain_Model class loaded
INFO - 2020-04-30 16:18:57 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:18:57 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:18:57 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:18:57 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 16:18:57 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 16:18:57 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 16:18:57 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 16:18:57 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 16:18:57 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 16:18:57 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 16:18:57 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 16:18:57 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 16:19:09 --> Config Class Initialized
INFO - 2020-04-30 16:19:09 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:19:09 --> Hooks Class Initialized
INFO - 2020-04-30 16:19:09 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:19:09 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:19:09 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:19:09 --> Utf8 Class Initialized
INFO - 2020-04-30 16:19:09 --> URI Class Initialized
DEBUG - 2020-04-30 16:19:09 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:19:09 --> Router Class Initialized
INFO - 2020-04-30 16:19:09 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:19:09 --> Output Class Initialized
INFO - 2020-04-30 16:19:09 --> Security Class Initialized
DEBUG - 2020-04-30 16:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:19:09 --> Input Class Initialized
INFO - 2020-04-30 16:19:09 --> Language Class Initialized
INFO - 2020-04-30 16:19:09 --> Loader Class Initialized
INFO - 2020-04-30 16:19:09 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:19:09 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:19:09 --> Helper loaded: data_helper
INFO - 2020-04-30 16:19:09 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:19:09 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:19:09 --> Helper loaded: view_helper
INFO - 2020-04-30 16:19:09 --> Helper loaded: url_helper
INFO - 2020-04-30 16:19:10 --> Database Driver Class Initialized
INFO - 2020-04-30 16:19:10 --> Controller Class Initialized
INFO - 2020-04-30 16:19:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:19:10 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:19:10 --> Plain_Model class loaded
INFO - 2020-04-30 16:19:10 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:19:10 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:19:10 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:19:10 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 16:19:10 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 16:19:10 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 16:19:10 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 16:19:10 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 16:19:10 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 16:19:10 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 16:19:10 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 16:19:10 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 16:19:27 --> Config Class Initialized
INFO - 2020-04-30 16:19:27 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:19:27 --> Hooks Class Initialized
INFO - 2020-04-30 16:19:27 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:19:27 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:19:27 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:19:27 --> Utf8 Class Initialized
INFO - 2020-04-30 16:19:27 --> URI Class Initialized
DEBUG - 2020-04-30 16:19:27 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:19:27 --> Router Class Initialized
INFO - 2020-04-30 16:19:27 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:19:27 --> Output Class Initialized
INFO - 2020-04-30 16:19:27 --> Security Class Initialized
DEBUG - 2020-04-30 16:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:19:27 --> Input Class Initialized
INFO - 2020-04-30 16:19:27 --> Language Class Initialized
INFO - 2020-04-30 16:19:28 --> Loader Class Initialized
INFO - 2020-04-30 16:19:28 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:19:28 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:19:28 --> Helper loaded: data_helper
INFO - 2020-04-30 16:19:28 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:19:28 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:19:28 --> Helper loaded: view_helper
INFO - 2020-04-30 16:19:28 --> Helper loaded: url_helper
INFO - 2020-04-30 16:19:28 --> Database Driver Class Initialized
INFO - 2020-04-30 16:19:28 --> Controller Class Initialized
INFO - 2020-04-30 16:19:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:19:28 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:19:28 --> Plain_Model class loaded
INFO - 2020-04-30 16:19:28 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:19:28 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:19:28 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:19:28 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 16:19:28 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 16:19:28 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 16:19:28 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 16:19:28 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 16:19:28 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 16:19:28 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 16:19:28 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 16:19:28 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 16:20:41 --> Config Class Initialized
INFO - 2020-04-30 16:20:41 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:20:41 --> Hooks Class Initialized
INFO - 2020-04-30 16:20:41 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:20:41 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:20:41 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:20:41 --> Utf8 Class Initialized
INFO - 2020-04-30 16:20:41 --> URI Class Initialized
DEBUG - 2020-04-30 16:20:41 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:20:41 --> Router Class Initialized
INFO - 2020-04-30 16:20:41 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:20:41 --> Output Class Initialized
INFO - 2020-04-30 16:20:41 --> Security Class Initialized
DEBUG - 2020-04-30 16:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:20:41 --> Input Class Initialized
INFO - 2020-04-30 16:20:41 --> Language Class Initialized
INFO - 2020-04-30 16:20:41 --> Loader Class Initialized
INFO - 2020-04-30 16:20:41 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:20:42 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:20:42 --> Helper loaded: data_helper
INFO - 2020-04-30 16:20:42 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:20:42 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:20:42 --> Helper loaded: view_helper
INFO - 2020-04-30 16:20:42 --> Helper loaded: url_helper
INFO - 2020-04-30 16:20:42 --> Database Driver Class Initialized
INFO - 2020-04-30 16:20:42 --> Controller Class Initialized
INFO - 2020-04-30 16:20:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:20:42 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:20:42 --> Plain_Model class loaded
INFO - 2020-04-30 16:20:42 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:20:42 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:20:42 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:20:42 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 16:20:42 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 16:20:42 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 16:20:42 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 16:20:42 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 16:20:42 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 16:20:42 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 16:20:42 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 16:20:42 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 16:20:46 --> Config Class Initialized
INFO - 2020-04-30 16:20:46 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:20:46 --> Hooks Class Initialized
INFO - 2020-04-30 16:20:46 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:20:46 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:20:46 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:20:46 --> Utf8 Class Initialized
INFO - 2020-04-30 16:20:46 --> URI Class Initialized
DEBUG - 2020-04-30 16:20:46 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:20:46 --> Router Class Initialized
INFO - 2020-04-30 16:20:46 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:20:46 --> Output Class Initialized
INFO - 2020-04-30 16:20:46 --> Security Class Initialized
DEBUG - 2020-04-30 16:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:20:46 --> Input Class Initialized
INFO - 2020-04-30 16:20:46 --> Language Class Initialized
INFO - 2020-04-30 16:20:46 --> Loader Class Initialized
INFO - 2020-04-30 16:20:46 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:20:46 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:20:46 --> Helper loaded: data_helper
INFO - 2020-04-30 16:20:46 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:20:46 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:20:46 --> Helper loaded: view_helper
INFO - 2020-04-30 16:20:46 --> Helper loaded: url_helper
INFO - 2020-04-30 16:20:46 --> Database Driver Class Initialized
INFO - 2020-04-30 16:20:46 --> Controller Class Initialized
INFO - 2020-04-30 16:20:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:20:46 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:20:46 --> Plain_Model class loaded
INFO - 2020-04-30 16:20:46 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:20:46 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:20:46 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:20:46 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 16:20:46 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 16:20:46 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 16:20:46 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 16:20:46 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 16:20:46 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 16:20:46 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 16:20:46 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 16:20:46 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 16:36:05 --> Config Class Initialized
INFO - 2020-04-30 16:36:05 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:36:05 --> Hooks Class Initialized
INFO - 2020-04-30 16:36:05 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:36:05 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:36:05 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:36:05 --> Utf8 Class Initialized
INFO - 2020-04-30 16:36:05 --> URI Class Initialized
DEBUG - 2020-04-30 16:36:05 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:36:05 --> Router Class Initialized
INFO - 2020-04-30 16:36:05 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:36:05 --> Output Class Initialized
INFO - 2020-04-30 16:36:05 --> Security Class Initialized
DEBUG - 2020-04-30 16:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:36:05 --> Input Class Initialized
INFO - 2020-04-30 16:36:05 --> Language Class Initialized
INFO - 2020-04-30 16:36:05 --> Loader Class Initialized
INFO - 2020-04-30 16:36:05 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:36:05 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:36:05 --> Helper loaded: data_helper
INFO - 2020-04-30 16:36:05 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:36:05 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:36:05 --> Helper loaded: view_helper
INFO - 2020-04-30 16:36:05 --> Helper loaded: url_helper
INFO - 2020-04-30 16:36:05 --> Database Driver Class Initialized
INFO - 2020-04-30 16:36:05 --> Controller Class Initialized
INFO - 2020-04-30 16:36:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:36:05 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:36:05 --> Plain_Model class loaded
INFO - 2020-04-30 16:36:05 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:36:05 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:36:05 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:36:05 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 16:36:06 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 16:36:06 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 16:36:06 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 16:36:06 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 16:36:06 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 16:36:06 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 16:36:06 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 16:36:06 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 16:47:46 --> Config Class Initialized
INFO - 2020-04-30 16:47:46 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:47:46 --> Hooks Class Initialized
INFO - 2020-04-30 16:47:46 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:47:46 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:47:46 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:47:46 --> Utf8 Class Initialized
INFO - 2020-04-30 16:47:46 --> URI Class Initialized
DEBUG - 2020-04-30 16:47:46 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:47:46 --> Router Class Initialized
INFO - 2020-04-30 16:47:46 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:47:46 --> Output Class Initialized
INFO - 2020-04-30 16:47:46 --> Security Class Initialized
DEBUG - 2020-04-30 16:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:47:46 --> Input Class Initialized
INFO - 2020-04-30 16:47:46 --> Language Class Initialized
INFO - 2020-04-30 16:47:47 --> Loader Class Initialized
INFO - 2020-04-30 16:47:47 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:47:47 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:47:47 --> Helper loaded: data_helper
INFO - 2020-04-30 16:47:47 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:47:47 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:47:47 --> Helper loaded: view_helper
INFO - 2020-04-30 16:47:47 --> Helper loaded: url_helper
INFO - 2020-04-30 16:47:47 --> Database Driver Class Initialized
INFO - 2020-04-30 16:47:47 --> Controller Class Initialized
INFO - 2020-04-30 16:47:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:47:47 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:47:47 --> Plain_Model class loaded
INFO - 2020-04-30 16:47:47 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:47:47 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:47:47 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:47:47 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 16:47:47 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 16:47:47 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 16:47:47 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 16:47:47 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 16:47:47 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 16:47:47 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 16:47:47 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 16:47:47 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 16:52:02 --> Config Class Initialized
INFO - 2020-04-30 16:52:02 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:52:02 --> Hooks Class Initialized
INFO - 2020-04-30 16:52:02 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:52:02 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:52:02 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:52:02 --> Utf8 Class Initialized
INFO - 2020-04-30 16:52:02 --> URI Class Initialized
DEBUG - 2020-04-30 16:52:02 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:52:02 --> Router Class Initialized
INFO - 2020-04-30 16:52:02 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:52:02 --> Output Class Initialized
INFO - 2020-04-30 16:52:02 --> Security Class Initialized
DEBUG - 2020-04-30 16:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:52:02 --> Input Class Initialized
INFO - 2020-04-30 16:52:02 --> Language Class Initialized
INFO - 2020-04-30 16:52:02 --> Loader Class Initialized
INFO - 2020-04-30 16:52:03 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:52:03 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:52:03 --> Helper loaded: data_helper
INFO - 2020-04-30 16:52:03 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:52:03 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:52:03 --> Helper loaded: view_helper
INFO - 2020-04-30 16:52:03 --> Helper loaded: url_helper
INFO - 2020-04-30 16:52:03 --> Database Driver Class Initialized
INFO - 2020-04-30 16:52:03 --> Controller Class Initialized
INFO - 2020-04-30 16:52:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:52:03 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:52:03 --> Plain_Model class loaded
INFO - 2020-04-30 16:52:03 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:52:03 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:52:03 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:52:03 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 16:52:03 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 16:52:03 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 16:52:03 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 16:52:03 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 16:52:03 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 16:52:03 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 16:52:03 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 16:52:03 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 16:52:20 --> Config Class Initialized
INFO - 2020-04-30 16:52:20 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:52:20 --> Hooks Class Initialized
INFO - 2020-04-30 16:52:20 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:52:20 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:52:20 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:52:20 --> Utf8 Class Initialized
INFO - 2020-04-30 16:52:20 --> URI Class Initialized
DEBUG - 2020-04-30 16:52:20 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:52:20 --> Router Class Initialized
INFO - 2020-04-30 16:52:20 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:52:20 --> Output Class Initialized
INFO - 2020-04-30 16:52:20 --> Security Class Initialized
DEBUG - 2020-04-30 16:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:52:20 --> Input Class Initialized
INFO - 2020-04-30 16:52:20 --> Language Class Initialized
INFO - 2020-04-30 16:52:20 --> Loader Class Initialized
INFO - 2020-04-30 16:52:20 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:52:20 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:52:20 --> Helper loaded: data_helper
INFO - 2020-04-30 16:52:20 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:52:20 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:52:21 --> Helper loaded: view_helper
INFO - 2020-04-30 16:52:21 --> Helper loaded: url_helper
INFO - 2020-04-30 16:52:21 --> Database Driver Class Initialized
INFO - 2020-04-30 16:52:21 --> Controller Class Initialized
INFO - 2020-04-30 16:52:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:52:21 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:52:21 --> Plain_Model class loaded
INFO - 2020-04-30 16:52:21 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:52:21 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:52:21 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:52:21 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 16:52:21 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 16:52:21 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 16:52:21 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 16:52:21 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 16:52:21 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 16:52:21 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 16:52:21 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 16:52:21 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 16:52:28 --> Config Class Initialized
INFO - 2020-04-30 16:52:28 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:52:28 --> Hooks Class Initialized
INFO - 2020-04-30 16:52:28 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:52:28 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:52:28 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:52:28 --> Utf8 Class Initialized
INFO - 2020-04-30 16:52:28 --> URI Class Initialized
DEBUG - 2020-04-30 16:52:28 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:52:28 --> Router Class Initialized
INFO - 2020-04-30 16:52:28 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:52:28 --> Output Class Initialized
INFO - 2020-04-30 16:52:28 --> Security Class Initialized
DEBUG - 2020-04-30 16:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:52:28 --> Input Class Initialized
INFO - 2020-04-30 16:52:28 --> Language Class Initialized
INFO - 2020-04-30 16:52:28 --> Loader Class Initialized
INFO - 2020-04-30 16:52:28 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:52:28 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:52:28 --> Helper loaded: data_helper
INFO - 2020-04-30 16:52:28 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:52:28 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:52:28 --> Helper loaded: view_helper
INFO - 2020-04-30 16:52:28 --> Helper loaded: url_helper
INFO - 2020-04-30 16:52:28 --> Database Driver Class Initialized
INFO - 2020-04-30 16:52:28 --> Controller Class Initialized
INFO - 2020-04-30 16:52:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:52:28 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:52:29 --> Plain_Model class loaded
INFO - 2020-04-30 16:52:29 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:52:29 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:52:29 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:52:29 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 16:52:29 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 16:52:29 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 16:52:29 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 16:52:29 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 16:52:29 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 16:52:29 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 16:52:29 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 16:52:29 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 16:52:48 --> Config Class Initialized
INFO - 2020-04-30 16:52:48 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:52:48 --> Hooks Class Initialized
INFO - 2020-04-30 16:52:48 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:52:48 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:52:48 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:52:48 --> Utf8 Class Initialized
INFO - 2020-04-30 16:52:48 --> URI Class Initialized
DEBUG - 2020-04-30 16:52:48 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:52:48 --> Router Class Initialized
INFO - 2020-04-30 16:52:48 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:52:48 --> Output Class Initialized
INFO - 2020-04-30 16:52:48 --> Security Class Initialized
DEBUG - 2020-04-30 16:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:52:48 --> Input Class Initialized
INFO - 2020-04-30 16:52:48 --> Language Class Initialized
INFO - 2020-04-30 16:52:48 --> Loader Class Initialized
INFO - 2020-04-30 16:52:49 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:52:49 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:52:49 --> Helper loaded: data_helper
INFO - 2020-04-30 16:52:49 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:52:49 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:52:49 --> Helper loaded: view_helper
INFO - 2020-04-30 16:52:49 --> Helper loaded: url_helper
INFO - 2020-04-30 16:52:49 --> Database Driver Class Initialized
INFO - 2020-04-30 16:52:49 --> Controller Class Initialized
INFO - 2020-04-30 16:52:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:52:49 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:52:49 --> Plain_Model class loaded
INFO - 2020-04-30 16:52:49 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:52:49 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:52:49 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:52:49 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 16:52:49 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 16:52:49 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 16:52:49 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 16:52:49 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 16:52:49 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 16:52:49 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 16:52:49 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 16:52:49 --> Plain_Exceptions Class Initialized
INFO - 2020-04-30 16:58:55 --> Config Class Initialized
INFO - 2020-04-30 16:58:55 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:58:55 --> Hooks Class Initialized
INFO - 2020-04-30 16:58:55 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:58:55 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:58:55 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:58:55 --> Utf8 Class Initialized
INFO - 2020-04-30 16:58:55 --> URI Class Initialized
DEBUG - 2020-04-30 16:58:55 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:58:55 --> Router Class Initialized
INFO - 2020-04-30 16:58:55 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:58:55 --> Output Class Initialized
INFO - 2020-04-30 16:58:55 --> Security Class Initialized
DEBUG - 2020-04-30 16:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:58:55 --> Input Class Initialized
INFO - 2020-04-30 16:58:55 --> Language Class Initialized
INFO - 2020-04-30 16:58:56 --> Loader Class Initialized
INFO - 2020-04-30 16:58:56 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:58:56 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:58:56 --> Helper loaded: data_helper
INFO - 2020-04-30 16:58:56 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:58:56 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:58:56 --> Helper loaded: view_helper
INFO - 2020-04-30 16:58:56 --> Helper loaded: url_helper
INFO - 2020-04-30 16:58:56 --> Database Driver Class Initialized
INFO - 2020-04-30 16:58:56 --> Controller Class Initialized
INFO - 2020-04-30 16:58:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:58:56 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:58:56 --> Plain_Model class loaded
INFO - 2020-04-30 16:58:56 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:58:56 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:58:56 --> Model "Labels_model" initialized
INFO - 2020-04-30 16:58:56 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 16:58:56 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 16:58:56 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 16:58:56 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 16:58:56 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-04-30 16:58:56 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-04-30 16:58:56 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-04-30 16:58:56 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 16:58:56 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-04-30 16:58:56 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-04-30 16:58:56 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-04-30 16:58:56 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-04-30 16:58:56 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-04-30 16:58:56 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-04-30 16:58:56 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-04-30 16:58:56 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-04-30 16:58:56 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-04-30 16:58:56 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-04-30 16:58:56 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-04-30 16:58:56 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-04-30 16:58:56 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-04-30 16:58:56 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-04-30 16:58:56 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-04-30 16:58:56 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-04-30 16:58:56 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-04-30 16:58:56 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-04-30 16:58:56 --> Final output sent to browser
DEBUG - 2020-04-30 16:58:56 --> Total execution time: 0.9713
INFO - 2020-04-30 16:58:58 --> Config Class Initialized
INFO - 2020-04-30 16:58:58 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:58:58 --> Hooks Class Initialized
INFO - 2020-04-30 16:58:58 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:58:58 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:58:58 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:58:58 --> Utf8 Class Initialized
INFO - 2020-04-30 16:58:58 --> URI Class Initialized
DEBUG - 2020-04-30 16:58:58 --> Validating request for /controllers/Custom.php
INFO - 2020-04-30 16:58:58 --> Plain_Exceptions Class Initialized
ERROR - 2020-04-30 16:58:58 --> 404 Page Not Found: custom
INFO - 2020-04-30 16:59:32 --> Config Class Initialized
INFO - 2020-04-30 16:59:33 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:59:33 --> Hooks Class Initialized
INFO - 2020-04-30 16:59:33 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:59:33 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:59:33 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:59:33 --> Utf8 Class Initialized
INFO - 2020-04-30 16:59:33 --> URI Class Initialized
DEBUG - 2020-04-30 16:59:33 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:59:33 --> Router Class Initialized
INFO - 2020-04-30 16:59:33 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:59:33 --> Output Class Initialized
INFO - 2020-04-30 16:59:33 --> Security Class Initialized
DEBUG - 2020-04-30 16:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:59:33 --> Input Class Initialized
INFO - 2020-04-30 16:59:33 --> Language Class Initialized
INFO - 2020-04-30 16:59:33 --> Loader Class Initialized
INFO - 2020-04-30 16:59:33 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:59:33 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:59:33 --> Helper loaded: data_helper
INFO - 2020-04-30 16:59:33 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:59:33 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:59:33 --> Helper loaded: view_helper
INFO - 2020-04-30 16:59:33 --> Helper loaded: url_helper
INFO - 2020-04-30 16:59:33 --> Database Driver Class Initialized
INFO - 2020-04-30 16:59:33 --> Controller Class Initialized
INFO - 2020-04-30 16:59:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:59:33 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:59:33 --> Plain_Model class loaded
INFO - 2020-04-30 16:59:33 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:59:33 --> The "english" language file has been loaded.
DEBUG - 2020-04-30 16:59:33 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-04-30 16:59:33 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-04-30 16:59:33 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-04-30 16:59:33 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-04-30 16:59:33 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-04-30 16:59:33 --> Final output sent to browser
DEBUG - 2020-04-30 16:59:33 --> Total execution time: 0.5607
INFO - 2020-04-30 16:59:34 --> Config Class Initialized
INFO - 2020-04-30 16:59:34 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:59:34 --> Hooks Class Initialized
INFO - 2020-04-30 16:59:34 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:59:34 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:59:34 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:59:34 --> Utf8 Class Initialized
INFO - 2020-04-30 16:59:34 --> URI Class Initialized
DEBUG - 2020-04-30 16:59:34 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:59:34 --> Router Class Initialized
INFO - 2020-04-30 16:59:34 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:59:34 --> Output Class Initialized
INFO - 2020-04-30 16:59:34 --> Security Class Initialized
DEBUG - 2020-04-30 16:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:59:34 --> Input Class Initialized
INFO - 2020-04-30 16:59:34 --> Language Class Initialized
INFO - 2020-04-30 16:59:34 --> Loader Class Initialized
INFO - 2020-04-30 16:59:34 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:59:35 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:59:35 --> Helper loaded: data_helper
INFO - 2020-04-30 16:59:35 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:59:35 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:59:35 --> Helper loaded: view_helper
INFO - 2020-04-30 16:59:35 --> Helper loaded: url_helper
INFO - 2020-04-30 16:59:35 --> Database Driver Class Initialized
INFO - 2020-04-30 16:59:35 --> Controller Class Initialized
INFO - 2020-04-30 16:59:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:59:35 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:59:35 --> Plain_Model class loaded
INFO - 2020-04-30 16:59:35 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:59:35 --> The "english" language file has been loaded.
DEBUG - 2020-04-30 16:59:35 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-04-30 16:59:35 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-04-30 16:59:35 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-04-30 16:59:35 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-04-30 16:59:35 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-04-30 16:59:35 --> Final output sent to browser
DEBUG - 2020-04-30 16:59:35 --> Total execution time: 0.5552
INFO - 2020-04-30 16:59:36 --> Config Class Initialized
INFO - 2020-04-30 16:59:36 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:59:36 --> Hooks Class Initialized
INFO - 2020-04-30 16:59:36 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:59:36 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:59:36 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:59:36 --> Utf8 Class Initialized
INFO - 2020-04-30 16:59:36 --> URI Class Initialized
DEBUG - 2020-04-30 16:59:36 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:59:36 --> Router Class Initialized
INFO - 2020-04-30 16:59:36 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:59:36 --> Output Class Initialized
INFO - 2020-04-30 16:59:36 --> Security Class Initialized
DEBUG - 2020-04-30 16:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:59:36 --> Input Class Initialized
INFO - 2020-04-30 16:59:36 --> Language Class Initialized
INFO - 2020-04-30 16:59:36 --> Loader Class Initialized
INFO - 2020-04-30 16:59:36 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:59:36 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:59:36 --> Helper loaded: data_helper
INFO - 2020-04-30 16:59:36 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:59:36 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:59:36 --> Helper loaded: view_helper
INFO - 2020-04-30 16:59:36 --> Helper loaded: url_helper
INFO - 2020-04-30 16:59:36 --> Database Driver Class Initialized
INFO - 2020-04-30 16:59:36 --> Controller Class Initialized
INFO - 2020-04-30 16:59:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:59:36 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:59:36 --> Plain_Model class loaded
INFO - 2020-04-30 16:59:36 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:59:36 --> The "english" language file has been loaded.
INFO - 2020-04-30 16:59:36 --> Model "Labels_model" initialized
DEBUG - 2020-04-30 16:59:36 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-04-30 16:59:36 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-04-30 16:59:36 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-04-30 16:59:36 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-04-30 16:59:36 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-04-30 16:59:36 --> Final output sent to browser
DEBUG - 2020-04-30 16:59:36 --> Total execution time: 0.4418
INFO - 2020-04-30 16:59:38 --> Config Class Initialized
INFO - 2020-04-30 16:59:38 --> Plain_Config Class Initialized
INFO - 2020-04-30 16:59:38 --> Hooks Class Initialized
INFO - 2020-04-30 16:59:38 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 16:59:38 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 16:59:38 --> UTF-8 Support Disabled
INFO - 2020-04-30 16:59:38 --> Utf8 Class Initialized
INFO - 2020-04-30 16:59:38 --> URI Class Initialized
DEBUG - 2020-04-30 16:59:38 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 16:59:38 --> Router Class Initialized
INFO - 2020-04-30 16:59:38 --> Plain_Router Class Initialized
INFO - 2020-04-30 16:59:38 --> Output Class Initialized
INFO - 2020-04-30 16:59:38 --> Security Class Initialized
DEBUG - 2020-04-30 16:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 16:59:38 --> Input Class Initialized
INFO - 2020-04-30 16:59:38 --> Language Class Initialized
INFO - 2020-04-30 16:59:38 --> Loader Class Initialized
INFO - 2020-04-30 16:59:38 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 16:59:38 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 16:59:38 --> Helper loaded: data_helper
INFO - 2020-04-30 16:59:38 --> Helper loaded: hash_helper
INFO - 2020-04-30 16:59:38 --> Helper loaded: validation_helper
INFO - 2020-04-30 16:59:38 --> Helper loaded: view_helper
INFO - 2020-04-30 16:59:38 --> Helper loaded: url_helper
INFO - 2020-04-30 16:59:38 --> Database Driver Class Initialized
INFO - 2020-04-30 16:59:38 --> Controller Class Initialized
INFO - 2020-04-30 16:59:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 16:59:38 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 16:59:38 --> Plain_Model class loaded
INFO - 2020-04-30 16:59:38 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 16:59:38 --> The "english" language file has been loaded.
DEBUG - 2020-04-30 16:59:38 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-04-30 16:59:38 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-04-30 16:59:38 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-04-30 16:59:38 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-04-30 16:59:38 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-04-30 16:59:38 --> Final output sent to browser
DEBUG - 2020-04-30 16:59:38 --> Total execution time: 0.5021
INFO - 2020-04-30 17:22:27 --> Config Class Initialized
INFO - 2020-04-30 17:22:27 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:22:27 --> Hooks Class Initialized
INFO - 2020-04-30 17:22:27 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:22:27 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:22:27 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:22:27 --> Utf8 Class Initialized
INFO - 2020-04-30 17:22:27 --> URI Class Initialized
DEBUG - 2020-04-30 17:22:27 --> Validating request for /controllers/Import.php
INFO - 2020-04-30 17:22:27 --> Router Class Initialized
INFO - 2020-04-30 17:22:27 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:22:27 --> Output Class Initialized
INFO - 2020-04-30 17:22:27 --> Security Class Initialized
DEBUG - 2020-04-30 17:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:22:27 --> Input Class Initialized
INFO - 2020-04-30 17:22:28 --> Language Class Initialized
INFO - 2020-04-30 17:22:28 --> Loader Class Initialized
INFO - 2020-04-30 17:22:28 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:22:28 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:22:28 --> Helper loaded: data_helper
INFO - 2020-04-30 17:22:28 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:22:28 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:22:28 --> Helper loaded: view_helper
INFO - 2020-04-30 17:22:28 --> Helper loaded: url_helper
INFO - 2020-04-30 17:22:28 --> Database Driver Class Initialized
INFO - 2020-04-30 17:22:28 --> Controller Class Initialized
INFO - 2020-04-30 17:22:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:22:28 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-04-30 17:22:28 --> The "english" language file has been loaded.
INFO - 2020-04-30 17:22:28 --> Plain_Model class loaded
INFO - 2020-04-30 17:22:28 --> Model "Marks_model" initialized
INFO - 2020-04-30 17:22:28 --> Model "Users_To_Marks_model" initialized
INFO - 2020-04-30 17:22:28 --> Model "Labels_model" initialized
INFO - 2020-04-30 17:22:30 --> Model "Tags_model" initialized
INFO - 2020-04-30 17:22:30 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 17:22:43 --> The phrase "Unmark : Importer" could not be found in the language file.
DEBUG - 2020-04-30 17:22:43 --> The phrase "Successful Upload!" could not be found in the language file.
DEBUG - 2020-04-30 17:22:43 --> The phrase "%s marks added" could not be found in the language file.
DEBUG - 2020-04-30 17:22:43 --> The phrase "%s marks skipped" could not be found in the language file.
DEBUG - 2020-04-30 17:22:43 --> The phrase "%s marks failed" could not be found in the language file.
DEBUG - 2020-04-30 17:22:43 --> The phrase "%s marks total" could not be found in the language file.
DEBUG - 2020-04-30 17:22:43 --> The phrase "<a href='/' class="back-button"> Go back & see them</a>" could not be found in the language file.
INFO - 2020-04-30 17:22:43 --> File loaded: /var/www/html/application/views/import/index.php
INFO - 2020-04-30 17:22:43 --> Final output sent to browser
DEBUG - 2020-04-30 17:22:43 --> Total execution time: 15.7177
INFO - 2020-04-30 17:22:44 --> Config Class Initialized
INFO - 2020-04-30 17:22:44 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:22:44 --> Hooks Class Initialized
INFO - 2020-04-30 17:22:44 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:22:44 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:22:44 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:22:44 --> Utf8 Class Initialized
INFO - 2020-04-30 17:22:44 --> URI Class Initialized
DEBUG - 2020-04-30 17:22:44 --> Validating request for /controllers/Custom.php
INFO - 2020-04-30 17:22:44 --> Plain_Exceptions Class Initialized
ERROR - 2020-04-30 17:22:44 --> 404 Page Not Found: custom
INFO - 2020-04-30 17:22:55 --> Config Class Initialized
INFO - 2020-04-30 17:22:55 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:22:55 --> Hooks Class Initialized
INFO - 2020-04-30 17:22:55 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:22:55 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:22:55 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:22:55 --> Utf8 Class Initialized
INFO - 2020-04-30 17:22:55 --> URI Class Initialized
DEBUG - 2020-04-30 17:22:55 --> No URI present. Default controller set.
INFO - 2020-04-30 17:22:55 --> Router Class Initialized
INFO - 2020-04-30 17:22:55 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:22:55 --> Output Class Initialized
INFO - 2020-04-30 17:22:55 --> Security Class Initialized
DEBUG - 2020-04-30 17:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:22:55 --> Input Class Initialized
INFO - 2020-04-30 17:22:55 --> Language Class Initialized
INFO - 2020-04-30 17:22:55 --> Loader Class Initialized
INFO - 2020-04-30 17:22:55 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:22:55 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:22:55 --> Helper loaded: data_helper
INFO - 2020-04-30 17:22:55 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:22:55 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:22:55 --> Helper loaded: view_helper
INFO - 2020-04-30 17:22:55 --> Helper loaded: url_helper
INFO - 2020-04-30 17:22:55 --> Database Driver Class Initialized
INFO - 2020-04-30 17:22:55 --> Controller Class Initialized
INFO - 2020-04-30 17:22:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:22:55 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-04-30 17:22:55 --> The "english" language file has been loaded.
INFO - 2020-04-30 17:22:55 --> Config Class Initialized
INFO - 2020-04-30 17:22:55 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:22:55 --> Hooks Class Initialized
INFO - 2020-04-30 17:22:55 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:22:55 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:22:55 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:22:55 --> Utf8 Class Initialized
INFO - 2020-04-30 17:22:56 --> URI Class Initialized
DEBUG - 2020-04-30 17:22:56 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 17:22:56 --> Router Class Initialized
INFO - 2020-04-30 17:22:56 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:22:56 --> Output Class Initialized
INFO - 2020-04-30 17:22:56 --> Security Class Initialized
DEBUG - 2020-04-30 17:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:22:56 --> Input Class Initialized
INFO - 2020-04-30 17:22:56 --> Language Class Initialized
INFO - 2020-04-30 17:22:56 --> Loader Class Initialized
INFO - 2020-04-30 17:22:56 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:22:56 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:22:56 --> Helper loaded: data_helper
INFO - 2020-04-30 17:22:56 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:22:56 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:22:56 --> Helper loaded: view_helper
INFO - 2020-04-30 17:22:56 --> Helper loaded: url_helper
INFO - 2020-04-30 17:22:56 --> Database Driver Class Initialized
INFO - 2020-04-30 17:22:56 --> Controller Class Initialized
INFO - 2020-04-30 17:22:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:22:56 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:22:56 --> Plain_Model class loaded
INFO - 2020-04-30 17:22:56 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 17:22:56 --> The "english" language file has been loaded.
INFO - 2020-04-30 17:22:56 --> Model "Labels_model" initialized
INFO - 2020-04-30 17:22:56 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 17:22:56 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-04-30 17:22:56 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-04-30 17:22:56 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-04-30 17:22:56 --> The phrase "Recently-Used Tags" could not be found in the language file.
INFO - 2020-04-30 17:22:56 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-04-30 17:22:56 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-04-30 17:22:56 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-04-30 17:22:56 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-04-30 17:22:56 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-04-30 17:22:56 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-04-30 17:22:56 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-04-30 17:22:56 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-04-30 17:22:56 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-04-30 17:22:56 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-04-30 17:22:56 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-04-30 17:22:56 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-04-30 17:22:56 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-04-30 17:22:56 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-04-30 17:22:56 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-04-30 17:22:56 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-04-30 17:22:56 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-04-30 17:22:56 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-04-30 17:22:56 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-04-30 17:22:56 --> Final output sent to browser
DEBUG - 2020-04-30 17:22:56 --> Total execution time: 0.8023
INFO - 2020-04-30 17:22:57 --> Config Class Initialized
INFO - 2020-04-30 17:22:57 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:22:57 --> Hooks Class Initialized
INFO - 2020-04-30 17:22:57 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:22:57 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:22:57 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:22:57 --> Utf8 Class Initialized
INFO - 2020-04-30 17:22:58 --> URI Class Initialized
DEBUG - 2020-04-30 17:22:58 --> Validating request for /controllers/Custom.php
INFO - 2020-04-30 17:22:58 --> Plain_Exceptions Class Initialized
ERROR - 2020-04-30 17:22:58 --> 404 Page Not Found: custom
INFO - 2020-04-30 17:23:03 --> Config Class Initialized
INFO - 2020-04-30 17:23:03 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:23:03 --> Hooks Class Initialized
INFO - 2020-04-30 17:23:03 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:23:04 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:23:04 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:23:04 --> Utf8 Class Initialized
INFO - 2020-04-30 17:23:04 --> URI Class Initialized
DEBUG - 2020-04-30 17:23:04 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 17:23:04 --> Router Class Initialized
INFO - 2020-04-30 17:23:04 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:23:04 --> Output Class Initialized
INFO - 2020-04-30 17:23:04 --> Security Class Initialized
DEBUG - 2020-04-30 17:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:23:04 --> Input Class Initialized
INFO - 2020-04-30 17:23:04 --> Language Class Initialized
INFO - 2020-04-30 17:23:04 --> Loader Class Initialized
INFO - 2020-04-30 17:23:04 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:23:04 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:23:04 --> Helper loaded: data_helper
INFO - 2020-04-30 17:23:04 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:23:04 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:23:04 --> Helper loaded: view_helper
INFO - 2020-04-30 17:23:04 --> Helper loaded: url_helper
INFO - 2020-04-30 17:23:04 --> Database Driver Class Initialized
INFO - 2020-04-30 17:23:04 --> Controller Class Initialized
INFO - 2020-04-30 17:23:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:23:04 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:23:04 --> Plain_Model class loaded
INFO - 2020-04-30 17:23:04 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 17:23:04 --> The "english" language file has been loaded.
DEBUG - 2020-04-30 17:23:04 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-04-30 17:23:04 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-04-30 17:23:04 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-04-30 17:23:04 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-04-30 17:23:04 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-04-30 17:23:04 --> Final output sent to browser
DEBUG - 2020-04-30 17:23:04 --> Total execution time: 0.4654
INFO - 2020-04-30 17:24:46 --> Config Class Initialized
INFO - 2020-04-30 17:24:46 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:24:46 --> Hooks Class Initialized
INFO - 2020-04-30 17:24:46 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:24:46 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:24:46 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:24:46 --> Utf8 Class Initialized
INFO - 2020-04-30 17:24:46 --> URI Class Initialized
DEBUG - 2020-04-30 17:24:46 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 17:24:46 --> Router Class Initialized
INFO - 2020-04-30 17:24:46 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:24:46 --> Output Class Initialized
INFO - 2020-04-30 17:24:46 --> Security Class Initialized
DEBUG - 2020-04-30 17:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:24:46 --> Input Class Initialized
INFO - 2020-04-30 17:24:46 --> Language Class Initialized
INFO - 2020-04-30 17:24:46 --> Loader Class Initialized
INFO - 2020-04-30 17:24:46 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:24:46 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:24:46 --> Helper loaded: data_helper
INFO - 2020-04-30 17:24:46 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:24:46 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:24:46 --> Helper loaded: view_helper
INFO - 2020-04-30 17:24:46 --> Helper loaded: url_helper
INFO - 2020-04-30 17:24:46 --> Database Driver Class Initialized
INFO - 2020-04-30 17:24:46 --> Controller Class Initialized
INFO - 2020-04-30 17:24:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:24:46 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:24:46 --> Plain_Model class loaded
INFO - 2020-04-30 17:24:46 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 17:24:46 --> The "english" language file has been loaded.
INFO - 2020-04-30 17:24:46 --> Helper loaded: http_build_url_helper
INFO - 2020-04-30 17:24:46 --> Model "Marks_model" initialized
INFO - 2020-04-30 17:24:46 --> Model "Labels_model" initialized
DEBUG - 2020-04-30 17:24:46 --> The phrase "Just Now" could not be found in the language file.
INFO - 2020-04-30 17:24:46 --> Config Class Initialized
INFO - 2020-04-30 17:24:46 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:24:46 --> Hooks Class Initialized
INFO - 2020-04-30 17:24:47 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:24:47 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:24:47 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:24:47 --> Utf8 Class Initialized
INFO - 2020-04-30 17:24:47 --> URI Class Initialized
DEBUG - 2020-04-30 17:24:47 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 17:24:47 --> Router Class Initialized
INFO - 2020-04-30 17:24:47 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:24:47 --> Output Class Initialized
INFO - 2020-04-30 17:24:47 --> Security Class Initialized
DEBUG - 2020-04-30 17:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:24:47 --> Input Class Initialized
INFO - 2020-04-30 17:24:47 --> Language Class Initialized
INFO - 2020-04-30 17:24:47 --> Loader Class Initialized
INFO - 2020-04-30 17:24:47 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:24:47 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:24:47 --> Helper loaded: data_helper
INFO - 2020-04-30 17:24:47 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:24:47 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:24:47 --> Helper loaded: view_helper
INFO - 2020-04-30 17:24:47 --> Helper loaded: url_helper
INFO - 2020-04-30 17:24:47 --> Database Driver Class Initialized
INFO - 2020-04-30 17:24:47 --> Controller Class Initialized
INFO - 2020-04-30 17:24:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:24:47 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:24:47 --> Plain_Model class loaded
INFO - 2020-04-30 17:24:47 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 17:24:47 --> The "english" language file has been loaded.
INFO - 2020-04-30 17:24:47 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 17:24:47 --> The phrase "Unmark : Mark Added" could not be found in the language file.
DEBUG - 2020-04-30 17:24:47 --> The phrase "This mark has been added to your stream." could not be found in the language file.
DEBUG - 2020-04-30 17:24:47 --> The phrase "Add a Note or Edit Title" could not be found in the language file.
DEBUG - 2020-04-30 17:24:47 --> The phrase "Type note text here..." could not be found in the language file.
DEBUG - 2020-04-30 17:24:47 --> The phrase "Delete Link" could not be found in the language file.
DEBUG - 2020-04-30 17:24:47 --> The phrase "Update &amp; Close" could not be found in the language file.
INFO - 2020-04-30 17:24:47 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-04-30 17:24:47 --> File loaded: /var/www/html/application/views/marks/info.php
INFO - 2020-04-30 17:24:47 --> Final output sent to browser
DEBUG - 2020-04-30 17:24:47 --> Total execution time: 0.5286
INFO - 2020-04-30 17:24:48 --> Config Class Initialized
INFO - 2020-04-30 17:24:48 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:24:48 --> Hooks Class Initialized
INFO - 2020-04-30 17:24:48 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:24:48 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:24:48 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:24:48 --> Utf8 Class Initialized
INFO - 2020-04-30 17:24:48 --> URI Class Initialized
DEBUG - 2020-04-30 17:24:48 --> Validating request for /controllers/Tags.php
INFO - 2020-04-30 17:24:48 --> Router Class Initialized
INFO - 2020-04-30 17:24:48 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:24:48 --> Output Class Initialized
INFO - 2020-04-30 17:24:48 --> Security Class Initialized
DEBUG - 2020-04-30 17:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:24:48 --> Input Class Initialized
INFO - 2020-04-30 17:24:48 --> Language Class Initialized
INFO - 2020-04-30 17:24:48 --> Loader Class Initialized
INFO - 2020-04-30 17:24:48 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:24:48 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:24:48 --> Helper loaded: data_helper
INFO - 2020-04-30 17:24:48 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:24:48 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:24:48 --> Helper loaded: view_helper
INFO - 2020-04-30 17:24:48 --> Helper loaded: url_helper
INFO - 2020-04-30 17:24:48 --> Database Driver Class Initialized
INFO - 2020-04-30 17:24:48 --> Controller Class Initialized
INFO - 2020-04-30 17:24:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:24:48 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:24:48 --> Plain_Model class loaded
INFO - 2020-04-30 17:24:48 --> Model "Tags_model" initialized
DEBUG - 2020-04-30 17:24:48 --> The "english" language file has been loaded.
INFO - 2020-04-30 17:24:48 --> Model "User_Marks_To_Tags_model" initialized
INFO - 2020-04-30 17:24:48 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-04-30 17:24:48 --> Final output sent to browser
DEBUG - 2020-04-30 17:24:48 --> Total execution time: 0.4034
INFO - 2020-04-30 17:24:48 --> Config Class Initialized
INFO - 2020-04-30 17:24:48 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:24:48 --> Hooks Class Initialized
INFO - 2020-04-30 17:24:48 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:24:48 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:24:48 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:24:48 --> Utf8 Class Initialized
INFO - 2020-04-30 17:24:48 --> URI Class Initialized
DEBUG - 2020-04-30 17:24:48 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 17:24:48 --> Router Class Initialized
INFO - 2020-04-30 17:24:48 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:24:48 --> Output Class Initialized
INFO - 2020-04-30 17:24:48 --> Security Class Initialized
DEBUG - 2020-04-30 17:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:24:48 --> Input Class Initialized
INFO - 2020-04-30 17:24:48 --> Language Class Initialized
INFO - 2020-04-30 17:24:48 --> Loader Class Initialized
INFO - 2020-04-30 17:24:48 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:24:48 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:24:48 --> Helper loaded: data_helper
INFO - 2020-04-30 17:24:48 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:24:48 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:24:48 --> Helper loaded: view_helper
INFO - 2020-04-30 17:24:48 --> Helper loaded: url_helper
INFO - 2020-04-30 17:24:48 --> Database Driver Class Initialized
INFO - 2020-04-30 17:24:48 --> Controller Class Initialized
INFO - 2020-04-30 17:24:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:24:48 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:24:48 --> Plain_Model class loaded
INFO - 2020-04-30 17:24:48 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 17:24:48 --> The "english" language file has been loaded.
DEBUG - 2020-04-30 17:24:48 --> Running get method for labels
INFO - 2020-04-30 17:24:48 --> Model "Labels_model" initialized
INFO - 2020-04-30 17:24:49 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-04-30 17:24:49 --> Final output sent to browser
DEBUG - 2020-04-30 17:24:49 --> Total execution time: 0.3531
INFO - 2020-04-30 17:32:16 --> Config Class Initialized
INFO - 2020-04-30 17:32:16 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:32:16 --> Hooks Class Initialized
INFO - 2020-04-30 17:32:16 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:32:16 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:32:16 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:32:16 --> Utf8 Class Initialized
INFO - 2020-04-30 17:32:16 --> URI Class Initialized
DEBUG - 2020-04-30 17:32:16 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 17:32:16 --> Router Class Initialized
INFO - 2020-04-30 17:32:16 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:32:16 --> Output Class Initialized
INFO - 2020-04-30 17:32:16 --> Security Class Initialized
DEBUG - 2020-04-30 17:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:32:16 --> Input Class Initialized
INFO - 2020-04-30 17:32:16 --> Language Class Initialized
INFO - 2020-04-30 17:32:16 --> Loader Class Initialized
INFO - 2020-04-30 17:32:16 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:32:16 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:32:16 --> Helper loaded: data_helper
INFO - 2020-04-30 17:32:16 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:32:16 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:32:16 --> Helper loaded: view_helper
INFO - 2020-04-30 17:32:16 --> Helper loaded: url_helper
INFO - 2020-04-30 17:32:16 --> Database Driver Class Initialized
INFO - 2020-04-30 17:32:16 --> Controller Class Initialized
INFO - 2020-04-30 17:32:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:32:16 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:32:17 --> Plain_Model class loaded
INFO - 2020-04-30 17:32:17 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 17:32:17 --> The "english" language file has been loaded.
INFO - 2020-04-30 17:32:17 --> Helper loaded: http_build_url_helper
INFO - 2020-04-30 17:32:17 --> Model "Marks_model" initialized
INFO - 2020-04-30 17:32:17 --> Config Class Initialized
INFO - 2020-04-30 17:32:17 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:32:17 --> Hooks Class Initialized
INFO - 2020-04-30 17:32:17 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:32:17 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:32:17 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:32:17 --> Utf8 Class Initialized
INFO - 2020-04-30 17:32:17 --> URI Class Initialized
DEBUG - 2020-04-30 17:32:17 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 17:32:17 --> Router Class Initialized
INFO - 2020-04-30 17:32:17 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:32:17 --> Output Class Initialized
INFO - 2020-04-30 17:32:17 --> Security Class Initialized
DEBUG - 2020-04-30 17:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:32:17 --> Input Class Initialized
INFO - 2020-04-30 17:32:17 --> Language Class Initialized
INFO - 2020-04-30 17:32:17 --> Loader Class Initialized
INFO - 2020-04-30 17:32:17 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:32:17 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:32:17 --> Helper loaded: data_helper
INFO - 2020-04-30 17:32:17 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:32:17 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:32:17 --> Helper loaded: view_helper
INFO - 2020-04-30 17:32:17 --> Helper loaded: url_helper
INFO - 2020-04-30 17:32:17 --> Database Driver Class Initialized
INFO - 2020-04-30 17:32:17 --> Controller Class Initialized
INFO - 2020-04-30 17:32:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:32:17 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:32:17 --> Plain_Model class loaded
INFO - 2020-04-30 17:32:17 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 17:32:17 --> The "english" language file has been loaded.
INFO - 2020-04-30 17:32:17 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 17:32:17 --> The phrase "Unmark : Mark Added" could not be found in the language file.
DEBUG - 2020-04-30 17:32:17 --> The phrase "This mark has been added to your stream." could not be found in the language file.
DEBUG - 2020-04-30 17:32:17 --> The phrase "Add a Note or Edit Title" could not be found in the language file.
DEBUG - 2020-04-30 17:32:17 --> The phrase "Type note text here..." could not be found in the language file.
DEBUG - 2020-04-30 17:32:17 --> The phrase "Delete Link" could not be found in the language file.
DEBUG - 2020-04-30 17:32:17 --> The phrase "Update &amp; Close" could not be found in the language file.
INFO - 2020-04-30 17:32:17 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-04-30 17:32:17 --> File loaded: /var/www/html/application/views/marks/info.php
INFO - 2020-04-30 17:32:17 --> Final output sent to browser
DEBUG - 2020-04-30 17:32:17 --> Total execution time: 0.4564
INFO - 2020-04-30 17:32:18 --> Config Class Initialized
INFO - 2020-04-30 17:32:18 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:32:18 --> Hooks Class Initialized
INFO - 2020-04-30 17:32:18 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:32:18 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:32:18 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:32:18 --> Utf8 Class Initialized
INFO - 2020-04-30 17:32:18 --> URI Class Initialized
DEBUG - 2020-04-30 17:32:18 --> Validating request for /controllers/Tags.php
INFO - 2020-04-30 17:32:18 --> Router Class Initialized
INFO - 2020-04-30 17:32:18 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:32:18 --> Output Class Initialized
INFO - 2020-04-30 17:32:18 --> Security Class Initialized
DEBUG - 2020-04-30 17:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:32:18 --> Input Class Initialized
INFO - 2020-04-30 17:32:18 --> Language Class Initialized
INFO - 2020-04-30 17:32:18 --> Loader Class Initialized
INFO - 2020-04-30 17:32:18 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:32:18 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:32:18 --> Helper loaded: data_helper
INFO - 2020-04-30 17:32:18 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:32:18 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:32:18 --> Helper loaded: view_helper
INFO - 2020-04-30 17:32:18 --> Helper loaded: url_helper
INFO - 2020-04-30 17:32:18 --> Database Driver Class Initialized
INFO - 2020-04-30 17:32:18 --> Controller Class Initialized
INFO - 2020-04-30 17:32:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:32:18 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:32:18 --> Plain_Model class loaded
INFO - 2020-04-30 17:32:18 --> Model "Tags_model" initialized
DEBUG - 2020-04-30 17:32:18 --> The "english" language file has been loaded.
INFO - 2020-04-30 17:32:18 --> Model "User_Marks_To_Tags_model" initialized
INFO - 2020-04-30 17:32:18 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-04-30 17:32:18 --> Final output sent to browser
DEBUG - 2020-04-30 17:32:18 --> Total execution time: 0.7092
INFO - 2020-04-30 17:32:19 --> Config Class Initialized
INFO - 2020-04-30 17:32:19 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:32:19 --> Hooks Class Initialized
INFO - 2020-04-30 17:32:19 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:32:19 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:32:19 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:32:19 --> Utf8 Class Initialized
INFO - 2020-04-30 17:32:19 --> URI Class Initialized
DEBUG - 2020-04-30 17:32:19 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 17:32:19 --> Router Class Initialized
INFO - 2020-04-30 17:32:19 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:32:19 --> Output Class Initialized
INFO - 2020-04-30 17:32:19 --> Security Class Initialized
DEBUG - 2020-04-30 17:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:32:19 --> Input Class Initialized
INFO - 2020-04-30 17:32:19 --> Language Class Initialized
INFO - 2020-04-30 17:32:19 --> Loader Class Initialized
INFO - 2020-04-30 17:32:19 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:32:19 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:32:19 --> Helper loaded: data_helper
INFO - 2020-04-30 17:32:19 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:32:19 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:32:19 --> Helper loaded: view_helper
INFO - 2020-04-30 17:32:19 --> Helper loaded: url_helper
INFO - 2020-04-30 17:32:19 --> Database Driver Class Initialized
INFO - 2020-04-30 17:32:19 --> Controller Class Initialized
INFO - 2020-04-30 17:32:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:32:19 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:32:19 --> Plain_Model class loaded
INFO - 2020-04-30 17:32:19 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 17:32:19 --> The "english" language file has been loaded.
DEBUG - 2020-04-30 17:32:19 --> Running get method for labels
INFO - 2020-04-30 17:32:19 --> Model "Labels_model" initialized
INFO - 2020-04-30 17:32:19 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-04-30 17:32:19 --> Final output sent to browser
DEBUG - 2020-04-30 17:32:19 --> Total execution time: 0.5556
INFO - 2020-04-30 17:32:38 --> Config Class Initialized
INFO - 2020-04-30 17:32:38 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:32:38 --> Hooks Class Initialized
INFO - 2020-04-30 17:32:38 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:32:38 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:32:38 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:32:38 --> Utf8 Class Initialized
INFO - 2020-04-30 17:32:38 --> URI Class Initialized
DEBUG - 2020-04-30 17:32:38 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 17:32:38 --> Router Class Initialized
INFO - 2020-04-30 17:32:38 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:32:38 --> Output Class Initialized
INFO - 2020-04-30 17:32:38 --> Security Class Initialized
DEBUG - 2020-04-30 17:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:32:38 --> Input Class Initialized
INFO - 2020-04-30 17:32:38 --> Language Class Initialized
INFO - 2020-04-30 17:32:38 --> Loader Class Initialized
INFO - 2020-04-30 17:32:38 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:32:38 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:32:38 --> Helper loaded: data_helper
INFO - 2020-04-30 17:32:38 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:32:38 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:32:38 --> Helper loaded: view_helper
INFO - 2020-04-30 17:32:38 --> Helper loaded: url_helper
INFO - 2020-04-30 17:32:38 --> Database Driver Class Initialized
INFO - 2020-04-30 17:32:38 --> Controller Class Initialized
INFO - 2020-04-30 17:32:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:32:38 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:32:38 --> Plain_Model class loaded
INFO - 2020-04-30 17:32:38 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 17:32:38 --> The "english" language file has been loaded.
INFO - 2020-04-30 17:32:38 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 17:32:38 --> The phrase "Unmark : Mark Added" could not be found in the language file.
DEBUG - 2020-04-30 17:32:38 --> The phrase "This mark has been added to your stream." could not be found in the language file.
DEBUG - 2020-04-30 17:32:38 --> The phrase "Add a Note or Edit Title" could not be found in the language file.
DEBUG - 2020-04-30 17:32:38 --> The phrase "Type note text here..." could not be found in the language file.
DEBUG - 2020-04-30 17:32:38 --> The phrase "Delete Link" could not be found in the language file.
DEBUG - 2020-04-30 17:32:38 --> The phrase "Update &amp; Close" could not be found in the language file.
INFO - 2020-04-30 17:32:38 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-04-30 17:32:38 --> File loaded: /var/www/html/application/views/marks/info.php
INFO - 2020-04-30 17:32:38 --> Final output sent to browser
DEBUG - 2020-04-30 17:32:38 --> Total execution time: 0.6542
INFO - 2020-04-30 17:32:39 --> Config Class Initialized
INFO - 2020-04-30 17:32:39 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:32:39 --> Hooks Class Initialized
INFO - 2020-04-30 17:32:39 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:32:39 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:32:39 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:32:39 --> Utf8 Class Initialized
INFO - 2020-04-30 17:32:39 --> URI Class Initialized
DEBUG - 2020-04-30 17:32:39 --> Validating request for /controllers/Tags.php
INFO - 2020-04-30 17:32:39 --> Router Class Initialized
INFO - 2020-04-30 17:32:39 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:32:39 --> Output Class Initialized
INFO - 2020-04-30 17:32:39 --> Security Class Initialized
DEBUG - 2020-04-30 17:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:32:39 --> Input Class Initialized
INFO - 2020-04-30 17:32:39 --> Language Class Initialized
INFO - 2020-04-30 17:32:39 --> Loader Class Initialized
INFO - 2020-04-30 17:32:39 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:32:39 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:32:39 --> Helper loaded: data_helper
INFO - 2020-04-30 17:32:39 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:32:39 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:32:39 --> Helper loaded: view_helper
INFO - 2020-04-30 17:32:39 --> Helper loaded: url_helper
INFO - 2020-04-30 17:32:39 --> Database Driver Class Initialized
INFO - 2020-04-30 17:32:39 --> Controller Class Initialized
INFO - 2020-04-30 17:32:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:32:39 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:32:39 --> Plain_Model class loaded
INFO - 2020-04-30 17:32:39 --> Model "Tags_model" initialized
DEBUG - 2020-04-30 17:32:39 --> The "english" language file has been loaded.
INFO - 2020-04-30 17:32:39 --> Model "User_Marks_To_Tags_model" initialized
INFO - 2020-04-30 17:32:39 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-04-30 17:32:39 --> Final output sent to browser
DEBUG - 2020-04-30 17:32:39 --> Total execution time: 0.5532
INFO - 2020-04-30 17:32:40 --> Config Class Initialized
INFO - 2020-04-30 17:32:40 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:32:40 --> Hooks Class Initialized
INFO - 2020-04-30 17:32:40 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:32:40 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:32:40 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:32:40 --> Utf8 Class Initialized
INFO - 2020-04-30 17:32:40 --> URI Class Initialized
DEBUG - 2020-04-30 17:32:40 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 17:32:40 --> Router Class Initialized
INFO - 2020-04-30 17:32:40 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:32:40 --> Output Class Initialized
INFO - 2020-04-30 17:32:40 --> Security Class Initialized
DEBUG - 2020-04-30 17:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:32:40 --> Input Class Initialized
INFO - 2020-04-30 17:32:40 --> Language Class Initialized
INFO - 2020-04-30 17:32:40 --> Loader Class Initialized
INFO - 2020-04-30 17:32:40 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:32:40 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:32:40 --> Helper loaded: data_helper
INFO - 2020-04-30 17:32:40 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:32:40 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:32:40 --> Helper loaded: view_helper
INFO - 2020-04-30 17:32:40 --> Helper loaded: url_helper
INFO - 2020-04-30 17:32:40 --> Database Driver Class Initialized
INFO - 2020-04-30 17:32:40 --> Controller Class Initialized
INFO - 2020-04-30 17:32:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:32:40 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:32:40 --> Plain_Model class loaded
INFO - 2020-04-30 17:32:40 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 17:32:40 --> The "english" language file has been loaded.
DEBUG - 2020-04-30 17:32:40 --> Running get method for labels
INFO - 2020-04-30 17:32:40 --> Model "Labels_model" initialized
INFO - 2020-04-30 17:32:40 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-04-30 17:32:40 --> Final output sent to browser
DEBUG - 2020-04-30 17:32:40 --> Total execution time: 0.5286
INFO - 2020-04-30 17:32:59 --> Config Class Initialized
INFO - 2020-04-30 17:32:59 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:32:59 --> Hooks Class Initialized
INFO - 2020-04-30 17:32:59 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:32:59 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:32:59 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:32:59 --> Utf8 Class Initialized
INFO - 2020-04-30 17:32:59 --> URI Class Initialized
DEBUG - 2020-04-30 17:32:59 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 17:32:59 --> Router Class Initialized
INFO - 2020-04-30 17:32:59 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:32:59 --> Output Class Initialized
INFO - 2020-04-30 17:32:59 --> Security Class Initialized
DEBUG - 2020-04-30 17:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:32:59 --> Input Class Initialized
INFO - 2020-04-30 17:32:59 --> Language Class Initialized
INFO - 2020-04-30 17:32:59 --> Loader Class Initialized
INFO - 2020-04-30 17:32:59 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:32:59 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:32:59 --> Helper loaded: data_helper
INFO - 2020-04-30 17:32:59 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:32:59 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:32:59 --> Helper loaded: view_helper
INFO - 2020-04-30 17:32:59 --> Helper loaded: url_helper
INFO - 2020-04-30 17:32:59 --> Database Driver Class Initialized
INFO - 2020-04-30 17:32:59 --> Controller Class Initialized
INFO - 2020-04-30 17:33:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:33:00 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:33:00 --> Plain_Model class loaded
INFO - 2020-04-30 17:33:00 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 17:33:00 --> The "english" language file has been loaded.
INFO - 2020-04-30 17:33:00 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 17:33:00 --> The phrase "Unmark : Mark Added" could not be found in the language file.
DEBUG - 2020-04-30 17:33:00 --> The phrase "This mark has been added to your stream." could not be found in the language file.
DEBUG - 2020-04-30 17:33:00 --> The phrase "Add a Note or Edit Title" could not be found in the language file.
DEBUG - 2020-04-30 17:33:00 --> The phrase "Type note text here..." could not be found in the language file.
DEBUG - 2020-04-30 17:33:00 --> The phrase "Delete Link" could not be found in the language file.
DEBUG - 2020-04-30 17:33:00 --> The phrase "Update &amp; Close" could not be found in the language file.
INFO - 2020-04-30 17:33:00 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-04-30 17:33:00 --> File loaded: /var/www/html/application/views/marks/info.php
INFO - 2020-04-30 17:33:00 --> Final output sent to browser
DEBUG - 2020-04-30 17:33:00 --> Total execution time: 0.5139
INFO - 2020-04-30 17:33:00 --> Config Class Initialized
INFO - 2020-04-30 17:33:00 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:33:00 --> Hooks Class Initialized
INFO - 2020-04-30 17:33:00 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:33:00 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:33:00 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:33:00 --> Utf8 Class Initialized
INFO - 2020-04-30 17:33:00 --> URI Class Initialized
DEBUG - 2020-04-30 17:33:00 --> Validating request for /controllers/Tags.php
INFO - 2020-04-30 17:33:00 --> Router Class Initialized
INFO - 2020-04-30 17:33:00 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:33:00 --> Output Class Initialized
INFO - 2020-04-30 17:33:00 --> Security Class Initialized
DEBUG - 2020-04-30 17:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:33:00 --> Input Class Initialized
INFO - 2020-04-30 17:33:00 --> Language Class Initialized
INFO - 2020-04-30 17:33:00 --> Loader Class Initialized
INFO - 2020-04-30 17:33:00 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:33:00 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:33:00 --> Helper loaded: data_helper
INFO - 2020-04-30 17:33:00 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:33:00 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:33:00 --> Helper loaded: view_helper
INFO - 2020-04-30 17:33:00 --> Helper loaded: url_helper
INFO - 2020-04-30 17:33:00 --> Database Driver Class Initialized
INFO - 2020-04-30 17:33:00 --> Controller Class Initialized
INFO - 2020-04-30 17:33:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:33:00 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:33:00 --> Plain_Model class loaded
INFO - 2020-04-30 17:33:00 --> Model "Tags_model" initialized
DEBUG - 2020-04-30 17:33:00 --> The "english" language file has been loaded.
INFO - 2020-04-30 17:33:00 --> Model "User_Marks_To_Tags_model" initialized
INFO - 2020-04-30 17:33:00 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-04-30 17:33:00 --> Final output sent to browser
DEBUG - 2020-04-30 17:33:00 --> Total execution time: 0.3740
INFO - 2020-04-30 17:33:01 --> Config Class Initialized
INFO - 2020-04-30 17:33:01 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:33:01 --> Hooks Class Initialized
INFO - 2020-04-30 17:33:01 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:33:01 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:33:01 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:33:01 --> Utf8 Class Initialized
INFO - 2020-04-30 17:33:01 --> URI Class Initialized
DEBUG - 2020-04-30 17:33:01 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 17:33:01 --> Router Class Initialized
INFO - 2020-04-30 17:33:01 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:33:01 --> Output Class Initialized
INFO - 2020-04-30 17:33:01 --> Security Class Initialized
DEBUG - 2020-04-30 17:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:33:01 --> Input Class Initialized
INFO - 2020-04-30 17:33:01 --> Language Class Initialized
INFO - 2020-04-30 17:33:01 --> Loader Class Initialized
INFO - 2020-04-30 17:33:01 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:33:01 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:33:01 --> Helper loaded: data_helper
INFO - 2020-04-30 17:33:01 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:33:01 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:33:01 --> Helper loaded: view_helper
INFO - 2020-04-30 17:33:01 --> Helper loaded: url_helper
INFO - 2020-04-30 17:33:01 --> Database Driver Class Initialized
INFO - 2020-04-30 17:33:01 --> Controller Class Initialized
INFO - 2020-04-30 17:33:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:33:01 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:33:01 --> Plain_Model class loaded
INFO - 2020-04-30 17:33:01 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 17:33:01 --> The "english" language file has been loaded.
DEBUG - 2020-04-30 17:33:01 --> Running get method for labels
INFO - 2020-04-30 17:33:01 --> Model "Labels_model" initialized
INFO - 2020-04-30 17:33:01 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-04-30 17:33:01 --> Final output sent to browser
DEBUG - 2020-04-30 17:33:01 --> Total execution time: 0.3428
INFO - 2020-04-30 17:33:22 --> Config Class Initialized
INFO - 2020-04-30 17:33:22 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:33:22 --> Hooks Class Initialized
INFO - 2020-04-30 17:33:22 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:33:22 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:33:22 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:33:22 --> Utf8 Class Initialized
INFO - 2020-04-30 17:33:22 --> URI Class Initialized
DEBUG - 2020-04-30 17:33:23 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 17:33:23 --> Router Class Initialized
INFO - 2020-04-30 17:33:23 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:33:23 --> Output Class Initialized
INFO - 2020-04-30 17:33:23 --> Security Class Initialized
DEBUG - 2020-04-30 17:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:33:23 --> Input Class Initialized
INFO - 2020-04-30 17:33:23 --> Language Class Initialized
INFO - 2020-04-30 17:33:23 --> Loader Class Initialized
INFO - 2020-04-30 17:33:23 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:33:23 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:33:23 --> Helper loaded: data_helper
INFO - 2020-04-30 17:33:23 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:33:23 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:33:23 --> Helper loaded: view_helper
INFO - 2020-04-30 17:33:23 --> Helper loaded: url_helper
INFO - 2020-04-30 17:33:23 --> Database Driver Class Initialized
INFO - 2020-04-30 17:33:23 --> Controller Class Initialized
INFO - 2020-04-30 17:33:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:33:23 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:33:23 --> Plain_Model class loaded
INFO - 2020-04-30 17:33:23 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 17:33:23 --> The "english" language file has been loaded.
INFO - 2020-04-30 17:33:23 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-04-30 17:33:23 --> The phrase "Unmark : Mark Added" could not be found in the language file.
DEBUG - 2020-04-30 17:33:23 --> The phrase "This mark has been added to your stream." could not be found in the language file.
DEBUG - 2020-04-30 17:33:23 --> The phrase "Add a Note or Edit Title" could not be found in the language file.
DEBUG - 2020-04-30 17:33:23 --> The phrase "Type note text here..." could not be found in the language file.
DEBUG - 2020-04-30 17:33:23 --> The phrase "Delete Link" could not be found in the language file.
DEBUG - 2020-04-30 17:33:23 --> The phrase "Update &amp; Close" could not be found in the language file.
INFO - 2020-04-30 17:33:23 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-04-30 17:33:23 --> File loaded: /var/www/html/application/views/marks/info.php
INFO - 2020-04-30 17:33:23 --> Final output sent to browser
DEBUG - 2020-04-30 17:33:23 --> Total execution time: 0.4946
INFO - 2020-04-30 17:33:23 --> Config Class Initialized
INFO - 2020-04-30 17:33:23 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:33:23 --> Hooks Class Initialized
INFO - 2020-04-30 17:33:23 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:33:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:33:23 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:33:23 --> Utf8 Class Initialized
INFO - 2020-04-30 17:33:24 --> URI Class Initialized
DEBUG - 2020-04-30 17:33:24 --> Validating request for /controllers/Tags.php
INFO - 2020-04-30 17:33:24 --> Router Class Initialized
INFO - 2020-04-30 17:33:24 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:33:24 --> Output Class Initialized
INFO - 2020-04-30 17:33:24 --> Security Class Initialized
DEBUG - 2020-04-30 17:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:33:24 --> Input Class Initialized
INFO - 2020-04-30 17:33:24 --> Language Class Initialized
INFO - 2020-04-30 17:33:24 --> Loader Class Initialized
INFO - 2020-04-30 17:33:24 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:33:24 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:33:24 --> Helper loaded: data_helper
INFO - 2020-04-30 17:33:24 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:33:24 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:33:24 --> Helper loaded: view_helper
INFO - 2020-04-30 17:33:24 --> Helper loaded: url_helper
INFO - 2020-04-30 17:33:24 --> Database Driver Class Initialized
INFO - 2020-04-30 17:33:24 --> Controller Class Initialized
INFO - 2020-04-30 17:33:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:33:24 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:33:24 --> Plain_Model class loaded
INFO - 2020-04-30 17:33:24 --> Model "Tags_model" initialized
DEBUG - 2020-04-30 17:33:24 --> The "english" language file has been loaded.
INFO - 2020-04-30 17:33:24 --> Model "User_Marks_To_Tags_model" initialized
INFO - 2020-04-30 17:33:24 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-04-30 17:33:24 --> Final output sent to browser
DEBUG - 2020-04-30 17:33:24 --> Total execution time: 0.7575
INFO - 2020-04-30 17:33:24 --> Config Class Initialized
INFO - 2020-04-30 17:33:24 --> Plain_Config Class Initialized
INFO - 2020-04-30 17:33:24 --> Hooks Class Initialized
INFO - 2020-04-30 17:33:24 --> Plain_Hooks Class Constructed
INFO - 2020-04-30 17:33:24 --> Plain_Hooks Class Initialized
DEBUG - 2020-04-30 17:33:24 --> UTF-8 Support Disabled
INFO - 2020-04-30 17:33:24 --> Utf8 Class Initialized
INFO - 2020-04-30 17:33:24 --> URI Class Initialized
DEBUG - 2020-04-30 17:33:24 --> Validating request for /controllers/Marks.php
INFO - 2020-04-30 17:33:24 --> Router Class Initialized
INFO - 2020-04-30 17:33:24 --> Plain_Router Class Initialized
INFO - 2020-04-30 17:33:24 --> Output Class Initialized
INFO - 2020-04-30 17:33:24 --> Security Class Initialized
DEBUG - 2020-04-30 17:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-04-30 17:33:24 --> Input Class Initialized
INFO - 2020-04-30 17:33:24 --> Language Class Initialized
INFO - 2020-04-30 17:33:25 --> Loader Class Initialized
INFO - 2020-04-30 17:33:25 --> Plain_Loader Class Initialized
DEBUG - 2020-04-30 17:33:25 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-04-30 17:33:25 --> Helper loaded: data_helper
INFO - 2020-04-30 17:33:25 --> Helper loaded: hash_helper
INFO - 2020-04-30 17:33:25 --> Helper loaded: validation_helper
INFO - 2020-04-30 17:33:25 --> Helper loaded: view_helper
INFO - 2020-04-30 17:33:25 --> Helper loaded: url_helper
INFO - 2020-04-30 17:33:25 --> Database Driver Class Initialized
INFO - 2020-04-30 17:33:25 --> Controller Class Initialized
INFO - 2020-04-30 17:33:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-04-30 17:33:25 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-04-30 17:33:25 --> Plain_Model class loaded
INFO - 2020-04-30 17:33:25 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-04-30 17:33:25 --> The "english" language file has been loaded.
DEBUG - 2020-04-30 17:33:25 --> Running get method for labels
INFO - 2020-04-30 17:33:25 --> Model "Labels_model" initialized
INFO - 2020-04-30 17:33:25 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-04-30 17:33:25 --> Final output sent to browser
DEBUG - 2020-04-30 17:33:25 --> Total execution time: 0.5359
