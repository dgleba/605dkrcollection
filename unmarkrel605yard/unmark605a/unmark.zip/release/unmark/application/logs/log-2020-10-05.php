<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-05 19:19:51 --> Config Class Initialized
INFO - 2020-10-05 19:19:51 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:19:51 --> Hooks Class Initialized
INFO - 2020-10-05 19:19:51 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:19:51 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:19:51 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:19:51 --> Utf8 Class Initialized
INFO - 2020-10-05 19:19:51 --> URI Class Initialized
DEBUG - 2020-10-05 19:19:51 --> No URI present. Default controller set.
INFO - 2020-10-05 19:19:51 --> Router Class Initialized
INFO - 2020-10-05 19:19:51 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:19:51 --> Output Class Initialized
INFO - 2020-10-05 19:19:51 --> Security Class Initialized
DEBUG - 2020-10-05 19:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:19:51 --> Input Class Initialized
INFO - 2020-10-05 19:19:51 --> Language Class Initialized
INFO - 2020-10-05 19:19:51 --> Loader Class Initialized
INFO - 2020-10-05 19:19:51 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:19:51 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:19:51 --> Helper loaded: data_helper
INFO - 2020-10-05 19:19:51 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:19:51 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:19:51 --> Helper loaded: view_helper
INFO - 2020-10-05 19:19:51 --> Helper loaded: url_helper
INFO - 2020-10-05 19:19:51 --> Database Driver Class Initialized
INFO - 2020-10-05 19:19:51 --> Controller Class Initialized
INFO - 2020-10-05 19:19:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:19:51 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-10-05 19:19:51 --> The "english" language file has been loaded.
INFO - 2020-10-05 19:19:51 --> Config Class Initialized
INFO - 2020-10-05 19:19:51 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:19:51 --> Hooks Class Initialized
INFO - 2020-10-05 19:19:51 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:19:51 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:19:51 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:19:51 --> Utf8 Class Initialized
INFO - 2020-10-05 19:19:51 --> URI Class Initialized
DEBUG - 2020-10-05 19:19:51 --> Validating request for /controllers/Install.php
INFO - 2020-10-05 19:19:51 --> Router Class Initialized
INFO - 2020-10-05 19:19:51 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:19:51 --> Output Class Initialized
INFO - 2020-10-05 19:19:51 --> Security Class Initialized
DEBUG - 2020-10-05 19:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:19:51 --> Input Class Initialized
INFO - 2020-10-05 19:19:51 --> Language Class Initialized
INFO - 2020-10-05 19:19:51 --> Loader Class Initialized
INFO - 2020-10-05 19:19:51 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:19:51 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:19:51 --> Helper loaded: data_helper
INFO - 2020-10-05 19:19:51 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:19:51 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:19:51 --> Helper loaded: view_helper
INFO - 2020-10-05 19:19:51 --> Helper loaded: url_helper
INFO - 2020-10-05 19:19:51 --> Database Driver Class Initialized
INFO - 2020-10-05 19:19:51 --> Controller Class Initialized
DEBUG - 2020-10-05 19:19:51 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:19:51 --> The phrase "Unmark: Setup" could not be found in the language file.
DEBUG - 2020-10-05 19:19:51 --> The phrase "Welcome to Unmark, the to-do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 19:19:51 --> The phrase "You're about to install version 2020.3 of the app.</p><p>Please <a href="https://github.com/plainmade/unmark/blob/master/readme.md">read the installation instructions</a> first." could not be found in the language file.
DEBUG - 2020-10-05 19:19:51 --> The phrase "Click to Install" could not be found in the language file.
INFO - 2020-10-05 19:19:51 --> File loaded: /var/www/html/application/views/setup.php
INFO - 2020-10-05 19:19:51 --> Final output sent to browser
DEBUG - 2020-10-05 19:19:51 --> Total execution time: 0.1252
INFO - 2020-10-05 19:19:52 --> Config Class Initialized
INFO - 2020-10-05 19:19:52 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:19:52 --> Hooks Class Initialized
INFO - 2020-10-05 19:19:52 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:19:52 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:19:52 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:19:52 --> Utf8 Class Initialized
INFO - 2020-10-05 19:19:52 --> URI Class Initialized
DEBUG - 2020-10-05 19:19:52 --> Validating request for /controllers/Custom.php
INFO - 2020-10-05 19:19:52 --> Plain_Exceptions Class Initialized
ERROR - 2020-10-05 19:19:52 --> 404 Page Not Found: custom
INFO - 2020-10-05 19:19:59 --> Config Class Initialized
INFO - 2020-10-05 19:19:59 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:19:59 --> Hooks Class Initialized
INFO - 2020-10-05 19:19:59 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:19:59 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:19:59 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:19:59 --> Utf8 Class Initialized
INFO - 2020-10-05 19:19:59 --> URI Class Initialized
DEBUG - 2020-10-05 19:19:59 --> No URI present. Default controller set.
INFO - 2020-10-05 19:19:59 --> Router Class Initialized
INFO - 2020-10-05 19:19:59 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:19:59 --> Output Class Initialized
INFO - 2020-10-05 19:19:59 --> Security Class Initialized
DEBUG - 2020-10-05 19:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:19:59 --> Input Class Initialized
INFO - 2020-10-05 19:19:59 --> Language Class Initialized
INFO - 2020-10-05 19:19:59 --> Loader Class Initialized
INFO - 2020-10-05 19:19:59 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:19:59 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:19:59 --> Helper loaded: data_helper
INFO - 2020-10-05 19:19:59 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:19:59 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:19:59 --> Helper loaded: view_helper
INFO - 2020-10-05 19:19:59 --> Helper loaded: url_helper
INFO - 2020-10-05 19:19:59 --> Database Driver Class Initialized
INFO - 2020-10-05 19:19:59 --> Controller Class Initialized
INFO - 2020-10-05 19:19:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:19:59 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-10-05 19:19:59 --> The "english" language file has been loaded.
INFO - 2020-10-05 19:20:42 --> Config Class Initialized
INFO - 2020-10-05 19:20:42 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:20:42 --> Hooks Class Initialized
INFO - 2020-10-05 19:20:42 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:20:42 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:20:42 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:20:42 --> Utf8 Class Initialized
INFO - 2020-10-05 19:20:42 --> URI Class Initialized
DEBUG - 2020-10-05 19:20:42 --> Validating request for /controllers/Install.php
INFO - 2020-10-05 19:20:42 --> Router Class Initialized
INFO - 2020-10-05 19:20:42 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:20:42 --> Output Class Initialized
INFO - 2020-10-05 19:20:42 --> Security Class Initialized
DEBUG - 2020-10-05 19:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:20:42 --> Input Class Initialized
INFO - 2020-10-05 19:20:42 --> Language Class Initialized
INFO - 2020-10-05 19:20:42 --> Loader Class Initialized
INFO - 2020-10-05 19:20:42 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:20:42 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:20:42 --> Helper loaded: data_helper
INFO - 2020-10-05 19:20:42 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:20:42 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:20:42 --> Helper loaded: view_helper
INFO - 2020-10-05 19:20:42 --> Helper loaded: url_helper
INFO - 2020-10-05 19:20:42 --> Database Driver Class Initialized
INFO - 2020-10-05 19:20:42 --> Controller Class Initialized
DEBUG - 2020-10-05 19:20:42 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:20:42 --> The phrase "Unmark: Setup" could not be found in the language file.
DEBUG - 2020-10-05 19:20:42 --> The phrase "Welcome to Unmark, the to-do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 19:20:42 --> The phrase "You're about to install version 2020.3 of the app.</p><p>Please <a href="https://github.com/plainmade/unmark/blob/master/readme.md">read the installation instructions</a> first." could not be found in the language file.
DEBUG - 2020-10-05 19:20:42 --> The phrase "Click to Install" could not be found in the language file.
INFO - 2020-10-05 19:20:42 --> File loaded: /var/www/html/application/views/setup.php
INFO - 2020-10-05 19:20:42 --> Final output sent to browser
DEBUG - 2020-10-05 19:20:42 --> Total execution time: 0.1178
INFO - 2020-10-05 19:20:42 --> Config Class Initialized
INFO - 2020-10-05 19:20:42 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:20:42 --> Hooks Class Initialized
INFO - 2020-10-05 19:20:42 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:20:42 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:20:42 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:20:42 --> Utf8 Class Initialized
INFO - 2020-10-05 19:20:42 --> URI Class Initialized
DEBUG - 2020-10-05 19:20:42 --> Validating request for /controllers/Custom.php
INFO - 2020-10-05 19:20:42 --> Plain_Exceptions Class Initialized
ERROR - 2020-10-05 19:20:42 --> 404 Page Not Found: custom
INFO - 2020-10-05 19:20:57 --> Config Class Initialized
INFO - 2020-10-05 19:20:57 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:20:57 --> Hooks Class Initialized
INFO - 2020-10-05 19:20:57 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:20:57 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:20:57 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:20:57 --> Utf8 Class Initialized
INFO - 2020-10-05 19:20:57 --> URI Class Initialized
DEBUG - 2020-10-05 19:20:57 --> Validating request for /controllers/Install.php
INFO - 2020-10-05 19:20:57 --> Router Class Initialized
INFO - 2020-10-05 19:20:57 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:20:57 --> Output Class Initialized
INFO - 2020-10-05 19:20:57 --> Security Class Initialized
DEBUG - 2020-10-05 19:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:20:57 --> Input Class Initialized
INFO - 2020-10-05 19:20:57 --> Language Class Initialized
INFO - 2020-10-05 19:20:57 --> Loader Class Initialized
INFO - 2020-10-05 19:20:57 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:20:57 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:20:57 --> Helper loaded: data_helper
INFO - 2020-10-05 19:20:57 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:20:57 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:20:57 --> Helper loaded: view_helper
INFO - 2020-10-05 19:20:57 --> Helper loaded: url_helper
INFO - 2020-10-05 19:20:57 --> Database Driver Class Initialized
INFO - 2020-10-05 19:20:57 --> Controller Class Initialized
DEBUG - 2020-10-05 19:20:57 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:20:57 --> Plain Migrations class initialized
DEBUG - 2020-10-05 19:20:57 --> Language file loaded: language/english/migration_lang.php
INFO - 2020-10-05 19:20:57 --> Database Forge Class Initialized
DEBUG - 2020-10-05 19:20:57 --> Making backup before migrating failed.
DEBUG - 2020-10-05 19:20:57 --> Migrating up from version 0 to version 001
DEBUG - 2020-10-05 19:20:57 --> Migrating up from version 001 to version 002
DEBUG - 2020-10-05 19:20:57 --> Migrating up from version 002 to version 003
DEBUG - 2020-10-05 19:20:57 --> Migrating up from version 003 to version 004
DEBUG - 2020-10-05 19:20:57 --> Migrating up from version 004 to version 005
DEBUG - 2020-10-05 19:20:57 --> Migrating up from version 005 to version 006
DEBUG - 2020-10-05 19:20:57 --> Migrating up from version 006 to version 007
DEBUG - 2020-10-05 19:20:58 --> Migrating up from version 007 to version 008
DEBUG - 2020-10-05 19:20:58 --> Migrating up from version 008 to version 009
DEBUG - 2020-10-05 19:20:58 --> Migrating up from version 009 to version 010
DEBUG - 2020-10-05 19:20:58 --> Migrating up from version 010 to version 2014022801
DEBUG - 2020-10-05 19:20:58 --> Migrating up from version 2014022801 to version 2014112501
DEBUG - 2020-10-05 19:20:58 --> Finished migrating to 2014112501
DEBUG - 2020-10-05 19:20:58 --> Making backup before migrating failed.
INFO - 2020-10-05 19:20:58 --> Config Class Initialized
INFO - 2020-10-05 19:20:58 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:20:58 --> Hooks Class Initialized
INFO - 2020-10-05 19:20:58 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:20:58 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:20:58 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:20:58 --> Utf8 Class Initialized
INFO - 2020-10-05 19:20:58 --> URI Class Initialized
DEBUG - 2020-10-05 19:20:58 --> Validating request for /controllers/Register.php
INFO - 2020-10-05 19:20:58 --> Router Class Initialized
INFO - 2020-10-05 19:20:58 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:20:58 --> Output Class Initialized
INFO - 2020-10-05 19:20:58 --> Security Class Initialized
DEBUG - 2020-10-05 19:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:20:58 --> Input Class Initialized
INFO - 2020-10-05 19:20:58 --> Language Class Initialized
INFO - 2020-10-05 19:20:58 --> Loader Class Initialized
INFO - 2020-10-05 19:20:58 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:20:58 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:20:58 --> Helper loaded: data_helper
INFO - 2020-10-05 19:20:58 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:20:58 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:20:58 --> Helper loaded: view_helper
INFO - 2020-10-05 19:20:58 --> Helper loaded: url_helper
INFO - 2020-10-05 19:20:58 --> Database Driver Class Initialized
INFO - 2020-10-05 19:20:58 --> Controller Class Initialized
INFO - 2020-10-05 19:20:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:20:58 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-10-05 19:20:58 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:20:58 --> The phrase "Unmark : User Registration" could not be found in the language file.
DEBUG - 2020-10-05 19:20:58 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:20:58 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 19:20:58 --> The phrase "Password Again" could not be found in the language file.
DEBUG - 2020-10-05 19:20:58 --> The phrase "Terms of Use" could not be found in the language file.
DEBUG - 2020-10-05 19:20:58 --> The phrase "Have An Account? Sign In Here" could not be found in the language file.
INFO - 2020-10-05 19:20:58 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 19:20:58 --> File loaded: /var/www/html/application/views/register/index.php
INFO - 2020-10-05 19:20:58 --> Final output sent to browser
DEBUG - 2020-10-05 19:20:58 --> Total execution time: 0.1254
INFO - 2020-10-05 19:20:58 --> Config Class Initialized
INFO - 2020-10-05 19:20:58 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:20:58 --> Hooks Class Initialized
INFO - 2020-10-05 19:20:58 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:20:58 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:20:58 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:20:58 --> Utf8 Class Initialized
INFO - 2020-10-05 19:20:58 --> URI Class Initialized
DEBUG - 2020-10-05 19:20:58 --> Validating request for /controllers/Custom.php
INFO - 2020-10-05 19:20:58 --> Plain_Exceptions Class Initialized
ERROR - 2020-10-05 19:20:58 --> 404 Page Not Found: custom
INFO - 2020-10-05 19:21:08 --> Config Class Initialized
INFO - 2020-10-05 19:21:08 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:21:08 --> Hooks Class Initialized
INFO - 2020-10-05 19:21:08 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:21:08 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:21:08 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:21:08 --> Utf8 Class Initialized
INFO - 2020-10-05 19:21:08 --> URI Class Initialized
DEBUG - 2020-10-05 19:21:08 --> Validating request for /controllers/Register.php
INFO - 2020-10-05 19:21:08 --> Router Class Initialized
INFO - 2020-10-05 19:21:08 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:21:08 --> Output Class Initialized
INFO - 2020-10-05 19:21:08 --> Security Class Initialized
DEBUG - 2020-10-05 19:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:21:08 --> Input Class Initialized
INFO - 2020-10-05 19:21:08 --> Language Class Initialized
INFO - 2020-10-05 19:21:08 --> Loader Class Initialized
INFO - 2020-10-05 19:21:08 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:21:08 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:21:08 --> Helper loaded: data_helper
INFO - 2020-10-05 19:21:08 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:21:08 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:21:08 --> Helper loaded: view_helper
INFO - 2020-10-05 19:21:08 --> Helper loaded: url_helper
INFO - 2020-10-05 19:21:08 --> Database Driver Class Initialized
INFO - 2020-10-05 19:21:08 --> Controller Class Initialized
INFO - 2020-10-05 19:21:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:21:08 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-10-05 19:21:08 --> The "english" language file has been loaded.
INFO - 2020-10-05 19:21:08 --> Plain_Model class loaded
INFO - 2020-10-05 19:21:08 --> Model "Users_model" initialized
INFO - 2020-10-05 19:21:08 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-10-05 19:21:08 --> Final output sent to browser
DEBUG - 2020-10-05 19:21:08 --> Total execution time: 0.1305
INFO - 2020-10-05 19:21:20 --> Config Class Initialized
INFO - 2020-10-05 19:21:20 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:21:20 --> Hooks Class Initialized
INFO - 2020-10-05 19:21:20 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:21:20 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:21:20 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:21:20 --> Utf8 Class Initialized
INFO - 2020-10-05 19:21:20 --> URI Class Initialized
DEBUG - 2020-10-05 19:21:20 --> Validating request for /controllers/Register.php
INFO - 2020-10-05 19:21:20 --> Router Class Initialized
INFO - 2020-10-05 19:21:20 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:21:20 --> Output Class Initialized
INFO - 2020-10-05 19:21:20 --> Security Class Initialized
DEBUG - 2020-10-05 19:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:21:20 --> Input Class Initialized
INFO - 2020-10-05 19:21:20 --> Language Class Initialized
INFO - 2020-10-05 19:21:20 --> Loader Class Initialized
INFO - 2020-10-05 19:21:20 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:21:20 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:21:20 --> Helper loaded: data_helper
INFO - 2020-10-05 19:21:20 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:21:20 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:21:20 --> Helper loaded: view_helper
INFO - 2020-10-05 19:21:20 --> Helper loaded: url_helper
INFO - 2020-10-05 19:21:20 --> Database Driver Class Initialized
INFO - 2020-10-05 19:21:20 --> Controller Class Initialized
INFO - 2020-10-05 19:21:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:21:20 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-10-05 19:21:20 --> The "english" language file has been loaded.
INFO - 2020-10-05 19:21:20 --> Plain_Model class loaded
INFO - 2020-10-05 19:21:20 --> Model "Users_model" initialized
INFO - 2020-10-05 19:21:20 --> Helper loaded: http_build_url_helper
INFO - 2020-10-05 19:21:20 --> Model "Marks_model" initialized
INFO - 2020-10-05 19:21:20 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:21:20 --> The phrase "Just Now" could not be found in the language file.
DEBUG - 2020-10-05 19:21:20 --> The phrase "Just Now" could not be found in the language file.
DEBUG - 2020-10-05 19:21:20 --> The phrase "Just Now" could not be found in the language file.
INFO - 2020-10-05 19:21:20 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-10-05 19:21:20 --> Final output sent to browser
DEBUG - 2020-10-05 19:21:20 --> Total execution time: 0.1934
INFO - 2020-10-05 19:21:23 --> Config Class Initialized
INFO - 2020-10-05 19:21:23 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:21:23 --> Hooks Class Initialized
INFO - 2020-10-05 19:21:23 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:21:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:21:23 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:21:23 --> Utf8 Class Initialized
INFO - 2020-10-05 19:21:23 --> URI Class Initialized
DEBUG - 2020-10-05 19:21:23 --> No URI present. Default controller set.
INFO - 2020-10-05 19:21:23 --> Router Class Initialized
INFO - 2020-10-05 19:21:23 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:21:23 --> Output Class Initialized
INFO - 2020-10-05 19:21:23 --> Security Class Initialized
DEBUG - 2020-10-05 19:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:21:23 --> Input Class Initialized
INFO - 2020-10-05 19:21:23 --> Language Class Initialized
INFO - 2020-10-05 19:21:23 --> Loader Class Initialized
INFO - 2020-10-05 19:21:23 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:21:23 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:21:23 --> Helper loaded: data_helper
INFO - 2020-10-05 19:21:23 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:21:23 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:21:23 --> Helper loaded: view_helper
INFO - 2020-10-05 19:21:23 --> Helper loaded: url_helper
INFO - 2020-10-05 19:21:23 --> Database Driver Class Initialized
INFO - 2020-10-05 19:21:23 --> Controller Class Initialized
INFO - 2020-10-05 19:21:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:21:23 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-10-05 19:21:23 --> The "english" language file has been loaded.
INFO - 2020-10-05 19:21:23 --> Config Class Initialized
INFO - 2020-10-05 19:21:23 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:21:23 --> Hooks Class Initialized
INFO - 2020-10-05 19:21:23 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:21:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:21:23 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:21:23 --> Utf8 Class Initialized
INFO - 2020-10-05 19:21:23 --> URI Class Initialized
DEBUG - 2020-10-05 19:21:23 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:21:23 --> Router Class Initialized
INFO - 2020-10-05 19:21:23 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:21:23 --> Output Class Initialized
INFO - 2020-10-05 19:21:23 --> Security Class Initialized
DEBUG - 2020-10-05 19:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:21:23 --> Input Class Initialized
INFO - 2020-10-05 19:21:23 --> Language Class Initialized
INFO - 2020-10-05 19:21:23 --> Loader Class Initialized
INFO - 2020-10-05 19:21:23 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:21:23 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:21:23 --> Helper loaded: data_helper
INFO - 2020-10-05 19:21:23 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:21:23 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:21:23 --> Helper loaded: view_helper
INFO - 2020-10-05 19:21:23 --> Helper loaded: url_helper
INFO - 2020-10-05 19:21:23 --> Database Driver Class Initialized
INFO - 2020-10-05 19:21:23 --> Controller Class Initialized
INFO - 2020-10-05 19:21:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:21:23 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:21:23 --> Plain_Model class loaded
INFO - 2020-10-05 19:21:23 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:21:23 --> The "english" language file has been loaded.
INFO - 2020-10-05 19:21:23 --> Model "Labels_model" initialized
INFO - 2020-10-05 19:21:23 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-10-05 19:21:23 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-10-05 19:21:23 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-10-05 19:21:23 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-10-05 19:21:23 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-10-05 19:21:23 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-10-05 19:21:23 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-10-05 19:21:23 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-10-05 19:21:23 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-10-05 19:21:23 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-10-05 19:21:23 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-10-05 19:21:23 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-10-05 19:21:23 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-10-05 19:21:23 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-10-05 19:21:23 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-10-05 19:21:23 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-10-05 19:21:23 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-10-05 19:21:23 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-10-05 19:21:23 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-10-05 19:21:23 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-10-05 19:21:23 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-10-05 19:21:23 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-10-05 19:21:23 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-10-05 19:21:23 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-10-05 19:21:23 --> The phrase "Note: HTML export is compatible with Pocket, Delicious, Pinboard, and others." could not be found in the language file.
DEBUG - 2020-10-05 19:21:23 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-10-05 19:21:23 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-10-05 19:21:23 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-10-05 19:21:23 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-10-05 19:21:23 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-10-05 19:21:23 --> Final output sent to browser
DEBUG - 2020-10-05 19:21:23 --> Total execution time: 0.2314
INFO - 2020-10-05 19:21:23 --> Config Class Initialized
INFO - 2020-10-05 19:21:23 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:21:23 --> Hooks Class Initialized
INFO - 2020-10-05 19:21:23 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:21:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:21:23 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:21:23 --> Utf8 Class Initialized
INFO - 2020-10-05 19:21:23 --> URI Class Initialized
DEBUG - 2020-10-05 19:21:23 --> Validating request for /controllers/Custom.php
INFO - 2020-10-05 19:21:23 --> Plain_Exceptions Class Initialized
ERROR - 2020-10-05 19:21:23 --> 404 Page Not Found: custom
INFO - 2020-10-05 19:21:46 --> Config Class Initialized
INFO - 2020-10-05 19:21:46 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:21:46 --> Hooks Class Initialized
INFO - 2020-10-05 19:21:46 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:21:46 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:21:46 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:21:46 --> Utf8 Class Initialized
INFO - 2020-10-05 19:21:46 --> URI Class Initialized
DEBUG - 2020-10-05 19:21:46 --> Validating request for /controllers/Export.php
INFO - 2020-10-05 19:21:46 --> Router Class Initialized
INFO - 2020-10-05 19:21:46 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:21:46 --> Output Class Initialized
INFO - 2020-10-05 19:21:46 --> Security Class Initialized
DEBUG - 2020-10-05 19:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:21:46 --> Input Class Initialized
INFO - 2020-10-05 19:21:46 --> Language Class Initialized
INFO - 2020-10-05 19:21:46 --> Loader Class Initialized
INFO - 2020-10-05 19:21:46 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:21:46 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:21:46 --> Helper loaded: data_helper
INFO - 2020-10-05 19:21:46 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:21:46 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:21:46 --> Helper loaded: view_helper
INFO - 2020-10-05 19:21:46 --> Helper loaded: url_helper
INFO - 2020-10-05 19:21:46 --> Database Driver Class Initialized
INFO - 2020-10-05 19:21:46 --> Controller Class Initialized
INFO - 2020-10-05 19:21:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:21:46 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-10-05 19:21:46 --> The "english" language file has been loaded.
INFO - 2020-10-05 19:21:46 --> Plain_Model class loaded
INFO - 2020-10-05 19:21:46 --> Model "Users_To_Marks_model" initialized
INFO - 2020-10-05 19:21:46 --> Final output sent to browser
DEBUG - 2020-10-05 19:21:46 --> Total execution time: 0.1261
INFO - 2020-10-05 19:22:13 --> Config Class Initialized
INFO - 2020-10-05 19:22:13 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:22:13 --> Hooks Class Initialized
INFO - 2020-10-05 19:22:13 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:22:13 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:22:13 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:22:13 --> Utf8 Class Initialized
INFO - 2020-10-05 19:22:13 --> URI Class Initialized
DEBUG - 2020-10-05 19:22:13 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:22:13 --> Router Class Initialized
INFO - 2020-10-05 19:22:13 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:22:13 --> Output Class Initialized
INFO - 2020-10-05 19:22:13 --> Security Class Initialized
DEBUG - 2020-10-05 19:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:22:13 --> Input Class Initialized
INFO - 2020-10-05 19:22:13 --> Language Class Initialized
INFO - 2020-10-05 19:22:13 --> Loader Class Initialized
INFO - 2020-10-05 19:22:13 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:22:13 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:22:13 --> Helper loaded: data_helper
INFO - 2020-10-05 19:22:13 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:22:13 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:22:13 --> Helper loaded: view_helper
INFO - 2020-10-05 19:22:13 --> Helper loaded: url_helper
INFO - 2020-10-05 19:22:13 --> Database Driver Class Initialized
INFO - 2020-10-05 19:22:13 --> Controller Class Initialized
INFO - 2020-10-05 19:22:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:22:13 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:22:13 --> Plain_Model class loaded
INFO - 2020-10-05 19:22:13 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:22:13 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:22:13 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-10-05 19:22:13 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-10-05 19:22:13 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-10-05 19:22:13 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-10-05 19:22:13 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-10-05 19:22:13 --> Final output sent to browser
DEBUG - 2020-10-05 19:22:13 --> Total execution time: 0.1346
INFO - 2020-10-05 19:22:19 --> Config Class Initialized
INFO - 2020-10-05 19:22:19 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:22:19 --> Hooks Class Initialized
INFO - 2020-10-05 19:22:19 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:22:19 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:22:19 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:22:19 --> Utf8 Class Initialized
INFO - 2020-10-05 19:22:19 --> URI Class Initialized
DEBUG - 2020-10-05 19:22:19 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:22:19 --> Router Class Initialized
INFO - 2020-10-05 19:22:19 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:22:19 --> Output Class Initialized
INFO - 2020-10-05 19:22:19 --> Security Class Initialized
DEBUG - 2020-10-05 19:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:22:19 --> Input Class Initialized
INFO - 2020-10-05 19:22:19 --> Language Class Initialized
INFO - 2020-10-05 19:22:19 --> Loader Class Initialized
INFO - 2020-10-05 19:22:19 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:22:19 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:22:19 --> Helper loaded: data_helper
INFO - 2020-10-05 19:22:19 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:22:19 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:22:19 --> Helper loaded: view_helper
INFO - 2020-10-05 19:22:19 --> Helper loaded: url_helper
INFO - 2020-10-05 19:22:19 --> Database Driver Class Initialized
INFO - 2020-10-05 19:22:19 --> Controller Class Initialized
INFO - 2020-10-05 19:22:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:22:19 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:22:19 --> Plain_Model class loaded
INFO - 2020-10-05 19:22:19 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:22:19 --> The "english" language file has been loaded.
INFO - 2020-10-05 19:22:19 --> Model "Labels_model" initialized
INFO - 2020-10-05 19:22:19 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-10-05 19:22:19 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-10-05 19:22:19 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-10-05 19:22:19 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-10-05 19:22:19 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-10-05 19:22:19 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-10-05 19:22:19 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-10-05 19:22:19 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-10-05 19:22:19 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-10-05 19:22:19 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-10-05 19:22:19 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-10-05 19:22:19 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-10-05 19:22:19 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-10-05 19:22:19 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-10-05 19:22:19 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-10-05 19:22:19 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-10-05 19:22:19 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-10-05 19:22:19 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-10-05 19:22:19 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-10-05 19:22:19 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-10-05 19:22:19 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-10-05 19:22:19 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-10-05 19:22:19 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-10-05 19:22:19 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-10-05 19:22:19 --> The phrase "Note: HTML export is compatible with Pocket, Delicious, Pinboard, and others." could not be found in the language file.
DEBUG - 2020-10-05 19:22:19 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-10-05 19:22:19 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-10-05 19:22:19 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-10-05 19:22:19 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-10-05 19:22:19 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-10-05 19:22:19 --> Final output sent to browser
DEBUG - 2020-10-05 19:22:19 --> Total execution time: 0.2054
INFO - 2020-10-05 19:22:19 --> Config Class Initialized
INFO - 2020-10-05 19:22:19 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:22:19 --> Hooks Class Initialized
INFO - 2020-10-05 19:22:19 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:22:19 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:22:19 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:22:19 --> Utf8 Class Initialized
INFO - 2020-10-05 19:22:19 --> URI Class Initialized
DEBUG - 2020-10-05 19:22:19 --> Validating request for /controllers/Custom.php
INFO - 2020-10-05 19:22:19 --> Plain_Exceptions Class Initialized
ERROR - 2020-10-05 19:22:19 --> 404 Page Not Found: custom
INFO - 2020-10-05 19:22:21 --> Config Class Initialized
INFO - 2020-10-05 19:22:21 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:22:21 --> Hooks Class Initialized
INFO - 2020-10-05 19:22:21 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:22:21 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:22:21 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:22:21 --> Utf8 Class Initialized
INFO - 2020-10-05 19:22:21 --> URI Class Initialized
DEBUG - 2020-10-05 19:22:21 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:22:21 --> Router Class Initialized
INFO - 2020-10-05 19:22:21 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:22:21 --> Output Class Initialized
INFO - 2020-10-05 19:22:21 --> Security Class Initialized
DEBUG - 2020-10-05 19:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:22:21 --> Input Class Initialized
INFO - 2020-10-05 19:22:21 --> Language Class Initialized
INFO - 2020-10-05 19:22:21 --> Loader Class Initialized
INFO - 2020-10-05 19:22:21 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:22:21 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:22:21 --> Helper loaded: data_helper
INFO - 2020-10-05 19:22:21 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:22:21 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:22:21 --> Helper loaded: view_helper
INFO - 2020-10-05 19:22:21 --> Helper loaded: url_helper
INFO - 2020-10-05 19:22:21 --> Database Driver Class Initialized
INFO - 2020-10-05 19:22:21 --> Controller Class Initialized
INFO - 2020-10-05 19:22:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:22:21 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:22:21 --> Plain_Model class loaded
INFO - 2020-10-05 19:22:21 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:22:21 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:22:21 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-10-05 19:22:21 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-10-05 19:22:21 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-10-05 19:22:21 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-10-05 19:22:21 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-10-05 19:22:21 --> Final output sent to browser
DEBUG - 2020-10-05 19:22:21 --> Total execution time: 0.1297
INFO - 2020-10-05 19:22:22 --> Config Class Initialized
INFO - 2020-10-05 19:22:22 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:22:22 --> Hooks Class Initialized
INFO - 2020-10-05 19:22:22 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:22:22 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:22:22 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:22:22 --> Utf8 Class Initialized
INFO - 2020-10-05 19:22:22 --> URI Class Initialized
DEBUG - 2020-10-05 19:22:22 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:22:23 --> Router Class Initialized
INFO - 2020-10-05 19:22:23 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:22:23 --> Output Class Initialized
INFO - 2020-10-05 19:22:23 --> Security Class Initialized
DEBUG - 2020-10-05 19:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:22:23 --> Input Class Initialized
INFO - 2020-10-05 19:22:23 --> Language Class Initialized
INFO - 2020-10-05 19:22:23 --> Loader Class Initialized
INFO - 2020-10-05 19:22:23 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:22:23 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:22:23 --> Helper loaded: data_helper
INFO - 2020-10-05 19:22:23 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:22:23 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:22:23 --> Helper loaded: view_helper
INFO - 2020-10-05 19:22:23 --> Helper loaded: url_helper
INFO - 2020-10-05 19:22:23 --> Database Driver Class Initialized
INFO - 2020-10-05 19:22:23 --> Controller Class Initialized
INFO - 2020-10-05 19:22:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:22:23 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:22:23 --> Plain_Model class loaded
INFO - 2020-10-05 19:22:23 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:22:23 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:22:23 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-10-05 19:22:23 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-10-05 19:22:23 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-10-05 19:22:23 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-10-05 19:22:23 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-10-05 19:22:23 --> Final output sent to browser
DEBUG - 2020-10-05 19:22:23 --> Total execution time: 0.1385
INFO - 2020-10-05 19:22:24 --> Config Class Initialized
INFO - 2020-10-05 19:22:24 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:22:24 --> Hooks Class Initialized
INFO - 2020-10-05 19:22:24 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:22:24 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:22:24 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:22:24 --> Utf8 Class Initialized
INFO - 2020-10-05 19:22:24 --> URI Class Initialized
DEBUG - 2020-10-05 19:22:24 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:22:24 --> Router Class Initialized
INFO - 2020-10-05 19:22:24 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:22:24 --> Output Class Initialized
INFO - 2020-10-05 19:22:24 --> Security Class Initialized
DEBUG - 2020-10-05 19:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:22:24 --> Input Class Initialized
INFO - 2020-10-05 19:22:24 --> Language Class Initialized
INFO - 2020-10-05 19:22:24 --> Loader Class Initialized
INFO - 2020-10-05 19:22:24 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:22:24 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:22:24 --> Helper loaded: data_helper
INFO - 2020-10-05 19:22:24 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:22:24 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:22:24 --> Helper loaded: view_helper
INFO - 2020-10-05 19:22:24 --> Helper loaded: url_helper
INFO - 2020-10-05 19:22:24 --> Database Driver Class Initialized
INFO - 2020-10-05 19:22:24 --> Controller Class Initialized
INFO - 2020-10-05 19:22:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:22:24 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:22:24 --> Plain_Model class loaded
INFO - 2020-10-05 19:22:24 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:22:24 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:22:24 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-10-05 19:22:24 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-10-05 19:22:24 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-10-05 19:22:24 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-10-05 19:22:24 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-10-05 19:22:24 --> Final output sent to browser
DEBUG - 2020-10-05 19:22:24 --> Total execution time: 0.1407
INFO - 2020-10-05 19:24:59 --> Config Class Initialized
INFO - 2020-10-05 19:24:59 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:24:59 --> Hooks Class Initialized
INFO - 2020-10-05 19:24:59 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:24:59 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:24:59 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:24:59 --> Utf8 Class Initialized
INFO - 2020-10-05 19:24:59 --> URI Class Initialized
DEBUG - 2020-10-05 19:24:59 --> No URI present. Default controller set.
INFO - 2020-10-05 19:24:59 --> Router Class Initialized
INFO - 2020-10-05 19:24:59 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:24:59 --> Output Class Initialized
INFO - 2020-10-05 19:24:59 --> Security Class Initialized
DEBUG - 2020-10-05 19:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:24:59 --> Input Class Initialized
INFO - 2020-10-05 19:24:59 --> Language Class Initialized
INFO - 2020-10-05 19:24:59 --> Loader Class Initialized
INFO - 2020-10-05 19:24:59 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:24:59 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:24:59 --> Helper loaded: data_helper
INFO - 2020-10-05 19:24:59 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:24:59 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:24:59 --> Helper loaded: view_helper
INFO - 2020-10-05 19:24:59 --> Helper loaded: url_helper
INFO - 2020-10-05 19:24:59 --> Database Driver Class Initialized
INFO - 2020-10-05 19:24:59 --> Controller Class Initialized
INFO - 2020-10-05 19:24:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:24:59 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-10-05 19:24:59 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:24:59 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 19:24:59 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:24:59 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 19:24:59 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:24:59 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:24:59 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:24:59 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 19:24:59 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-10-05 19:24:59 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 19:24:59 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-10-05 19:24:59 --> Final output sent to browser
DEBUG - 2020-10-05 19:24:59 --> Total execution time: 0.1396
INFO - 2020-10-05 19:30:00 --> Config Class Initialized
INFO - 2020-10-05 19:30:00 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:30:00 --> Hooks Class Initialized
INFO - 2020-10-05 19:30:00 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:30:00 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:30:00 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:30:00 --> Utf8 Class Initialized
INFO - 2020-10-05 19:30:00 --> URI Class Initialized
DEBUG - 2020-10-05 19:30:00 --> No URI present. Default controller set.
INFO - 2020-10-05 19:30:00 --> Router Class Initialized
INFO - 2020-10-05 19:30:00 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:30:00 --> Output Class Initialized
INFO - 2020-10-05 19:30:00 --> Security Class Initialized
DEBUG - 2020-10-05 19:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:30:00 --> Input Class Initialized
INFO - 2020-10-05 19:30:00 --> Language Class Initialized
INFO - 2020-10-05 19:30:00 --> Loader Class Initialized
INFO - 2020-10-05 19:30:00 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:30:00 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:30:00 --> Helper loaded: data_helper
INFO - 2020-10-05 19:30:00 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:30:00 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:30:00 --> Helper loaded: view_helper
INFO - 2020-10-05 19:30:00 --> Helper loaded: url_helper
INFO - 2020-10-05 19:30:00 --> Database Driver Class Initialized
INFO - 2020-10-05 19:30:00 --> Controller Class Initialized
INFO - 2020-10-05 19:30:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:30:00 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-10-05 19:30:00 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:30:00 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 19:30:00 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:30:00 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 19:30:00 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:30:00 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:30:00 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:30:00 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 19:30:00 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-10-05 19:30:00 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 19:30:00 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-10-05 19:30:00 --> Final output sent to browser
DEBUG - 2020-10-05 19:30:00 --> Total execution time: 0.1348
INFO - 2020-10-05 19:35:00 --> Config Class Initialized
INFO - 2020-10-05 19:35:00 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:35:00 --> Hooks Class Initialized
INFO - 2020-10-05 19:35:00 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:35:00 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:35:00 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:35:00 --> Utf8 Class Initialized
INFO - 2020-10-05 19:35:00 --> URI Class Initialized
DEBUG - 2020-10-05 19:35:00 --> No URI present. Default controller set.
INFO - 2020-10-05 19:35:00 --> Router Class Initialized
INFO - 2020-10-05 19:35:00 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:35:00 --> Output Class Initialized
INFO - 2020-10-05 19:35:00 --> Security Class Initialized
DEBUG - 2020-10-05 19:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:35:00 --> Input Class Initialized
INFO - 2020-10-05 19:35:00 --> Language Class Initialized
INFO - 2020-10-05 19:35:00 --> Loader Class Initialized
INFO - 2020-10-05 19:35:00 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:35:00 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:35:00 --> Helper loaded: data_helper
INFO - 2020-10-05 19:35:00 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:35:00 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:35:00 --> Helper loaded: view_helper
INFO - 2020-10-05 19:35:00 --> Helper loaded: url_helper
INFO - 2020-10-05 19:35:00 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:35:00 --> Database Driver Class Initialized
INFO - 2020-10-05 19:35:00 --> Controller Class Initialized
INFO - 2020-10-05 19:35:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:35:00 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:35:00 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:35:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 19:35:00 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:35:00 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:35:00 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:35:00 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 19:35:00 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:35:00 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 19:35:00 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:35:00 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:35:00 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:35:00 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 19:35:00 --> The phrase "Need to Sign In?" could not be found in the language file.
DEBUG - 2020-10-05 19:35:00 --> The phrase "What is Unmark?" could not be found in the language file.
DEBUG - 2020-10-05 19:35:00 --> The phrase "What is Unmark?" could not be found in the language file.
INFO - 2020-10-05 19:35:00 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 19:35:00 --> File loaded: /var/www/html/custom/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 19:35:00 --> File loaded: /var/www/html/custom/views/welcome.php
INFO - 2020-10-05 19:35:00 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:35:00 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:35:00 --> Final output sent to browser
DEBUG - 2020-10-05 19:35:00 --> Total execution time: 0.1689
INFO - 2020-10-05 19:38:30 --> Config Class Initialized
INFO - 2020-10-05 19:38:30 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:38:30 --> Hooks Class Initialized
INFO - 2020-10-05 19:38:30 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:38:30 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:38:30 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:38:30 --> Utf8 Class Initialized
INFO - 2020-10-05 19:38:30 --> URI Class Initialized
DEBUG - 2020-10-05 19:38:30 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:38:30 --> Router Class Initialized
INFO - 2020-10-05 19:38:30 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:38:30 --> Output Class Initialized
INFO - 2020-10-05 19:38:30 --> Security Class Initialized
DEBUG - 2020-10-05 19:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:38:30 --> Input Class Initialized
INFO - 2020-10-05 19:38:30 --> Language Class Initialized
INFO - 2020-10-05 19:38:30 --> Loader Class Initialized
INFO - 2020-10-05 19:38:30 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:38:30 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:38:30 --> Helper loaded: data_helper
INFO - 2020-10-05 19:38:30 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:38:30 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:38:30 --> Helper loaded: view_helper
INFO - 2020-10-05 19:38:30 --> Helper loaded: url_helper
INFO - 2020-10-05 19:38:30 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:38:30 --> Database Driver Class Initialized
INFO - 2020-10-05 19:38:30 --> Controller Class Initialized
INFO - 2020-10-05 19:38:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:38:30 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:38:30 --> Plain_Model class loaded
INFO - 2020-10-05 19:38:30 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:38:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:38:30 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:38:30 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:38:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:38:30 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:38:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:38:30 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:38:30 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:38:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:38:30 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

INFO - 2020-10-05 19:38:30 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:38:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:38:30 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

ERROR - 2020-10-05 19:38:30 --> Query error: Table 'unmark.user_settings' doesn't exist - Invalid query: SELECT k,v,category FROM `user_settings` WHERE user_id = '1' ORDER BY created_on ASC
DEBUG - 2020-10-05 19:38:30 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-05 19:38:30 --> Plain_Exceptions Class Initialized
INFO - 2020-10-05 19:40:00 --> Config Class Initialized
INFO - 2020-10-05 19:40:00 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:40:00 --> Hooks Class Initialized
INFO - 2020-10-05 19:40:00 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:40:00 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:40:00 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:40:00 --> Utf8 Class Initialized
INFO - 2020-10-05 19:40:00 --> URI Class Initialized
DEBUG - 2020-10-05 19:40:00 --> No URI present. Default controller set.
INFO - 2020-10-05 19:40:00 --> Router Class Initialized
INFO - 2020-10-05 19:40:00 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:40:00 --> Output Class Initialized
INFO - 2020-10-05 19:40:00 --> Security Class Initialized
DEBUG - 2020-10-05 19:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:40:00 --> Input Class Initialized
INFO - 2020-10-05 19:40:00 --> Language Class Initialized
INFO - 2020-10-05 19:40:01 --> Loader Class Initialized
INFO - 2020-10-05 19:40:01 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:40:01 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:40:01 --> Helper loaded: data_helper
INFO - 2020-10-05 19:40:01 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:40:01 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:40:01 --> Helper loaded: view_helper
INFO - 2020-10-05 19:40:01 --> Helper loaded: url_helper
INFO - 2020-10-05 19:40:01 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:40:01 --> Database Driver Class Initialized
INFO - 2020-10-05 19:40:01 --> Controller Class Initialized
INFO - 2020-10-05 19:40:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:40:01 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:40:01 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:40:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 19:40:01 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:40:01 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:40:01 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:40:01 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 19:40:01 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:40:01 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 19:40:01 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:40:01 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:40:01 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:40:01 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 19:40:01 --> The phrase "Need to Sign In?" could not be found in the language file.
DEBUG - 2020-10-05 19:40:01 --> The phrase "What is Unmark?" could not be found in the language file.
DEBUG - 2020-10-05 19:40:01 --> The phrase "What is Unmark?" could not be found in the language file.
INFO - 2020-10-05 19:40:01 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 19:40:01 --> File loaded: /var/www/html/custom/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 19:40:01 --> File loaded: /var/www/html/custom/views/welcome.php
INFO - 2020-10-05 19:40:01 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:40:01 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:40:01 --> Final output sent to browser
DEBUG - 2020-10-05 19:40:01 --> Total execution time: 0.1823
INFO - 2020-10-05 19:40:07 --> Config Class Initialized
INFO - 2020-10-05 19:40:07 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:40:07 --> Hooks Class Initialized
INFO - 2020-10-05 19:40:07 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:40:07 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:40:07 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:40:07 --> Utf8 Class Initialized
INFO - 2020-10-05 19:40:07 --> URI Class Initialized
DEBUG - 2020-10-05 19:40:07 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:40:07 --> Router Class Initialized
INFO - 2020-10-05 19:40:07 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:40:07 --> Output Class Initialized
INFO - 2020-10-05 19:40:07 --> Security Class Initialized
DEBUG - 2020-10-05 19:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:40:07 --> Input Class Initialized
INFO - 2020-10-05 19:40:07 --> Language Class Initialized
INFO - 2020-10-05 19:40:07 --> Loader Class Initialized
INFO - 2020-10-05 19:40:07 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:40:07 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:40:07 --> Helper loaded: data_helper
INFO - 2020-10-05 19:40:07 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:40:07 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:40:07 --> Helper loaded: view_helper
INFO - 2020-10-05 19:40:07 --> Helper loaded: url_helper
INFO - 2020-10-05 19:40:07 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:40:07 --> Database Driver Class Initialized
INFO - 2020-10-05 19:40:07 --> Controller Class Initialized
INFO - 2020-10-05 19:40:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:40:07 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:40:07 --> Plain_Model class loaded
INFO - 2020-10-05 19:40:07 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:40:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:40:07 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:40:07 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:40:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:40:07 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:40:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:40:07 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:40:07 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:40:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:40:07 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

INFO - 2020-10-05 19:40:07 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:40:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:40:07 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

ERROR - 2020-10-05 19:40:07 --> Query error: Table 'unmark.user_settings' doesn't exist - Invalid query: SELECT k,v,category FROM `user_settings` WHERE user_id = '1' ORDER BY created_on ASC
DEBUG - 2020-10-05 19:40:07 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-05 19:40:07 --> Plain_Exceptions Class Initialized
INFO - 2020-10-05 19:40:09 --> Config Class Initialized
INFO - 2020-10-05 19:40:09 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:40:09 --> Hooks Class Initialized
INFO - 2020-10-05 19:40:09 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:40:09 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:40:09 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:40:09 --> Utf8 Class Initialized
INFO - 2020-10-05 19:40:09 --> URI Class Initialized
DEBUG - 2020-10-05 19:40:09 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:40:09 --> Router Class Initialized
INFO - 2020-10-05 19:40:09 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:40:09 --> Output Class Initialized
INFO - 2020-10-05 19:40:09 --> Security Class Initialized
DEBUG - 2020-10-05 19:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:40:09 --> Input Class Initialized
INFO - 2020-10-05 19:40:09 --> Language Class Initialized
INFO - 2020-10-05 19:40:09 --> Loader Class Initialized
INFO - 2020-10-05 19:40:09 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:40:09 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:40:09 --> Helper loaded: data_helper
INFO - 2020-10-05 19:40:09 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:40:09 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:40:09 --> Helper loaded: view_helper
INFO - 2020-10-05 19:40:09 --> Helper loaded: url_helper
INFO - 2020-10-05 19:40:09 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:40:09 --> Database Driver Class Initialized
INFO - 2020-10-05 19:40:09 --> Controller Class Initialized
INFO - 2020-10-05 19:40:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:40:09 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:40:09 --> Plain_Model class loaded
INFO - 2020-10-05 19:40:09 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:40:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:40:09 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:40:09 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:40:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:40:09 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:40:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:40:09 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:40:09 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:40:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:40:09 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

INFO - 2020-10-05 19:40:09 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:40:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:40:09 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

ERROR - 2020-10-05 19:40:09 --> Query error: Table 'unmark.user_settings' doesn't exist - Invalid query: SELECT k,v,category FROM `user_settings` WHERE user_id = '1' ORDER BY created_on ASC
DEBUG - 2020-10-05 19:40:09 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-05 19:40:09 --> Plain_Exceptions Class Initialized
INFO - 2020-10-05 19:40:53 --> Config Class Initialized
INFO - 2020-10-05 19:40:53 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:40:53 --> Hooks Class Initialized
INFO - 2020-10-05 19:40:53 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:40:53 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:40:53 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:40:53 --> Utf8 Class Initialized
INFO - 2020-10-05 19:40:53 --> URI Class Initialized
DEBUG - 2020-10-05 19:40:53 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:40:53 --> Router Class Initialized
INFO - 2020-10-05 19:40:53 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:40:53 --> Output Class Initialized
INFO - 2020-10-05 19:40:53 --> Security Class Initialized
DEBUG - 2020-10-05 19:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:40:53 --> Input Class Initialized
INFO - 2020-10-05 19:40:53 --> Language Class Initialized
INFO - 2020-10-05 19:40:53 --> Loader Class Initialized
INFO - 2020-10-05 19:40:53 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:40:53 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:40:53 --> Helper loaded: data_helper
INFO - 2020-10-05 19:40:53 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:40:53 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:40:53 --> Helper loaded: view_helper
INFO - 2020-10-05 19:40:53 --> Helper loaded: url_helper
INFO - 2020-10-05 19:40:53 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:40:53 --> Database Driver Class Initialized
INFO - 2020-10-05 19:40:53 --> Controller Class Initialized
INFO - 2020-10-05 19:40:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:40:53 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:40:53 --> Config Class Initialized
INFO - 2020-10-05 19:40:53 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:40:53 --> Hooks Class Initialized
INFO - 2020-10-05 19:40:53 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:40:53 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:40:53 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:40:53 --> Utf8 Class Initialized
INFO - 2020-10-05 19:40:53 --> URI Class Initialized
DEBUG - 2020-10-05 19:40:53 --> No URI present. Default controller set.
INFO - 2020-10-05 19:40:53 --> Router Class Initialized
INFO - 2020-10-05 19:40:53 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:40:53 --> Output Class Initialized
INFO - 2020-10-05 19:40:53 --> Security Class Initialized
DEBUG - 2020-10-05 19:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:40:53 --> Input Class Initialized
INFO - 2020-10-05 19:40:53 --> Language Class Initialized
INFO - 2020-10-05 19:40:53 --> Loader Class Initialized
INFO - 2020-10-05 19:40:53 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:40:53 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:40:53 --> Helper loaded: data_helper
INFO - 2020-10-05 19:40:53 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:40:53 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:40:53 --> Helper loaded: view_helper
INFO - 2020-10-05 19:40:53 --> Helper loaded: url_helper
INFO - 2020-10-05 19:40:53 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:40:53 --> Database Driver Class Initialized
INFO - 2020-10-05 19:40:53 --> Controller Class Initialized
INFO - 2020-10-05 19:40:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:40:53 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:40:53 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:40:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 19:40:53 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:40:53 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:40:53 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:40:53 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 19:40:53 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:40:53 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 19:40:53 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:40:53 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:40:53 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:40:53 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 19:40:53 --> The phrase "Need to Sign In?" could not be found in the language file.
DEBUG - 2020-10-05 19:40:53 --> The phrase "What is Unmark?" could not be found in the language file.
DEBUG - 2020-10-05 19:40:53 --> The phrase "What is Unmark?" could not be found in the language file.
INFO - 2020-10-05 19:40:53 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 19:40:53 --> File loaded: /var/www/html/custom/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 19:40:53 --> File loaded: /var/www/html/custom/views/welcome.php
INFO - 2020-10-05 19:40:53 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:40:53 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:40:53 --> Final output sent to browser
DEBUG - 2020-10-05 19:40:53 --> Total execution time: 0.1852
INFO - 2020-10-05 19:40:54 --> Config Class Initialized
INFO - 2020-10-05 19:40:54 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:40:54 --> Hooks Class Initialized
INFO - 2020-10-05 19:40:54 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:40:54 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:40:54 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:40:54 --> Utf8 Class Initialized
INFO - 2020-10-05 19:40:54 --> URI Class Initialized
DEBUG - 2020-10-05 19:40:54 --> Validating request for /controllers/Custom.php
INFO - 2020-10-05 19:40:54 --> Plain_Exceptions Class Initialized
ERROR - 2020-10-05 19:40:54 --> 404 Page Not Found: custom
INFO - 2020-10-05 19:41:02 --> Config Class Initialized
INFO - 2020-10-05 19:41:02 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:41:02 --> Hooks Class Initialized
INFO - 2020-10-05 19:41:02 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:41:02 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:41:02 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:41:02 --> Utf8 Class Initialized
INFO - 2020-10-05 19:41:02 --> URI Class Initialized
DEBUG - 2020-10-05 19:41:02 --> Validating request for /controllers/Login.php
INFO - 2020-10-05 19:41:02 --> Router Class Initialized
INFO - 2020-10-05 19:41:02 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:41:02 --> Output Class Initialized
INFO - 2020-10-05 19:41:02 --> Security Class Initialized
DEBUG - 2020-10-05 19:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:41:02 --> Input Class Initialized
INFO - 2020-10-05 19:41:02 --> Language Class Initialized
INFO - 2020-10-05 19:41:02 --> Loader Class Initialized
INFO - 2020-10-05 19:41:02 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:41:02 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:41:02 --> Helper loaded: data_helper
INFO - 2020-10-05 19:41:02 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:41:02 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:41:02 --> Helper loaded: view_helper
INFO - 2020-10-05 19:41:02 --> Helper loaded: url_helper
INFO - 2020-10-05 19:41:02 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:41:02 --> Database Driver Class Initialized
INFO - 2020-10-05 19:41:02 --> Controller Class Initialized
INFO - 2020-10-05 19:41:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:41:02 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:41:02 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:41:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 19:41:02 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:41:02 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:41:02 --> The "english" language file has been loaded.
INFO - 2020-10-05 19:41:02 --> Plain_Model class loaded
INFO - 2020-10-05 19:41:02 --> Model "Users_model" initialized
DEBUG - 2020-10-05 19:41:02 --> The phrase "Your password is incorrect. Please try again." could not be found in the language file.
INFO - 2020-10-05 19:41:02 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-10-05 19:41:02 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:41:02 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:41:02 --> Final output sent to browser
DEBUG - 2020-10-05 19:41:02 --> Total execution time: 0.1777
INFO - 2020-10-05 19:41:08 --> Config Class Initialized
INFO - 2020-10-05 19:41:08 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:41:08 --> Hooks Class Initialized
INFO - 2020-10-05 19:41:08 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:41:08 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:41:08 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:41:08 --> Utf8 Class Initialized
INFO - 2020-10-05 19:41:08 --> URI Class Initialized
DEBUG - 2020-10-05 19:41:08 --> Validating request for /controllers/Login.php
INFO - 2020-10-05 19:41:08 --> Router Class Initialized
INFO - 2020-10-05 19:41:08 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:41:08 --> Output Class Initialized
INFO - 2020-10-05 19:41:08 --> Security Class Initialized
DEBUG - 2020-10-05 19:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:41:08 --> Input Class Initialized
INFO - 2020-10-05 19:41:08 --> Language Class Initialized
INFO - 2020-10-05 19:41:08 --> Loader Class Initialized
INFO - 2020-10-05 19:41:08 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:41:08 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:41:08 --> Helper loaded: data_helper
INFO - 2020-10-05 19:41:08 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:41:08 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:41:08 --> Helper loaded: view_helper
INFO - 2020-10-05 19:41:08 --> Helper loaded: url_helper
INFO - 2020-10-05 19:41:08 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:41:08 --> Database Driver Class Initialized
INFO - 2020-10-05 19:41:08 --> Controller Class Initialized
INFO - 2020-10-05 19:41:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:41:08 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:41:08 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 19:41:08 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:41:08 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:41:08 --> The "english" language file has been loaded.
INFO - 2020-10-05 19:41:08 --> Plain_Model class loaded
INFO - 2020-10-05 19:41:08 --> Model "Users_model" initialized
INFO - 2020-10-05 19:41:08 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-10-05 19:41:08 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:41:08 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:41:08 --> Final output sent to browser
DEBUG - 2020-10-05 19:41:08 --> Total execution time: 0.1580
INFO - 2020-10-05 19:41:10 --> Config Class Initialized
INFO - 2020-10-05 19:41:10 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:41:10 --> Hooks Class Initialized
INFO - 2020-10-05 19:41:10 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:41:10 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:41:10 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:41:10 --> Utf8 Class Initialized
INFO - 2020-10-05 19:41:10 --> URI Class Initialized
DEBUG - 2020-10-05 19:41:10 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:41:10 --> Router Class Initialized
INFO - 2020-10-05 19:41:10 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:41:10 --> Output Class Initialized
INFO - 2020-10-05 19:41:10 --> Security Class Initialized
DEBUG - 2020-10-05 19:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:41:10 --> Input Class Initialized
INFO - 2020-10-05 19:41:10 --> Language Class Initialized
INFO - 2020-10-05 19:41:10 --> Loader Class Initialized
INFO - 2020-10-05 19:41:10 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:41:10 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:41:10 --> Helper loaded: data_helper
INFO - 2020-10-05 19:41:10 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:41:10 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:41:10 --> Helper loaded: view_helper
INFO - 2020-10-05 19:41:10 --> Helper loaded: url_helper
INFO - 2020-10-05 19:41:10 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:41:10 --> Database Driver Class Initialized
INFO - 2020-10-05 19:41:10 --> Controller Class Initialized
INFO - 2020-10-05 19:41:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:41:10 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:41:10 --> Plain_Model class loaded
INFO - 2020-10-05 19:41:10 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:41:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:10 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:10 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:41:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:10 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:10 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:10 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:41:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:10 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

INFO - 2020-10-05 19:41:10 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:41:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:10 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

ERROR - 2020-10-05 19:41:10 --> Query error: Table 'unmark.user_settings' doesn't exist - Invalid query: SELECT k,v,category FROM `user_settings` WHERE user_id = '1' ORDER BY created_on ASC
DEBUG - 2020-10-05 19:41:10 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-05 19:41:10 --> Plain_Exceptions Class Initialized
INFO - 2020-10-05 19:41:16 --> Config Class Initialized
INFO - 2020-10-05 19:41:16 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:41:16 --> Hooks Class Initialized
INFO - 2020-10-05 19:41:16 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:41:16 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:41:16 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:41:16 --> Utf8 Class Initialized
INFO - 2020-10-05 19:41:16 --> URI Class Initialized
DEBUG - 2020-10-05 19:41:16 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:41:16 --> Router Class Initialized
INFO - 2020-10-05 19:41:16 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:41:16 --> Output Class Initialized
INFO - 2020-10-05 19:41:16 --> Security Class Initialized
DEBUG - 2020-10-05 19:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:41:16 --> Input Class Initialized
INFO - 2020-10-05 19:41:16 --> Language Class Initialized
INFO - 2020-10-05 19:41:16 --> Loader Class Initialized
INFO - 2020-10-05 19:41:16 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:41:16 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:41:16 --> Helper loaded: data_helper
INFO - 2020-10-05 19:41:16 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:41:16 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:41:16 --> Helper loaded: view_helper
INFO - 2020-10-05 19:41:16 --> Helper loaded: url_helper
INFO - 2020-10-05 19:41:16 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:41:16 --> Database Driver Class Initialized
INFO - 2020-10-05 19:41:16 --> Controller Class Initialized
INFO - 2020-10-05 19:41:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:41:16 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:41:16 --> Plain_Model class loaded
INFO - 2020-10-05 19:41:16 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:41:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:16 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:16 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:41:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:16 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:16 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:16 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:41:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:16 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

INFO - 2020-10-05 19:41:16 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:41:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:16 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

ERROR - 2020-10-05 19:41:16 --> Query error: Table 'unmark.user_settings' doesn't exist - Invalid query: SELECT k,v,category FROM `user_settings` WHERE user_id = '1' ORDER BY created_on ASC
DEBUG - 2020-10-05 19:41:16 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-05 19:41:16 --> Plain_Exceptions Class Initialized
INFO - 2020-10-05 19:41:17 --> Config Class Initialized
INFO - 2020-10-05 19:41:17 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:41:17 --> Hooks Class Initialized
INFO - 2020-10-05 19:41:17 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:41:17 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:41:17 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:41:17 --> Utf8 Class Initialized
INFO - 2020-10-05 19:41:17 --> URI Class Initialized
DEBUG - 2020-10-05 19:41:17 --> No URI present. Default controller set.
INFO - 2020-10-05 19:41:17 --> Router Class Initialized
INFO - 2020-10-05 19:41:17 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:41:17 --> Output Class Initialized
INFO - 2020-10-05 19:41:17 --> Security Class Initialized
DEBUG - 2020-10-05 19:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:41:17 --> Input Class Initialized
INFO - 2020-10-05 19:41:17 --> Language Class Initialized
INFO - 2020-10-05 19:41:17 --> Loader Class Initialized
INFO - 2020-10-05 19:41:17 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:41:17 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:41:17 --> Helper loaded: data_helper
INFO - 2020-10-05 19:41:17 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:41:17 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:41:17 --> Helper loaded: view_helper
INFO - 2020-10-05 19:41:17 --> Helper loaded: url_helper
INFO - 2020-10-05 19:41:17 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:41:17 --> Database Driver Class Initialized
INFO - 2020-10-05 19:41:17 --> Controller Class Initialized
INFO - 2020-10-05 19:41:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:41:17 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:41:17 --> Plain_Model class loaded
INFO - 2020-10-05 19:41:17 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:41:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:17 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:41:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:17 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:41:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

INFO - 2020-10-05 19:41:17 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:41:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

ERROR - 2020-10-05 19:41:17 --> Query error: Table 'unmark.user_settings' doesn't exist - Invalid query: SELECT k,v,category FROM `user_settings` WHERE user_id = '1' ORDER BY created_on ASC
DEBUG - 2020-10-05 19:41:17 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-05 19:41:17 --> Plain_Exceptions Class Initialized
INFO - 2020-10-05 19:41:17 --> Config Class Initialized
INFO - 2020-10-05 19:41:17 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:41:17 --> Hooks Class Initialized
INFO - 2020-10-05 19:41:17 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:41:17 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:41:17 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:41:17 --> Utf8 Class Initialized
INFO - 2020-10-05 19:41:17 --> URI Class Initialized
DEBUG - 2020-10-05 19:41:17 --> Validating request for /controllers/Install.php
INFO - 2020-10-05 19:41:17 --> Router Class Initialized
INFO - 2020-10-05 19:41:17 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:41:17 --> Output Class Initialized
INFO - 2020-10-05 19:41:17 --> Security Class Initialized
DEBUG - 2020-10-05 19:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:41:17 --> Input Class Initialized
INFO - 2020-10-05 19:41:17 --> Language Class Initialized
INFO - 2020-10-05 19:41:17 --> Loader Class Initialized
INFO - 2020-10-05 19:41:17 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:41:17 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:41:17 --> Helper loaded: data_helper
INFO - 2020-10-05 19:41:17 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:41:17 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:41:17 --> Helper loaded: view_helper
INFO - 2020-10-05 19:41:17 --> Helper loaded: url_helper
INFO - 2020-10-05 19:41:17 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:41:17 --> Database Driver Class Initialized
INFO - 2020-10-05 19:41:17 --> Controller Class Initialized
INFO - 2020-10-05 19:41:17 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:41:17 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:41:17 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:41:17 --> The "english" language file has been loaded.
INFO - 2020-10-05 19:41:17 --> Config Class Initialized
INFO - 2020-10-05 19:41:17 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:41:17 --> Hooks Class Initialized
INFO - 2020-10-05 19:41:17 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:41:17 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:41:17 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:41:17 --> Utf8 Class Initialized
INFO - 2020-10-05 19:41:17 --> URI Class Initialized
DEBUG - 2020-10-05 19:41:17 --> No URI present. Default controller set.
INFO - 2020-10-05 19:41:17 --> Router Class Initialized
INFO - 2020-10-05 19:41:17 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:41:17 --> Output Class Initialized
INFO - 2020-10-05 19:41:17 --> Security Class Initialized
DEBUG - 2020-10-05 19:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:41:17 --> Input Class Initialized
INFO - 2020-10-05 19:41:17 --> Language Class Initialized
INFO - 2020-10-05 19:41:17 --> Loader Class Initialized
INFO - 2020-10-05 19:41:17 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:41:17 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:41:17 --> Helper loaded: data_helper
INFO - 2020-10-05 19:41:17 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:41:17 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:41:17 --> Helper loaded: view_helper
INFO - 2020-10-05 19:41:17 --> Helper loaded: url_helper
INFO - 2020-10-05 19:41:17 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:41:17 --> Database Driver Class Initialized
INFO - 2020-10-05 19:41:17 --> Controller Class Initialized
INFO - 2020-10-05 19:41:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:41:17 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:41:17 --> Plain_Model class loaded
INFO - 2020-10-05 19:41:17 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:41:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:17 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:41:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:17 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:41:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

INFO - 2020-10-05 19:41:17 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:41:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

ERROR - 2020-10-05 19:41:17 --> Query error: Table 'unmark.user_settings' doesn't exist - Invalid query: SELECT k,v,category FROM `user_settings` WHERE user_id = '1' ORDER BY created_on ASC
DEBUG - 2020-10-05 19:41:17 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-05 19:41:17 --> Plain_Exceptions Class Initialized
INFO - 2020-10-05 19:41:22 --> Config Class Initialized
INFO - 2020-10-05 19:41:22 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:41:22 --> Hooks Class Initialized
INFO - 2020-10-05 19:41:22 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:41:22 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:41:22 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:41:22 --> Utf8 Class Initialized
INFO - 2020-10-05 19:41:22 --> URI Class Initialized
DEBUG - 2020-10-05 19:41:22 --> No URI present. Default controller set.
INFO - 2020-10-05 19:41:22 --> Router Class Initialized
INFO - 2020-10-05 19:41:22 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:41:22 --> Output Class Initialized
INFO - 2020-10-05 19:41:22 --> Security Class Initialized
DEBUG - 2020-10-05 19:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:41:22 --> Input Class Initialized
INFO - 2020-10-05 19:41:22 --> Language Class Initialized
INFO - 2020-10-05 19:41:22 --> Loader Class Initialized
INFO - 2020-10-05 19:41:22 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:41:22 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:41:22 --> Helper loaded: data_helper
INFO - 2020-10-05 19:41:22 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:41:22 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:41:22 --> Helper loaded: view_helper
INFO - 2020-10-05 19:41:22 --> Helper loaded: url_helper
INFO - 2020-10-05 19:41:22 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:41:22 --> Database Driver Class Initialized
INFO - 2020-10-05 19:41:22 --> Controller Class Initialized
INFO - 2020-10-05 19:41:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:41:22 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:41:22 --> Plain_Model class loaded
INFO - 2020-10-05 19:41:22 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:41:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:22 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:41:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:22 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:41:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

INFO - 2020-10-05 19:41:22 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:41:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

ERROR - 2020-10-05 19:41:22 --> Query error: Table 'unmark.user_settings' doesn't exist - Invalid query: SELECT k,v,category FROM `user_settings` WHERE user_id = '1' ORDER BY created_on ASC
DEBUG - 2020-10-05 19:41:22 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-05 19:41:22 --> Plain_Exceptions Class Initialized
INFO - 2020-10-05 19:41:23 --> Config Class Initialized
INFO - 2020-10-05 19:41:23 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:41:23 --> Hooks Class Initialized
INFO - 2020-10-05 19:41:23 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:41:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:41:23 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:41:23 --> Utf8 Class Initialized
INFO - 2020-10-05 19:41:23 --> URI Class Initialized
DEBUG - 2020-10-05 19:41:23 --> Validating request for /controllers/Install.php
INFO - 2020-10-05 19:41:23 --> Router Class Initialized
INFO - 2020-10-05 19:41:23 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:41:23 --> Output Class Initialized
INFO - 2020-10-05 19:41:23 --> Security Class Initialized
DEBUG - 2020-10-05 19:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:41:23 --> Input Class Initialized
INFO - 2020-10-05 19:41:23 --> Language Class Initialized
INFO - 2020-10-05 19:41:23 --> Loader Class Initialized
INFO - 2020-10-05 19:41:23 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:41:23 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:41:23 --> Helper loaded: data_helper
INFO - 2020-10-05 19:41:23 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:41:23 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:41:23 --> Helper loaded: view_helper
INFO - 2020-10-05 19:41:23 --> Helper loaded: url_helper
INFO - 2020-10-05 19:41:23 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:41:23 --> Database Driver Class Initialized
INFO - 2020-10-05 19:41:23 --> Controller Class Initialized
INFO - 2020-10-05 19:41:23 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:41:23 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:41:23 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:41:23 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:41:23 --> Plain Migrations class initialized
DEBUG - 2020-10-05 19:41:23 --> Language file loaded: language/english/migration_lang.php
INFO - 2020-10-05 19:41:23 --> Database Forge Class Initialized
DEBUG - 2020-10-05 19:41:23 --> Making backup before migrating failed.
DEBUG - 2020-10-05 19:41:23 --> Making backup before migrating failed.
DEBUG - 2020-10-05 19:41:23 --> The phrase "Upgraded. Please <a href="%s">return home</a>." could not be found in the language file.
INFO - 2020-10-05 19:41:25 --> Config Class Initialized
INFO - 2020-10-05 19:41:25 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:41:25 --> Hooks Class Initialized
INFO - 2020-10-05 19:41:25 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:41:25 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:41:25 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:41:25 --> Utf8 Class Initialized
INFO - 2020-10-05 19:41:25 --> URI Class Initialized
DEBUG - 2020-10-05 19:41:25 --> No URI present. Default controller set.
INFO - 2020-10-05 19:41:25 --> Router Class Initialized
INFO - 2020-10-05 19:41:25 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:41:25 --> Output Class Initialized
INFO - 2020-10-05 19:41:25 --> Security Class Initialized
DEBUG - 2020-10-05 19:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:41:25 --> Input Class Initialized
INFO - 2020-10-05 19:41:25 --> Language Class Initialized
INFO - 2020-10-05 19:41:25 --> Loader Class Initialized
INFO - 2020-10-05 19:41:25 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:41:25 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:41:25 --> Helper loaded: data_helper
INFO - 2020-10-05 19:41:25 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:41:25 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:41:25 --> Helper loaded: view_helper
INFO - 2020-10-05 19:41:25 --> Helper loaded: url_helper
INFO - 2020-10-05 19:41:25 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:41:25 --> Database Driver Class Initialized
INFO - 2020-10-05 19:41:25 --> Controller Class Initialized
INFO - 2020-10-05 19:41:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:41:25 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:41:25 --> Plain_Model class loaded
INFO - 2020-10-05 19:41:25 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:41:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:25 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:25 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:41:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:25 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:25 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:41:25 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:41:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:25 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

INFO - 2020-10-05 19:41:25 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:41:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:41:25 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

ERROR - 2020-10-05 19:41:25 --> Query error: Table 'unmark.user_settings' doesn't exist - Invalid query: SELECT k,v,category FROM `user_settings` WHERE user_id = '1' ORDER BY created_on ASC
DEBUG - 2020-10-05 19:41:25 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-05 19:41:25 --> Plain_Exceptions Class Initialized
INFO - 2020-10-05 19:42:06 --> Config Class Initialized
INFO - 2020-10-05 19:42:06 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:42:06 --> Hooks Class Initialized
INFO - 2020-10-05 19:42:06 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:42:06 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:42:06 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:42:06 --> Utf8 Class Initialized
INFO - 2020-10-05 19:42:06 --> URI Class Initialized
DEBUG - 2020-10-05 19:42:06 --> No URI present. Default controller set.
INFO - 2020-10-05 19:42:06 --> Router Class Initialized
INFO - 2020-10-05 19:42:06 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:42:06 --> Output Class Initialized
INFO - 2020-10-05 19:42:06 --> Security Class Initialized
DEBUG - 2020-10-05 19:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:42:06 --> Input Class Initialized
INFO - 2020-10-05 19:42:06 --> Language Class Initialized
INFO - 2020-10-05 19:42:06 --> Loader Class Initialized
INFO - 2020-10-05 19:42:06 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:42:06 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:42:06 --> Helper loaded: data_helper
INFO - 2020-10-05 19:42:06 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:42:06 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:42:06 --> Helper loaded: view_helper
INFO - 2020-10-05 19:42:06 --> Helper loaded: url_helper
INFO - 2020-10-05 19:42:06 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:42:06 --> Database Driver Class Initialized
INFO - 2020-10-05 19:42:06 --> Controller Class Initialized
INFO - 2020-10-05 19:42:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:42:06 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:42:06 --> Plain_Model class loaded
INFO - 2020-10-05 19:42:06 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:42:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:42:06 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:42:06 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:42:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:42:06 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:42:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:42:06 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

DEBUG - 2020-10-05 19:42:06 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:42:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:42:06 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

INFO - 2020-10-05 19:42:06 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:42:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:42:06 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => mopsriYpdrmJy9xda0OVDsZNbrZgPfe94a652dda8982acdbbcc0553a965231
            [active] => 1
            [admin] => 0
            [created_on] => 2020-10-05 19:21:20
            [last_updated] => 2020-10-05 19:21:20
        )

)

ERROR - 2020-10-05 19:42:06 --> Query error: Table 'unmark.user_settings' doesn't exist - Invalid query: SELECT k,v,category FROM `user_settings` WHERE user_id = '1' ORDER BY created_on ASC
DEBUG - 2020-10-05 19:42:06 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-05 19:42:06 --> Plain_Exceptions Class Initialized
INFO - 2020-10-05 19:43:32 --> Config Class Initialized
INFO - 2020-10-05 19:43:32 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:43:32 --> Hooks Class Initialized
INFO - 2020-10-05 19:43:32 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:43:32 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:43:32 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:43:32 --> Utf8 Class Initialized
INFO - 2020-10-05 19:43:32 --> URI Class Initialized
DEBUG - 2020-10-05 19:43:32 --> No URI present. Default controller set.
INFO - 2020-10-05 19:43:32 --> Router Class Initialized
INFO - 2020-10-05 19:43:32 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:43:32 --> Output Class Initialized
INFO - 2020-10-05 19:43:32 --> Security Class Initialized
DEBUG - 2020-10-05 19:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:43:32 --> Input Class Initialized
INFO - 2020-10-05 19:43:32 --> Language Class Initialized
INFO - 2020-10-05 19:43:32 --> Loader Class Initialized
INFO - 2020-10-05 19:43:32 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:43:32 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:43:32 --> Helper loaded: data_helper
INFO - 2020-10-05 19:43:32 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:43:32 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:43:32 --> Helper loaded: view_helper
INFO - 2020-10-05 19:43:32 --> Helper loaded: url_helper
INFO - 2020-10-05 19:43:32 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:43:32 --> Database Driver Class Initialized
ERROR - 2020-10-05 19:43:32 --> Unable to connect to the database
DEBUG - 2020-10-05 19:43:32 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-05 19:43:32 --> Plain_Exceptions Class Initialized
INFO - 2020-10-05 19:43:38 --> Config Class Initialized
INFO - 2020-10-05 19:43:38 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:43:38 --> Hooks Class Initialized
INFO - 2020-10-05 19:43:38 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:43:38 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:43:38 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:43:38 --> Utf8 Class Initialized
INFO - 2020-10-05 19:43:38 --> URI Class Initialized
DEBUG - 2020-10-05 19:43:38 --> No URI present. Default controller set.
INFO - 2020-10-05 19:43:38 --> Router Class Initialized
INFO - 2020-10-05 19:43:38 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:43:38 --> Output Class Initialized
INFO - 2020-10-05 19:43:38 --> Security Class Initialized
DEBUG - 2020-10-05 19:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:43:38 --> Input Class Initialized
INFO - 2020-10-05 19:43:38 --> Language Class Initialized
INFO - 2020-10-05 19:43:38 --> Loader Class Initialized
INFO - 2020-10-05 19:43:38 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:43:38 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:43:38 --> Helper loaded: data_helper
INFO - 2020-10-05 19:43:38 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:43:38 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:43:38 --> Helper loaded: view_helper
INFO - 2020-10-05 19:43:38 --> Helper loaded: url_helper
INFO - 2020-10-05 19:43:38 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:43:38 --> Database Driver Class Initialized
INFO - 2020-10-05 19:43:38 --> Controller Class Initialized
INFO - 2020-10-05 19:43:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:43:38 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:43:38 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 19:43:38 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:43:38 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:43:38 --> The "english" language file has been loaded.
INFO - 2020-10-05 19:43:38 --> Config Class Initialized
INFO - 2020-10-05 19:43:38 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:43:38 --> Hooks Class Initialized
INFO - 2020-10-05 19:43:38 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:43:38 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:43:38 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:43:38 --> Utf8 Class Initialized
INFO - 2020-10-05 19:43:38 --> URI Class Initialized
DEBUG - 2020-10-05 19:43:38 --> Validating request for /controllers/Install.php
INFO - 2020-10-05 19:43:38 --> Router Class Initialized
INFO - 2020-10-05 19:43:38 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:43:38 --> Output Class Initialized
INFO - 2020-10-05 19:43:38 --> Security Class Initialized
DEBUG - 2020-10-05 19:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:43:38 --> Input Class Initialized
INFO - 2020-10-05 19:43:38 --> Language Class Initialized
INFO - 2020-10-05 19:43:38 --> Loader Class Initialized
INFO - 2020-10-05 19:43:38 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:43:38 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:43:38 --> Helper loaded: data_helper
INFO - 2020-10-05 19:43:38 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:43:38 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:43:38 --> Helper loaded: view_helper
INFO - 2020-10-05 19:43:38 --> Helper loaded: url_helper
INFO - 2020-10-05 19:43:38 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:43:38 --> Database Driver Class Initialized
INFO - 2020-10-05 19:43:38 --> Controller Class Initialized
INFO - 2020-10-05 19:43:38 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:43:38 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:43:38 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:43:38 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:43:38 --> The phrase "Unmark: Setup" could not be found in the language file.
DEBUG - 2020-10-05 19:43:38 --> The phrase "Welcome to Unmark, the to-do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 19:43:38 --> The phrase "You're about to install version 2020.3 of the app.</p><p>Please <a href="https://github.com/plainmade/unmark/blob/master/readme.md">read the installation instructions</a> first." could not be found in the language file.
DEBUG - 2020-10-05 19:43:38 --> The phrase "Click to Install" could not be found in the language file.
INFO - 2020-10-05 19:43:38 --> File loaded: /var/www/html/application/views/setup.php
INFO - 2020-10-05 19:43:38 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:43:38 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:43:38 --> Final output sent to browser
DEBUG - 2020-10-05 19:43:38 --> Total execution time: 0.1439
INFO - 2020-10-05 19:43:38 --> Config Class Initialized
INFO - 2020-10-05 19:43:38 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:43:38 --> Hooks Class Initialized
INFO - 2020-10-05 19:43:38 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:43:38 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:43:38 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:43:38 --> Utf8 Class Initialized
INFO - 2020-10-05 19:43:38 --> URI Class Initialized
DEBUG - 2020-10-05 19:43:38 --> Validating request for /controllers/Custom.php
INFO - 2020-10-05 19:43:38 --> Plain_Exceptions Class Initialized
ERROR - 2020-10-05 19:43:38 --> 404 Page Not Found: custom
INFO - 2020-10-05 19:43:41 --> Config Class Initialized
INFO - 2020-10-05 19:43:41 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:43:41 --> Hooks Class Initialized
INFO - 2020-10-05 19:43:41 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:43:41 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:43:41 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:43:41 --> Utf8 Class Initialized
INFO - 2020-10-05 19:43:41 --> URI Class Initialized
DEBUG - 2020-10-05 19:43:41 --> Validating request for /controllers/Install.php
INFO - 2020-10-05 19:43:41 --> Router Class Initialized
INFO - 2020-10-05 19:43:41 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:43:41 --> Output Class Initialized
INFO - 2020-10-05 19:43:41 --> Security Class Initialized
DEBUG - 2020-10-05 19:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:43:41 --> Input Class Initialized
INFO - 2020-10-05 19:43:41 --> Language Class Initialized
INFO - 2020-10-05 19:43:41 --> Loader Class Initialized
INFO - 2020-10-05 19:43:41 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:43:41 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:43:41 --> Helper loaded: data_helper
INFO - 2020-10-05 19:43:41 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:43:41 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:43:41 --> Helper loaded: view_helper
INFO - 2020-10-05 19:43:41 --> Helper loaded: url_helper
INFO - 2020-10-05 19:43:41 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:43:41 --> Database Driver Class Initialized
INFO - 2020-10-05 19:43:41 --> Controller Class Initialized
INFO - 2020-10-05 19:43:41 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:43:41 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:43:41 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:43:41 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:43:41 --> Plain Migrations class initialized
DEBUG - 2020-10-05 19:43:41 --> Language file loaded: language/english/migration_lang.php
INFO - 2020-10-05 19:43:41 --> Database Forge Class Initialized
DEBUG - 2020-10-05 19:43:41 --> Making backup before migrating failed.
DEBUG - 2020-10-05 19:43:41 --> Migrating up from version 0 to version 001
DEBUG - 2020-10-05 19:43:41 --> Migrating up from version 001 to version 002
DEBUG - 2020-10-05 19:43:41 --> Migrating up from version 002 to version 003
DEBUG - 2020-10-05 19:43:41 --> Migrating up from version 003 to version 004
DEBUG - 2020-10-05 19:43:41 --> Migrating up from version 004 to version 005
DEBUG - 2020-10-05 19:43:41 --> Migrating up from version 005 to version 006
DEBUG - 2020-10-05 19:43:41 --> Migrating up from version 006 to version 007
DEBUG - 2020-10-05 19:43:42 --> Migrating up from version 007 to version 008
DEBUG - 2020-10-05 19:43:42 --> Migrating up from version 008 to version 009
DEBUG - 2020-10-05 19:43:42 --> Migrating up from version 009 to version 010
DEBUG - 2020-10-05 19:43:42 --> Migrating up from version 010 to version 2014021701
DEBUG - 2020-10-05 19:43:42 --> Migrating up from version 2014021701 to version 2014022801
DEBUG - 2020-10-05 19:43:42 --> Migrating up from version 2014022801 to version 2014031901
DEBUG - 2020-10-05 19:43:42 --> Migrating up from version 2014031901 to version 2014112501
DEBUG - 2020-10-05 19:43:42 --> Finished migrating to 2014112501
DEBUG - 2020-10-05 19:43:42 --> Making backup before migrating failed.
INFO - 2020-10-05 19:43:42 --> Config Class Initialized
INFO - 2020-10-05 19:43:42 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:43:42 --> Hooks Class Initialized
INFO - 2020-10-05 19:43:42 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:43:42 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:43:42 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:43:42 --> Utf8 Class Initialized
INFO - 2020-10-05 19:43:42 --> URI Class Initialized
DEBUG - 2020-10-05 19:43:42 --> Validating request for /controllers/Register.php
INFO - 2020-10-05 19:43:42 --> Router Class Initialized
INFO - 2020-10-05 19:43:42 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:43:42 --> Output Class Initialized
INFO - 2020-10-05 19:43:42 --> Security Class Initialized
DEBUG - 2020-10-05 19:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:43:42 --> Input Class Initialized
INFO - 2020-10-05 19:43:42 --> Language Class Initialized
INFO - 2020-10-05 19:43:42 --> Loader Class Initialized
INFO - 2020-10-05 19:43:42 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:43:42 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:43:42 --> Helper loaded: data_helper
INFO - 2020-10-05 19:43:42 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:43:42 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:43:42 --> Helper loaded: view_helper
INFO - 2020-10-05 19:43:42 --> Helper loaded: url_helper
INFO - 2020-10-05 19:43:42 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:43:42 --> Database Driver Class Initialized
INFO - 2020-10-05 19:43:42 --> Controller Class Initialized
INFO - 2020-10-05 19:43:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:43:42 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:43:42 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 19:43:42 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:43:42 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:43:42 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:43:42 --> The phrase "Unmark : User Registration" could not be found in the language file.
DEBUG - 2020-10-05 19:43:42 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:43:42 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 19:43:42 --> The phrase "Password Again" could not be found in the language file.
DEBUG - 2020-10-05 19:43:42 --> The phrase "Terms of Use" could not be found in the language file.
DEBUG - 2020-10-05 19:43:42 --> The phrase "Have An Account? Sign In Here" could not be found in the language file.
INFO - 2020-10-05 19:43:42 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 19:43:42 --> File loaded: /var/www/html/custom/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 19:43:42 --> File loaded: /var/www/html/application/views/register/index.php
INFO - 2020-10-05 19:43:42 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:43:42 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:43:42 --> Final output sent to browser
DEBUG - 2020-10-05 19:43:42 --> Total execution time: 0.1520
INFO - 2020-10-05 19:43:42 --> Config Class Initialized
INFO - 2020-10-05 19:43:42 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:43:42 --> Hooks Class Initialized
INFO - 2020-10-05 19:43:42 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:43:42 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:43:42 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:43:42 --> Utf8 Class Initialized
INFO - 2020-10-05 19:43:42 --> URI Class Initialized
DEBUG - 2020-10-05 19:43:42 --> Validating request for /controllers/Custom.php
INFO - 2020-10-05 19:43:42 --> Plain_Exceptions Class Initialized
ERROR - 2020-10-05 19:43:42 --> 404 Page Not Found: custom
INFO - 2020-10-05 19:43:51 --> Config Class Initialized
INFO - 2020-10-05 19:43:51 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:43:51 --> Hooks Class Initialized
INFO - 2020-10-05 19:43:51 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:43:51 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:43:51 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:43:51 --> Utf8 Class Initialized
INFO - 2020-10-05 19:43:51 --> URI Class Initialized
DEBUG - 2020-10-05 19:43:51 --> Validating request for /controllers/Register.php
INFO - 2020-10-05 19:43:51 --> Router Class Initialized
INFO - 2020-10-05 19:43:51 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:43:51 --> Output Class Initialized
INFO - 2020-10-05 19:43:51 --> Security Class Initialized
DEBUG - 2020-10-05 19:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:43:51 --> Input Class Initialized
INFO - 2020-10-05 19:43:51 --> Language Class Initialized
INFO - 2020-10-05 19:43:51 --> Loader Class Initialized
INFO - 2020-10-05 19:43:51 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:43:51 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:43:51 --> Helper loaded: data_helper
INFO - 2020-10-05 19:43:51 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:43:51 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:43:51 --> Helper loaded: view_helper
INFO - 2020-10-05 19:43:51 --> Helper loaded: url_helper
INFO - 2020-10-05 19:43:51 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:43:51 --> Database Driver Class Initialized
INFO - 2020-10-05 19:43:52 --> Controller Class Initialized
INFO - 2020-10-05 19:43:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:43:52 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:43:52 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 19:43:52 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:43:52 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:43:52 --> The "english" language file has been loaded.
INFO - 2020-10-05 19:43:52 --> Plain_Model class loaded
INFO - 2020-10-05 19:43:52 --> Model "Users_model" initialized
DEBUG - 2020-10-05 19:43:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:52 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
        )

)

DEBUG - 2020-10-05 19:43:52 --> Adding cache entry for key unmark-1-3b330fdd11e724e2aeea6c24227bb1ef
DEBUG - 2020-10-05 19:43:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:52 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
        )

)

INFO - 2020-10-05 19:43:52 --> Helper loaded: http_build_url_helper
INFO - 2020-10-05 19:43:52 --> Model "Marks_model" initialized
INFO - 2020-10-05 19:43:52 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:43:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:52 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:52 --> Adding cache entry for key unmark-1-24f2a9ab4e9c547564634c79c86375da
DEBUG - 2020-10-05 19:43:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:52 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:52 --> Removing multiple cache entries for key unmark\-1\-.*?
DEBUG - 2020-10-05 19:43:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:52 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:52 --> The phrase "Just Now" could not be found in the language file.
DEBUG - 2020-10-05 19:43:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:52 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:52 --> Adding cache entry for key unmark-1-2c85019365b18c75573eae8b5fb616cf
DEBUG - 2020-10-05 19:43:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:52 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:52 --> Removing multiple cache entries for key unmark\-1\-.*?
DEBUG - 2020-10-05 19:43:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:52 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:52 --> The phrase "Just Now" could not be found in the language file.
DEBUG - 2020-10-05 19:43:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:52 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:52 --> Adding cache entry for key unmark-1-5e0ad2cfa31936c727ad5b0688fe9eb6
DEBUG - 2020-10-05 19:43:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:52 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:52 --> Removing multiple cache entries for key unmark\-1\-.*?
DEBUG - 2020-10-05 19:43:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:52 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:52 --> The phrase "Just Now" could not be found in the language file.
DEBUG - 2020-10-05 19:43:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:52 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:52 --> Adding cache entry for key unmark-1-c23601b4107700006c91a317ffc5d3eb
DEBUG - 2020-10-05 19:43:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:52 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:52 --> Removing multiple cache entries for key unmark\-1\-.*?
DEBUG - 2020-10-05 19:43:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:52 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:52 --> The phrase "Just Now" could not be found in the language file.
INFO - 2020-10-05 19:43:52 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-10-05 19:43:52 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:43:52 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:43:52 --> Final output sent to browser
DEBUG - 2020-10-05 19:43:52 --> Total execution time: 0.2745
INFO - 2020-10-05 19:43:54 --> Config Class Initialized
INFO - 2020-10-05 19:43:54 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:43:54 --> Hooks Class Initialized
INFO - 2020-10-05 19:43:54 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:43:54 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:43:54 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:43:54 --> Utf8 Class Initialized
INFO - 2020-10-05 19:43:54 --> URI Class Initialized
DEBUG - 2020-10-05 19:43:54 --> No URI present. Default controller set.
INFO - 2020-10-05 19:43:54 --> Router Class Initialized
INFO - 2020-10-05 19:43:54 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:43:54 --> Output Class Initialized
INFO - 2020-10-05 19:43:54 --> Security Class Initialized
DEBUG - 2020-10-05 19:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:43:54 --> Input Class Initialized
INFO - 2020-10-05 19:43:54 --> Language Class Initialized
INFO - 2020-10-05 19:43:54 --> Loader Class Initialized
INFO - 2020-10-05 19:43:54 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:43:54 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:43:54 --> Helper loaded: data_helper
INFO - 2020-10-05 19:43:54 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:43:54 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:43:54 --> Helper loaded: view_helper
INFO - 2020-10-05 19:43:54 --> Helper loaded: url_helper
INFO - 2020-10-05 19:43:54 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:43:54 --> Database Driver Class Initialized
INFO - 2020-10-05 19:43:54 --> Controller Class Initialized
INFO - 2020-10-05 19:43:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:43:54 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:43:54 --> Plain_Model class loaded
INFO - 2020-10-05 19:43:54 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:54 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:54 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

INFO - 2020-10-05 19:43:54 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

DEBUG - 2020-10-05 19:43:54 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
        )

)

INFO - 2020-10-05 19:43:54 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:54 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:54 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:54 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:43:54 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:54 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:54 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:54 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:43:54 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:54 --> Adding cache entry for key unmark-1-8af433397221df14d5acded668608071
DEBUG - 2020-10-05 19:43:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:54 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:54 --> The "english" language file has been loaded.
INFO - 2020-10-05 19:43:55 --> Config Class Initialized
INFO - 2020-10-05 19:43:55 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:43:55 --> Hooks Class Initialized
INFO - 2020-10-05 19:43:55 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:43:55 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:43:55 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:43:55 --> Utf8 Class Initialized
INFO - 2020-10-05 19:43:55 --> URI Class Initialized
DEBUG - 2020-10-05 19:43:55 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:43:55 --> Router Class Initialized
INFO - 2020-10-05 19:43:55 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:43:55 --> Output Class Initialized
INFO - 2020-10-05 19:43:55 --> Security Class Initialized
DEBUG - 2020-10-05 19:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:43:55 --> Input Class Initialized
INFO - 2020-10-05 19:43:55 --> Language Class Initialized
INFO - 2020-10-05 19:43:55 --> Loader Class Initialized
INFO - 2020-10-05 19:43:55 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:43:55 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:43:55 --> Helper loaded: data_helper
INFO - 2020-10-05 19:43:55 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:43:55 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:43:55 --> Helper loaded: view_helper
INFO - 2020-10-05 19:43:55 --> Helper loaded: url_helper
INFO - 2020-10-05 19:43:55 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:43:55 --> Database Driver Class Initialized
INFO - 2020-10-05 19:43:55 --> Controller Class Initialized
INFO - 2020-10-05 19:43:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:43:55 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:43:55 --> Plain_Model class loaded
INFO - 2020-10-05 19:43:55 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:43:55 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:43:55 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:43:55 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:43:55 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-8af433397221df14d5acded668608071
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-3148f26ee7eb82372ffa8bca07defb53
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-db48908d834c268cb6b14be365ffd84c
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:43:55 --> Model "Labels_model" initialized
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-labels-system-48c0a90953564647c82b8662bae5328b
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-0fd080f93b6c928d772c4920aa0a273a
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-89ea20d8914c229f520613eba3de585c
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-c5c0ed943e805f1a5db8b9df2a2465c6
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-93259509c08ad0db8705ca5f779513aa
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-cd0f86397a3377900ef6c3eba28f4998
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-0443f5cbe4e0510238dba4b39932d021
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-48b1bc13f0ca7b48785df97baac36842
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-a2d2a4e9470cb75b5727afdff6a8aeab
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-161cec4c96e8334bcc88dc77298d6390
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-5e1309504e29f1b765326cdfd7ecaa08
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-872e78486c7944ac8a2b25a73c06d8f9
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-d41eb4185c522aba4592dd772f04d3ca
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-8234e859b70bcbffd6f04e1dea525ec2
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-fdcd55bcceba33712c9b3a4fe94a386b
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:43:55 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-5e9976e6b5f27f7c9962851711cafec9
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-712028e091203f64d5e0da11a34ede7f
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-10-05 19:43:55 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-10-05 19:43:55 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Tap to view what's new in this version!" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-10-05 19:43:55 --> File loaded: /var/www/html/application/views/layouts/timeline.php
DEBUG - 2020-10-05 19:43:55 --> The phrase "Free Account" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Upgrade to Paid" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Connect with Twitter" could not be found in the language file.
INFO - 2020-10-05 19:43:55 --> File loaded: /var/www/html/custom/views/layouts/accountlinks.php
DEBUG - 2020-10-05 19:43:55 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-10-05 19:43:55 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
DEBUG - 2020-10-05 19:43:55 --> The phrase "You are currently using a free account, which is limited. Upgrade now and gain the ability to:" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Search your marks" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Connect to Twitter to save tweets" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Keep and access an unlimited amount of marks" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Import and Export your marks" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "UPGRADE NOW" could not be found in the language file.
INFO - 2020-10-05 19:43:55 --> File loaded: /var/www/html/custom/views/layouts/navigation.php
INFO - 2020-10-05 19:43:55 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-10-05 19:43:55 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-10-05 19:43:55 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-10-05 19:43:55 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-10-05 19:43:55 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-10-05 19:43:55 --> The phrase "Connect with Twitter" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "By connecting your account with Twitter, we will automatically import any link contained in a tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Note: We will never tweet on your behalf." could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Connect Twitter" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Sorry, your Twitter account could not be connected at this time, please try again." could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "OK" could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "Your Twitter account has been successfully connected." could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "We will now import the links in any tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 19:43:55 --> The phrase "OK" could not be found in the language file.
INFO - 2020-10-05 19:43:55 --> File loaded: /var/www/html/custom/views/layouts/userforms.php
INFO - 2020-10-05 19:43:55 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-10-05 19:43:55 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 19:43:55 --> File loaded: /var/www/html/custom/views/layouts/footer_scripts.php
INFO - 2020-10-05 19:43:55 --> File loaded: /var/www/html/application/views/layouts/footer.php
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:43:55 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:43:55 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:43:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:43:55 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:43:55 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:43:55 --> Final output sent to browser
DEBUG - 2020-10-05 19:43:55 --> Total execution time: 0.6648
INFO - 2020-10-05 19:43:55 --> Config Class Initialized
INFO - 2020-10-05 19:43:55 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:43:55 --> Hooks Class Initialized
INFO - 2020-10-05 19:43:55 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:43:55 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:43:55 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:43:55 --> Utf8 Class Initialized
INFO - 2020-10-05 19:43:55 --> URI Class Initialized
DEBUG - 2020-10-05 19:43:55 --> Validating request for /controllers/Custom.php
INFO - 2020-10-05 19:43:55 --> Plain_Exceptions Class Initialized
ERROR - 2020-10-05 19:43:55 --> 404 Page Not Found: custom
INFO - 2020-10-05 19:45:01 --> Config Class Initialized
INFO - 2020-10-05 19:45:01 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:45:01 --> Hooks Class Initialized
INFO - 2020-10-05 19:45:01 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:45:01 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:45:01 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:45:01 --> Utf8 Class Initialized
INFO - 2020-10-05 19:45:01 --> URI Class Initialized
DEBUG - 2020-10-05 19:45:01 --> No URI present. Default controller set.
INFO - 2020-10-05 19:45:01 --> Router Class Initialized
INFO - 2020-10-05 19:45:01 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:45:01 --> Output Class Initialized
INFO - 2020-10-05 19:45:01 --> Security Class Initialized
DEBUG - 2020-10-05 19:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:45:01 --> Input Class Initialized
INFO - 2020-10-05 19:45:01 --> Language Class Initialized
INFO - 2020-10-05 19:45:01 --> Loader Class Initialized
INFO - 2020-10-05 19:45:01 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:45:01 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:45:01 --> Helper loaded: data_helper
INFO - 2020-10-05 19:45:01 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:45:01 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:45:01 --> Helper loaded: view_helper
INFO - 2020-10-05 19:45:01 --> Helper loaded: url_helper
INFO - 2020-10-05 19:45:01 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:45:01 --> Database Driver Class Initialized
INFO - 2020-10-05 19:45:01 --> Controller Class Initialized
INFO - 2020-10-05 19:45:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:45:01 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:45:01 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:45:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 19:45:01 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:45:01 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:45:01 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:45:01 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 19:45:01 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:45:01 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 19:45:01 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:45:01 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:45:01 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:45:01 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 19:45:01 --> The phrase "Need to Sign In?" could not be found in the language file.
DEBUG - 2020-10-05 19:45:01 --> The phrase "What is Unmark?" could not be found in the language file.
DEBUG - 2020-10-05 19:45:01 --> The phrase "What is Unmark?" could not be found in the language file.
INFO - 2020-10-05 19:45:01 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 19:45:01 --> File loaded: /var/www/html/custom/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 19:45:01 --> File loaded: /var/www/html/custom/views/welcome.php
INFO - 2020-10-05 19:45:01 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:45:01 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:45:01 --> Final output sent to browser
DEBUG - 2020-10-05 19:45:01 --> Total execution time: 0.1580
INFO - 2020-10-05 19:50:02 --> Config Class Initialized
INFO - 2020-10-05 19:50:02 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:50:02 --> Hooks Class Initialized
INFO - 2020-10-05 19:50:02 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:50:02 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:50:02 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:50:02 --> Utf8 Class Initialized
INFO - 2020-10-05 19:50:02 --> URI Class Initialized
DEBUG - 2020-10-05 19:50:02 --> No URI present. Default controller set.
INFO - 2020-10-05 19:50:02 --> Router Class Initialized
INFO - 2020-10-05 19:50:02 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:50:02 --> Output Class Initialized
INFO - 2020-10-05 19:50:02 --> Security Class Initialized
DEBUG - 2020-10-05 19:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:50:02 --> Input Class Initialized
INFO - 2020-10-05 19:50:02 --> Language Class Initialized
INFO - 2020-10-05 19:50:02 --> Loader Class Initialized
INFO - 2020-10-05 19:50:02 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:50:02 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:50:02 --> Helper loaded: data_helper
INFO - 2020-10-05 19:50:02 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:50:02 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:50:02 --> Helper loaded: view_helper
INFO - 2020-10-05 19:50:02 --> Helper loaded: url_helper
INFO - 2020-10-05 19:50:02 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:50:02 --> Database Driver Class Initialized
INFO - 2020-10-05 19:50:02 --> Controller Class Initialized
INFO - 2020-10-05 19:50:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:50:02 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:50:02 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:50:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 19:50:02 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:50:02 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:50:02 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:50:02 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 19:50:02 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:50:02 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 19:50:02 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:50:02 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:50:02 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:50:02 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 19:50:02 --> The phrase "Need to Sign In?" could not be found in the language file.
DEBUG - 2020-10-05 19:50:02 --> The phrase "What is Unmark?" could not be found in the language file.
DEBUG - 2020-10-05 19:50:02 --> The phrase "What is Unmark?" could not be found in the language file.
INFO - 2020-10-05 19:50:02 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 19:50:02 --> File loaded: /var/www/html/custom/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 19:50:02 --> File loaded: /var/www/html/custom/views/welcome.php
INFO - 2020-10-05 19:50:02 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:50:02 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:50:02 --> Final output sent to browser
DEBUG - 2020-10-05 19:50:02 --> Total execution time: 0.1558
INFO - 2020-10-05 19:55:02 --> Config Class Initialized
INFO - 2020-10-05 19:55:02 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:55:02 --> Hooks Class Initialized
INFO - 2020-10-05 19:55:02 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:55:02 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:55:02 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:55:02 --> Utf8 Class Initialized
INFO - 2020-10-05 19:55:02 --> URI Class Initialized
DEBUG - 2020-10-05 19:55:02 --> No URI present. Default controller set.
INFO - 2020-10-05 19:55:02 --> Router Class Initialized
INFO - 2020-10-05 19:55:02 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:55:02 --> Output Class Initialized
INFO - 2020-10-05 19:55:02 --> Security Class Initialized
DEBUG - 2020-10-05 19:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:55:02 --> Input Class Initialized
INFO - 2020-10-05 19:55:02 --> Language Class Initialized
INFO - 2020-10-05 19:55:02 --> Loader Class Initialized
INFO - 2020-10-05 19:55:02 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:55:02 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:55:02 --> Helper loaded: data_helper
INFO - 2020-10-05 19:55:02 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:55:02 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:55:02 --> Helper loaded: view_helper
INFO - 2020-10-05 19:55:02 --> Helper loaded: url_helper
INFO - 2020-10-05 19:55:02 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:55:02 --> Database Driver Class Initialized
INFO - 2020-10-05 19:55:02 --> Controller Class Initialized
INFO - 2020-10-05 19:55:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:55:02 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:55:02 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:55:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 19:55:02 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:55:02 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:55:02 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:55:02 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 19:55:02 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:55:02 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 19:55:02 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:55:02 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 19:55:02 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 19:55:02 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 19:55:02 --> The phrase "Need to Sign In?" could not be found in the language file.
DEBUG - 2020-10-05 19:55:02 --> The phrase "What is Unmark?" could not be found in the language file.
DEBUG - 2020-10-05 19:55:02 --> The phrase "What is Unmark?" could not be found in the language file.
INFO - 2020-10-05 19:55:02 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 19:55:02 --> File loaded: /var/www/html/custom/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 19:55:02 --> File loaded: /var/www/html/custom/views/welcome.php
INFO - 2020-10-05 19:55:02 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:55:02 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:55:02 --> Final output sent to browser
DEBUG - 2020-10-05 19:55:02 --> Total execution time: 0.1571
INFO - 2020-10-05 19:56:17 --> Config Class Initialized
INFO - 2020-10-05 19:56:17 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:56:17 --> Hooks Class Initialized
INFO - 2020-10-05 19:56:17 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:56:17 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:56:17 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:56:17 --> Utf8 Class Initialized
INFO - 2020-10-05 19:56:17 --> URI Class Initialized
DEBUG - 2020-10-05 19:56:17 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:56:17 --> Router Class Initialized
INFO - 2020-10-05 19:56:17 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:56:17 --> Output Class Initialized
INFO - 2020-10-05 19:56:17 --> Security Class Initialized
DEBUG - 2020-10-05 19:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:56:17 --> Input Class Initialized
INFO - 2020-10-05 19:56:17 --> Language Class Initialized
INFO - 2020-10-05 19:56:17 --> Loader Class Initialized
INFO - 2020-10-05 19:56:17 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:56:17 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:56:17 --> Helper loaded: data_helper
INFO - 2020-10-05 19:56:17 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:56:17 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:56:17 --> Helper loaded: view_helper
INFO - 2020-10-05 19:56:17 --> Helper loaded: url_helper
INFO - 2020-10-05 19:56:17 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:56:17 --> Database Driver Class Initialized
INFO - 2020-10-05 19:56:17 --> Controller Class Initialized
INFO - 2020-10-05 19:56:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:56:17 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:56:17 --> Plain_Model class loaded
INFO - 2020-10-05 19:56:17 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:17 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:17 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:17 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:17 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-8af433397221df14d5acded668608071
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-3148f26ee7eb82372ffa8bca07defb53
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-db48908d834c268cb6b14be365ffd84c
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:17 --> Model "Labels_model" initialized
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-labels-system-48c0a90953564647c82b8662bae5328b
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-0fd080f93b6c928d772c4920aa0a273a
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-89ea20d8914c229f520613eba3de585c
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-c5c0ed943e805f1a5db8b9df2a2465c6
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-93259509c08ad0db8705ca5f779513aa
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-cd0f86397a3377900ef6c3eba28f4998
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-0443f5cbe4e0510238dba4b39932d021
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-48b1bc13f0ca7b48785df97baac36842
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-a2d2a4e9470cb75b5727afdff6a8aeab
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-161cec4c96e8334bcc88dc77298d6390
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-5e1309504e29f1b765326cdfd7ecaa08
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-872e78486c7944ac8a2b25a73c06d8f9
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-d41eb4185c522aba4592dd772f04d3ca
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-8234e859b70bcbffd6f04e1dea525ec2
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-fdcd55bcceba33712c9b3a4fe94a386b
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:17 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-5e9976e6b5f27f7c9962851711cafec9
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> Adding cache entry for key unmark-1-712028e091203f64d5e0da11a34ede7f
DEBUG - 2020-10-05 19:56:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:17 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:17 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-10-05 19:56:17 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-10-05 19:56:17 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Tap to view what's new in this version!" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-10-05 19:56:17 --> File loaded: /var/www/html/application/views/layouts/timeline.php
DEBUG - 2020-10-05 19:56:17 --> The phrase "Free Account" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Upgrade to Paid" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Connect with Twitter" could not be found in the language file.
INFO - 2020-10-05 19:56:17 --> File loaded: /var/www/html/custom/views/layouts/accountlinks.php
DEBUG - 2020-10-05 19:56:17 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-10-05 19:56:17 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
DEBUG - 2020-10-05 19:56:17 --> The phrase "You are currently using a free account, which is limited. Upgrade now and gain the ability to:" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Search your marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Connect to Twitter to save tweets" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Keep and access an unlimited amount of marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Import and Export your marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "UPGRADE NOW" could not be found in the language file.
INFO - 2020-10-05 19:56:17 --> File loaded: /var/www/html/custom/views/layouts/navigation.php
INFO - 2020-10-05 19:56:17 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-10-05 19:56:17 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-10-05 19:56:17 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-10-05 19:56:17 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-10-05 19:56:17 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-10-05 19:56:17 --> The phrase "Connect with Twitter" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "By connecting your account with Twitter, we will automatically import any link contained in a tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Note: We will never tweet on your behalf." could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Connect Twitter" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Sorry, your Twitter account could not be connected at this time, please try again." could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "OK" could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "Your Twitter account has been successfully connected." could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "We will now import the links in any tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 19:56:17 --> The phrase "OK" could not be found in the language file.
INFO - 2020-10-05 19:56:18 --> File loaded: /var/www/html/custom/views/layouts/userforms.php
INFO - 2020-10-05 19:56:18 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-10-05 19:56:18 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 19:56:18 --> File loaded: /var/www/html/custom/views/layouts/footer_scripts.php
INFO - 2020-10-05 19:56:18 --> File loaded: /var/www/html/application/views/layouts/footer.php
DEBUG - 2020-10-05 19:56:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:18 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:18 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:18 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:18 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:18 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:18 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:18 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:18 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:18 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:18 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:18 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:18 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:18 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:18 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:18 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:18 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:18 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:18 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:18 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:18 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:56:18 --> Final output sent to browser
DEBUG - 2020-10-05 19:56:18 --> Total execution time: 0.5991
INFO - 2020-10-05 19:56:18 --> Config Class Initialized
INFO - 2020-10-05 19:56:18 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:56:18 --> Hooks Class Initialized
INFO - 2020-10-05 19:56:18 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:56:18 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:56:18 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:56:18 --> Utf8 Class Initialized
INFO - 2020-10-05 19:56:18 --> URI Class Initialized
DEBUG - 2020-10-05 19:56:18 --> Validating request for /controllers/Custom.php
INFO - 2020-10-05 19:56:18 --> Plain_Exceptions Class Initialized
ERROR - 2020-10-05 19:56:18 --> 404 Page Not Found: custom
INFO - 2020-10-05 19:56:20 --> Config Class Initialized
INFO - 2020-10-05 19:56:20 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:56:20 --> Hooks Class Initialized
INFO - 2020-10-05 19:56:20 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:56:20 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:56:20 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:56:20 --> Utf8 Class Initialized
INFO - 2020-10-05 19:56:21 --> URI Class Initialized
DEBUG - 2020-10-05 19:56:21 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:56:21 --> Router Class Initialized
INFO - 2020-10-05 19:56:21 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:56:21 --> Output Class Initialized
INFO - 2020-10-05 19:56:21 --> Security Class Initialized
DEBUG - 2020-10-05 19:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:56:21 --> Input Class Initialized
INFO - 2020-10-05 19:56:21 --> Language Class Initialized
INFO - 2020-10-05 19:56:21 --> Loader Class Initialized
INFO - 2020-10-05 19:56:21 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:56:21 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:56:21 --> Helper loaded: data_helper
INFO - 2020-10-05 19:56:21 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:56:21 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:56:21 --> Helper loaded: view_helper
INFO - 2020-10-05 19:56:21 --> Helper loaded: url_helper
INFO - 2020-10-05 19:56:21 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:56:21 --> Database Driver Class Initialized
INFO - 2020-10-05 19:56:21 --> Controller Class Initialized
INFO - 2020-10-05 19:56:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:56:21 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:56:21 --> Plain_Model class loaded
INFO - 2020-10-05 19:56:21 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:21 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:21 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:21 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:21 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-8af433397221df14d5acded668608071
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-398a331f6977458fa6f1322289898151
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:21 --> Model "Labels_model" initialized
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-labels-system-48c0a90953564647c82b8662bae5328b
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-0fd080f93b6c928d772c4920aa0a273a
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-89ea20d8914c229f520613eba3de585c
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-c5c0ed943e805f1a5db8b9df2a2465c6
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-93259509c08ad0db8705ca5f779513aa
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-cd0f86397a3377900ef6c3eba28f4998
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-0443f5cbe4e0510238dba4b39932d021
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-48b1bc13f0ca7b48785df97baac36842
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-a2d2a4e9470cb75b5727afdff6a8aeab
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-161cec4c96e8334bcc88dc77298d6390
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-5e1309504e29f1b765326cdfd7ecaa08
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-872e78486c7944ac8a2b25a73c06d8f9
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-d41eb4185c522aba4592dd772f04d3ca
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-8234e859b70bcbffd6f04e1dea525ec2
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-fdcd55bcceba33712c9b3a4fe94a386b
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:21 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-5e9976e6b5f27f7c9962851711cafec9
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-712028e091203f64d5e0da11a34ede7f
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-10-05 19:56:21 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-10-05 19:56:21 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Tap to view what's new in this version!" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-10-05 19:56:21 --> File loaded: /var/www/html/application/views/layouts/timeline.php
DEBUG - 2020-10-05 19:56:21 --> The phrase "Free Account" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Upgrade to Paid" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Connect with Twitter" could not be found in the language file.
INFO - 2020-10-05 19:56:21 --> File loaded: /var/www/html/custom/views/layouts/accountlinks.php
DEBUG - 2020-10-05 19:56:21 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-10-05 19:56:21 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
DEBUG - 2020-10-05 19:56:21 --> The phrase "You are currently using a free account, which is limited. Upgrade now and gain the ability to:" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Search your marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Connect to Twitter to save tweets" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Keep and access an unlimited amount of marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Import and Export your marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "UPGRADE NOW" could not be found in the language file.
INFO - 2020-10-05 19:56:21 --> File loaded: /var/www/html/custom/views/layouts/navigation.php
INFO - 2020-10-05 19:56:21 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-10-05 19:56:21 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-10-05 19:56:21 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-10-05 19:56:21 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-10-05 19:56:21 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-10-05 19:56:21 --> The phrase "Connect with Twitter" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "By connecting your account with Twitter, we will automatically import any link contained in a tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Note: We will never tweet on your behalf." could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Connect Twitter" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Sorry, your Twitter account could not be connected at this time, please try again." could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "OK" could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "Your Twitter account has been successfully connected." could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "We will now import the links in any tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 19:56:21 --> The phrase "OK" could not be found in the language file.
INFO - 2020-10-05 19:56:21 --> File loaded: /var/www/html/custom/views/layouts/userforms.php
INFO - 2020-10-05 19:56:21 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-10-05 19:56:21 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 19:56:21 --> File loaded: /var/www/html/custom/views/layouts/footer_scripts.php
INFO - 2020-10-05 19:56:21 --> File loaded: /var/www/html/application/views/layouts/footer.php
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:21 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:21 --> Config Class Initialized
INFO - 2020-10-05 19:56:21 --> Plain_Config Class Initialized
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 19:56:21 --> Hooks Class Initialized
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:21 --> Plain_Hooks Class Constructed
DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
INFO - 2020-10-05 19:56:21 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:56:21 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:56:21 --> Utf8 Class Initialized
INFO - 2020-10-05 19:56:21 --> Final output sent to browser
DEBUG - 2020-10-05 19:56:21 --> Total execution time: 0.6045
INFO - 2020-10-05 19:56:21 --> URI Class Initialized
DEBUG - 2020-10-05 19:56:21 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:56:21 --> Router Class Initialized
INFO - 2020-10-05 19:56:21 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:56:21 --> Output Class Initialized
INFO - 2020-10-05 19:56:21 --> Security Class Initialized
DEBUG - 2020-10-05 19:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:56:21 --> Input Class Initialized
INFO - 2020-10-05 19:56:21 --> Language Class Initialized
INFO - 2020-10-05 19:56:21 --> Loader Class Initialized
INFO - 2020-10-05 19:56:21 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:56:21 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:56:21 --> Helper loaded: data_helper
INFO - 2020-10-05 19:56:21 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:56:21 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:56:21 --> Helper loaded: view_helper
INFO - 2020-10-05 19:56:21 --> Helper loaded: url_helper
INFO - 2020-10-05 19:56:21 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:56:21 --> Database Driver Class Initialized
INFO - 2020-10-05 19:56:21 --> Controller Class Initialized
INFO - 2020-10-05 19:56:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:56:21 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:56:21 --> Plain_Model class loaded
INFO - 2020-10-05 19:56:21 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:21 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:21 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:21 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:21 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-8af433397221df14d5acded668608071
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-3148f26ee7eb82372ffa8bca07defb53
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-db48908d834c268cb6b14be365ffd84c
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:21 --> Model "Labels_model" initialized
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-labels-system-48c0a90953564647c82b8662bae5328b
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-0fd080f93b6c928d772c4920aa0a273a
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-89ea20d8914c229f520613eba3de585c
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-c5c0ed943e805f1a5db8b9df2a2465c6
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-93259509c08ad0db8705ca5f779513aa
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-cd0f86397a3377900ef6c3eba28f4998
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-0443f5cbe4e0510238dba4b39932d021
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-48b1bc13f0ca7b48785df97baac36842
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-a2d2a4e9470cb75b5727afdff6a8aeab
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-161cec4c96e8334bcc88dc77298d6390
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-5e1309504e29f1b765326cdfd7ecaa08
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-872e78486c7944ac8a2b25a73c06d8f9
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-d41eb4185c522aba4592dd772f04d3ca
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-8234e859b70bcbffd6f04e1dea525ec2
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:21 --> Adding cache entry for key unmark-1-fdcd55bcceba33712c9b3a4fe94a386b
DEBUG - 2020-10-05 19:56:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:21 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:22 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:22 --> Adding cache entry for key unmark-1-5e9976e6b5f27f7c9962851711cafec9
DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:22 --> Adding cache entry for key unmark-1-712028e091203f64d5e0da11a34ede7f
DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:22 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-10-05 19:56:22 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-10-05 19:56:22 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Tap to view what's new in this version!" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-10-05 19:56:22 --> File loaded: /var/www/html/application/views/layouts/timeline.php
DEBUG - 2020-10-05 19:56:22 --> The phrase "Free Account" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Upgrade to Paid" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Connect with Twitter" could not be found in the language file.
INFO - 2020-10-05 19:56:22 --> File loaded: /var/www/html/custom/views/layouts/accountlinks.php
DEBUG - 2020-10-05 19:56:22 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-10-05 19:56:22 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
DEBUG - 2020-10-05 19:56:22 --> The phrase "You are currently using a free account, which is limited. Upgrade now and gain the ability to:" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Search your marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Connect to Twitter to save tweets" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Keep and access an unlimited amount of marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Import and Export your marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "UPGRADE NOW" could not be found in the language file.
INFO - 2020-10-05 19:56:22 --> File loaded: /var/www/html/custom/views/layouts/navigation.php
INFO - 2020-10-05 19:56:22 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-10-05 19:56:22 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-10-05 19:56:22 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-10-05 19:56:22 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-10-05 19:56:22 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-10-05 19:56:22 --> The phrase "Connect with Twitter" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "By connecting your account with Twitter, we will automatically import any link contained in a tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Note: We will never tweet on your behalf." could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Connect Twitter" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Sorry, your Twitter account could not be connected at this time, please try again." could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "OK" could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "Your Twitter account has been successfully connected." could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "We will now import the links in any tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 19:56:22 --> The phrase "OK" could not be found in the language file.
INFO - 2020-10-05 19:56:22 --> File loaded: /var/www/html/custom/views/layouts/userforms.php
INFO - 2020-10-05 19:56:22 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-10-05 19:56:22 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 19:56:22 --> File loaded: /var/www/html/custom/views/layouts/footer_scripts.php
INFO - 2020-10-05 19:56:22 --> File loaded: /var/www/html/application/views/layouts/footer.php
DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:22 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:22 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:22 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:22 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:22 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:22 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:22 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:22 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:22 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:56:22 --> Final output sent to browser
DEBUG - 2020-10-05 19:56:22 --> Total execution time: 0.6021
INFO - 2020-10-05 19:56:22 --> Config Class Initialized
INFO - 2020-10-05 19:56:22 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:56:22 --> Hooks Class Initialized
INFO - 2020-10-05 19:56:22 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:56:22 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:56:22 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:56:22 --> Utf8 Class Initialized
INFO - 2020-10-05 19:56:22 --> URI Class Initialized
DEBUG - 2020-10-05 19:56:22 --> Validating request for /controllers/Custom.php
INFO - 2020-10-05 19:56:22 --> Plain_Exceptions Class Initialized
ERROR - 2020-10-05 19:56:22 --> 404 Page Not Found: custom
INFO - 2020-10-05 19:56:36 --> Config Class Initialized
INFO - 2020-10-05 19:56:36 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:56:36 --> Hooks Class Initialized
INFO - 2020-10-05 19:56:36 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:56:36 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:56:36 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:56:36 --> Utf8 Class Initialized
INFO - 2020-10-05 19:56:36 --> URI Class Initialized
DEBUG - 2020-10-05 19:56:36 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:56:36 --> Router Class Initialized
INFO - 2020-10-05 19:56:36 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:56:36 --> Output Class Initialized
INFO - 2020-10-05 19:56:36 --> Security Class Initialized
DEBUG - 2020-10-05 19:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:56:36 --> Input Class Initialized
INFO - 2020-10-05 19:56:36 --> Language Class Initialized
INFO - 2020-10-05 19:56:36 --> Loader Class Initialized
INFO - 2020-10-05 19:56:36 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:56:36 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:56:36 --> Helper loaded: data_helper
INFO - 2020-10-05 19:56:36 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:56:36 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:56:36 --> Helper loaded: view_helper
INFO - 2020-10-05 19:56:36 --> Helper loaded: url_helper
INFO - 2020-10-05 19:56:36 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:56:36 --> Database Driver Class Initialized
INFO - 2020-10-05 19:56:36 --> Controller Class Initialized
INFO - 2020-10-05 19:56:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:56:36 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:56:36 --> Plain_Model class loaded
INFO - 2020-10-05 19:56:36 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:36 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:36 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:36 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:36 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-8af433397221df14d5acded668608071
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-3148f26ee7eb82372ffa8bca07defb53
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-db48908d834c268cb6b14be365ffd84c
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:36 --> Model "Labels_model" initialized
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-labels-system-48c0a90953564647c82b8662bae5328b
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-0fd080f93b6c928d772c4920aa0a273a
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-89ea20d8914c229f520613eba3de585c
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-c5c0ed943e805f1a5db8b9df2a2465c6
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-93259509c08ad0db8705ca5f779513aa
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-cd0f86397a3377900ef6c3eba28f4998
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-0443f5cbe4e0510238dba4b39932d021
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-48b1bc13f0ca7b48785df97baac36842
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-a2d2a4e9470cb75b5727afdff6a8aeab
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-161cec4c96e8334bcc88dc77298d6390
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-5e1309504e29f1b765326cdfd7ecaa08
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-872e78486c7944ac8a2b25a73c06d8f9
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-d41eb4185c522aba4592dd772f04d3ca
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-8234e859b70bcbffd6f04e1dea525ec2
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-fdcd55bcceba33712c9b3a4fe94a386b
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:36 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-5e9976e6b5f27f7c9962851711cafec9
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> Adding cache entry for key unmark-1-712028e091203f64d5e0da11a34ede7f
DEBUG - 2020-10-05 19:56:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:36 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:36 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-10-05 19:56:36 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-10-05 19:56:36 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-10-05 19:56:36 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 19:56:36 --> The phrase "Tap to view what's new in this version!" could not be found in the language file.
DEBUG - 2020-10-05 19:56:36 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 19:56:36 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-10-05 19:56:36 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-10-05 19:56:36 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-10-05 19:56:36 --> File loaded: /var/www/html/application/views/layouts/timeline.php
DEBUG - 2020-10-05 19:56:36 --> The phrase "Free Account" could not be found in the language file.
DEBUG - 2020-10-05 19:56:36 --> The phrase "Upgrade to Paid" could not be found in the language file.
DEBUG - 2020-10-05 19:56:36 --> The phrase "Connect with Twitter" could not be found in the language file.
INFO - 2020-10-05 19:56:36 --> File loaded: /var/www/html/custom/views/layouts/accountlinks.php
DEBUG - 2020-10-05 19:56:36 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-10-05 19:56:36 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-10-05 19:56:36 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
DEBUG - 2020-10-05 19:56:36 --> The phrase "You are currently using a free account, which is limited. Upgrade now and gain the ability to:" could not be found in the language file.
DEBUG - 2020-10-05 19:56:36 --> The phrase "Search your marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:36 --> The phrase "Connect to Twitter to save tweets" could not be found in the language file.
DEBUG - 2020-10-05 19:56:37 --> The phrase "Keep and access an unlimited amount of marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:37 --> The phrase "Import and Export your marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:37 --> The phrase "UPGRADE NOW" could not be found in the language file.
INFO - 2020-10-05 19:56:37 --> File loaded: /var/www/html/custom/views/layouts/navigation.php
INFO - 2020-10-05 19:56:37 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-10-05 19:56:37 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-10-05 19:56:37 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-10-05 19:56:37 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-10-05 19:56:37 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-10-05 19:56:37 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-10-05 19:56:37 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-10-05 19:56:37 --> The phrase "Connect with Twitter" could not be found in the language file.
DEBUG - 2020-10-05 19:56:37 --> The phrase "By connecting your account with Twitter, we will automatically import any link contained in a tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 19:56:37 --> The phrase "Note: We will never tweet on your behalf." could not be found in the language file.
DEBUG - 2020-10-05 19:56:37 --> The phrase "Connect Twitter" could not be found in the language file.
DEBUG - 2020-10-05 19:56:37 --> The phrase "Sorry, your Twitter account could not be connected at this time, please try again." could not be found in the language file.
DEBUG - 2020-10-05 19:56:37 --> The phrase "OK" could not be found in the language file.
DEBUG - 2020-10-05 19:56:37 --> The phrase "Your Twitter account has been successfully connected." could not be found in the language file.
DEBUG - 2020-10-05 19:56:37 --> The phrase "We will now import the links in any tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 19:56:37 --> The phrase "OK" could not be found in the language file.
INFO - 2020-10-05 19:56:37 --> File loaded: /var/www/html/custom/views/layouts/userforms.php
INFO - 2020-10-05 19:56:37 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-10-05 19:56:37 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 19:56:37 --> File loaded: /var/www/html/custom/views/layouts/footer_scripts.php
INFO - 2020-10-05 19:56:37 --> File loaded: /var/www/html/application/views/layouts/footer.php
DEBUG - 2020-10-05 19:56:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:37 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:37 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:37 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:37 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:37 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:37 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:37 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:37 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:37 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:37 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:37 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:37 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:37 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:37 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:37 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:37 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:37 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:37 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:37 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:37 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:56:37 --> Final output sent to browser
DEBUG - 2020-10-05 19:56:37 --> Total execution time: 0.7357
INFO - 2020-10-05 19:56:37 --> Config Class Initialized
INFO - 2020-10-05 19:56:37 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:56:37 --> Hooks Class Initialized
INFO - 2020-10-05 19:56:37 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:56:37 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:56:37 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:56:37 --> Utf8 Class Initialized
INFO - 2020-10-05 19:56:37 --> URI Class Initialized
DEBUG - 2020-10-05 19:56:37 --> Validating request for /controllers/Custom.php
INFO - 2020-10-05 19:56:37 --> Plain_Exceptions Class Initialized
ERROR - 2020-10-05 19:56:37 --> 404 Page Not Found: custom
INFO - 2020-10-05 19:56:40 --> Config Class Initialized
INFO - 2020-10-05 19:56:40 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:56:40 --> Hooks Class Initialized
INFO - 2020-10-05 19:56:40 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:56:40 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:56:40 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:56:40 --> Utf8 Class Initialized
INFO - 2020-10-05 19:56:40 --> URI Class Initialized
DEBUG - 2020-10-05 19:56:40 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:56:40 --> Router Class Initialized
INFO - 2020-10-05 19:56:40 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:56:40 --> Output Class Initialized
INFO - 2020-10-05 19:56:40 --> Security Class Initialized
DEBUG - 2020-10-05 19:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:56:40 --> Input Class Initialized
INFO - 2020-10-05 19:56:40 --> Language Class Initialized
INFO - 2020-10-05 19:56:40 --> Loader Class Initialized
INFO - 2020-10-05 19:56:40 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:56:40 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:56:40 --> Helper loaded: data_helper
INFO - 2020-10-05 19:56:40 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:56:40 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:56:40 --> Helper loaded: view_helper
INFO - 2020-10-05 19:56:40 --> Helper loaded: url_helper
INFO - 2020-10-05 19:56:40 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:56:40 --> Database Driver Class Initialized
INFO - 2020-10-05 19:56:40 --> Controller Class Initialized
INFO - 2020-10-05 19:56:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:56:40 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:56:40 --> Plain_Model class loaded
INFO - 2020-10-05 19:56:40 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:40 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:40 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:40 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:40 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-8af433397221df14d5acded668608071
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-398a331f6977458fa6f1322289898151
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:40 --> Model "Labels_model" initialized
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-labels-system-48c0a90953564647c82b8662bae5328b
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-0fd080f93b6c928d772c4920aa0a273a
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-89ea20d8914c229f520613eba3de585c
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-c5c0ed943e805f1a5db8b9df2a2465c6
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-93259509c08ad0db8705ca5f779513aa
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-cd0f86397a3377900ef6c3eba28f4998
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-0443f5cbe4e0510238dba4b39932d021
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-48b1bc13f0ca7b48785df97baac36842
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-a2d2a4e9470cb75b5727afdff6a8aeab
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-161cec4c96e8334bcc88dc77298d6390
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-5e1309504e29f1b765326cdfd7ecaa08
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-872e78486c7944ac8a2b25a73c06d8f9
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-d41eb4185c522aba4592dd772f04d3ca
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-8234e859b70bcbffd6f04e1dea525ec2
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-fdcd55bcceba33712c9b3a4fe94a386b
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:40 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-5e9976e6b5f27f7c9962851711cafec9
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-712028e091203f64d5e0da11a34ede7f
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-10-05 19:56:40 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-10-05 19:56:40 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Tap to view what's new in this version!" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-10-05 19:56:40 --> File loaded: /var/www/html/application/views/layouts/timeline.php
DEBUG - 2020-10-05 19:56:40 --> The phrase "Free Account" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Upgrade to Paid" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Connect with Twitter" could not be found in the language file.
INFO - 2020-10-05 19:56:40 --> File loaded: /var/www/html/custom/views/layouts/accountlinks.php
DEBUG - 2020-10-05 19:56:40 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-10-05 19:56:40 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
DEBUG - 2020-10-05 19:56:40 --> The phrase "You are currently using a free account, which is limited. Upgrade now and gain the ability to:" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Search your marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Connect to Twitter to save tweets" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Keep and access an unlimited amount of marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Import and Export your marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "UPGRADE NOW" could not be found in the language file.
INFO - 2020-10-05 19:56:40 --> File loaded: /var/www/html/custom/views/layouts/navigation.php
INFO - 2020-10-05 19:56:40 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-10-05 19:56:40 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-10-05 19:56:40 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-10-05 19:56:40 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-10-05 19:56:40 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-10-05 19:56:40 --> The phrase "Connect with Twitter" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "By connecting your account with Twitter, we will automatically import any link contained in a tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Note: We will never tweet on your behalf." could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Connect Twitter" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Sorry, your Twitter account could not be connected at this time, please try again." could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "OK" could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "Your Twitter account has been successfully connected." could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "We will now import the links in any tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 19:56:40 --> The phrase "OK" could not be found in the language file.
INFO - 2020-10-05 19:56:40 --> File loaded: /var/www/html/custom/views/layouts/userforms.php
INFO - 2020-10-05 19:56:40 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-10-05 19:56:40 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 19:56:40 --> File loaded: /var/www/html/custom/views/layouts/footer_scripts.php
INFO - 2020-10-05 19:56:40 --> File loaded: /var/www/html/application/views/layouts/footer.php
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:40 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:40 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:40 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:40 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:56:40 --> Final output sent to browser
DEBUG - 2020-10-05 19:56:40 --> Total execution time: 0.5977
INFO - 2020-10-05 19:56:40 --> Config Class Initialized
INFO - 2020-10-05 19:56:40 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:56:40 --> Hooks Class Initialized
INFO - 2020-10-05 19:56:40 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:56:40 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:56:40 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:56:40 --> Utf8 Class Initialized
INFO - 2020-10-05 19:56:40 --> URI Class Initialized
DEBUG - 2020-10-05 19:56:40 --> Validating request for /controllers/Custom.php
INFO - 2020-10-05 19:56:40 --> Plain_Exceptions Class Initialized
ERROR - 2020-10-05 19:56:40 --> 404 Page Not Found: custom
INFO - 2020-10-05 19:56:42 --> Config Class Initialized
INFO - 2020-10-05 19:56:42 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:56:42 --> Hooks Class Initialized
INFO - 2020-10-05 19:56:42 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:56:42 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:56:42 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:56:42 --> Utf8 Class Initialized
INFO - 2020-10-05 19:56:42 --> URI Class Initialized
DEBUG - 2020-10-05 19:56:42 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 19:56:42 --> Router Class Initialized
INFO - 2020-10-05 19:56:42 --> Plain_Router Class Initialized
INFO - 2020-10-05 19:56:42 --> Output Class Initialized
INFO - 2020-10-05 19:56:42 --> Security Class Initialized
DEBUG - 2020-10-05 19:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 19:56:42 --> Input Class Initialized
INFO - 2020-10-05 19:56:42 --> Language Class Initialized
INFO - 2020-10-05 19:56:42 --> Loader Class Initialized
INFO - 2020-10-05 19:56:42 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 19:56:42 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 19:56:42 --> Helper loaded: data_helper
INFO - 2020-10-05 19:56:42 --> Helper loaded: hash_helper
INFO - 2020-10-05 19:56:42 --> Helper loaded: validation_helper
INFO - 2020-10-05 19:56:42 --> Helper loaded: view_helper
INFO - 2020-10-05 19:56:42 --> Helper loaded: url_helper
INFO - 2020-10-05 19:56:42 --> Helper loaded: rss_helper
INFO - 2020-10-05 19:56:42 --> Database Driver Class Initialized
INFO - 2020-10-05 19:56:42 --> Controller Class Initialized
INFO - 2020-10-05 19:56:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 19:56:42 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 19:56:42 --> Plain_Model class loaded
INFO - 2020-10-05 19:56:42 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:42 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:42 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:42 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:42 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-8af433397221df14d5acded668608071
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-3148f26ee7eb82372ffa8bca07defb53
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-db48908d834c268cb6b14be365ffd84c
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:42 --> Model "Labels_model" initialized
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-labels-system-48c0a90953564647c82b8662bae5328b
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-0fd080f93b6c928d772c4920aa0a273a
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-89ea20d8914c229f520613eba3de585c
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-c5c0ed943e805f1a5db8b9df2a2465c6
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-93259509c08ad0db8705ca5f779513aa
DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:42 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:42 --> Adding cache entry for key unmark-1-cd0f86397a3377900ef6c3eba28f4998
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-0443f5cbe4e0510238dba4b39932d021
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-48b1bc13f0ca7b48785df97baac36842
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-a2d2a4e9470cb75b5727afdff6a8aeab
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-161cec4c96e8334bcc88dc77298d6390
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-5e1309504e29f1b765326cdfd7ecaa08
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-872e78486c7944ac8a2b25a73c06d8f9
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-d41eb4185c522aba4592dd772f04d3ca
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-8234e859b70bcbffd6f04e1dea525ec2
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-fdcd55bcceba33712c9b3a4fe94a386b
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:43 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-5e9976e6b5f27f7c9962851711cafec9
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-712028e091203f64d5e0da11a34ede7f
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-10-05 19:56:43 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-10-05 19:56:43 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Tap to view what's new in this version!" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-10-05 19:56:43 --> File loaded: /var/www/html/application/views/layouts/timeline.php
DEBUG - 2020-10-05 19:56:43 --> The phrase "Free Account" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Upgrade to Paid" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Connect with Twitter" could not be found in the language file.
INFO - 2020-10-05 19:56:43 --> File loaded: /var/www/html/custom/views/layouts/accountlinks.php
DEBUG - 2020-10-05 19:56:43 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-10-05 19:56:43 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
DEBUG - 2020-10-05 19:56:43 --> The phrase "You are currently using a free account, which is limited. Upgrade now and gain the ability to:" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Search your marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Connect to Twitter to save tweets" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Keep and access an unlimited amount of marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Import and Export your marks" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "UPGRADE NOW" could not be found in the language file.
INFO - 2020-10-05 19:56:43 --> File loaded: /var/www/html/custom/views/layouts/navigation.php
INFO - 2020-10-05 19:56:43 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-10-05 19:56:43 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-10-05 19:56:43 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-10-05 19:56:43 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-10-05 19:56:43 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-10-05 19:56:43 --> The phrase "Connect with Twitter" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "By connecting your account with Twitter, we will automatically import any link contained in a tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Note: We will never tweet on your behalf." could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Connect Twitter" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Sorry, your Twitter account could not be connected at this time, please try again." could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "OK" could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "Your Twitter account has been successfully connected." could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "We will now import the links in any tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 19:56:43 --> The phrase "OK" could not be found in the language file.
INFO - 2020-10-05 19:56:43 --> File loaded: /var/www/html/custom/views/layouts/userforms.php
INFO - 2020-10-05 19:56:43 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-10-05 19:56:43 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 19:56:43 --> File loaded: /var/www/html/custom/views/layouts/footer_scripts.php
INFO - 2020-10-05 19:56:43 --> File loaded: /var/www/html/application/views/layouts/footer.php
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:43 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 19:56:43 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 19:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 19:56:43 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 19:56:43 --> Custom Hooks class initialized.
INFO - 2020-10-05 19:56:43 --> Final output sent to browser
DEBUG - 2020-10-05 19:56:43 --> Total execution time: 0.5986
INFO - 2020-10-05 19:56:43 --> Config Class Initialized
INFO - 2020-10-05 19:56:43 --> Plain_Config Class Initialized
INFO - 2020-10-05 19:56:43 --> Hooks Class Initialized
INFO - 2020-10-05 19:56:43 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 19:56:43 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 19:56:43 --> UTF-8 Support Disabled
INFO - 2020-10-05 19:56:43 --> Utf8 Class Initialized
INFO - 2020-10-05 19:56:43 --> URI Class Initialized
DEBUG - 2020-10-05 19:56:43 --> Validating request for /controllers/Custom.php
INFO - 2020-10-05 19:56:43 --> Plain_Exceptions Class Initialized
ERROR - 2020-10-05 19:56:43 --> 404 Page Not Found: custom
INFO - 2020-10-05 20:00:03 --> Config Class Initialized
INFO - 2020-10-05 20:00:03 --> Plain_Config Class Initialized
INFO - 2020-10-05 20:00:03 --> Hooks Class Initialized
INFO - 2020-10-05 20:00:03 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 20:00:03 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 20:00:03 --> UTF-8 Support Disabled
INFO - 2020-10-05 20:00:03 --> Utf8 Class Initialized
INFO - 2020-10-05 20:00:03 --> URI Class Initialized
DEBUG - 2020-10-05 20:00:03 --> No URI present. Default controller set.
INFO - 2020-10-05 20:00:03 --> Router Class Initialized
INFO - 2020-10-05 20:00:03 --> Plain_Router Class Initialized
INFO - 2020-10-05 20:00:03 --> Output Class Initialized
INFO - 2020-10-05 20:00:03 --> Security Class Initialized
DEBUG - 2020-10-05 20:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 20:00:03 --> Input Class Initialized
INFO - 2020-10-05 20:00:03 --> Language Class Initialized
INFO - 2020-10-05 20:00:03 --> Loader Class Initialized
INFO - 2020-10-05 20:00:03 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 20:00:03 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 20:00:03 --> Helper loaded: data_helper
INFO - 2020-10-05 20:00:03 --> Helper loaded: hash_helper
INFO - 2020-10-05 20:00:03 --> Helper loaded: validation_helper
INFO - 2020-10-05 20:00:03 --> Helper loaded: view_helper
INFO - 2020-10-05 20:00:03 --> Helper loaded: url_helper
INFO - 2020-10-05 20:00:03 --> Helper loaded: rss_helper
INFO - 2020-10-05 20:00:03 --> Database Driver Class Initialized
INFO - 2020-10-05 20:00:03 --> Controller Class Initialized
INFO - 2020-10-05 20:00:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 20:00:03 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 20:00:03 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:00:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 20:00:03 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:00:03 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:00:03 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 20:00:03 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 20:00:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:00:03 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 20:00:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:00:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:00:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:00:03 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 20:00:03 --> The phrase "Need to Sign In?" could not be found in the language file.
DEBUG - 2020-10-05 20:00:03 --> The phrase "What is Unmark?" could not be found in the language file.
DEBUG - 2020-10-05 20:00:03 --> The phrase "What is Unmark?" could not be found in the language file.
INFO - 2020-10-05 20:00:03 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 20:00:03 --> File loaded: /var/www/html/custom/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 20:00:03 --> File loaded: /var/www/html/custom/views/welcome.php
INFO - 2020-10-05 20:00:03 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:00:03 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:00:03 --> Final output sent to browser
DEBUG - 2020-10-05 20:00:03 --> Total execution time: 0.1637
INFO - 2020-10-05 20:05:03 --> Config Class Initialized
INFO - 2020-10-05 20:05:03 --> Plain_Config Class Initialized
INFO - 2020-10-05 20:05:03 --> Hooks Class Initialized
INFO - 2020-10-05 20:05:03 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 20:05:03 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 20:05:03 --> UTF-8 Support Disabled
INFO - 2020-10-05 20:05:03 --> Utf8 Class Initialized
INFO - 2020-10-05 20:05:03 --> URI Class Initialized
DEBUG - 2020-10-05 20:05:03 --> No URI present. Default controller set.
INFO - 2020-10-05 20:05:03 --> Router Class Initialized
INFO - 2020-10-05 20:05:03 --> Plain_Router Class Initialized
INFO - 2020-10-05 20:05:03 --> Output Class Initialized
INFO - 2020-10-05 20:05:03 --> Security Class Initialized
DEBUG - 2020-10-05 20:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 20:05:03 --> Input Class Initialized
INFO - 2020-10-05 20:05:03 --> Language Class Initialized
INFO - 2020-10-05 20:05:03 --> Loader Class Initialized
INFO - 2020-10-05 20:05:03 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 20:05:03 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 20:05:03 --> Helper loaded: data_helper
INFO - 2020-10-05 20:05:03 --> Helper loaded: hash_helper
INFO - 2020-10-05 20:05:03 --> Helper loaded: validation_helper
INFO - 2020-10-05 20:05:03 --> Helper loaded: view_helper
INFO - 2020-10-05 20:05:03 --> Helper loaded: url_helper
INFO - 2020-10-05 20:05:03 --> Helper loaded: rss_helper
INFO - 2020-10-05 20:05:03 --> Database Driver Class Initialized
INFO - 2020-10-05 20:05:03 --> Controller Class Initialized
INFO - 2020-10-05 20:05:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 20:05:03 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 20:05:03 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:05:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 20:05:03 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:05:03 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:05:03 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 20:05:03 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 20:05:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:05:03 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 20:05:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:05:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:05:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:05:03 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 20:05:03 --> The phrase "Need to Sign In?" could not be found in the language file.
DEBUG - 2020-10-05 20:05:03 --> The phrase "What is Unmark?" could not be found in the language file.
DEBUG - 2020-10-05 20:05:03 --> The phrase "What is Unmark?" could not be found in the language file.
INFO - 2020-10-05 20:05:03 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 20:05:03 --> File loaded: /var/www/html/custom/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 20:05:03 --> File loaded: /var/www/html/custom/views/welcome.php
INFO - 2020-10-05 20:05:03 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:05:03 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:05:03 --> Final output sent to browser
DEBUG - 2020-10-05 20:05:03 --> Total execution time: 0.1707
INFO - 2020-10-05 20:09:04 --> Config Class Initialized
INFO - 2020-10-05 20:09:04 --> Plain_Config Class Initialized
INFO - 2020-10-05 20:09:04 --> Hooks Class Initialized
INFO - 2020-10-05 20:09:04 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 20:09:04 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 20:09:04 --> UTF-8 Support Disabled
INFO - 2020-10-05 20:09:04 --> Utf8 Class Initialized
INFO - 2020-10-05 20:09:04 --> URI Class Initialized
DEBUG - 2020-10-05 20:09:04 --> Validating request for /controllers/Marks.php
INFO - 2020-10-05 20:09:04 --> Router Class Initialized
INFO - 2020-10-05 20:09:04 --> Plain_Router Class Initialized
INFO - 2020-10-05 20:09:04 --> Output Class Initialized
INFO - 2020-10-05 20:09:04 --> Security Class Initialized
DEBUG - 2020-10-05 20:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 20:09:04 --> Input Class Initialized
INFO - 2020-10-05 20:09:04 --> Language Class Initialized
INFO - 2020-10-05 20:09:04 --> Loader Class Initialized
INFO - 2020-10-05 20:09:04 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 20:09:04 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 20:09:04 --> Helper loaded: data_helper
INFO - 2020-10-05 20:09:04 --> Helper loaded: hash_helper
INFO - 2020-10-05 20:09:04 --> Helper loaded: validation_helper
INFO - 2020-10-05 20:09:04 --> Helper loaded: view_helper
INFO - 2020-10-05 20:09:04 --> Helper loaded: url_helper
INFO - 2020-10-05 20:09:04 --> Helper loaded: rss_helper
INFO - 2020-10-05 20:09:04 --> Database Driver Class Initialized
INFO - 2020-10-05 20:09:04 --> Controller Class Initialized
INFO - 2020-10-05 20:09:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 20:09:04 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 20:09:04 --> Plain_Model class loaded
INFO - 2020-10-05 20:09:04 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-10-05 20:09:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:04 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:04 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 20:09:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:04 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:04 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:04 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 20:09:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:04 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 20:09:04 --> Model "User_Settings_model" initialized
DEBUG - 2020-10-05 20:09:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:04 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:04 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 20:09:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:04 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 20:09:04 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:09:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 20:09:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:04 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:04 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 20:09:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:04 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 20:09:05 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 20:09:05 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-8af433397221df14d5acded668608071
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-3148f26ee7eb82372ffa8bca07defb53
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-db48908d834c268cb6b14be365ffd84c
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 20:09:05 --> Model "Labels_model" initialized
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-labels-system-48c0a90953564647c82b8662bae5328b
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-0fd080f93b6c928d772c4920aa0a273a
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-89ea20d8914c229f520613eba3de585c
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-c5c0ed943e805f1a5db8b9df2a2465c6
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-93259509c08ad0db8705ca5f779513aa
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-cd0f86397a3377900ef6c3eba28f4998
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-0443f5cbe4e0510238dba4b39932d021
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-48b1bc13f0ca7b48785df97baac36842
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-a2d2a4e9470cb75b5727afdff6a8aeab
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-161cec4c96e8334bcc88dc77298d6390
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-5e1309504e29f1b765326cdfd7ecaa08
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-872e78486c7944ac8a2b25a73c06d8f9
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-d41eb4185c522aba4592dd772f04d3ca
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-8234e859b70bcbffd6f04e1dea525ec2
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-fdcd55bcceba33712c9b3a4fe94a386b
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 20:09:05 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-5e9976e6b5f27f7c9962851711cafec9
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-712028e091203f64d5e0da11a34ede7f
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-10-05 20:09:05 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-10-05 20:09:05 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Tap to view what's new in this version!" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Upgrade" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-10-05 20:09:05 --> File loaded: /var/www/html/application/views/layouts/timeline.php
DEBUG - 2020-10-05 20:09:05 --> The phrase "Free Account" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Upgrade to Paid" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Connect with Twitter" could not be found in the language file.
INFO - 2020-10-05 20:09:05 --> File loaded: /var/www/html/custom/views/layouts/accountlinks.php
DEBUG - 2020-10-05 20:09:05 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-10-05 20:09:05 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
DEBUG - 2020-10-05 20:09:05 --> The phrase "You are currently using a free account, which is limited. Upgrade now and gain the ability to:" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Search your marks" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Connect to Twitter to save tweets" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Keep and access an unlimited amount of marks" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Import and Export your marks" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "UPGRADE NOW" could not be found in the language file.
INFO - 2020-10-05 20:09:05 --> File loaded: /var/www/html/custom/views/layouts/navigation.php
INFO - 2020-10-05 20:09:05 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-10-05 20:09:05 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-10-05 20:09:05 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-10-05 20:09:05 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-10-05 20:09:05 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-10-05 20:09:05 --> The phrase "Connect with Twitter" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "By connecting your account with Twitter, we will automatically import any link contained in a tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Note: We will never tweet on your behalf." could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Connect Twitter" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Sorry, your Twitter account could not be connected at this time, please try again." could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "OK" could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "Your Twitter account has been successfully connected." could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "We will now import the links in any tweet that you favorite." could not be found in the language file.
DEBUG - 2020-10-05 20:09:05 --> The phrase "OK" could not be found in the language file.
INFO - 2020-10-05 20:09:05 --> File loaded: /var/www/html/custom/views/layouts/userforms.php
INFO - 2020-10-05 20:09:05 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-10-05 20:09:05 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 20:09:05 --> File loaded: /var/www/html/custom/views/layouts/footer_scripts.php
INFO - 2020-10-05 20:09:05 --> File loaded: /var/www/html/application/views/layouts/footer.php
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 20:09:05 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-a1fbe25c1f2a1d7c68d829a4ca8cc067
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-64026d2ccc8cd6860bdd1f949be4b02a
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

DEBUG - 2020-10-05 20:09:05 --> Adding cache entry for key unmark-1-8c853b79cb875866371c9a98ae19890d
DEBUG - 2020-10-05 20:09:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 20:09:05 --> Array
(
    [message] => Error: Invalid cache directory set.
    [type] => Error
    [backtrace] => /var/www/html/custom/libraries/CCache.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [customer_id] => 
            [email] => colin@cdevroe.com
            [user_token] => ARJOBaoKTBSX346IYSuMd7GHgYodgK492bdb6fb6f81fdfd1a05435e5a0b98d
            [active] => 1
            [admin] => 0
            [plan_id] => 
            [expires_on] => 
            [created_on] => 2020-10-05 19:43:52
            [last_updated] => 2020-10-05 19:43:52
            [active_customer] => 
            [active_subscription] => 
            [over_total_limit] => 
            [over_daily_limit] => 
        )

)

INFO - 2020-10-05 20:09:05 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:09:05 --> Final output sent to browser
DEBUG - 2020-10-05 20:09:05 --> Total execution time: 0.6170
INFO - 2020-10-05 20:09:05 --> Config Class Initialized
INFO - 2020-10-05 20:09:05 --> Plain_Config Class Initialized
INFO - 2020-10-05 20:09:05 --> Hooks Class Initialized
INFO - 2020-10-05 20:09:05 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 20:09:05 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 20:09:05 --> UTF-8 Support Disabled
INFO - 2020-10-05 20:09:05 --> Utf8 Class Initialized
INFO - 2020-10-05 20:09:05 --> URI Class Initialized
DEBUG - 2020-10-05 20:09:05 --> Validating request for /controllers/Custom.php
INFO - 2020-10-05 20:09:05 --> Plain_Exceptions Class Initialized
ERROR - 2020-10-05 20:09:05 --> 404 Page Not Found: custom
INFO - 2020-10-05 20:10:03 --> Config Class Initialized
INFO - 2020-10-05 20:10:03 --> Plain_Config Class Initialized
INFO - 2020-10-05 20:10:03 --> Hooks Class Initialized
INFO - 2020-10-05 20:10:03 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 20:10:03 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 20:10:03 --> UTF-8 Support Disabled
INFO - 2020-10-05 20:10:03 --> Utf8 Class Initialized
INFO - 2020-10-05 20:10:03 --> URI Class Initialized
DEBUG - 2020-10-05 20:10:03 --> No URI present. Default controller set.
INFO - 2020-10-05 20:10:03 --> Router Class Initialized
INFO - 2020-10-05 20:10:03 --> Plain_Router Class Initialized
INFO - 2020-10-05 20:10:03 --> Output Class Initialized
INFO - 2020-10-05 20:10:03 --> Security Class Initialized
DEBUG - 2020-10-05 20:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 20:10:03 --> Input Class Initialized
INFO - 2020-10-05 20:10:03 --> Language Class Initialized
INFO - 2020-10-05 20:10:03 --> Loader Class Initialized
INFO - 2020-10-05 20:10:03 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 20:10:03 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 20:10:03 --> Helper loaded: data_helper
INFO - 2020-10-05 20:10:03 --> Helper loaded: hash_helper
INFO - 2020-10-05 20:10:03 --> Helper loaded: validation_helper
INFO - 2020-10-05 20:10:03 --> Helper loaded: view_helper
INFO - 2020-10-05 20:10:03 --> Helper loaded: url_helper
INFO - 2020-10-05 20:10:03 --> Helper loaded: rss_helper
INFO - 2020-10-05 20:10:03 --> Database Driver Class Initialized
INFO - 2020-10-05 20:10:04 --> Controller Class Initialized
INFO - 2020-10-05 20:10:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 20:10:04 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 20:10:04 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:10:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 20:10:04 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:10:04 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:10:04 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 20:10:04 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 20:10:04 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:10:04 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 20:10:04 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:10:04 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:10:04 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:10:04 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 20:10:04 --> The phrase "Need to Sign In?" could not be found in the language file.
DEBUG - 2020-10-05 20:10:04 --> The phrase "What is Unmark?" could not be found in the language file.
DEBUG - 2020-10-05 20:10:04 --> The phrase "What is Unmark?" could not be found in the language file.
INFO - 2020-10-05 20:10:04 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 20:10:04 --> File loaded: /var/www/html/custom/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 20:10:04 --> File loaded: /var/www/html/custom/views/welcome.php
INFO - 2020-10-05 20:10:04 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:10:04 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:10:04 --> Final output sent to browser
DEBUG - 2020-10-05 20:10:04 --> Total execution time: 0.1572
INFO - 2020-10-05 20:15:04 --> Config Class Initialized
INFO - 2020-10-05 20:15:04 --> Plain_Config Class Initialized
INFO - 2020-10-05 20:15:04 --> Hooks Class Initialized
INFO - 2020-10-05 20:15:04 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 20:15:04 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 20:15:04 --> UTF-8 Support Disabled
INFO - 2020-10-05 20:15:04 --> Utf8 Class Initialized
INFO - 2020-10-05 20:15:04 --> URI Class Initialized
DEBUG - 2020-10-05 20:15:04 --> No URI present. Default controller set.
INFO - 2020-10-05 20:15:04 --> Router Class Initialized
INFO - 2020-10-05 20:15:04 --> Plain_Router Class Initialized
INFO - 2020-10-05 20:15:04 --> Output Class Initialized
INFO - 2020-10-05 20:15:04 --> Security Class Initialized
DEBUG - 2020-10-05 20:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 20:15:04 --> Input Class Initialized
INFO - 2020-10-05 20:15:04 --> Language Class Initialized
INFO - 2020-10-05 20:15:04 --> Loader Class Initialized
INFO - 2020-10-05 20:15:04 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 20:15:04 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 20:15:04 --> Helper loaded: data_helper
INFO - 2020-10-05 20:15:04 --> Helper loaded: hash_helper
INFO - 2020-10-05 20:15:04 --> Helper loaded: validation_helper
INFO - 2020-10-05 20:15:04 --> Helper loaded: view_helper
INFO - 2020-10-05 20:15:04 --> Helper loaded: url_helper
INFO - 2020-10-05 20:15:04 --> Helper loaded: rss_helper
INFO - 2020-10-05 20:15:04 --> Database Driver Class Initialized
INFO - 2020-10-05 20:15:04 --> Controller Class Initialized
INFO - 2020-10-05 20:15:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 20:15:04 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 20:15:04 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:15:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 20:15:04 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:15:04 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:15:04 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 20:15:04 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 20:15:04 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:15:04 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 20:15:04 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:15:04 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:15:04 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:15:04 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 20:15:04 --> The phrase "Need to Sign In?" could not be found in the language file.
DEBUG - 2020-10-05 20:15:04 --> The phrase "What is Unmark?" could not be found in the language file.
DEBUG - 2020-10-05 20:15:04 --> The phrase "What is Unmark?" could not be found in the language file.
INFO - 2020-10-05 20:15:04 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 20:15:04 --> File loaded: /var/www/html/custom/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 20:15:04 --> File loaded: /var/www/html/custom/views/welcome.php
INFO - 2020-10-05 20:15:04 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:15:04 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:15:04 --> Final output sent to browser
DEBUG - 2020-10-05 20:15:04 --> Total execution time: 0.1582
INFO - 2020-10-05 20:20:05 --> Config Class Initialized
INFO - 2020-10-05 20:20:05 --> Plain_Config Class Initialized
INFO - 2020-10-05 20:20:05 --> Hooks Class Initialized
INFO - 2020-10-05 20:20:05 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 20:20:05 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 20:20:05 --> UTF-8 Support Disabled
INFO - 2020-10-05 20:20:05 --> Utf8 Class Initialized
INFO - 2020-10-05 20:20:05 --> URI Class Initialized
DEBUG - 2020-10-05 20:20:05 --> No URI present. Default controller set.
INFO - 2020-10-05 20:20:05 --> Router Class Initialized
INFO - 2020-10-05 20:20:05 --> Plain_Router Class Initialized
INFO - 2020-10-05 20:20:05 --> Output Class Initialized
INFO - 2020-10-05 20:20:05 --> Security Class Initialized
DEBUG - 2020-10-05 20:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 20:20:05 --> Input Class Initialized
INFO - 2020-10-05 20:20:05 --> Language Class Initialized
INFO - 2020-10-05 20:20:05 --> Loader Class Initialized
INFO - 2020-10-05 20:20:05 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 20:20:05 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 20:20:05 --> Helper loaded: data_helper
INFO - 2020-10-05 20:20:05 --> Helper loaded: hash_helper
INFO - 2020-10-05 20:20:05 --> Helper loaded: validation_helper
INFO - 2020-10-05 20:20:05 --> Helper loaded: view_helper
INFO - 2020-10-05 20:20:05 --> Helper loaded: url_helper
INFO - 2020-10-05 20:20:05 --> Helper loaded: rss_helper
INFO - 2020-10-05 20:20:05 --> Database Driver Class Initialized
INFO - 2020-10-05 20:20:05 --> Controller Class Initialized
INFO - 2020-10-05 20:20:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 20:20:05 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 20:20:05 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:20:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 20:20:05 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:20:05 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:20:05 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 20:20:05 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 20:20:05 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:20:05 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 20:20:05 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:20:05 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:20:05 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:20:05 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 20:20:05 --> The phrase "Need to Sign In?" could not be found in the language file.
DEBUG - 2020-10-05 20:20:05 --> The phrase "What is Unmark?" could not be found in the language file.
DEBUG - 2020-10-05 20:20:05 --> The phrase "What is Unmark?" could not be found in the language file.
INFO - 2020-10-05 20:20:05 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 20:20:05 --> File loaded: /var/www/html/custom/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 20:20:05 --> File loaded: /var/www/html/custom/views/welcome.php
INFO - 2020-10-05 20:20:05 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:20:05 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:20:05 --> Final output sent to browser
DEBUG - 2020-10-05 20:20:05 --> Total execution time: 0.1946
INFO - 2020-10-05 20:25:05 --> Config Class Initialized
INFO - 2020-10-05 20:25:05 --> Plain_Config Class Initialized
INFO - 2020-10-05 20:25:05 --> Hooks Class Initialized
INFO - 2020-10-05 20:25:05 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 20:25:05 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 20:25:05 --> UTF-8 Support Disabled
INFO - 2020-10-05 20:25:05 --> Utf8 Class Initialized
INFO - 2020-10-05 20:25:05 --> URI Class Initialized
DEBUG - 2020-10-05 20:25:05 --> No URI present. Default controller set.
INFO - 2020-10-05 20:25:05 --> Router Class Initialized
INFO - 2020-10-05 20:25:05 --> Plain_Router Class Initialized
INFO - 2020-10-05 20:25:05 --> Output Class Initialized
INFO - 2020-10-05 20:25:05 --> Security Class Initialized
DEBUG - 2020-10-05 20:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 20:25:05 --> Input Class Initialized
INFO - 2020-10-05 20:25:05 --> Language Class Initialized
INFO - 2020-10-05 20:25:05 --> Loader Class Initialized
INFO - 2020-10-05 20:25:05 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 20:25:05 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 20:25:05 --> Helper loaded: data_helper
INFO - 2020-10-05 20:25:05 --> Helper loaded: hash_helper
INFO - 2020-10-05 20:25:05 --> Helper loaded: validation_helper
INFO - 2020-10-05 20:25:05 --> Helper loaded: view_helper
INFO - 2020-10-05 20:25:05 --> Helper loaded: url_helper
INFO - 2020-10-05 20:25:05 --> Helper loaded: rss_helper
INFO - 2020-10-05 20:25:05 --> Database Driver Class Initialized
INFO - 2020-10-05 20:25:05 --> Controller Class Initialized
INFO - 2020-10-05 20:25:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 20:25:05 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 20:25:05 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 20:25:05 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:25:05 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:25:05 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 20:25:06 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 20:25:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:25:06 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 20:25:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:25:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:25:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:25:06 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 20:25:06 --> The phrase "Need to Sign In?" could not be found in the language file.
DEBUG - 2020-10-05 20:25:06 --> The phrase "What is Unmark?" could not be found in the language file.
DEBUG - 2020-10-05 20:25:06 --> The phrase "What is Unmark?" could not be found in the language file.
INFO - 2020-10-05 20:25:06 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 20:25:06 --> File loaded: /var/www/html/custom/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 20:25:06 --> File loaded: /var/www/html/custom/views/welcome.php
INFO - 2020-10-05 20:25:06 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:25:06 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:25:06 --> Final output sent to browser
DEBUG - 2020-10-05 20:25:06 --> Total execution time: 0.1553
INFO - 2020-10-05 20:30:06 --> Config Class Initialized
INFO - 2020-10-05 20:30:06 --> Plain_Config Class Initialized
INFO - 2020-10-05 20:30:06 --> Hooks Class Initialized
INFO - 2020-10-05 20:30:06 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 20:30:06 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 20:30:06 --> UTF-8 Support Disabled
INFO - 2020-10-05 20:30:06 --> Utf8 Class Initialized
INFO - 2020-10-05 20:30:06 --> URI Class Initialized
DEBUG - 2020-10-05 20:30:06 --> No URI present. Default controller set.
INFO - 2020-10-05 20:30:06 --> Router Class Initialized
INFO - 2020-10-05 20:30:06 --> Plain_Router Class Initialized
INFO - 2020-10-05 20:30:06 --> Output Class Initialized
INFO - 2020-10-05 20:30:06 --> Security Class Initialized
DEBUG - 2020-10-05 20:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 20:30:06 --> Input Class Initialized
INFO - 2020-10-05 20:30:06 --> Language Class Initialized
INFO - 2020-10-05 20:30:06 --> Loader Class Initialized
INFO - 2020-10-05 20:30:06 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 20:30:06 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 20:30:06 --> Helper loaded: data_helper
INFO - 2020-10-05 20:30:06 --> Helper loaded: hash_helper
INFO - 2020-10-05 20:30:06 --> Helper loaded: validation_helper
INFO - 2020-10-05 20:30:06 --> Helper loaded: view_helper
INFO - 2020-10-05 20:30:06 --> Helper loaded: url_helper
INFO - 2020-10-05 20:30:06 --> Helper loaded: rss_helper
INFO - 2020-10-05 20:30:06 --> Database Driver Class Initialized
INFO - 2020-10-05 20:30:06 --> Controller Class Initialized
INFO - 2020-10-05 20:30:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 20:30:06 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 20:30:06 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:30:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 20:30:06 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:30:06 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:30:06 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 20:30:06 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 20:30:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:30:06 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 20:30:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:30:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:30:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:30:06 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 20:30:06 --> The phrase "Need to Sign In?" could not be found in the language file.
DEBUG - 2020-10-05 20:30:06 --> The phrase "What is Unmark?" could not be found in the language file.
DEBUG - 2020-10-05 20:30:06 --> The phrase "What is Unmark?" could not be found in the language file.
INFO - 2020-10-05 20:30:06 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 20:30:06 --> File loaded: /var/www/html/custom/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 20:30:06 --> File loaded: /var/www/html/custom/views/welcome.php
INFO - 2020-10-05 20:30:06 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:30:06 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:30:06 --> Final output sent to browser
DEBUG - 2020-10-05 20:30:06 --> Total execution time: 0.1777
INFO - 2020-10-05 20:35:07 --> Config Class Initialized
INFO - 2020-10-05 20:35:07 --> Plain_Config Class Initialized
INFO - 2020-10-05 20:35:07 --> Hooks Class Initialized
INFO - 2020-10-05 20:35:07 --> Plain_Hooks Class Constructed
INFO - 2020-10-05 20:35:07 --> Plain_Hooks Class Initialized
DEBUG - 2020-10-05 20:35:07 --> UTF-8 Support Disabled
INFO - 2020-10-05 20:35:07 --> Utf8 Class Initialized
INFO - 2020-10-05 20:35:07 --> URI Class Initialized
DEBUG - 2020-10-05 20:35:07 --> No URI present. Default controller set.
INFO - 2020-10-05 20:35:07 --> Router Class Initialized
INFO - 2020-10-05 20:35:07 --> Plain_Router Class Initialized
INFO - 2020-10-05 20:35:07 --> Output Class Initialized
INFO - 2020-10-05 20:35:07 --> Security Class Initialized
DEBUG - 2020-10-05 20:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 20:35:07 --> Input Class Initialized
INFO - 2020-10-05 20:35:07 --> Language Class Initialized
INFO - 2020-10-05 20:35:07 --> Loader Class Initialized
INFO - 2020-10-05 20:35:07 --> Plain_Loader Class Initialized
DEBUG - 2020-10-05 20:35:07 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-10-05 20:35:07 --> Helper loaded: data_helper
INFO - 2020-10-05 20:35:07 --> Helper loaded: hash_helper
INFO - 2020-10-05 20:35:07 --> Helper loaded: validation_helper
INFO - 2020-10-05 20:35:07 --> Helper loaded: view_helper
INFO - 2020-10-05 20:35:07 --> Helper loaded: url_helper
INFO - 2020-10-05 20:35:07 --> Helper loaded: rss_helper
INFO - 2020-10-05 20:35:07 --> Database Driver Class Initialized
INFO - 2020-10-05 20:35:07 --> Controller Class Initialized
INFO - 2020-10-05 20:35:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 20:35:07 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-10-05 20:35:07 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:35:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 20:35:07 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:35:07 --> Custom Hooks class initialized.
DEBUG - 2020-10-05 20:35:07 --> The "english" language file has been loaded.
DEBUG - 2020-10-05 20:35:07 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-10-05 20:35:07 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:35:07 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-10-05 20:35:07 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:35:07 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-10-05 20:35:07 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-10-05 20:35:07 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-10-05 20:35:07 --> The phrase "Need to Sign In?" could not be found in the language file.
DEBUG - 2020-10-05 20:35:07 --> The phrase "What is Unmark?" could not be found in the language file.
DEBUG - 2020-10-05 20:35:07 --> The phrase "What is Unmark?" could not be found in the language file.
INFO - 2020-10-05 20:35:07 --> File loaded: /var/www/html/custom/views/layouts/analyticsjs.php
INFO - 2020-10-05 20:35:07 --> File loaded: /var/www/html/custom/views/layouts/footer_unlogged_scripts.php
INFO - 2020-10-05 20:35:07 --> File loaded: /var/www/html/custom/views/welcome.php
INFO - 2020-10-05 20:35:07 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:35:07 --> Custom Hooks class initialized.
INFO - 2020-10-05 20:35:07 --> Final output sent to browser
DEBUG - 2020-10-05 20:35:07 --> Total execution time: 0.1659
