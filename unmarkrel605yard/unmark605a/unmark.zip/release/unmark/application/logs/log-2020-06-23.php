<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-06-23 19:16:56 --> Config Class Initialized
INFO - 2020-06-23 19:16:56 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:16:56 --> Hooks Class Initialized
INFO - 2020-06-23 19:16:56 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:16:56 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:16:56 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:16:56 --> Utf8 Class Initialized
INFO - 2020-06-23 19:16:56 --> URI Class Initialized
DEBUG - 2020-06-23 19:16:56 --> No URI present. Default controller set.
INFO - 2020-06-23 19:16:56 --> Router Class Initialized
INFO - 2020-06-23 19:16:56 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:16:56 --> Output Class Initialized
INFO - 2020-06-23 19:16:56 --> Security Class Initialized
DEBUG - 2020-06-23 19:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:16:56 --> Input Class Initialized
INFO - 2020-06-23 19:16:56 --> Language Class Initialized
INFO - 2020-06-23 19:16:56 --> Loader Class Initialized
INFO - 2020-06-23 19:16:56 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:16:56 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:16:56 --> Helper loaded: data_helper
INFO - 2020-06-23 19:16:56 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:16:56 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:16:56 --> Helper loaded: view_helper
INFO - 2020-06-23 19:16:56 --> Helper loaded: url_helper
INFO - 2020-06-23 19:16:56 --> Database Driver Class Initialized
INFO - 2020-06-23 19:16:56 --> Controller Class Initialized
INFO - 2020-06-23 19:16:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:16:56 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:16:56 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 19:16:56 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 19:16:56 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:16:56 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 19:16:56 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:16:56 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:16:56 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:16:56 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-23 19:16:56 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-23 19:16:56 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 19:16:56 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-23 19:16:56 --> Final output sent to browser
DEBUG - 2020-06-23 19:16:56 --> Total execution time: 0.1873
INFO - 2020-06-23 19:16:58 --> Config Class Initialized
INFO - 2020-06-23 19:16:58 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:16:58 --> Hooks Class Initialized
INFO - 2020-06-23 19:16:58 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:16:58 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:16:58 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:16:58 --> Utf8 Class Initialized
INFO - 2020-06-23 19:16:58 --> URI Class Initialized
DEBUG - 2020-06-23 19:16:58 --> Validating request for /controllers/Custom.php
INFO - 2020-06-23 19:16:58 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-23 19:16:58 --> 404 Page Not Found: custom
INFO - 2020-06-23 19:16:59 --> Config Class Initialized
INFO - 2020-06-23 19:16:59 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:16:59 --> Hooks Class Initialized
INFO - 2020-06-23 19:16:59 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:16:59 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:16:59 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:16:59 --> Utf8 Class Initialized
INFO - 2020-06-23 19:16:59 --> URI Class Initialized
DEBUG - 2020-06-23 19:16:59 --> No URI present. Default controller set.
INFO - 2020-06-23 19:16:59 --> Router Class Initialized
INFO - 2020-06-23 19:16:59 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:16:59 --> Output Class Initialized
INFO - 2020-06-23 19:16:59 --> Security Class Initialized
DEBUG - 2020-06-23 19:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:16:59 --> Input Class Initialized
INFO - 2020-06-23 19:16:59 --> Language Class Initialized
INFO - 2020-06-23 19:16:59 --> Loader Class Initialized
INFO - 2020-06-23 19:16:59 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:16:59 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:16:59 --> Helper loaded: data_helper
INFO - 2020-06-23 19:16:59 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:16:59 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:16:59 --> Helper loaded: view_helper
INFO - 2020-06-23 19:16:59 --> Helper loaded: url_helper
INFO - 2020-06-23 19:16:59 --> Database Driver Class Initialized
INFO - 2020-06-23 19:16:59 --> Controller Class Initialized
INFO - 2020-06-23 19:16:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:16:59 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:16:59 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 19:16:59 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 19:16:59 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:16:59 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 19:16:59 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:16:59 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:16:59 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:16:59 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-23 19:16:59 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-23 19:16:59 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 19:16:59 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-23 19:16:59 --> Final output sent to browser
DEBUG - 2020-06-23 19:16:59 --> Total execution time: 0.1220
INFO - 2020-06-23 19:17:04 --> Config Class Initialized
INFO - 2020-06-23 19:17:04 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:17:04 --> Hooks Class Initialized
INFO - 2020-06-23 19:17:04 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:17:04 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:17:04 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:17:04 --> Utf8 Class Initialized
INFO - 2020-06-23 19:17:04 --> URI Class Initialized
DEBUG - 2020-06-23 19:17:04 --> Validating request for /controllers/Login.php
INFO - 2020-06-23 19:17:04 --> Router Class Initialized
INFO - 2020-06-23 19:17:04 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:17:04 --> Output Class Initialized
INFO - 2020-06-23 19:17:04 --> Security Class Initialized
DEBUG - 2020-06-23 19:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:17:04 --> Input Class Initialized
INFO - 2020-06-23 19:17:04 --> Language Class Initialized
INFO - 2020-06-23 19:17:04 --> Loader Class Initialized
INFO - 2020-06-23 19:17:04 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:17:04 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:17:04 --> Helper loaded: data_helper
INFO - 2020-06-23 19:17:04 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:17:04 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:17:04 --> Helper loaded: view_helper
INFO - 2020-06-23 19:17:04 --> Helper loaded: url_helper
INFO - 2020-06-23 19:17:05 --> Database Driver Class Initialized
INFO - 2020-06-23 19:17:05 --> Controller Class Initialized
INFO - 2020-06-23 19:17:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:17:05 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:17:05 --> The "english" language file has been loaded.
INFO - 2020-06-23 19:17:05 --> Plain_Model class loaded
INFO - 2020-06-23 19:17:05 --> Model "Users_model" initialized
ERROR - 2020-06-23 19:17:05 --> Query error: Table 'unmark.users' doesn't exist - Invalid query: SELECT * FROM `users` WHERE email = 'colin@cdevroe.com' ORDER BY user_id DESC LIMIT 0,1
DEBUG - 2020-06-23 19:17:05 --> Language file loaded: language/english/db_lang.php
INFO - 2020-06-23 19:17:05 --> Plain_Exceptions Class Initialized
INFO - 2020-06-23 19:17:10 --> Config Class Initialized
INFO - 2020-06-23 19:17:10 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:17:10 --> Hooks Class Initialized
INFO - 2020-06-23 19:17:10 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:17:10 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:17:10 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:17:10 --> Utf8 Class Initialized
INFO - 2020-06-23 19:17:10 --> URI Class Initialized
DEBUG - 2020-06-23 19:17:10 --> Validating request for /controllers/Login.php
INFO - 2020-06-23 19:17:10 --> Router Class Initialized
INFO - 2020-06-23 19:17:10 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:17:10 --> Output Class Initialized
INFO - 2020-06-23 19:17:10 --> Security Class Initialized
DEBUG - 2020-06-23 19:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:17:10 --> Input Class Initialized
INFO - 2020-06-23 19:17:10 --> Language Class Initialized
INFO - 2020-06-23 19:17:10 --> Loader Class Initialized
INFO - 2020-06-23 19:17:10 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:17:10 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:17:10 --> Helper loaded: data_helper
INFO - 2020-06-23 19:17:10 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:17:10 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:17:10 --> Helper loaded: view_helper
INFO - 2020-06-23 19:17:10 --> Helper loaded: url_helper
INFO - 2020-06-23 19:17:10 --> Database Driver Class Initialized
INFO - 2020-06-23 19:17:10 --> Controller Class Initialized
INFO - 2020-06-23 19:17:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:17:10 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:17:10 --> The "english" language file has been loaded.
INFO - 2020-06-23 19:17:10 --> Plain_Model class loaded
INFO - 2020-06-23 19:17:10 --> Model "Users_model" initialized
ERROR - 2020-06-23 19:17:10 --> Query error: Table 'unmark.users' doesn't exist - Invalid query: SELECT * FROM `users` WHERE email = 'colin@cdevroe.com' ORDER BY user_id DESC LIMIT 0,1
DEBUG - 2020-06-23 19:17:10 --> Language file loaded: language/english/db_lang.php
INFO - 2020-06-23 19:17:10 --> Plain_Exceptions Class Initialized
INFO - 2020-06-23 19:17:13 --> Config Class Initialized
INFO - 2020-06-23 19:17:13 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:17:13 --> Hooks Class Initialized
INFO - 2020-06-23 19:17:13 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:17:13 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:17:13 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:17:13 --> Utf8 Class Initialized
INFO - 2020-06-23 19:17:13 --> URI Class Initialized
DEBUG - 2020-06-23 19:17:13 --> Validating request for /controllers/Register.php
INFO - 2020-06-23 19:17:13 --> Router Class Initialized
INFO - 2020-06-23 19:17:13 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:17:13 --> Output Class Initialized
INFO - 2020-06-23 19:17:13 --> Security Class Initialized
DEBUG - 2020-06-23 19:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:17:13 --> Input Class Initialized
INFO - 2020-06-23 19:17:13 --> Language Class Initialized
INFO - 2020-06-23 19:17:13 --> Loader Class Initialized
INFO - 2020-06-23 19:17:13 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:17:13 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:17:13 --> Helper loaded: data_helper
INFO - 2020-06-23 19:17:13 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:17:13 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:17:13 --> Helper loaded: view_helper
INFO - 2020-06-23 19:17:13 --> Helper loaded: url_helper
INFO - 2020-06-23 19:17:13 --> Database Driver Class Initialized
INFO - 2020-06-23 19:17:13 --> Controller Class Initialized
INFO - 2020-06-23 19:17:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:17:13 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:17:13 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 19:17:13 --> The phrase "Unmark : User Registration" could not be found in the language file.
DEBUG - 2020-06-23 19:17:13 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:17:13 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 19:17:13 --> The phrase "Password Again" could not be found in the language file.
DEBUG - 2020-06-23 19:17:13 --> The phrase "Terms of Use" could not be found in the language file.
DEBUG - 2020-06-23 19:17:13 --> The phrase "Have An Account? Sign In Here" could not be found in the language file.
INFO - 2020-06-23 19:17:13 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 19:17:13 --> File loaded: /var/www/html/application/views/register/index.php
INFO - 2020-06-23 19:17:13 --> Final output sent to browser
DEBUG - 2020-06-23 19:17:13 --> Total execution time: 0.1714
INFO - 2020-06-23 19:17:13 --> Config Class Initialized
INFO - 2020-06-23 19:17:13 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:17:13 --> Hooks Class Initialized
INFO - 2020-06-23 19:17:13 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:17:13 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:17:13 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:17:13 --> Utf8 Class Initialized
INFO - 2020-06-23 19:17:13 --> URI Class Initialized
DEBUG - 2020-06-23 19:17:13 --> Validating request for /controllers/Custom.php
INFO - 2020-06-23 19:17:13 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-23 19:17:13 --> 404 Page Not Found: custom
INFO - 2020-06-23 19:17:27 --> Config Class Initialized
INFO - 2020-06-23 19:17:27 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:17:27 --> Hooks Class Initialized
INFO - 2020-06-23 19:17:27 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:17:27 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:17:27 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:17:27 --> Utf8 Class Initialized
INFO - 2020-06-23 19:17:27 --> URI Class Initialized
DEBUG - 2020-06-23 19:17:27 --> Validating request for /controllers/Register.php
INFO - 2020-06-23 19:17:27 --> Router Class Initialized
INFO - 2020-06-23 19:17:27 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:17:27 --> Output Class Initialized
INFO - 2020-06-23 19:17:27 --> Security Class Initialized
DEBUG - 2020-06-23 19:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:17:27 --> Input Class Initialized
INFO - 2020-06-23 19:17:27 --> Language Class Initialized
INFO - 2020-06-23 19:17:27 --> Loader Class Initialized
INFO - 2020-06-23 19:17:27 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:17:27 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:17:27 --> Helper loaded: data_helper
INFO - 2020-06-23 19:17:27 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:17:27 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:17:27 --> Helper loaded: view_helper
INFO - 2020-06-23 19:17:27 --> Helper loaded: url_helper
INFO - 2020-06-23 19:17:27 --> Database Driver Class Initialized
INFO - 2020-06-23 19:17:27 --> Controller Class Initialized
INFO - 2020-06-23 19:17:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:17:27 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:17:27 --> The "english" language file has been loaded.
INFO - 2020-06-23 19:17:27 --> Plain_Model class loaded
INFO - 2020-06-23 19:17:27 --> Model "Users_model" initialized
ERROR - 2020-06-23 19:17:27 --> Query error: Table 'unmark.users' doesn't exist - Invalid query: 
            SELECT
            COUNT(users.user_id) AS total
            FROM `users` WHERE email = 'colin@cdevroe.com'
DEBUG - 2020-06-23 19:17:27 --> Language file loaded: language/english/db_lang.php
INFO - 2020-06-23 19:17:27 --> Plain_Exceptions Class Initialized
INFO - 2020-06-23 19:17:48 --> Config Class Initialized
INFO - 2020-06-23 19:17:48 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:17:48 --> Hooks Class Initialized
INFO - 2020-06-23 19:17:48 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:17:48 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:17:48 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:17:48 --> Utf8 Class Initialized
INFO - 2020-06-23 19:17:48 --> URI Class Initialized
DEBUG - 2020-06-23 19:17:48 --> Validating request for /controllers/Register.php
INFO - 2020-06-23 19:17:48 --> Router Class Initialized
INFO - 2020-06-23 19:17:48 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:17:48 --> Output Class Initialized
INFO - 2020-06-23 19:17:48 --> Security Class Initialized
DEBUG - 2020-06-23 19:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:17:48 --> Input Class Initialized
INFO - 2020-06-23 19:17:48 --> Language Class Initialized
INFO - 2020-06-23 19:17:48 --> Loader Class Initialized
INFO - 2020-06-23 19:17:48 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:17:48 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:17:48 --> Helper loaded: data_helper
INFO - 2020-06-23 19:17:48 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:17:48 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:17:48 --> Helper loaded: view_helper
INFO - 2020-06-23 19:17:48 --> Helper loaded: url_helper
INFO - 2020-06-23 19:17:48 --> Database Driver Class Initialized
INFO - 2020-06-23 19:17:48 --> Controller Class Initialized
INFO - 2020-06-23 19:17:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:17:48 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:17:48 --> The "english" language file has been loaded.
INFO - 2020-06-23 19:17:48 --> Plain_Model class loaded
INFO - 2020-06-23 19:17:48 --> Model "Users_model" initialized
ERROR - 2020-06-23 19:17:48 --> Query error: Table 'unmark.users' doesn't exist - Invalid query: 
            SELECT
            COUNT(users.user_id) AS total
            FROM `users` WHERE email = 'colin@cdevroe.com'
DEBUG - 2020-06-23 19:17:48 --> Language file loaded: language/english/db_lang.php
INFO - 2020-06-23 19:17:48 --> Plain_Exceptions Class Initialized
INFO - 2020-06-23 19:18:02 --> Config Class Initialized
INFO - 2020-06-23 19:18:02 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:18:02 --> Hooks Class Initialized
INFO - 2020-06-23 19:18:02 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:18:02 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:18:02 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:18:02 --> Utf8 Class Initialized
INFO - 2020-06-23 19:18:02 --> URI Class Initialized
DEBUG - 2020-06-23 19:18:02 --> Validating request for /controllers/Register.php
INFO - 2020-06-23 19:18:02 --> Router Class Initialized
INFO - 2020-06-23 19:18:02 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:18:02 --> Output Class Initialized
INFO - 2020-06-23 19:18:02 --> Security Class Initialized
DEBUG - 2020-06-23 19:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:18:02 --> Input Class Initialized
INFO - 2020-06-23 19:18:02 --> Language Class Initialized
INFO - 2020-06-23 19:18:02 --> Loader Class Initialized
INFO - 2020-06-23 19:18:02 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:18:02 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:18:02 --> Helper loaded: data_helper
INFO - 2020-06-23 19:18:02 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:18:02 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:18:02 --> Helper loaded: view_helper
INFO - 2020-06-23 19:18:02 --> Helper loaded: url_helper
INFO - 2020-06-23 19:18:02 --> Database Driver Class Initialized
INFO - 2020-06-23 19:18:02 --> Controller Class Initialized
INFO - 2020-06-23 19:18:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:18:02 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:18:02 --> The "english" language file has been loaded.
INFO - 2020-06-23 19:18:02 --> Plain_Model class loaded
INFO - 2020-06-23 19:18:02 --> Model "Users_model" initialized
ERROR - 2020-06-23 19:18:02 --> Query error: Table 'unmark.users' doesn't exist - Invalid query: 
            SELECT
            COUNT(users.user_id) AS total
            FROM `users` WHERE email = 'colin+localunmark@cdevroe.com'
DEBUG - 2020-06-23 19:18:02 --> Language file loaded: language/english/db_lang.php
INFO - 2020-06-23 19:18:02 --> Plain_Exceptions Class Initialized
INFO - 2020-06-23 19:18:09 --> Config Class Initialized
INFO - 2020-06-23 19:18:09 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:18:09 --> Hooks Class Initialized
INFO - 2020-06-23 19:18:09 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:18:09 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:18:09 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:18:09 --> Utf8 Class Initialized
INFO - 2020-06-23 19:18:09 --> URI Class Initialized
DEBUG - 2020-06-23 19:18:09 --> Validating request for /controllers/Register.php
INFO - 2020-06-23 19:18:09 --> Router Class Initialized
INFO - 2020-06-23 19:18:09 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:18:09 --> Output Class Initialized
INFO - 2020-06-23 19:18:09 --> Security Class Initialized
DEBUG - 2020-06-23 19:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:18:09 --> Input Class Initialized
INFO - 2020-06-23 19:18:09 --> Language Class Initialized
INFO - 2020-06-23 19:18:09 --> Loader Class Initialized
INFO - 2020-06-23 19:18:09 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:18:09 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:18:09 --> Helper loaded: data_helper
INFO - 2020-06-23 19:18:09 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:18:09 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:18:09 --> Helper loaded: view_helper
INFO - 2020-06-23 19:18:09 --> Helper loaded: url_helper
INFO - 2020-06-23 19:18:09 --> Database Driver Class Initialized
INFO - 2020-06-23 19:18:09 --> Controller Class Initialized
INFO - 2020-06-23 19:18:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:18:09 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:18:09 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 19:18:09 --> The phrase "Unmark : User Registration" could not be found in the language file.
DEBUG - 2020-06-23 19:18:09 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:18:09 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 19:18:09 --> The phrase "Password Again" could not be found in the language file.
DEBUG - 2020-06-23 19:18:09 --> The phrase "Terms of Use" could not be found in the language file.
DEBUG - 2020-06-23 19:18:09 --> The phrase "Have An Account? Sign In Here" could not be found in the language file.
INFO - 2020-06-23 19:18:09 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 19:18:09 --> File loaded: /var/www/html/application/views/register/index.php
INFO - 2020-06-23 19:18:09 --> Final output sent to browser
DEBUG - 2020-06-23 19:18:09 --> Total execution time: 0.1996
INFO - 2020-06-23 19:18:16 --> Config Class Initialized
INFO - 2020-06-23 19:18:16 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:18:16 --> Hooks Class Initialized
INFO - 2020-06-23 19:18:16 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:18:16 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:18:16 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:18:16 --> Utf8 Class Initialized
INFO - 2020-06-23 19:18:16 --> URI Class Initialized
DEBUG - 2020-06-23 19:18:16 --> Validating request for /controllers/Register.php
INFO - 2020-06-23 19:18:16 --> Router Class Initialized
INFO - 2020-06-23 19:18:16 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:18:16 --> Output Class Initialized
INFO - 2020-06-23 19:18:16 --> Security Class Initialized
DEBUG - 2020-06-23 19:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:18:16 --> Input Class Initialized
INFO - 2020-06-23 19:18:16 --> Language Class Initialized
INFO - 2020-06-23 19:18:16 --> Loader Class Initialized
INFO - 2020-06-23 19:18:16 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:18:16 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:18:16 --> Helper loaded: data_helper
INFO - 2020-06-23 19:18:16 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:18:16 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:18:16 --> Helper loaded: view_helper
INFO - 2020-06-23 19:18:16 --> Helper loaded: url_helper
INFO - 2020-06-23 19:18:16 --> Database Driver Class Initialized
INFO - 2020-06-23 19:18:16 --> Controller Class Initialized
INFO - 2020-06-23 19:18:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:18:16 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:18:16 --> The "english" language file has been loaded.
INFO - 2020-06-23 19:18:16 --> Plain_Model class loaded
INFO - 2020-06-23 19:18:16 --> Model "Users_model" initialized
ERROR - 2020-06-23 19:18:16 --> Query error: Table 'unmark.users' doesn't exist - Invalid query: 
            SELECT
            COUNT(users.user_id) AS total
            FROM `users` WHERE email = 'colin+localunmark@cdevroe.com'
DEBUG - 2020-06-23 19:18:16 --> Language file loaded: language/english/db_lang.php
INFO - 2020-06-23 19:18:16 --> Plain_Exceptions Class Initialized
INFO - 2020-06-23 19:18:42 --> Config Class Initialized
INFO - 2020-06-23 19:18:42 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:18:42 --> Hooks Class Initialized
INFO - 2020-06-23 19:18:42 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:18:42 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:18:42 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:18:42 --> Utf8 Class Initialized
INFO - 2020-06-23 19:18:42 --> URI Class Initialized
DEBUG - 2020-06-23 19:18:42 --> Validating request for /controllers/Install.php
INFO - 2020-06-23 19:18:42 --> Router Class Initialized
INFO - 2020-06-23 19:18:42 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:18:42 --> Output Class Initialized
INFO - 2020-06-23 19:18:42 --> Security Class Initialized
DEBUG - 2020-06-23 19:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:18:42 --> Input Class Initialized
INFO - 2020-06-23 19:18:42 --> Language Class Initialized
INFO - 2020-06-23 19:18:42 --> Loader Class Initialized
INFO - 2020-06-23 19:18:42 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:18:42 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:18:42 --> Helper loaded: data_helper
INFO - 2020-06-23 19:18:42 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:18:42 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:18:42 --> Helper loaded: view_helper
INFO - 2020-06-23 19:18:42 --> Helper loaded: url_helper
INFO - 2020-06-23 19:18:42 --> Database Driver Class Initialized
INFO - 2020-06-23 19:18:42 --> Controller Class Initialized
DEBUG - 2020-06-23 19:18:42 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 19:18:42 --> The phrase "Unmark: Setup" could not be found in the language file.
DEBUG - 2020-06-23 19:18:42 --> The phrase "Welcome to Unmark, the to-do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 19:18:42 --> The phrase "You're about to install version 2020.1 of the app.</p><p>Please <a href="https://github.com/plainmade/unmark/blob/master/readme.md">read the installation instructions</a> first." could not be found in the language file.
DEBUG - 2020-06-23 19:18:42 --> The phrase "Click to Install" could not be found in the language file.
INFO - 2020-06-23 19:18:42 --> File loaded: /var/www/html/application/views/setup.php
INFO - 2020-06-23 19:18:42 --> Final output sent to browser
DEBUG - 2020-06-23 19:18:42 --> Total execution time: 0.1487
INFO - 2020-06-23 19:18:42 --> Config Class Initialized
INFO - 2020-06-23 19:18:42 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:18:42 --> Hooks Class Initialized
INFO - 2020-06-23 19:18:42 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:18:42 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:18:42 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:18:42 --> Utf8 Class Initialized
INFO - 2020-06-23 19:18:42 --> URI Class Initialized
DEBUG - 2020-06-23 19:18:42 --> Validating request for /controllers/Custom.php
INFO - 2020-06-23 19:18:42 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-23 19:18:42 --> 404 Page Not Found: custom
INFO - 2020-06-23 19:18:46 --> Config Class Initialized
INFO - 2020-06-23 19:18:46 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:18:46 --> Hooks Class Initialized
INFO - 2020-06-23 19:18:46 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:18:46 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:18:46 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:18:46 --> Utf8 Class Initialized
INFO - 2020-06-23 19:18:46 --> URI Class Initialized
DEBUG - 2020-06-23 19:18:46 --> Validating request for /controllers/Install.php
INFO - 2020-06-23 19:18:46 --> Router Class Initialized
INFO - 2020-06-23 19:18:46 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:18:46 --> Output Class Initialized
INFO - 2020-06-23 19:18:46 --> Security Class Initialized
DEBUG - 2020-06-23 19:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:18:46 --> Input Class Initialized
INFO - 2020-06-23 19:18:46 --> Language Class Initialized
INFO - 2020-06-23 19:18:46 --> Loader Class Initialized
INFO - 2020-06-23 19:18:46 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:18:46 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:18:46 --> Helper loaded: data_helper
INFO - 2020-06-23 19:18:46 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:18:46 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:18:46 --> Helper loaded: view_helper
INFO - 2020-06-23 19:18:46 --> Helper loaded: url_helper
INFO - 2020-06-23 19:18:46 --> Database Driver Class Initialized
INFO - 2020-06-23 19:18:46 --> Controller Class Initialized
DEBUG - 2020-06-23 19:18:46 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 19:18:46 --> Plain Migrations class initialized
DEBUG - 2020-06-23 19:18:46 --> Language file loaded: language/english/migration_lang.php
INFO - 2020-06-23 19:18:46 --> Database Forge Class Initialized
DEBUG - 2020-06-23 19:18:46 --> Making backup before migrating failed.
DEBUG - 2020-06-23 19:18:46 --> Migrating up from version 0 to version 001
DEBUG - 2020-06-23 19:18:46 --> Migrating up from version 001 to version 002
DEBUG - 2020-06-23 19:18:46 --> Migrating up from version 002 to version 003
DEBUG - 2020-06-23 19:18:46 --> Migrating up from version 003 to version 004
DEBUG - 2020-06-23 19:18:46 --> Migrating up from version 004 to version 005
DEBUG - 2020-06-23 19:18:46 --> Migrating up from version 005 to version 006
DEBUG - 2020-06-23 19:18:46 --> Migrating up from version 006 to version 007
DEBUG - 2020-06-23 19:18:47 --> Migrating up from version 007 to version 008
DEBUG - 2020-06-23 19:18:47 --> Migrating up from version 008 to version 009
DEBUG - 2020-06-23 19:18:47 --> Migrating up from version 009 to version 010
DEBUG - 2020-06-23 19:18:47 --> Migrating up from version 010 to version 2014022801
DEBUG - 2020-06-23 19:18:47 --> Migrating up from version 2014022801 to version 2014112501
DEBUG - 2020-06-23 19:18:47 --> Finished migrating to 2014112501
DEBUG - 2020-06-23 19:18:47 --> Making backup before migrating failed.
INFO - 2020-06-23 19:18:47 --> Config Class Initialized
INFO - 2020-06-23 19:18:47 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:18:47 --> Hooks Class Initialized
INFO - 2020-06-23 19:18:47 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:18:47 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:18:47 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:18:47 --> Utf8 Class Initialized
INFO - 2020-06-23 19:18:47 --> URI Class Initialized
DEBUG - 2020-06-23 19:18:47 --> Validating request for /controllers/Register.php
INFO - 2020-06-23 19:18:47 --> Router Class Initialized
INFO - 2020-06-23 19:18:47 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:18:47 --> Output Class Initialized
INFO - 2020-06-23 19:18:47 --> Security Class Initialized
DEBUG - 2020-06-23 19:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:18:47 --> Input Class Initialized
INFO - 2020-06-23 19:18:47 --> Language Class Initialized
INFO - 2020-06-23 19:18:47 --> Loader Class Initialized
INFO - 2020-06-23 19:18:47 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:18:47 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:18:47 --> Helper loaded: data_helper
INFO - 2020-06-23 19:18:47 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:18:47 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:18:47 --> Helper loaded: view_helper
INFO - 2020-06-23 19:18:47 --> Helper loaded: url_helper
INFO - 2020-06-23 19:18:47 --> Database Driver Class Initialized
INFO - 2020-06-23 19:18:47 --> Controller Class Initialized
INFO - 2020-06-23 19:18:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:18:47 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:18:47 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 19:18:47 --> The phrase "Unmark : User Registration" could not be found in the language file.
DEBUG - 2020-06-23 19:18:47 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:18:47 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 19:18:47 --> The phrase "Password Again" could not be found in the language file.
DEBUG - 2020-06-23 19:18:47 --> The phrase "Terms of Use" could not be found in the language file.
DEBUG - 2020-06-23 19:18:47 --> The phrase "Have An Account? Sign In Here" could not be found in the language file.
INFO - 2020-06-23 19:18:47 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 19:18:47 --> File loaded: /var/www/html/application/views/register/index.php
INFO - 2020-06-23 19:18:47 --> Final output sent to browser
DEBUG - 2020-06-23 19:18:47 --> Total execution time: 0.1513
INFO - 2020-06-23 19:18:47 --> Config Class Initialized
INFO - 2020-06-23 19:18:47 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:18:47 --> Hooks Class Initialized
INFO - 2020-06-23 19:18:47 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:18:47 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:18:47 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:18:47 --> Utf8 Class Initialized
INFO - 2020-06-23 19:18:47 --> URI Class Initialized
DEBUG - 2020-06-23 19:18:47 --> Validating request for /controllers/Custom.php
INFO - 2020-06-23 19:18:47 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-23 19:18:47 --> 404 Page Not Found: custom
INFO - 2020-06-23 19:19:05 --> Config Class Initialized
INFO - 2020-06-23 19:19:05 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:19:05 --> Hooks Class Initialized
INFO - 2020-06-23 19:19:05 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:19:05 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:19:05 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:19:05 --> Utf8 Class Initialized
INFO - 2020-06-23 19:19:05 --> URI Class Initialized
DEBUG - 2020-06-23 19:19:05 --> Validating request for /controllers/Register.php
INFO - 2020-06-23 19:19:05 --> Router Class Initialized
INFO - 2020-06-23 19:19:05 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:19:05 --> Output Class Initialized
INFO - 2020-06-23 19:19:05 --> Security Class Initialized
DEBUG - 2020-06-23 19:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:19:05 --> Input Class Initialized
INFO - 2020-06-23 19:19:05 --> Language Class Initialized
INFO - 2020-06-23 19:19:05 --> Loader Class Initialized
INFO - 2020-06-23 19:19:05 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:19:05 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:19:05 --> Helper loaded: data_helper
INFO - 2020-06-23 19:19:05 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:19:05 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:19:05 --> Helper loaded: view_helper
INFO - 2020-06-23 19:19:05 --> Helper loaded: url_helper
INFO - 2020-06-23 19:19:05 --> Database Driver Class Initialized
INFO - 2020-06-23 19:19:05 --> Controller Class Initialized
INFO - 2020-06-23 19:19:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:19:05 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:19:05 --> The "english" language file has been loaded.
INFO - 2020-06-23 19:19:05 --> Plain_Model class loaded
INFO - 2020-06-23 19:19:05 --> Model "Users_model" initialized
INFO - 2020-06-23 19:19:05 --> Helper loaded: http_build_url_helper
INFO - 2020-06-23 19:19:05 --> Model "Marks_model" initialized
INFO - 2020-06-23 19:19:05 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-23 19:19:05 --> The phrase "Just Now" could not be found in the language file.
DEBUG - 2020-06-23 19:19:05 --> The phrase "Just Now" could not be found in the language file.
DEBUG - 2020-06-23 19:19:05 --> The phrase "Just Now" could not be found in the language file.
INFO - 2020-06-23 19:19:05 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-06-23 19:19:05 --> Final output sent to browser
DEBUG - 2020-06-23 19:19:05 --> Total execution time: 0.1469
INFO - 2020-06-23 19:19:08 --> Config Class Initialized
INFO - 2020-06-23 19:19:08 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:19:08 --> Hooks Class Initialized
INFO - 2020-06-23 19:19:08 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:19:08 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:19:08 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:19:08 --> Utf8 Class Initialized
INFO - 2020-06-23 19:19:08 --> URI Class Initialized
DEBUG - 2020-06-23 19:19:08 --> No URI present. Default controller set.
INFO - 2020-06-23 19:19:08 --> Router Class Initialized
INFO - 2020-06-23 19:19:08 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:19:08 --> Output Class Initialized
INFO - 2020-06-23 19:19:08 --> Security Class Initialized
DEBUG - 2020-06-23 19:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:19:08 --> Input Class Initialized
INFO - 2020-06-23 19:19:08 --> Language Class Initialized
INFO - 2020-06-23 19:19:08 --> Loader Class Initialized
INFO - 2020-06-23 19:19:08 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:19:08 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:19:08 --> Helper loaded: data_helper
INFO - 2020-06-23 19:19:08 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:19:08 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:19:08 --> Helper loaded: view_helper
INFO - 2020-06-23 19:19:08 --> Helper loaded: url_helper
INFO - 2020-06-23 19:19:08 --> Database Driver Class Initialized
INFO - 2020-06-23 19:19:08 --> Controller Class Initialized
INFO - 2020-06-23 19:19:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:19:08 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:19:08 --> The "english" language file has been loaded.
INFO - 2020-06-23 19:19:08 --> Config Class Initialized
INFO - 2020-06-23 19:19:08 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:19:08 --> Hooks Class Initialized
INFO - 2020-06-23 19:19:08 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:19:08 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:19:08 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:19:08 --> Utf8 Class Initialized
INFO - 2020-06-23 19:19:08 --> URI Class Initialized
DEBUG - 2020-06-23 19:19:08 --> Validating request for /controllers/Marks.php
INFO - 2020-06-23 19:19:08 --> Router Class Initialized
INFO - 2020-06-23 19:19:08 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:19:08 --> Output Class Initialized
INFO - 2020-06-23 19:19:08 --> Security Class Initialized
DEBUG - 2020-06-23 19:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:19:08 --> Input Class Initialized
INFO - 2020-06-23 19:19:08 --> Language Class Initialized
INFO - 2020-06-23 19:19:08 --> Loader Class Initialized
INFO - 2020-06-23 19:19:08 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:19:08 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:19:08 --> Helper loaded: data_helper
INFO - 2020-06-23 19:19:08 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:19:08 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:19:08 --> Helper loaded: view_helper
INFO - 2020-06-23 19:19:08 --> Helper loaded: url_helper
INFO - 2020-06-23 19:19:08 --> Database Driver Class Initialized
INFO - 2020-06-23 19:19:08 --> Controller Class Initialized
INFO - 2020-06-23 19:19:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:19:08 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-23 19:19:08 --> Plain_Model class loaded
INFO - 2020-06-23 19:19:08 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-23 19:19:08 --> The "english" language file has been loaded.
INFO - 2020-06-23 19:19:08 --> Model "Labels_model" initialized
INFO - 2020-06-23 19:19:08 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-23 19:19:08 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-23 19:19:08 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-23 19:19:08 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-23 19:19:08 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-23 19:19:08 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-23 19:19:08 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-23 19:19:08 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-23 19:19:08 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-23 19:19:08 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-23 19:19:08 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-23 19:19:08 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-23 19:19:08 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-23 19:19:08 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-23 19:19:08 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-23 19:19:08 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-23 19:19:08 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-23 19:19:08 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-23 19:19:08 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-23 19:19:08 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-23 19:19:08 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-23 19:19:08 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-23 19:19:08 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-23 19:19:08 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-23 19:19:08 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-23 19:19:08 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-23 19:19:08 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-23 19:19:08 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-23 19:19:08 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-23 19:19:08 --> Final output sent to browser
DEBUG - 2020-06-23 19:19:08 --> Total execution time: 0.2000
INFO - 2020-06-23 19:19:08 --> Config Class Initialized
INFO - 2020-06-23 19:19:08 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:19:08 --> Hooks Class Initialized
INFO - 2020-06-23 19:19:08 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:19:08 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:19:08 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:19:08 --> Utf8 Class Initialized
INFO - 2020-06-23 19:19:08 --> URI Class Initialized
DEBUG - 2020-06-23 19:19:08 --> Validating request for /controllers/Custom.php
INFO - 2020-06-23 19:19:08 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-23 19:19:08 --> 404 Page Not Found: custom
INFO - 2020-06-23 19:22:00 --> Config Class Initialized
INFO - 2020-06-23 19:22:00 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:22:00 --> Hooks Class Initialized
INFO - 2020-06-23 19:22:00 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:22:00 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:22:00 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:22:00 --> Utf8 Class Initialized
INFO - 2020-06-23 19:22:00 --> URI Class Initialized
DEBUG - 2020-06-23 19:22:00 --> No URI present. Default controller set.
INFO - 2020-06-23 19:22:00 --> Router Class Initialized
INFO - 2020-06-23 19:22:00 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:22:00 --> Output Class Initialized
INFO - 2020-06-23 19:22:00 --> Security Class Initialized
DEBUG - 2020-06-23 19:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:22:00 --> Input Class Initialized
INFO - 2020-06-23 19:22:00 --> Language Class Initialized
INFO - 2020-06-23 19:22:00 --> Loader Class Initialized
INFO - 2020-06-23 19:22:00 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:22:00 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:22:00 --> Helper loaded: data_helper
INFO - 2020-06-23 19:22:00 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:22:00 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:22:00 --> Helper loaded: view_helper
INFO - 2020-06-23 19:22:00 --> Helper loaded: url_helper
INFO - 2020-06-23 19:22:00 --> Database Driver Class Initialized
INFO - 2020-06-23 19:22:00 --> Controller Class Initialized
INFO - 2020-06-23 19:22:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:22:00 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:22:00 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 19:22:00 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 19:22:00 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:22:00 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 19:22:00 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:22:00 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:22:00 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:22:00 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-23 19:22:00 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-23 19:22:00 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 19:22:00 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-23 19:22:00 --> Final output sent to browser
DEBUG - 2020-06-23 19:22:00 --> Total execution time: 0.1787
INFO - 2020-06-23 19:27:00 --> Config Class Initialized
INFO - 2020-06-23 19:27:00 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:27:00 --> Hooks Class Initialized
INFO - 2020-06-23 19:27:00 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:27:00 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:27:00 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:27:00 --> Utf8 Class Initialized
INFO - 2020-06-23 19:27:00 --> URI Class Initialized
DEBUG - 2020-06-23 19:27:00 --> No URI present. Default controller set.
INFO - 2020-06-23 19:27:00 --> Router Class Initialized
INFO - 2020-06-23 19:27:00 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:27:00 --> Output Class Initialized
INFO - 2020-06-23 19:27:00 --> Security Class Initialized
DEBUG - 2020-06-23 19:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:27:00 --> Input Class Initialized
INFO - 2020-06-23 19:27:00 --> Language Class Initialized
INFO - 2020-06-23 19:27:00 --> Loader Class Initialized
INFO - 2020-06-23 19:27:00 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:27:00 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:27:00 --> Helper loaded: data_helper
INFO - 2020-06-23 19:27:00 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:27:00 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:27:00 --> Helper loaded: view_helper
INFO - 2020-06-23 19:27:00 --> Helper loaded: url_helper
INFO - 2020-06-23 19:27:00 --> Database Driver Class Initialized
INFO - 2020-06-23 19:27:00 --> Controller Class Initialized
INFO - 2020-06-23 19:27:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:27:00 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:27:00 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 19:27:00 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 19:27:00 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:27:00 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 19:27:00 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:27:00 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:27:00 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:27:00 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-23 19:27:00 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-23 19:27:00 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 19:27:00 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-23 19:27:00 --> Final output sent to browser
DEBUG - 2020-06-23 19:27:00 --> Total execution time: 0.1550
INFO - 2020-06-23 19:29:32 --> Config Class Initialized
INFO - 2020-06-23 19:29:32 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:29:32 --> Hooks Class Initialized
INFO - 2020-06-23 19:29:32 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:29:32 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:29:32 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:29:32 --> Utf8 Class Initialized
INFO - 2020-06-23 19:29:32 --> URI Class Initialized
DEBUG - 2020-06-23 19:29:32 --> Validating request for /controllers/Marks.php
INFO - 2020-06-23 19:29:32 --> Router Class Initialized
INFO - 2020-06-23 19:29:32 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:29:32 --> Output Class Initialized
INFO - 2020-06-23 19:29:32 --> Security Class Initialized
DEBUG - 2020-06-23 19:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:29:32 --> Input Class Initialized
INFO - 2020-06-23 19:29:32 --> Language Class Initialized
INFO - 2020-06-23 19:29:32 --> Loader Class Initialized
INFO - 2020-06-23 19:29:32 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:29:32 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:29:32 --> Helper loaded: data_helper
INFO - 2020-06-23 19:29:32 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:29:32 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:29:32 --> Helper loaded: view_helper
INFO - 2020-06-23 19:29:32 --> Helper loaded: url_helper
INFO - 2020-06-23 19:29:33 --> Database Driver Class Initialized
INFO - 2020-06-23 19:29:33 --> Controller Class Initialized
INFO - 2020-06-23 19:29:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:29:33 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-23 19:29:33 --> Plain_Model class loaded
INFO - 2020-06-23 19:29:33 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-23 19:29:33 --> The "english" language file has been loaded.
INFO - 2020-06-23 19:29:33 --> Model "Labels_model" initialized
INFO - 2020-06-23 19:29:33 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-23 19:29:33 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-23 19:29:33 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-23 19:29:33 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-23 19:29:33 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-23 19:29:33 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-23 19:29:33 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-23 19:29:33 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-23 19:29:33 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-23 19:29:33 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-23 19:29:33 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-23 19:29:33 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-23 19:29:33 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-23 19:29:33 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-23 19:29:33 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-23 19:29:33 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-23 19:29:33 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-23 19:29:33 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-23 19:29:33 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-23 19:29:33 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-23 19:29:33 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-23 19:29:33 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-23 19:29:33 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-23 19:29:33 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-23 19:29:33 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-23 19:29:33 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-23 19:29:33 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-23 19:29:33 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-23 19:29:33 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-23 19:29:33 --> Final output sent to browser
DEBUG - 2020-06-23 19:29:33 --> Total execution time: 0.3048
INFO - 2020-06-23 19:29:33 --> Config Class Initialized
INFO - 2020-06-23 19:29:33 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:29:33 --> Hooks Class Initialized
INFO - 2020-06-23 19:29:33 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:29:33 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:29:33 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:29:33 --> Utf8 Class Initialized
INFO - 2020-06-23 19:29:33 --> URI Class Initialized
DEBUG - 2020-06-23 19:29:33 --> Validating request for /controllers/Custom.php
INFO - 2020-06-23 19:29:33 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-23 19:29:33 --> 404 Page Not Found: custom
INFO - 2020-06-23 19:30:40 --> Config Class Initialized
INFO - 2020-06-23 19:30:40 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:30:40 --> Hooks Class Initialized
INFO - 2020-06-23 19:30:40 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:30:40 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:30:40 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:30:40 --> Utf8 Class Initialized
INFO - 2020-06-23 19:30:40 --> URI Class Initialized
DEBUG - 2020-06-23 19:30:40 --> Validating request for /controllers/Marks.php
INFO - 2020-06-23 19:30:40 --> Router Class Initialized
INFO - 2020-06-23 19:30:40 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:30:40 --> Output Class Initialized
INFO - 2020-06-23 19:30:40 --> Security Class Initialized
DEBUG - 2020-06-23 19:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:30:40 --> Input Class Initialized
INFO - 2020-06-23 19:30:40 --> Language Class Initialized
INFO - 2020-06-23 19:30:40 --> Loader Class Initialized
INFO - 2020-06-23 19:30:40 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:30:40 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:30:40 --> Helper loaded: data_helper
INFO - 2020-06-23 19:30:40 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:30:40 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:30:40 --> Helper loaded: view_helper
INFO - 2020-06-23 19:30:40 --> Helper loaded: url_helper
INFO - 2020-06-23 19:30:40 --> Database Driver Class Initialized
INFO - 2020-06-23 19:30:40 --> Controller Class Initialized
INFO - 2020-06-23 19:30:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:30:40 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-23 19:30:40 --> Plain_Model class loaded
INFO - 2020-06-23 19:30:40 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-23 19:30:40 --> The "english" language file has been loaded.
INFO - 2020-06-23 19:30:40 --> Model "Labels_model" initialized
INFO - 2020-06-23 19:30:40 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-23 19:30:40 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-23 19:30:40 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-23 19:30:40 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-23 19:30:40 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-23 19:30:40 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-23 19:30:40 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-23 19:30:40 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-23 19:30:40 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-23 19:30:40 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-23 19:30:40 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-23 19:30:40 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-23 19:30:40 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-23 19:30:40 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-23 19:30:40 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-23 19:30:40 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-23 19:30:40 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-23 19:30:40 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-23 19:30:40 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-23 19:30:40 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-23 19:30:40 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-23 19:30:40 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-23 19:30:40 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-23 19:30:40 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-23 19:30:40 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-23 19:30:40 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-23 19:30:40 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-23 19:30:40 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-23 19:30:40 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-23 19:30:40 --> Final output sent to browser
DEBUG - 2020-06-23 19:30:40 --> Total execution time: 0.3454
INFO - 2020-06-23 19:30:41 --> Config Class Initialized
INFO - 2020-06-23 19:30:41 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:30:41 --> Hooks Class Initialized
INFO - 2020-06-23 19:30:41 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:30:41 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:30:41 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:30:41 --> Utf8 Class Initialized
INFO - 2020-06-23 19:30:41 --> URI Class Initialized
DEBUG - 2020-06-23 19:30:41 --> Validating request for /controllers/Custom.php
INFO - 2020-06-23 19:30:41 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-23 19:30:41 --> 404 Page Not Found: custom
INFO - 2020-06-23 19:32:01 --> Config Class Initialized
INFO - 2020-06-23 19:32:01 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:32:01 --> Hooks Class Initialized
INFO - 2020-06-23 19:32:01 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:32:01 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:32:01 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:32:01 --> Utf8 Class Initialized
INFO - 2020-06-23 19:32:01 --> URI Class Initialized
DEBUG - 2020-06-23 19:32:01 --> No URI present. Default controller set.
INFO - 2020-06-23 19:32:01 --> Router Class Initialized
INFO - 2020-06-23 19:32:01 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:32:01 --> Output Class Initialized
INFO - 2020-06-23 19:32:01 --> Security Class Initialized
DEBUG - 2020-06-23 19:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:32:01 --> Input Class Initialized
INFO - 2020-06-23 19:32:01 --> Language Class Initialized
INFO - 2020-06-23 19:32:01 --> Loader Class Initialized
INFO - 2020-06-23 19:32:01 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:32:01 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:32:01 --> Helper loaded: data_helper
INFO - 2020-06-23 19:32:01 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:32:01 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:32:01 --> Helper loaded: view_helper
INFO - 2020-06-23 19:32:01 --> Helper loaded: url_helper
INFO - 2020-06-23 19:32:01 --> Database Driver Class Initialized
INFO - 2020-06-23 19:32:01 --> Controller Class Initialized
INFO - 2020-06-23 19:32:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:32:01 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:32:01 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 19:32:01 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 19:32:01 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:32:01 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 19:32:01 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:32:01 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:32:01 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:32:01 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-23 19:32:01 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-23 19:32:01 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 19:32:01 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-23 19:32:01 --> Final output sent to browser
DEBUG - 2020-06-23 19:32:01 --> Total execution time: 0.1762
INFO - 2020-06-23 19:37:01 --> Config Class Initialized
INFO - 2020-06-23 19:37:01 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:37:01 --> Hooks Class Initialized
INFO - 2020-06-23 19:37:01 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:37:01 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:37:01 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:37:01 --> Utf8 Class Initialized
INFO - 2020-06-23 19:37:01 --> URI Class Initialized
DEBUG - 2020-06-23 19:37:01 --> No URI present. Default controller set.
INFO - 2020-06-23 19:37:01 --> Router Class Initialized
INFO - 2020-06-23 19:37:01 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:37:01 --> Output Class Initialized
INFO - 2020-06-23 19:37:01 --> Security Class Initialized
DEBUG - 2020-06-23 19:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:37:01 --> Input Class Initialized
INFO - 2020-06-23 19:37:01 --> Language Class Initialized
INFO - 2020-06-23 19:37:01 --> Loader Class Initialized
INFO - 2020-06-23 19:37:01 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:37:01 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:37:01 --> Helper loaded: data_helper
INFO - 2020-06-23 19:37:01 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:37:01 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:37:01 --> Helper loaded: view_helper
INFO - 2020-06-23 19:37:01 --> Helper loaded: url_helper
INFO - 2020-06-23 19:37:01 --> Database Driver Class Initialized
INFO - 2020-06-23 19:37:01 --> Controller Class Initialized
INFO - 2020-06-23 19:37:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:37:01 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:37:01 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 19:37:01 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 19:37:01 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:37:01 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 19:37:01 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:37:01 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:37:01 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:37:01 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-23 19:37:01 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-23 19:37:01 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 19:37:01 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-23 19:37:01 --> Final output sent to browser
DEBUG - 2020-06-23 19:37:01 --> Total execution time: 0.1710
INFO - 2020-06-23 19:42:02 --> Config Class Initialized
INFO - 2020-06-23 19:42:02 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:42:02 --> Hooks Class Initialized
INFO - 2020-06-23 19:42:02 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:42:02 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:42:02 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:42:02 --> Utf8 Class Initialized
INFO - 2020-06-23 19:42:02 --> URI Class Initialized
DEBUG - 2020-06-23 19:42:02 --> No URI present. Default controller set.
INFO - 2020-06-23 19:42:02 --> Router Class Initialized
INFO - 2020-06-23 19:42:02 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:42:02 --> Output Class Initialized
INFO - 2020-06-23 19:42:02 --> Security Class Initialized
DEBUG - 2020-06-23 19:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:42:02 --> Input Class Initialized
INFO - 2020-06-23 19:42:02 --> Language Class Initialized
INFO - 2020-06-23 19:42:02 --> Loader Class Initialized
INFO - 2020-06-23 19:42:02 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:42:02 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:42:02 --> Helper loaded: data_helper
INFO - 2020-06-23 19:42:02 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:42:02 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:42:02 --> Helper loaded: view_helper
INFO - 2020-06-23 19:42:02 --> Helper loaded: url_helper
INFO - 2020-06-23 19:42:02 --> Database Driver Class Initialized
INFO - 2020-06-23 19:42:02 --> Controller Class Initialized
INFO - 2020-06-23 19:42:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:42:02 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:42:02 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 19:42:02 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 19:42:02 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:42:02 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 19:42:02 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:42:02 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:42:02 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:42:02 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-23 19:42:02 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-23 19:42:02 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 19:42:02 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-23 19:42:02 --> Final output sent to browser
DEBUG - 2020-06-23 19:42:02 --> Total execution time: 0.1930
INFO - 2020-06-23 19:47:02 --> Config Class Initialized
INFO - 2020-06-23 19:47:02 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:47:02 --> Hooks Class Initialized
INFO - 2020-06-23 19:47:02 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:47:02 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:47:02 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:47:02 --> Utf8 Class Initialized
INFO - 2020-06-23 19:47:02 --> URI Class Initialized
DEBUG - 2020-06-23 19:47:03 --> No URI present. Default controller set.
INFO - 2020-06-23 19:47:03 --> Router Class Initialized
INFO - 2020-06-23 19:47:03 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:47:03 --> Output Class Initialized
INFO - 2020-06-23 19:47:03 --> Security Class Initialized
DEBUG - 2020-06-23 19:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:47:03 --> Input Class Initialized
INFO - 2020-06-23 19:47:03 --> Language Class Initialized
INFO - 2020-06-23 19:47:03 --> Loader Class Initialized
INFO - 2020-06-23 19:47:03 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:47:03 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:47:03 --> Helper loaded: data_helper
INFO - 2020-06-23 19:47:03 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:47:03 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:47:03 --> Helper loaded: view_helper
INFO - 2020-06-23 19:47:03 --> Helper loaded: url_helper
INFO - 2020-06-23 19:47:03 --> Database Driver Class Initialized
INFO - 2020-06-23 19:47:03 --> Controller Class Initialized
INFO - 2020-06-23 19:47:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:47:03 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:47:03 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 19:47:03 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 19:47:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:47:03 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 19:47:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:47:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:47:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:47:03 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-23 19:47:03 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-23 19:47:03 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 19:47:03 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-23 19:47:03 --> Final output sent to browser
DEBUG - 2020-06-23 19:47:03 --> Total execution time: 0.1751
INFO - 2020-06-23 19:52:03 --> Config Class Initialized
INFO - 2020-06-23 19:52:03 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:52:03 --> Hooks Class Initialized
INFO - 2020-06-23 19:52:03 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:52:03 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:52:03 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:52:03 --> Utf8 Class Initialized
INFO - 2020-06-23 19:52:03 --> URI Class Initialized
DEBUG - 2020-06-23 19:52:03 --> No URI present. Default controller set.
INFO - 2020-06-23 19:52:03 --> Router Class Initialized
INFO - 2020-06-23 19:52:03 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:52:03 --> Output Class Initialized
INFO - 2020-06-23 19:52:03 --> Security Class Initialized
DEBUG - 2020-06-23 19:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:52:03 --> Input Class Initialized
INFO - 2020-06-23 19:52:03 --> Language Class Initialized
INFO - 2020-06-23 19:52:03 --> Loader Class Initialized
INFO - 2020-06-23 19:52:03 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:52:03 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:52:03 --> Helper loaded: data_helper
INFO - 2020-06-23 19:52:03 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:52:03 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:52:03 --> Helper loaded: view_helper
INFO - 2020-06-23 19:52:03 --> Helper loaded: url_helper
INFO - 2020-06-23 19:52:03 --> Database Driver Class Initialized
INFO - 2020-06-23 19:52:03 --> Controller Class Initialized
INFO - 2020-06-23 19:52:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:52:03 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:52:03 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 19:52:03 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 19:52:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:52:03 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 19:52:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:52:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:52:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:52:03 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-23 19:52:03 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-23 19:52:03 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 19:52:03 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-23 19:52:03 --> Final output sent to browser
DEBUG - 2020-06-23 19:52:03 --> Total execution time: 0.1162
INFO - 2020-06-23 19:57:04 --> Config Class Initialized
INFO - 2020-06-23 19:57:04 --> Plain_Config Class Initialized
INFO - 2020-06-23 19:57:04 --> Hooks Class Initialized
INFO - 2020-06-23 19:57:04 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 19:57:04 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 19:57:04 --> UTF-8 Support Disabled
INFO - 2020-06-23 19:57:04 --> Utf8 Class Initialized
INFO - 2020-06-23 19:57:04 --> URI Class Initialized
DEBUG - 2020-06-23 19:57:04 --> No URI present. Default controller set.
INFO - 2020-06-23 19:57:04 --> Router Class Initialized
INFO - 2020-06-23 19:57:04 --> Plain_Router Class Initialized
INFO - 2020-06-23 19:57:04 --> Output Class Initialized
INFO - 2020-06-23 19:57:04 --> Security Class Initialized
DEBUG - 2020-06-23 19:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 19:57:04 --> Input Class Initialized
INFO - 2020-06-23 19:57:04 --> Language Class Initialized
INFO - 2020-06-23 19:57:04 --> Loader Class Initialized
INFO - 2020-06-23 19:57:04 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 19:57:04 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 19:57:04 --> Helper loaded: data_helper
INFO - 2020-06-23 19:57:04 --> Helper loaded: hash_helper
INFO - 2020-06-23 19:57:04 --> Helper loaded: validation_helper
INFO - 2020-06-23 19:57:04 --> Helper loaded: view_helper
INFO - 2020-06-23 19:57:04 --> Helper loaded: url_helper
INFO - 2020-06-23 19:57:04 --> Database Driver Class Initialized
INFO - 2020-06-23 19:57:04 --> Controller Class Initialized
INFO - 2020-06-23 19:57:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 19:57:04 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 19:57:04 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 19:57:04 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 19:57:04 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:57:04 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 19:57:04 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:57:04 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 19:57:04 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 19:57:04 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-23 19:57:04 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-23 19:57:04 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 19:57:04 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-23 19:57:04 --> Final output sent to browser
DEBUG - 2020-06-23 19:57:04 --> Total execution time: 0.1732
INFO - 2020-06-23 20:01:33 --> Config Class Initialized
INFO - 2020-06-23 20:01:33 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:01:33 --> Hooks Class Initialized
INFO - 2020-06-23 20:01:33 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:01:33 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:01:33 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:01:33 --> Utf8 Class Initialized
INFO - 2020-06-23 20:01:33 --> URI Class Initialized
DEBUG - 2020-06-23 20:01:33 --> Validating request for /controllers/Marks.php
INFO - 2020-06-23 20:01:33 --> Router Class Initialized
INFO - 2020-06-23 20:01:33 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:01:33 --> Output Class Initialized
INFO - 2020-06-23 20:01:33 --> Security Class Initialized
DEBUG - 2020-06-23 20:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:01:33 --> Input Class Initialized
INFO - 2020-06-23 20:01:33 --> Language Class Initialized
INFO - 2020-06-23 20:01:33 --> Loader Class Initialized
INFO - 2020-06-23 20:01:33 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:01:33 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:01:33 --> Helper loaded: data_helper
INFO - 2020-06-23 20:01:33 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:01:33 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:01:33 --> Helper loaded: view_helper
INFO - 2020-06-23 20:01:33 --> Helper loaded: url_helper
INFO - 2020-06-23 20:01:33 --> Database Driver Class Initialized
INFO - 2020-06-23 20:01:33 --> Controller Class Initialized
INFO - 2020-06-23 20:01:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:01:33 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-23 20:01:33 --> Plain_Model class loaded
INFO - 2020-06-23 20:01:33 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-23 20:01:33 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:01:33 --> Model "Labels_model" initialized
INFO - 2020-06-23 20:01:33 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-23 20:01:33 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-23 20:01:33 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-23 20:01:33 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-23 20:01:33 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-23 20:01:33 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-23 20:01:33 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-23 20:01:33 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-23 20:01:33 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-23 20:01:33 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-23 20:01:33 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-23 20:01:33 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-23 20:01:33 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-23 20:01:33 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-23 20:01:33 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-23 20:01:33 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-23 20:01:33 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-23 20:01:33 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-23 20:01:33 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-23 20:01:33 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-23 20:01:33 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-23 20:01:33 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-23 20:01:33 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-23 20:01:33 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-23 20:01:33 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-23 20:01:33 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-23 20:01:33 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-23 20:01:33 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-23 20:01:33 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-23 20:01:33 --> Final output sent to browser
DEBUG - 2020-06-23 20:01:33 --> Total execution time: 0.2908
INFO - 2020-06-23 20:01:34 --> Config Class Initialized
INFO - 2020-06-23 20:01:34 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:01:34 --> Hooks Class Initialized
INFO - 2020-06-23 20:01:34 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:01:34 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:01:34 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:01:34 --> Utf8 Class Initialized
INFO - 2020-06-23 20:01:34 --> URI Class Initialized
DEBUG - 2020-06-23 20:01:34 --> Validating request for /controllers/Custom.php
INFO - 2020-06-23 20:01:34 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-23 20:01:34 --> 404 Page Not Found: custom
INFO - 2020-06-23 20:02:05 --> Config Class Initialized
INFO - 2020-06-23 20:02:05 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:02:05 --> Hooks Class Initialized
INFO - 2020-06-23 20:02:05 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:02:05 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:02:05 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:02:05 --> Utf8 Class Initialized
INFO - 2020-06-23 20:02:05 --> URI Class Initialized
DEBUG - 2020-06-23 20:02:05 --> No URI present. Default controller set.
INFO - 2020-06-23 20:02:05 --> Router Class Initialized
INFO - 2020-06-23 20:02:05 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:02:05 --> Output Class Initialized
INFO - 2020-06-23 20:02:05 --> Security Class Initialized
DEBUG - 2020-06-23 20:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:02:05 --> Input Class Initialized
INFO - 2020-06-23 20:02:05 --> Language Class Initialized
INFO - 2020-06-23 20:02:05 --> Loader Class Initialized
INFO - 2020-06-23 20:02:05 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:02:05 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:02:05 --> Helper loaded: data_helper
INFO - 2020-06-23 20:02:05 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:02:05 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:02:05 --> Helper loaded: view_helper
INFO - 2020-06-23 20:02:05 --> Helper loaded: url_helper
INFO - 2020-06-23 20:02:05 --> Database Driver Class Initialized
INFO - 2020-06-23 20:02:05 --> Controller Class Initialized
INFO - 2020-06-23 20:02:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:02:05 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:02:05 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 20:02:05 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 20:02:05 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 20:02:05 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 20:02:05 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 20:02:05 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 20:02:05 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 20:02:05 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-23 20:02:05 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-23 20:02:05 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 20:02:05 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-23 20:02:05 --> Final output sent to browser
DEBUG - 2020-06-23 20:02:05 --> Total execution time: 0.1760
INFO - 2020-06-23 20:04:45 --> Config Class Initialized
INFO - 2020-06-23 20:04:45 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:04:45 --> Hooks Class Initialized
INFO - 2020-06-23 20:04:45 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:04:45 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:04:45 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:04:45 --> Utf8 Class Initialized
INFO - 2020-06-23 20:04:45 --> URI Class Initialized
DEBUG - 2020-06-23 20:04:45 --> Validating request for /controllers/Marks.php
INFO - 2020-06-23 20:04:45 --> Router Class Initialized
INFO - 2020-06-23 20:04:45 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:04:45 --> Output Class Initialized
INFO - 2020-06-23 20:04:45 --> Security Class Initialized
DEBUG - 2020-06-23 20:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:04:45 --> Input Class Initialized
INFO - 2020-06-23 20:04:45 --> Language Class Initialized
INFO - 2020-06-23 20:04:45 --> Loader Class Initialized
INFO - 2020-06-23 20:04:45 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:04:45 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:04:45 --> Helper loaded: data_helper
INFO - 2020-06-23 20:04:45 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:04:45 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:04:45 --> Helper loaded: view_helper
INFO - 2020-06-23 20:04:45 --> Helper loaded: url_helper
INFO - 2020-06-23 20:04:45 --> Database Driver Class Initialized
INFO - 2020-06-23 20:04:45 --> Controller Class Initialized
INFO - 2020-06-23 20:04:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:04:45 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-23 20:04:45 --> Plain_Model class loaded
INFO - 2020-06-23 20:04:45 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-23 20:04:45 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:04:45 --> Model "Labels_model" initialized
INFO - 2020-06-23 20:04:45 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-23 20:04:45 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-23 20:04:45 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-23 20:04:45 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-23 20:04:45 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-23 20:04:45 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-23 20:04:45 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-23 20:04:45 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-23 20:04:45 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-23 20:04:45 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-23 20:04:45 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-23 20:04:45 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-23 20:04:45 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-23 20:04:45 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-23 20:04:45 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-23 20:04:45 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-23 20:04:45 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-23 20:04:45 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-23 20:04:45 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-23 20:04:45 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-23 20:04:45 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-23 20:04:45 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-23 20:04:45 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-23 20:04:45 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-23 20:04:45 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-23 20:04:45 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-23 20:04:45 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-23 20:04:45 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-23 20:04:45 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-23 20:04:45 --> Final output sent to browser
DEBUG - 2020-06-23 20:04:45 --> Total execution time: 0.1728
INFO - 2020-06-23 20:04:46 --> Config Class Initialized
INFO - 2020-06-23 20:04:46 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:04:46 --> Hooks Class Initialized
INFO - 2020-06-23 20:04:46 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:04:46 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:04:46 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:04:46 --> Utf8 Class Initialized
INFO - 2020-06-23 20:04:46 --> URI Class Initialized
DEBUG - 2020-06-23 20:04:46 --> Validating request for /controllers/Custom.php
INFO - 2020-06-23 20:04:46 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-23 20:04:46 --> 404 Page Not Found: custom
INFO - 2020-06-23 20:04:51 --> Config Class Initialized
INFO - 2020-06-23 20:04:51 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:04:51 --> Hooks Class Initialized
INFO - 2020-06-23 20:04:51 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:04:51 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:04:51 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:04:51 --> Utf8 Class Initialized
INFO - 2020-06-23 20:04:51 --> URI Class Initialized
DEBUG - 2020-06-23 20:04:51 --> Validating request for /controllers/Export.php
INFO - 2020-06-23 20:04:51 --> Router Class Initialized
INFO - 2020-06-23 20:04:51 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:04:51 --> Output Class Initialized
INFO - 2020-06-23 20:04:51 --> Security Class Initialized
DEBUG - 2020-06-23 20:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:04:51 --> Input Class Initialized
INFO - 2020-06-23 20:04:51 --> Language Class Initialized
INFO - 2020-06-23 20:04:51 --> Loader Class Initialized
INFO - 2020-06-23 20:04:51 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:04:51 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:04:51 --> Helper loaded: data_helper
INFO - 2020-06-23 20:04:51 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:04:51 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:04:51 --> Helper loaded: view_helper
INFO - 2020-06-23 20:04:51 --> Helper loaded: url_helper
INFO - 2020-06-23 20:04:51 --> Database Driver Class Initialized
INFO - 2020-06-23 20:04:51 --> Controller Class Initialized
INFO - 2020-06-23 20:04:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:04:51 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:04:51 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:04:51 --> Plain_Model class loaded
INFO - 2020-06-23 20:04:51 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-23 20:04:51 --> Final output sent to browser
DEBUG - 2020-06-23 20:04:51 --> Total execution time: 0.1428
INFO - 2020-06-23 20:05:08 --> Config Class Initialized
INFO - 2020-06-23 20:05:08 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:05:08 --> Hooks Class Initialized
INFO - 2020-06-23 20:05:08 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:05:08 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:05:08 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:05:08 --> Utf8 Class Initialized
INFO - 2020-06-23 20:05:08 --> URI Class Initialized
DEBUG - 2020-06-23 20:05:08 --> Validating request for /controllers/Export.php
INFO - 2020-06-23 20:05:08 --> Router Class Initialized
INFO - 2020-06-23 20:05:08 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:05:08 --> Output Class Initialized
INFO - 2020-06-23 20:05:08 --> Security Class Initialized
DEBUG - 2020-06-23 20:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:05:08 --> Input Class Initialized
INFO - 2020-06-23 20:05:08 --> Language Class Initialized
INFO - 2020-06-23 20:05:08 --> Loader Class Initialized
INFO - 2020-06-23 20:05:08 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:05:08 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:05:08 --> Helper loaded: data_helper
INFO - 2020-06-23 20:05:08 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:05:08 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:05:08 --> Helper loaded: view_helper
INFO - 2020-06-23 20:05:08 --> Helper loaded: url_helper
INFO - 2020-06-23 20:05:08 --> Database Driver Class Initialized
INFO - 2020-06-23 20:05:08 --> Controller Class Initialized
INFO - 2020-06-23 20:05:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:05:08 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:05:08 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:05:08 --> Plain_Model class loaded
INFO - 2020-06-23 20:05:09 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-23 20:05:09 --> Final output sent to browser
DEBUG - 2020-06-23 20:05:09 --> Total execution time: 0.1502
INFO - 2020-06-23 20:05:17 --> Config Class Initialized
INFO - 2020-06-23 20:05:17 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:05:17 --> Hooks Class Initialized
INFO - 2020-06-23 20:05:17 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:05:17 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:05:17 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:05:17 --> Utf8 Class Initialized
INFO - 2020-06-23 20:05:17 --> URI Class Initialized
DEBUG - 2020-06-23 20:05:17 --> Validating request for /controllers/Export.php
INFO - 2020-06-23 20:05:17 --> Router Class Initialized
INFO - 2020-06-23 20:05:17 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:05:17 --> Output Class Initialized
INFO - 2020-06-23 20:05:17 --> Security Class Initialized
DEBUG - 2020-06-23 20:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:05:17 --> Input Class Initialized
INFO - 2020-06-23 20:05:17 --> Language Class Initialized
INFO - 2020-06-23 20:05:17 --> Loader Class Initialized
INFO - 2020-06-23 20:05:17 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:05:17 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:05:17 --> Helper loaded: data_helper
INFO - 2020-06-23 20:05:17 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:05:17 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:05:17 --> Helper loaded: view_helper
INFO - 2020-06-23 20:05:17 --> Helper loaded: url_helper
INFO - 2020-06-23 20:05:17 --> Database Driver Class Initialized
INFO - 2020-06-23 20:05:17 --> Controller Class Initialized
INFO - 2020-06-23 20:05:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:05:17 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:05:17 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:05:17 --> Plain_Model class loaded
INFO - 2020-06-23 20:05:17 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-23 20:05:17 --> Final output sent to browser
DEBUG - 2020-06-23 20:05:17 --> Total execution time: 0.1506
INFO - 2020-06-23 20:07:05 --> Config Class Initialized
INFO - 2020-06-23 20:07:05 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:07:05 --> Hooks Class Initialized
INFO - 2020-06-23 20:07:05 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:07:05 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:07:05 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:07:05 --> Utf8 Class Initialized
INFO - 2020-06-23 20:07:05 --> URI Class Initialized
DEBUG - 2020-06-23 20:07:05 --> No URI present. Default controller set.
INFO - 2020-06-23 20:07:05 --> Router Class Initialized
INFO - 2020-06-23 20:07:05 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:07:05 --> Output Class Initialized
INFO - 2020-06-23 20:07:05 --> Security Class Initialized
DEBUG - 2020-06-23 20:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:07:05 --> Input Class Initialized
INFO - 2020-06-23 20:07:05 --> Language Class Initialized
INFO - 2020-06-23 20:07:05 --> Loader Class Initialized
INFO - 2020-06-23 20:07:05 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:07:05 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:07:05 --> Helper loaded: data_helper
INFO - 2020-06-23 20:07:05 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:07:05 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:07:05 --> Helper loaded: view_helper
INFO - 2020-06-23 20:07:05 --> Helper loaded: url_helper
INFO - 2020-06-23 20:07:05 --> Database Driver Class Initialized
INFO - 2020-06-23 20:07:05 --> Controller Class Initialized
INFO - 2020-06-23 20:07:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:07:05 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:07:05 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 20:07:05 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 20:07:05 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 20:07:05 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 20:07:05 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 20:07:05 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 20:07:05 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 20:07:05 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-23 20:07:05 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-23 20:07:05 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 20:07:05 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-23 20:07:05 --> Final output sent to browser
DEBUG - 2020-06-23 20:07:05 --> Total execution time: 0.1188
INFO - 2020-06-23 20:07:07 --> Config Class Initialized
INFO - 2020-06-23 20:07:07 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:07:07 --> Hooks Class Initialized
INFO - 2020-06-23 20:07:07 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:07:07 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:07:07 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:07:07 --> Utf8 Class Initialized
INFO - 2020-06-23 20:07:07 --> URI Class Initialized
DEBUG - 2020-06-23 20:07:07 --> Validating request for /controllers/Export.php
INFO - 2020-06-23 20:07:07 --> Router Class Initialized
INFO - 2020-06-23 20:07:07 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:07:07 --> Output Class Initialized
INFO - 2020-06-23 20:07:07 --> Security Class Initialized
DEBUG - 2020-06-23 20:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:07:07 --> Input Class Initialized
INFO - 2020-06-23 20:07:07 --> Language Class Initialized
INFO - 2020-06-23 20:07:07 --> Loader Class Initialized
INFO - 2020-06-23 20:07:07 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:07:07 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:07:07 --> Helper loaded: data_helper
INFO - 2020-06-23 20:07:07 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:07:07 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:07:07 --> Helper loaded: view_helper
INFO - 2020-06-23 20:07:07 --> Helper loaded: url_helper
INFO - 2020-06-23 20:07:07 --> Database Driver Class Initialized
INFO - 2020-06-23 20:07:07 --> Controller Class Initialized
INFO - 2020-06-23 20:07:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:07:07 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:07:07 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:07:08 --> Plain_Model class loaded
INFO - 2020-06-23 20:07:08 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-23 20:07:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-23 20:07:08 --> Array
(
    [message] => Error: Cannot use object of type stdClass as array
    [type] => Error
    [backtrace] => /var/www/html/application/controllers/Export.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-23 20:07:34 --> Config Class Initialized
INFO - 2020-06-23 20:07:34 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:07:34 --> Hooks Class Initialized
INFO - 2020-06-23 20:07:34 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:07:34 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:07:34 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:07:34 --> Utf8 Class Initialized
INFO - 2020-06-23 20:07:34 --> URI Class Initialized
DEBUG - 2020-06-23 20:07:34 --> Validating request for /controllers/Export.php
INFO - 2020-06-23 20:07:34 --> Router Class Initialized
INFO - 2020-06-23 20:07:34 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:07:34 --> Output Class Initialized
INFO - 2020-06-23 20:07:34 --> Security Class Initialized
DEBUG - 2020-06-23 20:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:07:34 --> Input Class Initialized
INFO - 2020-06-23 20:07:34 --> Language Class Initialized
INFO - 2020-06-23 20:07:34 --> Loader Class Initialized
INFO - 2020-06-23 20:07:34 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:07:34 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:07:34 --> Helper loaded: data_helper
INFO - 2020-06-23 20:07:34 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:07:34 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:07:34 --> Helper loaded: view_helper
INFO - 2020-06-23 20:07:34 --> Helper loaded: url_helper
INFO - 2020-06-23 20:07:34 --> Database Driver Class Initialized
INFO - 2020-06-23 20:07:34 --> Controller Class Initialized
INFO - 2020-06-23 20:07:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:07:34 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:07:34 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:07:34 --> Plain_Model class loaded
INFO - 2020-06-23 20:07:34 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-23 20:07:34 --> Final output sent to browser
DEBUG - 2020-06-23 20:07:34 --> Total execution time: 0.1906
INFO - 2020-06-23 20:08:22 --> Config Class Initialized
INFO - 2020-06-23 20:08:22 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:08:22 --> Hooks Class Initialized
INFO - 2020-06-23 20:08:22 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:08:22 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:08:22 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:08:22 --> Utf8 Class Initialized
INFO - 2020-06-23 20:08:22 --> URI Class Initialized
DEBUG - 2020-06-23 20:08:22 --> Validating request for /controllers/Export.php
INFO - 2020-06-23 20:08:22 --> Router Class Initialized
INFO - 2020-06-23 20:08:22 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:08:22 --> Output Class Initialized
INFO - 2020-06-23 20:08:22 --> Security Class Initialized
DEBUG - 2020-06-23 20:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:08:22 --> Input Class Initialized
INFO - 2020-06-23 20:08:22 --> Language Class Initialized
INFO - 2020-06-23 20:08:22 --> Loader Class Initialized
INFO - 2020-06-23 20:08:22 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:08:22 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:08:22 --> Helper loaded: data_helper
INFO - 2020-06-23 20:08:22 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:08:22 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:08:22 --> Helper loaded: view_helper
INFO - 2020-06-23 20:08:22 --> Helper loaded: url_helper
INFO - 2020-06-23 20:08:22 --> Database Driver Class Initialized
INFO - 2020-06-23 20:08:22 --> Controller Class Initialized
INFO - 2020-06-23 20:08:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:08:22 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:08:22 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:08:22 --> Plain_Model class loaded
INFO - 2020-06-23 20:08:22 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-23 20:08:22 --> Final output sent to browser
DEBUG - 2020-06-23 20:08:22 --> Total execution time: 0.1893
INFO - 2020-06-23 20:08:32 --> Config Class Initialized
INFO - 2020-06-23 20:08:32 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:08:32 --> Hooks Class Initialized
INFO - 2020-06-23 20:08:32 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:08:32 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:08:32 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:08:32 --> Utf8 Class Initialized
INFO - 2020-06-23 20:08:32 --> URI Class Initialized
DEBUG - 2020-06-23 20:08:32 --> Validating request for /controllers/Export.php
INFO - 2020-06-23 20:08:32 --> Router Class Initialized
INFO - 2020-06-23 20:08:33 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:08:33 --> Output Class Initialized
INFO - 2020-06-23 20:08:33 --> Security Class Initialized
DEBUG - 2020-06-23 20:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:08:33 --> Input Class Initialized
INFO - 2020-06-23 20:08:33 --> Language Class Initialized
INFO - 2020-06-23 20:08:33 --> Loader Class Initialized
INFO - 2020-06-23 20:08:33 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:08:33 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:08:33 --> Helper loaded: data_helper
INFO - 2020-06-23 20:08:33 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:08:33 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:08:33 --> Helper loaded: view_helper
INFO - 2020-06-23 20:08:33 --> Helper loaded: url_helper
INFO - 2020-06-23 20:08:33 --> Database Driver Class Initialized
INFO - 2020-06-23 20:08:33 --> Controller Class Initialized
INFO - 2020-06-23 20:08:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:08:33 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:08:33 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:08:33 --> Plain_Model class loaded
INFO - 2020-06-23 20:08:33 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-23 20:08:33 --> Final output sent to browser
DEBUG - 2020-06-23 20:08:33 --> Total execution time: 0.1559
INFO - 2020-06-23 20:11:13 --> Config Class Initialized
INFO - 2020-06-23 20:11:13 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:11:13 --> Hooks Class Initialized
INFO - 2020-06-23 20:11:13 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:11:13 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:11:13 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:11:13 --> Utf8 Class Initialized
INFO - 2020-06-23 20:11:13 --> URI Class Initialized
DEBUG - 2020-06-23 20:11:13 --> Validating request for /controllers/Export.php
INFO - 2020-06-23 20:11:13 --> Router Class Initialized
INFO - 2020-06-23 20:11:13 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:11:13 --> Output Class Initialized
INFO - 2020-06-23 20:11:13 --> Security Class Initialized
DEBUG - 2020-06-23 20:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:11:13 --> Input Class Initialized
INFO - 2020-06-23 20:11:13 --> Language Class Initialized
INFO - 2020-06-23 20:11:13 --> Loader Class Initialized
INFO - 2020-06-23 20:11:13 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:11:13 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:11:13 --> Helper loaded: data_helper
INFO - 2020-06-23 20:11:13 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:11:13 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:11:13 --> Helper loaded: view_helper
INFO - 2020-06-23 20:11:13 --> Helper loaded: url_helper
INFO - 2020-06-23 20:11:13 --> Database Driver Class Initialized
INFO - 2020-06-23 20:11:13 --> Controller Class Initialized
INFO - 2020-06-23 20:11:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:11:13 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:11:13 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:11:13 --> Plain_Model class loaded
INFO - 2020-06-23 20:11:13 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-23 20:11:13 --> Final output sent to browser
DEBUG - 2020-06-23 20:11:13 --> Total execution time: 0.1500
INFO - 2020-06-23 20:11:36 --> Config Class Initialized
INFO - 2020-06-23 20:11:36 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:11:36 --> Hooks Class Initialized
INFO - 2020-06-23 20:11:36 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:11:36 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:11:36 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:11:36 --> Utf8 Class Initialized
INFO - 2020-06-23 20:11:36 --> URI Class Initialized
DEBUG - 2020-06-23 20:11:36 --> Validating request for /controllers/Export.php
INFO - 2020-06-23 20:11:36 --> Router Class Initialized
INFO - 2020-06-23 20:11:36 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:11:36 --> Output Class Initialized
INFO - 2020-06-23 20:11:36 --> Security Class Initialized
DEBUG - 2020-06-23 20:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:11:36 --> Input Class Initialized
INFO - 2020-06-23 20:11:36 --> Language Class Initialized
INFO - 2020-06-23 20:11:36 --> Loader Class Initialized
INFO - 2020-06-23 20:11:36 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:11:36 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:11:36 --> Helper loaded: data_helper
INFO - 2020-06-23 20:11:36 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:11:36 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:11:36 --> Helper loaded: view_helper
INFO - 2020-06-23 20:11:36 --> Helper loaded: url_helper
INFO - 2020-06-23 20:11:36 --> Database Driver Class Initialized
INFO - 2020-06-23 20:11:36 --> Controller Class Initialized
INFO - 2020-06-23 20:11:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:11:36 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:11:36 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:11:36 --> Plain_Model class loaded
INFO - 2020-06-23 20:11:36 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-23 20:11:36 --> Final output sent to browser
DEBUG - 2020-06-23 20:11:36 --> Total execution time: 0.1386
INFO - 2020-06-23 20:12:02 --> Config Class Initialized
INFO - 2020-06-23 20:12:02 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:12:02 --> Hooks Class Initialized
INFO - 2020-06-23 20:12:02 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:12:02 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:12:02 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:12:02 --> Utf8 Class Initialized
INFO - 2020-06-23 20:12:02 --> URI Class Initialized
DEBUG - 2020-06-23 20:12:02 --> Validating request for /controllers/Export.php
INFO - 2020-06-23 20:12:02 --> Router Class Initialized
INFO - 2020-06-23 20:12:02 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:12:02 --> Output Class Initialized
INFO - 2020-06-23 20:12:02 --> Security Class Initialized
DEBUG - 2020-06-23 20:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:12:02 --> Input Class Initialized
INFO - 2020-06-23 20:12:02 --> Language Class Initialized
INFO - 2020-06-23 20:12:02 --> Loader Class Initialized
INFO - 2020-06-23 20:12:02 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:12:02 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:12:02 --> Helper loaded: data_helper
INFO - 2020-06-23 20:12:02 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:12:02 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:12:02 --> Helper loaded: view_helper
INFO - 2020-06-23 20:12:02 --> Helper loaded: url_helper
INFO - 2020-06-23 20:12:02 --> Database Driver Class Initialized
INFO - 2020-06-23 20:12:02 --> Controller Class Initialized
INFO - 2020-06-23 20:12:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:12:02 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:12:02 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:12:02 --> Plain_Model class loaded
INFO - 2020-06-23 20:12:02 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-23 20:12:02 --> Final output sent to browser
DEBUG - 2020-06-23 20:12:02 --> Total execution time: 0.1736
INFO - 2020-06-23 20:12:06 --> Config Class Initialized
INFO - 2020-06-23 20:12:06 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:12:06 --> Hooks Class Initialized
INFO - 2020-06-23 20:12:06 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:12:06 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:12:06 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:12:06 --> Utf8 Class Initialized
INFO - 2020-06-23 20:12:06 --> URI Class Initialized
DEBUG - 2020-06-23 20:12:06 --> No URI present. Default controller set.
INFO - 2020-06-23 20:12:06 --> Router Class Initialized
INFO - 2020-06-23 20:12:06 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:12:06 --> Output Class Initialized
INFO - 2020-06-23 20:12:06 --> Security Class Initialized
DEBUG - 2020-06-23 20:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:12:06 --> Input Class Initialized
INFO - 2020-06-23 20:12:06 --> Language Class Initialized
INFO - 2020-06-23 20:12:06 --> Loader Class Initialized
INFO - 2020-06-23 20:12:06 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:12:06 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:12:06 --> Helper loaded: data_helper
INFO - 2020-06-23 20:12:06 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:12:06 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:12:06 --> Helper loaded: view_helper
INFO - 2020-06-23 20:12:06 --> Helper loaded: url_helper
INFO - 2020-06-23 20:12:06 --> Database Driver Class Initialized
INFO - 2020-06-23 20:12:06 --> Controller Class Initialized
INFO - 2020-06-23 20:12:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:12:06 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:12:06 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 20:12:06 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 20:12:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 20:12:06 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 20:12:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 20:12:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 20:12:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 20:12:06 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-23 20:12:06 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-23 20:12:06 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 20:12:06 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-23 20:12:06 --> Final output sent to browser
DEBUG - 2020-06-23 20:12:06 --> Total execution time: 0.1497
INFO - 2020-06-23 20:17:07 --> Config Class Initialized
INFO - 2020-06-23 20:17:07 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:17:07 --> Hooks Class Initialized
INFO - 2020-06-23 20:17:07 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:17:07 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:17:07 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:17:07 --> Utf8 Class Initialized
INFO - 2020-06-23 20:17:07 --> URI Class Initialized
DEBUG - 2020-06-23 20:17:07 --> No URI present. Default controller set.
INFO - 2020-06-23 20:17:07 --> Router Class Initialized
INFO - 2020-06-23 20:17:07 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:17:07 --> Output Class Initialized
INFO - 2020-06-23 20:17:07 --> Security Class Initialized
DEBUG - 2020-06-23 20:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:17:07 --> Input Class Initialized
INFO - 2020-06-23 20:17:07 --> Language Class Initialized
INFO - 2020-06-23 20:17:07 --> Loader Class Initialized
INFO - 2020-06-23 20:17:07 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:17:07 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:17:07 --> Helper loaded: data_helper
INFO - 2020-06-23 20:17:07 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:17:07 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:17:07 --> Helper loaded: view_helper
INFO - 2020-06-23 20:17:07 --> Helper loaded: url_helper
INFO - 2020-06-23 20:17:07 --> Database Driver Class Initialized
INFO - 2020-06-23 20:17:07 --> Controller Class Initialized
INFO - 2020-06-23 20:17:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:17:07 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:17:07 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 20:17:07 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 20:17:07 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 20:17:07 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 20:17:07 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 20:17:07 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 20:17:07 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 20:17:07 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-23 20:17:07 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-23 20:17:07 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 20:17:07 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-23 20:17:07 --> Final output sent to browser
DEBUG - 2020-06-23 20:17:07 --> Total execution time: 0.1587
INFO - 2020-06-23 20:17:09 --> Config Class Initialized
INFO - 2020-06-23 20:17:09 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:17:09 --> Hooks Class Initialized
INFO - 2020-06-23 20:17:09 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:17:09 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:17:09 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:17:09 --> Utf8 Class Initialized
INFO - 2020-06-23 20:17:09 --> URI Class Initialized
DEBUG - 2020-06-23 20:17:09 --> Validating request for /controllers/Export.php
INFO - 2020-06-23 20:17:09 --> Router Class Initialized
INFO - 2020-06-23 20:17:09 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:17:09 --> Output Class Initialized
INFO - 2020-06-23 20:17:09 --> Security Class Initialized
DEBUG - 2020-06-23 20:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:17:09 --> Input Class Initialized
INFO - 2020-06-23 20:17:09 --> Language Class Initialized
INFO - 2020-06-23 20:17:09 --> Loader Class Initialized
INFO - 2020-06-23 20:17:09 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:17:09 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:17:09 --> Helper loaded: data_helper
INFO - 2020-06-23 20:17:09 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:17:09 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:17:09 --> Helper loaded: view_helper
INFO - 2020-06-23 20:17:09 --> Helper loaded: url_helper
INFO - 2020-06-23 20:17:09 --> Database Driver Class Initialized
INFO - 2020-06-23 20:17:09 --> Controller Class Initialized
INFO - 2020-06-23 20:17:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:17:09 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:17:09 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:17:09 --> Plain_Model class loaded
INFO - 2020-06-23 20:17:09 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-23 20:17:09 --> Final output sent to browser
DEBUG - 2020-06-23 20:17:09 --> Total execution time: 0.1460
INFO - 2020-06-23 20:18:27 --> Config Class Initialized
INFO - 2020-06-23 20:18:27 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:18:27 --> Hooks Class Initialized
INFO - 2020-06-23 20:18:27 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:18:27 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:18:27 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:18:27 --> Utf8 Class Initialized
INFO - 2020-06-23 20:18:27 --> URI Class Initialized
DEBUG - 2020-06-23 20:18:27 --> Validating request for /controllers/Export.php
INFO - 2020-06-23 20:18:27 --> Router Class Initialized
INFO - 2020-06-23 20:18:27 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:18:27 --> Output Class Initialized
INFO - 2020-06-23 20:18:27 --> Security Class Initialized
DEBUG - 2020-06-23 20:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:18:27 --> Input Class Initialized
INFO - 2020-06-23 20:18:27 --> Language Class Initialized
INFO - 2020-06-23 20:18:27 --> Loader Class Initialized
INFO - 2020-06-23 20:18:27 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:18:27 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:18:27 --> Helper loaded: data_helper
INFO - 2020-06-23 20:18:27 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:18:27 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:18:27 --> Helper loaded: view_helper
INFO - 2020-06-23 20:18:27 --> Helper loaded: url_helper
INFO - 2020-06-23 20:18:27 --> Database Driver Class Initialized
INFO - 2020-06-23 20:18:27 --> Controller Class Initialized
INFO - 2020-06-23 20:18:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:18:27 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:18:27 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 20:18:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-23 20:18:27 --> Array
(
    [message] => Error: Undefined constant 'n\n'
    [type] => Error
    [backtrace] => /var/www/html/application/controllers/Export.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-23 20:19:34 --> Config Class Initialized
INFO - 2020-06-23 20:19:34 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:19:34 --> Hooks Class Initialized
INFO - 2020-06-23 20:19:34 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:19:34 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:19:34 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:19:34 --> Utf8 Class Initialized
INFO - 2020-06-23 20:19:34 --> URI Class Initialized
DEBUG - 2020-06-23 20:19:34 --> Validating request for /controllers/Export.php
INFO - 2020-06-23 20:19:34 --> Router Class Initialized
INFO - 2020-06-23 20:19:34 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:19:34 --> Output Class Initialized
INFO - 2020-06-23 20:19:34 --> Security Class Initialized
DEBUG - 2020-06-23 20:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:19:34 --> Input Class Initialized
INFO - 2020-06-23 20:19:34 --> Language Class Initialized
INFO - 2020-06-23 20:19:34 --> Loader Class Initialized
INFO - 2020-06-23 20:19:34 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:19:34 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:19:34 --> Helper loaded: data_helper
INFO - 2020-06-23 20:19:34 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:19:34 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:19:34 --> Helper loaded: view_helper
INFO - 2020-06-23 20:19:34 --> Helper loaded: url_helper
INFO - 2020-06-23 20:19:34 --> Database Driver Class Initialized
INFO - 2020-06-23 20:19:34 --> Controller Class Initialized
INFO - 2020-06-23 20:19:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:19:34 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:19:34 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:19:34 --> Plain_Model class loaded
INFO - 2020-06-23 20:19:34 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-23 20:19:34 --> Final output sent to browser
DEBUG - 2020-06-23 20:19:34 --> Total execution time: 0.1188
INFO - 2020-06-23 20:20:16 --> Config Class Initialized
INFO - 2020-06-23 20:20:16 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:20:16 --> Hooks Class Initialized
INFO - 2020-06-23 20:20:16 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:20:16 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:20:16 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:20:16 --> Utf8 Class Initialized
INFO - 2020-06-23 20:20:16 --> URI Class Initialized
DEBUG - 2020-06-23 20:20:16 --> No URI present. Default controller set.
INFO - 2020-06-23 20:20:16 --> Router Class Initialized
INFO - 2020-06-23 20:20:16 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:20:16 --> Output Class Initialized
INFO - 2020-06-23 20:20:16 --> Security Class Initialized
DEBUG - 2020-06-23 20:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:20:16 --> Input Class Initialized
INFO - 2020-06-23 20:20:16 --> Language Class Initialized
INFO - 2020-06-23 20:20:16 --> Loader Class Initialized
INFO - 2020-06-23 20:20:16 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:20:16 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:20:16 --> Helper loaded: data_helper
INFO - 2020-06-23 20:20:16 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:20:16 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:20:16 --> Helper loaded: view_helper
INFO - 2020-06-23 20:20:16 --> Helper loaded: url_helper
INFO - 2020-06-23 20:20:16 --> Database Driver Class Initialized
INFO - 2020-06-23 20:20:16 --> Controller Class Initialized
INFO - 2020-06-23 20:20:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:20:16 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:20:16 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:20:16 --> Config Class Initialized
INFO - 2020-06-23 20:20:16 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:20:16 --> Hooks Class Initialized
INFO - 2020-06-23 20:20:16 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:20:16 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:20:16 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:20:16 --> Utf8 Class Initialized
INFO - 2020-06-23 20:20:16 --> URI Class Initialized
DEBUG - 2020-06-23 20:20:16 --> Validating request for /controllers/Marks.php
INFO - 2020-06-23 20:20:16 --> Router Class Initialized
INFO - 2020-06-23 20:20:16 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:20:16 --> Output Class Initialized
INFO - 2020-06-23 20:20:16 --> Security Class Initialized
DEBUG - 2020-06-23 20:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:20:16 --> Input Class Initialized
INFO - 2020-06-23 20:20:16 --> Language Class Initialized
INFO - 2020-06-23 20:20:16 --> Loader Class Initialized
INFO - 2020-06-23 20:20:16 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:20:16 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:20:16 --> Helper loaded: data_helper
INFO - 2020-06-23 20:20:16 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:20:16 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:20:16 --> Helper loaded: view_helper
INFO - 2020-06-23 20:20:16 --> Helper loaded: url_helper
INFO - 2020-06-23 20:20:16 --> Database Driver Class Initialized
INFO - 2020-06-23 20:20:16 --> Controller Class Initialized
INFO - 2020-06-23 20:20:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:20:16 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-23 20:20:16 --> Plain_Model class loaded
INFO - 2020-06-23 20:20:17 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-23 20:20:17 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:20:17 --> Model "Labels_model" initialized
INFO - 2020-06-23 20:20:17 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-23 20:20:17 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-23 20:20:17 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-23 20:20:17 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-23 20:20:17 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-23 20:20:17 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-23 20:20:17 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-23 20:20:17 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-23 20:20:17 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-23 20:20:17 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-23 20:20:17 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-23 20:20:17 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-23 20:20:17 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-23 20:20:17 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-23 20:20:17 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-23 20:20:17 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-23 20:20:17 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-23 20:20:17 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-23 20:20:17 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-23 20:20:17 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-23 20:20:17 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-23 20:20:17 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-23 20:20:17 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-23 20:20:17 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-23 20:20:17 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-23 20:20:17 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-23 20:20:17 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-23 20:20:17 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-23 20:20:17 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-23 20:20:17 --> Final output sent to browser
DEBUG - 2020-06-23 20:20:17 --> Total execution time: 0.1680
INFO - 2020-06-23 20:20:17 --> Config Class Initialized
INFO - 2020-06-23 20:20:17 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:20:17 --> Hooks Class Initialized
INFO - 2020-06-23 20:20:17 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:20:17 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:20:17 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:20:17 --> Utf8 Class Initialized
INFO - 2020-06-23 20:20:17 --> URI Class Initialized
DEBUG - 2020-06-23 20:20:17 --> Validating request for /controllers/Custom.php
INFO - 2020-06-23 20:20:17 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-23 20:20:17 --> 404 Page Not Found: custom
INFO - 2020-06-23 20:20:36 --> Config Class Initialized
INFO - 2020-06-23 20:20:36 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:20:36 --> Hooks Class Initialized
INFO - 2020-06-23 20:20:36 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:20:36 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:20:36 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:20:36 --> Utf8 Class Initialized
INFO - 2020-06-23 20:20:36 --> URI Class Initialized
DEBUG - 2020-06-23 20:20:36 --> Validating request for /controllers/Import.php
INFO - 2020-06-23 20:20:36 --> Router Class Initialized
INFO - 2020-06-23 20:20:36 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:20:36 --> Output Class Initialized
INFO - 2020-06-23 20:20:36 --> Security Class Initialized
DEBUG - 2020-06-23 20:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:20:36 --> Input Class Initialized
INFO - 2020-06-23 20:20:36 --> Language Class Initialized
INFO - 2020-06-23 20:20:36 --> Loader Class Initialized
INFO - 2020-06-23 20:20:36 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:20:36 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:20:36 --> Helper loaded: data_helper
INFO - 2020-06-23 20:20:36 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:20:36 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:20:36 --> Helper loaded: view_helper
INFO - 2020-06-23 20:20:36 --> Helper loaded: url_helper
INFO - 2020-06-23 20:20:36 --> Database Driver Class Initialized
INFO - 2020-06-23 20:20:36 --> Controller Class Initialized
INFO - 2020-06-23 20:20:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:20:36 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:20:36 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:20:36 --> Plain_Model class loaded
INFO - 2020-06-23 20:20:36 --> Model "Marks_model" initialized
INFO - 2020-06-23 20:20:36 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-23 20:20:36 --> Model "Labels_model" initialized
INFO - 2020-06-23 20:20:37 --> Model "Tags_model" initialized
INFO - 2020-06-23 20:20:37 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-23 20:20:40 --> The phrase "Unmark : Importer" could not be found in the language file.
DEBUG - 2020-06-23 20:20:40 --> The phrase "Successful Upload!" could not be found in the language file.
DEBUG - 2020-06-23 20:20:40 --> The phrase "%s marks added" could not be found in the language file.
DEBUG - 2020-06-23 20:20:40 --> The phrase "%s marks skipped" could not be found in the language file.
DEBUG - 2020-06-23 20:20:40 --> The phrase "%s marks failed" could not be found in the language file.
DEBUG - 2020-06-23 20:20:40 --> The phrase "%s marks total" could not be found in the language file.
DEBUG - 2020-06-23 20:20:40 --> The phrase "<a href='/' class="back-button"> Go back & see them</a>" could not be found in the language file.
INFO - 2020-06-23 20:20:40 --> File loaded: /var/www/html/application/views/import/index.php
INFO - 2020-06-23 20:20:40 --> Final output sent to browser
DEBUG - 2020-06-23 20:20:40 --> Total execution time: 4.6199
INFO - 2020-06-23 20:20:40 --> Config Class Initialized
INFO - 2020-06-23 20:20:40 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:20:40 --> Hooks Class Initialized
INFO - 2020-06-23 20:20:40 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:20:40 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:20:40 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:20:40 --> Utf8 Class Initialized
INFO - 2020-06-23 20:20:40 --> URI Class Initialized
DEBUG - 2020-06-23 20:20:40 --> Validating request for /controllers/Custom.php
INFO - 2020-06-23 20:20:41 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-23 20:20:41 --> 404 Page Not Found: custom
INFO - 2020-06-23 20:20:43 --> Config Class Initialized
INFO - 2020-06-23 20:20:43 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:20:43 --> Hooks Class Initialized
INFO - 2020-06-23 20:20:43 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:20:43 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:20:44 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:20:44 --> Utf8 Class Initialized
INFO - 2020-06-23 20:20:44 --> URI Class Initialized
DEBUG - 2020-06-23 20:20:44 --> No URI present. Default controller set.
INFO - 2020-06-23 20:20:44 --> Router Class Initialized
INFO - 2020-06-23 20:20:44 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:20:44 --> Output Class Initialized
INFO - 2020-06-23 20:20:44 --> Security Class Initialized
DEBUG - 2020-06-23 20:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:20:44 --> Input Class Initialized
INFO - 2020-06-23 20:20:44 --> Language Class Initialized
INFO - 2020-06-23 20:20:44 --> Loader Class Initialized
INFO - 2020-06-23 20:20:44 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:20:44 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:20:44 --> Helper loaded: data_helper
INFO - 2020-06-23 20:20:44 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:20:44 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:20:44 --> Helper loaded: view_helper
INFO - 2020-06-23 20:20:44 --> Helper loaded: url_helper
INFO - 2020-06-23 20:20:44 --> Database Driver Class Initialized
INFO - 2020-06-23 20:20:44 --> Controller Class Initialized
INFO - 2020-06-23 20:20:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:20:44 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:20:44 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:20:44 --> Config Class Initialized
INFO - 2020-06-23 20:20:44 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:20:44 --> Hooks Class Initialized
INFO - 2020-06-23 20:20:44 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:20:44 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:20:44 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:20:44 --> Utf8 Class Initialized
INFO - 2020-06-23 20:20:44 --> URI Class Initialized
DEBUG - 2020-06-23 20:20:44 --> Validating request for /controllers/Marks.php
INFO - 2020-06-23 20:20:44 --> Router Class Initialized
INFO - 2020-06-23 20:20:44 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:20:44 --> Output Class Initialized
INFO - 2020-06-23 20:20:44 --> Security Class Initialized
DEBUG - 2020-06-23 20:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:20:44 --> Input Class Initialized
INFO - 2020-06-23 20:20:44 --> Language Class Initialized
INFO - 2020-06-23 20:20:44 --> Loader Class Initialized
INFO - 2020-06-23 20:20:44 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:20:44 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:20:44 --> Helper loaded: data_helper
INFO - 2020-06-23 20:20:44 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:20:44 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:20:44 --> Helper loaded: view_helper
INFO - 2020-06-23 20:20:44 --> Helper loaded: url_helper
INFO - 2020-06-23 20:20:44 --> Database Driver Class Initialized
INFO - 2020-06-23 20:20:44 --> Controller Class Initialized
INFO - 2020-06-23 20:20:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:20:44 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-23 20:20:44 --> Plain_Model class loaded
INFO - 2020-06-23 20:20:44 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-23 20:20:44 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:20:44 --> Model "Labels_model" initialized
INFO - 2020-06-23 20:20:44 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-23 20:20:44 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-23 20:20:44 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-23 20:20:44 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-23 20:20:44 --> The phrase "Recently-Used Tags" could not be found in the language file.
INFO - 2020-06-23 20:20:44 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-23 20:20:44 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-23 20:20:44 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-23 20:20:44 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-23 20:20:44 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-23 20:20:44 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-23 20:20:44 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-23 20:20:44 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-23 20:20:44 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-23 20:20:44 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-23 20:20:44 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-23 20:20:44 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-23 20:20:44 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-23 20:20:44 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-23 20:20:44 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-23 20:20:44 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-23 20:20:44 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-23 20:20:44 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-23 20:20:44 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-23 20:20:44 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-23 20:20:44 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-23 20:20:44 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-23 20:20:44 --> Final output sent to browser
DEBUG - 2020-06-23 20:20:44 --> Total execution time: 0.2065
INFO - 2020-06-23 20:20:44 --> Config Class Initialized
INFO - 2020-06-23 20:20:44 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:20:44 --> Hooks Class Initialized
INFO - 2020-06-23 20:20:44 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:20:44 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:20:44 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:20:44 --> Utf8 Class Initialized
INFO - 2020-06-23 20:20:44 --> URI Class Initialized
DEBUG - 2020-06-23 20:20:44 --> Validating request for /controllers/Custom.php
INFO - 2020-06-23 20:20:44 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-23 20:20:44 --> 404 Page Not Found: custom
INFO - 2020-06-23 20:20:51 --> Config Class Initialized
INFO - 2020-06-23 20:20:51 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:20:51 --> Hooks Class Initialized
INFO - 2020-06-23 20:20:51 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:20:51 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:20:51 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:20:51 --> Utf8 Class Initialized
INFO - 2020-06-23 20:20:51 --> URI Class Initialized
DEBUG - 2020-06-23 20:20:51 --> Validating request for /controllers/Export.php
INFO - 2020-06-23 20:20:51 --> Router Class Initialized
INFO - 2020-06-23 20:20:51 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:20:51 --> Output Class Initialized
INFO - 2020-06-23 20:20:51 --> Security Class Initialized
DEBUG - 2020-06-23 20:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:20:51 --> Input Class Initialized
INFO - 2020-06-23 20:20:51 --> Language Class Initialized
INFO - 2020-06-23 20:20:51 --> Loader Class Initialized
INFO - 2020-06-23 20:20:51 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:20:51 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:20:51 --> Helper loaded: data_helper
INFO - 2020-06-23 20:20:51 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:20:51 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:20:51 --> Helper loaded: view_helper
INFO - 2020-06-23 20:20:51 --> Helper loaded: url_helper
INFO - 2020-06-23 20:20:51 --> Database Driver Class Initialized
INFO - 2020-06-23 20:20:51 --> Controller Class Initialized
INFO - 2020-06-23 20:20:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:20:51 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:20:51 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:20:51 --> Plain_Model class loaded
INFO - 2020-06-23 20:20:51 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-23 20:20:51 --> Final output sent to browser
DEBUG - 2020-06-23 20:20:51 --> Total execution time: 0.2730
INFO - 2020-06-23 20:21:18 --> Config Class Initialized
INFO - 2020-06-23 20:21:18 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:21:18 --> Hooks Class Initialized
INFO - 2020-06-23 20:21:18 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:21:18 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:21:18 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:21:18 --> Utf8 Class Initialized
INFO - 2020-06-23 20:21:18 --> URI Class Initialized
DEBUG - 2020-06-23 20:21:18 --> Validating request for /controllers/Import.php
INFO - 2020-06-23 20:21:18 --> Router Class Initialized
INFO - 2020-06-23 20:21:18 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:21:18 --> Output Class Initialized
INFO - 2020-06-23 20:21:18 --> Security Class Initialized
DEBUG - 2020-06-23 20:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:21:18 --> Input Class Initialized
INFO - 2020-06-23 20:21:18 --> Language Class Initialized
INFO - 2020-06-23 20:21:18 --> Loader Class Initialized
INFO - 2020-06-23 20:21:18 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:21:18 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:21:18 --> Helper loaded: data_helper
INFO - 2020-06-23 20:21:18 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:21:18 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:21:18 --> Helper loaded: view_helper
INFO - 2020-06-23 20:21:18 --> Helper loaded: url_helper
INFO - 2020-06-23 20:21:18 --> Database Driver Class Initialized
INFO - 2020-06-23 20:21:18 --> Controller Class Initialized
INFO - 2020-06-23 20:21:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:21:18 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:21:18 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 20:21:18 --> Importing bookmarks from an HTML file.
INFO - 2020-06-23 20:21:18 --> Plain_Model class loaded
INFO - 2020-06-23 20:21:18 --> Model "Marks_model" initialized
INFO - 2020-06-23 20:21:18 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-23 20:21:18 --> Model "Labels_model" initialized
DEBUG - 2020-06-23 20:21:18 --> Finished importing bookmarks from an HTML file.
DEBUG - 2020-06-23 20:21:18 --> The phrase "Unmark : Importer" could not be found in the language file.
DEBUG - 2020-06-23 20:21:18 --> The phrase "Successful Upload!" could not be found in the language file.
DEBUG - 2020-06-23 20:21:18 --> The phrase "%s marks added" could not be found in the language file.
DEBUG - 2020-06-23 20:21:18 --> The phrase "%s marks skipped" could not be found in the language file.
DEBUG - 2020-06-23 20:21:18 --> The phrase "%s marks failed" could not be found in the language file.
DEBUG - 2020-06-23 20:21:18 --> The phrase "%s marks total" could not be found in the language file.
DEBUG - 2020-06-23 20:21:18 --> The phrase "<a href='/' class="back-button"> Go back & see them</a>" could not be found in the language file.
INFO - 2020-06-23 20:21:18 --> File loaded: /var/www/html/application/views/import/index.php
INFO - 2020-06-23 20:21:18 --> Final output sent to browser
DEBUG - 2020-06-23 20:21:18 --> Total execution time: 0.5325
DEBUG - 2020-06-23 20:21:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-23 20:21:18 --> Array
(
    [message] => Warning: date() expects parameter 2 to be long, string given
    [type] => Warning
    [backtrace] => /var/www/html/application/controllers/Import.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-23 20:21:18 --> Config Class Initialized
INFO - 2020-06-23 20:21:18 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:21:18 --> Hooks Class Initialized
INFO - 2020-06-23 20:21:18 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:21:18 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:21:18 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:21:18 --> Utf8 Class Initialized
INFO - 2020-06-23 20:21:18 --> URI Class Initialized
DEBUG - 2020-06-23 20:21:18 --> Validating request for /controllers/Custom.php
INFO - 2020-06-23 20:21:19 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-23 20:21:19 --> 404 Page Not Found: custom
INFO - 2020-06-23 20:21:22 --> Config Class Initialized
INFO - 2020-06-23 20:21:22 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:21:22 --> Hooks Class Initialized
INFO - 2020-06-23 20:21:23 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:21:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:21:23 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:21:23 --> Utf8 Class Initialized
INFO - 2020-06-23 20:21:23 --> URI Class Initialized
DEBUG - 2020-06-23 20:21:23 --> No URI present. Default controller set.
INFO - 2020-06-23 20:21:23 --> Router Class Initialized
INFO - 2020-06-23 20:21:23 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:21:23 --> Output Class Initialized
INFO - 2020-06-23 20:21:23 --> Security Class Initialized
DEBUG - 2020-06-23 20:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:21:23 --> Input Class Initialized
INFO - 2020-06-23 20:21:23 --> Language Class Initialized
INFO - 2020-06-23 20:21:23 --> Loader Class Initialized
INFO - 2020-06-23 20:21:23 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:21:23 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:21:23 --> Helper loaded: data_helper
INFO - 2020-06-23 20:21:23 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:21:23 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:21:23 --> Helper loaded: view_helper
INFO - 2020-06-23 20:21:23 --> Helper loaded: url_helper
INFO - 2020-06-23 20:21:23 --> Database Driver Class Initialized
INFO - 2020-06-23 20:21:23 --> Controller Class Initialized
INFO - 2020-06-23 20:21:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:21:23 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:21:23 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:21:23 --> Config Class Initialized
INFO - 2020-06-23 20:21:23 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:21:23 --> Hooks Class Initialized
INFO - 2020-06-23 20:21:23 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:21:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:21:23 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:21:23 --> Utf8 Class Initialized
INFO - 2020-06-23 20:21:23 --> URI Class Initialized
DEBUG - 2020-06-23 20:21:23 --> Validating request for /controllers/Marks.php
INFO - 2020-06-23 20:21:23 --> Router Class Initialized
INFO - 2020-06-23 20:21:23 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:21:23 --> Output Class Initialized
INFO - 2020-06-23 20:21:23 --> Security Class Initialized
DEBUG - 2020-06-23 20:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:21:23 --> Input Class Initialized
INFO - 2020-06-23 20:21:23 --> Language Class Initialized
INFO - 2020-06-23 20:21:23 --> Loader Class Initialized
INFO - 2020-06-23 20:21:23 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:21:23 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:21:23 --> Helper loaded: data_helper
INFO - 2020-06-23 20:21:23 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:21:23 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:21:23 --> Helper loaded: view_helper
INFO - 2020-06-23 20:21:23 --> Helper loaded: url_helper
INFO - 2020-06-23 20:21:23 --> Database Driver Class Initialized
INFO - 2020-06-23 20:21:23 --> Controller Class Initialized
INFO - 2020-06-23 20:21:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:21:23 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-23 20:21:23 --> Plain_Model class loaded
INFO - 2020-06-23 20:21:23 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-23 20:21:23 --> The "english" language file has been loaded.
INFO - 2020-06-23 20:21:23 --> Model "Labels_model" initialized
INFO - 2020-06-23 20:21:23 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-23 20:21:23 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-23 20:21:23 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-23 20:21:23 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-23 20:21:23 --> The phrase "Recently-Used Tags" could not be found in the language file.
INFO - 2020-06-23 20:21:23 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-23 20:21:23 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-23 20:21:23 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-23 20:21:23 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-23 20:21:23 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-23 20:21:23 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-23 20:21:23 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-23 20:21:23 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-23 20:21:23 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-23 20:21:23 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-23 20:21:23 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-23 20:21:23 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-23 20:21:23 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-23 20:21:23 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-23 20:21:23 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-23 20:21:23 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-23 20:21:23 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-23 20:21:23 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-23 20:21:23 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-23 20:21:23 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-23 20:21:23 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-23 20:21:23 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-23 20:21:23 --> Final output sent to browser
DEBUG - 2020-06-23 20:21:23 --> Total execution time: 0.2061
INFO - 2020-06-23 20:21:23 --> Config Class Initialized
INFO - 2020-06-23 20:21:23 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:21:23 --> Hooks Class Initialized
INFO - 2020-06-23 20:21:23 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:21:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:21:23 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:21:23 --> Utf8 Class Initialized
INFO - 2020-06-23 20:21:23 --> URI Class Initialized
DEBUG - 2020-06-23 20:21:23 --> Validating request for /controllers/Custom.php
INFO - 2020-06-23 20:21:23 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-23 20:21:23 --> 404 Page Not Found: custom
INFO - 2020-06-23 20:22:08 --> Config Class Initialized
INFO - 2020-06-23 20:22:08 --> Plain_Config Class Initialized
INFO - 2020-06-23 20:22:08 --> Hooks Class Initialized
INFO - 2020-06-23 20:22:08 --> Plain_Hooks Class Constructed
INFO - 2020-06-23 20:22:08 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-23 20:22:08 --> UTF-8 Support Disabled
INFO - 2020-06-23 20:22:08 --> Utf8 Class Initialized
INFO - 2020-06-23 20:22:08 --> URI Class Initialized
DEBUG - 2020-06-23 20:22:08 --> No URI present. Default controller set.
INFO - 2020-06-23 20:22:08 --> Router Class Initialized
INFO - 2020-06-23 20:22:08 --> Plain_Router Class Initialized
INFO - 2020-06-23 20:22:08 --> Output Class Initialized
INFO - 2020-06-23 20:22:08 --> Security Class Initialized
DEBUG - 2020-06-23 20:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-23 20:22:08 --> Input Class Initialized
INFO - 2020-06-23 20:22:08 --> Language Class Initialized
INFO - 2020-06-23 20:22:08 --> Loader Class Initialized
INFO - 2020-06-23 20:22:08 --> Plain_Loader Class Initialized
DEBUG - 2020-06-23 20:22:08 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-23 20:22:08 --> Helper loaded: data_helper
INFO - 2020-06-23 20:22:08 --> Helper loaded: hash_helper
INFO - 2020-06-23 20:22:08 --> Helper loaded: validation_helper
INFO - 2020-06-23 20:22:08 --> Helper loaded: view_helper
INFO - 2020-06-23 20:22:08 --> Helper loaded: url_helper
INFO - 2020-06-23 20:22:08 --> Database Driver Class Initialized
INFO - 2020-06-23 20:22:08 --> Controller Class Initialized
INFO - 2020-06-23 20:22:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-23 20:22:08 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-23 20:22:08 --> The "english" language file has been loaded.
DEBUG - 2020-06-23 20:22:08 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-23 20:22:08 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 20:22:08 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-23 20:22:08 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 20:22:08 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-23 20:22:08 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-23 20:22:08 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-23 20:22:08 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-23 20:22:08 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-23 20:22:08 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-23 20:22:08 --> Final output sent to browser
DEBUG - 2020-06-23 20:22:08 --> Total execution time: 0.1268
