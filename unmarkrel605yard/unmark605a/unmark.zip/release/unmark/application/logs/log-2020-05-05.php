<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-05-05 13:45:11 --> Config Class Initialized
INFO - 2020-05-05 13:45:11 --> Plain_Config Class Initialized
INFO - 2020-05-05 13:45:11 --> Hooks Class Initialized
INFO - 2020-05-05 13:45:11 --> Plain_Hooks Class Constructed
INFO - 2020-05-05 13:45:11 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-05 13:45:11 --> UTF-8 Support Disabled
INFO - 2020-05-05 13:45:11 --> Utf8 Class Initialized
INFO - 2020-05-05 13:45:11 --> URI Class Initialized
DEBUG - 2020-05-05 13:45:11 --> No URI present. Default controller set.
INFO - 2020-05-05 13:45:11 --> Router Class Initialized
INFO - 2020-05-05 13:45:11 --> Plain_Router Class Initialized
INFO - 2020-05-05 13:45:11 --> Output Class Initialized
INFO - 2020-05-05 13:45:11 --> Security Class Initialized
DEBUG - 2020-05-05 13:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-05 13:45:11 --> Input Class Initialized
INFO - 2020-05-05 13:45:11 --> Language Class Initialized
INFO - 2020-05-05 13:45:11 --> Loader Class Initialized
INFO - 2020-05-05 13:45:11 --> Plain_Loader Class Initialized
DEBUG - 2020-05-05 13:45:11 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-05 13:45:11 --> Helper loaded: data_helper
INFO - 2020-05-05 13:45:11 --> Helper loaded: hash_helper
INFO - 2020-05-05 13:45:11 --> Helper loaded: validation_helper
INFO - 2020-05-05 13:45:11 --> Helper loaded: view_helper
INFO - 2020-05-05 13:45:11 --> Helper loaded: url_helper
INFO - 2020-05-05 13:45:11 --> Database Driver Class Initialized
INFO - 2020-05-05 13:45:11 --> Controller Class Initialized
INFO - 2020-05-05 13:45:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-05 13:45:12 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-05-05 13:45:12 --> The "english" language file has been loaded.
DEBUG - 2020-05-05 13:45:12 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-05-05 13:45:12 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-05-05 13:45:12 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-05-05 13:45:12 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-05-05 13:45:12 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-05-05 13:45:12 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-05-05 13:45:12 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-05-05 13:45:12 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-05-05 13:45:12 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-05-05 13:45:12 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-05-05 13:45:12 --> Final output sent to browser
DEBUG - 2020-05-05 13:45:12 --> Total execution time: 0.5384
INFO - 2020-05-05 13:45:13 --> Config Class Initialized
INFO - 2020-05-05 13:45:13 --> Plain_Config Class Initialized
INFO - 2020-05-05 13:45:13 --> Hooks Class Initialized
INFO - 2020-05-05 13:45:13 --> Plain_Hooks Class Constructed
INFO - 2020-05-05 13:45:13 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-05 13:45:13 --> UTF-8 Support Disabled
INFO - 2020-05-05 13:45:13 --> Utf8 Class Initialized
INFO - 2020-05-05 13:45:13 --> URI Class Initialized
DEBUG - 2020-05-05 13:45:13 --> Validating request for /controllers/Custom.php
INFO - 2020-05-05 13:45:13 --> Plain_Exceptions Class Initialized
ERROR - 2020-05-05 13:45:13 --> 404 Page Not Found: custom
INFO - 2020-05-05 13:45:20 --> Config Class Initialized
INFO - 2020-05-05 13:45:20 --> Plain_Config Class Initialized
INFO - 2020-05-05 13:45:20 --> Hooks Class Initialized
INFO - 2020-05-05 13:45:20 --> Plain_Hooks Class Constructed
INFO - 2020-05-05 13:45:20 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-05 13:45:20 --> UTF-8 Support Disabled
INFO - 2020-05-05 13:45:20 --> Utf8 Class Initialized
INFO - 2020-05-05 13:45:20 --> URI Class Initialized
DEBUG - 2020-05-05 13:45:21 --> Validating request for /controllers/Login.php
INFO - 2020-05-05 13:45:21 --> Router Class Initialized
INFO - 2020-05-05 13:45:21 --> Plain_Router Class Initialized
INFO - 2020-05-05 13:45:21 --> Output Class Initialized
INFO - 2020-05-05 13:45:21 --> Security Class Initialized
DEBUG - 2020-05-05 13:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-05 13:45:21 --> Input Class Initialized
INFO - 2020-05-05 13:45:21 --> Language Class Initialized
INFO - 2020-05-05 13:45:21 --> Loader Class Initialized
INFO - 2020-05-05 13:45:21 --> Plain_Loader Class Initialized
DEBUG - 2020-05-05 13:45:21 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-05 13:45:21 --> Helper loaded: data_helper
INFO - 2020-05-05 13:45:21 --> Helper loaded: hash_helper
INFO - 2020-05-05 13:45:21 --> Helper loaded: validation_helper
INFO - 2020-05-05 13:45:21 --> Helper loaded: view_helper
INFO - 2020-05-05 13:45:21 --> Helper loaded: url_helper
INFO - 2020-05-05 13:45:21 --> Database Driver Class Initialized
INFO - 2020-05-05 13:45:21 --> Controller Class Initialized
INFO - 2020-05-05 13:45:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-05 13:45:21 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-05-05 13:45:21 --> The "english" language file has been loaded.
INFO - 2020-05-05 13:45:21 --> Plain_Model class loaded
INFO - 2020-05-05 13:45:21 --> Model "Users_model" initialized
INFO - 2020-05-05 13:45:21 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-05-05 13:45:21 --> Final output sent to browser
DEBUG - 2020-05-05 13:45:21 --> Total execution time: 0.5560
INFO - 2020-05-05 13:45:23 --> Config Class Initialized
INFO - 2020-05-05 13:45:23 --> Plain_Config Class Initialized
INFO - 2020-05-05 13:45:23 --> Hooks Class Initialized
INFO - 2020-05-05 13:45:23 --> Plain_Hooks Class Constructed
INFO - 2020-05-05 13:45:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-05 13:45:23 --> UTF-8 Support Disabled
INFO - 2020-05-05 13:45:23 --> Utf8 Class Initialized
INFO - 2020-05-05 13:45:23 --> URI Class Initialized
DEBUG - 2020-05-05 13:45:23 --> Validating request for /controllers/Marks.php
INFO - 2020-05-05 13:45:23 --> Router Class Initialized
INFO - 2020-05-05 13:45:23 --> Plain_Router Class Initialized
INFO - 2020-05-05 13:45:23 --> Output Class Initialized
INFO - 2020-05-05 13:45:23 --> Security Class Initialized
DEBUG - 2020-05-05 13:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-05 13:45:23 --> Input Class Initialized
INFO - 2020-05-05 13:45:23 --> Language Class Initialized
INFO - 2020-05-05 13:45:23 --> Loader Class Initialized
INFO - 2020-05-05 13:45:23 --> Plain_Loader Class Initialized
DEBUG - 2020-05-05 13:45:23 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-05 13:45:23 --> Helper loaded: data_helper
INFO - 2020-05-05 13:45:23 --> Helper loaded: hash_helper
INFO - 2020-05-05 13:45:23 --> Helper loaded: validation_helper
INFO - 2020-05-05 13:45:23 --> Helper loaded: view_helper
INFO - 2020-05-05 13:45:23 --> Helper loaded: url_helper
INFO - 2020-05-05 13:45:23 --> Database Driver Class Initialized
INFO - 2020-05-05 13:45:23 --> Controller Class Initialized
INFO - 2020-05-05 13:45:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-05 13:45:23 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-05-05 13:45:23 --> Plain_Model class loaded
INFO - 2020-05-05 13:45:23 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-05-05 13:45:23 --> The "english" language file has been loaded.
INFO - 2020-05-05 13:45:23 --> Model "Labels_model" initialized
INFO - 2020-05-05 13:45:23 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-05-05 13:45:23 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-05-05 13:45:23 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-05-05 13:45:23 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-05-05 13:45:23 --> The phrase "Recently-Used Tags" could not be found in the language file.
INFO - 2020-05-05 13:45:23 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-05-05 13:45:23 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-05-05 13:45:23 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-05-05 13:45:23 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-05-05 13:45:23 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-05-05 13:45:23 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-05-05 13:45:23 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-05-05 13:45:23 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-05-05 13:45:23 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-05-05 13:45:23 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-05-05 13:45:23 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-05-05 13:45:23 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-05-05 13:45:23 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-05-05 13:45:23 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-05-05 13:45:23 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-05-05 13:45:23 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-05-05 13:45:23 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-05-05 13:45:23 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-05-05 13:45:23 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-05-05 13:45:23 --> Final output sent to browser
DEBUG - 2020-05-05 13:45:23 --> Total execution time: 0.7169
INFO - 2020-05-05 13:45:25 --> Config Class Initialized
INFO - 2020-05-05 13:45:25 --> Plain_Config Class Initialized
INFO - 2020-05-05 13:45:25 --> Hooks Class Initialized
INFO - 2020-05-05 13:45:25 --> Plain_Hooks Class Constructed
INFO - 2020-05-05 13:45:25 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-05 13:45:25 --> UTF-8 Support Disabled
INFO - 2020-05-05 13:45:25 --> Utf8 Class Initialized
INFO - 2020-05-05 13:45:25 --> URI Class Initialized
DEBUG - 2020-05-05 13:45:25 --> Validating request for /controllers/Custom.php
INFO - 2020-05-05 13:45:25 --> Plain_Exceptions Class Initialized
ERROR - 2020-05-05 13:45:25 --> 404 Page Not Found: custom
