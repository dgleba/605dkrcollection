<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-05-27 22:44:47 --> Config Class Initialized
INFO - 2020-05-27 22:44:47 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:44:47 --> Hooks Class Initialized
INFO - 2020-05-27 22:44:47 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:44:47 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:44:47 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:44:47 --> Utf8 Class Initialized
INFO - 2020-05-27 22:44:47 --> URI Class Initialized
DEBUG - 2020-05-27 22:44:47 --> No URI present. Default controller set.
INFO - 2020-05-27 22:44:47 --> Router Class Initialized
INFO - 2020-05-27 22:44:47 --> Plain_Router Class Initialized
INFO - 2020-05-27 22:44:47 --> Output Class Initialized
INFO - 2020-05-27 22:44:47 --> Security Class Initialized
DEBUG - 2020-05-27 22:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-27 22:44:47 --> Input Class Initialized
INFO - 2020-05-27 22:44:47 --> Language Class Initialized
INFO - 2020-05-27 22:44:47 --> Loader Class Initialized
INFO - 2020-05-27 22:44:47 --> Plain_Loader Class Initialized
DEBUG - 2020-05-27 22:44:47 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-27 22:44:47 --> Helper loaded: data_helper
INFO - 2020-05-27 22:44:47 --> Helper loaded: hash_helper
INFO - 2020-05-27 22:44:47 --> Helper loaded: validation_helper
INFO - 2020-05-27 22:44:48 --> Helper loaded: view_helper
INFO - 2020-05-27 22:44:48 --> Helper loaded: url_helper
INFO - 2020-05-27 22:44:48 --> Database Driver Class Initialized
INFO - 2020-05-27 22:44:48 --> Controller Class Initialized
INFO - 2020-05-27 22:44:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-27 22:44:48 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-05-27 22:44:48 --> The "english" language file has been loaded.
DEBUG - 2020-05-27 22:44:48 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-05-27 22:44:48 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-05-27 22:44:48 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-05-27 22:44:48 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-05-27 22:44:48 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-05-27 22:44:48 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-05-27 22:44:48 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-05-27 22:44:48 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-05-27 22:44:48 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-05-27 22:44:48 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-05-27 22:44:48 --> Final output sent to browser
DEBUG - 2020-05-27 22:44:48 --> Total execution time: 0.1975
INFO - 2020-05-27 22:44:48 --> Config Class Initialized
INFO - 2020-05-27 22:44:48 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:44:48 --> Hooks Class Initialized
INFO - 2020-05-27 22:44:48 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:44:48 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:44:48 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:44:48 --> Utf8 Class Initialized
INFO - 2020-05-27 22:44:48 --> URI Class Initialized
DEBUG - 2020-05-27 22:44:48 --> Validating request for /controllers/Custom.php
INFO - 2020-05-27 22:44:48 --> Plain_Exceptions Class Initialized
ERROR - 2020-05-27 22:44:48 --> 404 Page Not Found: custom
INFO - 2020-05-27 22:44:53 --> Config Class Initialized
INFO - 2020-05-27 22:44:53 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:44:53 --> Hooks Class Initialized
INFO - 2020-05-27 22:44:53 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:44:53 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:44:53 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:44:53 --> Utf8 Class Initialized
INFO - 2020-05-27 22:44:53 --> URI Class Initialized
DEBUG - 2020-05-27 22:44:53 --> Validating request for /controllers/Register.php
INFO - 2020-05-27 22:44:53 --> Router Class Initialized
INFO - 2020-05-27 22:44:53 --> Plain_Router Class Initialized
INFO - 2020-05-27 22:44:53 --> Output Class Initialized
INFO - 2020-05-27 22:44:53 --> Security Class Initialized
DEBUG - 2020-05-27 22:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-27 22:44:53 --> Input Class Initialized
INFO - 2020-05-27 22:44:53 --> Language Class Initialized
INFO - 2020-05-27 22:44:53 --> Loader Class Initialized
INFO - 2020-05-27 22:44:53 --> Plain_Loader Class Initialized
DEBUG - 2020-05-27 22:44:53 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-27 22:44:53 --> Helper loaded: data_helper
INFO - 2020-05-27 22:44:53 --> Helper loaded: hash_helper
INFO - 2020-05-27 22:44:53 --> Helper loaded: validation_helper
INFO - 2020-05-27 22:44:53 --> Helper loaded: view_helper
INFO - 2020-05-27 22:44:53 --> Helper loaded: url_helper
INFO - 2020-05-27 22:44:53 --> Database Driver Class Initialized
INFO - 2020-05-27 22:44:53 --> Controller Class Initialized
INFO - 2020-05-27 22:44:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-27 22:44:53 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-05-27 22:44:53 --> The "english" language file has been loaded.
DEBUG - 2020-05-27 22:44:53 --> The phrase "Unmark : User Registration" could not be found in the language file.
DEBUG - 2020-05-27 22:44:53 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-05-27 22:44:53 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-05-27 22:44:53 --> The phrase "Password Again" could not be found in the language file.
DEBUG - 2020-05-27 22:44:53 --> The phrase "Terms of Use" could not be found in the language file.
DEBUG - 2020-05-27 22:44:53 --> The phrase "Have An Account? Sign In Here" could not be found in the language file.
INFO - 2020-05-27 22:44:53 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-05-27 22:44:53 --> File loaded: /var/www/html/application/views/register/index.php
INFO - 2020-05-27 22:44:53 --> Final output sent to browser
DEBUG - 2020-05-27 22:44:53 --> Total execution time: 0.2072
INFO - 2020-05-27 22:44:53 --> Config Class Initialized
INFO - 2020-05-27 22:44:53 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:44:53 --> Hooks Class Initialized
INFO - 2020-05-27 22:44:53 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:44:53 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:44:53 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:44:53 --> Utf8 Class Initialized
INFO - 2020-05-27 22:44:53 --> URI Class Initialized
DEBUG - 2020-05-27 22:44:53 --> Validating request for /controllers/Custom.php
INFO - 2020-05-27 22:44:53 --> Plain_Exceptions Class Initialized
ERROR - 2020-05-27 22:44:53 --> 404 Page Not Found: custom
INFO - 2020-05-27 22:45:00 --> Config Class Initialized
INFO - 2020-05-27 22:45:00 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:45:00 --> Hooks Class Initialized
INFO - 2020-05-27 22:45:00 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:45:00 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:45:00 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:45:00 --> Utf8 Class Initialized
INFO - 2020-05-27 22:45:00 --> URI Class Initialized
DEBUG - 2020-05-27 22:45:00 --> Validating request for /controllers/Register.php
INFO - 2020-05-27 22:45:00 --> Router Class Initialized
INFO - 2020-05-27 22:45:00 --> Plain_Router Class Initialized
INFO - 2020-05-27 22:45:00 --> Output Class Initialized
INFO - 2020-05-27 22:45:00 --> Security Class Initialized
DEBUG - 2020-05-27 22:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-27 22:45:00 --> Input Class Initialized
INFO - 2020-05-27 22:45:00 --> Language Class Initialized
INFO - 2020-05-27 22:45:00 --> Loader Class Initialized
INFO - 2020-05-27 22:45:00 --> Plain_Loader Class Initialized
DEBUG - 2020-05-27 22:45:00 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-27 22:45:00 --> Helper loaded: data_helper
INFO - 2020-05-27 22:45:00 --> Helper loaded: hash_helper
INFO - 2020-05-27 22:45:00 --> Helper loaded: validation_helper
INFO - 2020-05-27 22:45:00 --> Helper loaded: view_helper
INFO - 2020-05-27 22:45:00 --> Helper loaded: url_helper
INFO - 2020-05-27 22:45:00 --> Database Driver Class Initialized
INFO - 2020-05-27 22:45:00 --> Controller Class Initialized
INFO - 2020-05-27 22:45:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-27 22:45:00 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-05-27 22:45:00 --> The "english" language file has been loaded.
INFO - 2020-05-27 22:45:00 --> Plain_Model class loaded
INFO - 2020-05-27 22:45:00 --> Model "Users_model" initialized
INFO - 2020-05-27 22:45:00 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-05-27 22:45:00 --> Final output sent to browser
DEBUG - 2020-05-27 22:45:00 --> Total execution time: 0.2043
INFO - 2020-05-27 22:45:14 --> Config Class Initialized
INFO - 2020-05-27 22:45:14 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:45:14 --> Hooks Class Initialized
INFO - 2020-05-27 22:45:14 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:45:14 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:45:14 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:45:14 --> Utf8 Class Initialized
INFO - 2020-05-27 22:45:14 --> URI Class Initialized
DEBUG - 2020-05-27 22:45:14 --> Validating request for /controllers/Register.php
INFO - 2020-05-27 22:45:14 --> Router Class Initialized
INFO - 2020-05-27 22:45:14 --> Plain_Router Class Initialized
INFO - 2020-05-27 22:45:14 --> Output Class Initialized
INFO - 2020-05-27 22:45:14 --> Security Class Initialized
DEBUG - 2020-05-27 22:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-27 22:45:14 --> Input Class Initialized
INFO - 2020-05-27 22:45:14 --> Language Class Initialized
INFO - 2020-05-27 22:45:14 --> Loader Class Initialized
INFO - 2020-05-27 22:45:14 --> Plain_Loader Class Initialized
DEBUG - 2020-05-27 22:45:14 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-27 22:45:14 --> Helper loaded: data_helper
INFO - 2020-05-27 22:45:14 --> Helper loaded: hash_helper
INFO - 2020-05-27 22:45:14 --> Helper loaded: validation_helper
INFO - 2020-05-27 22:45:14 --> Helper loaded: view_helper
INFO - 2020-05-27 22:45:14 --> Helper loaded: url_helper
INFO - 2020-05-27 22:45:14 --> Database Driver Class Initialized
INFO - 2020-05-27 22:45:14 --> Controller Class Initialized
INFO - 2020-05-27 22:45:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-27 22:45:14 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-05-27 22:45:14 --> The "english" language file has been loaded.
INFO - 2020-05-27 22:45:14 --> Plain_Model class loaded
INFO - 2020-05-27 22:45:14 --> Model "Users_model" initialized
ERROR - 2020-05-27 22:45:14 --> Query error: Table 'unmark.users' doesn't exist - Invalid query: 
            SELECT
            COUNT(users.user_id) AS total
            FROM `users` WHERE email = 'colin@cdevroe.com'
DEBUG - 2020-05-27 22:45:14 --> Language file loaded: language/english/db_lang.php
INFO - 2020-05-27 22:45:14 --> Plain_Exceptions Class Initialized
INFO - 2020-05-27 22:45:29 --> Config Class Initialized
INFO - 2020-05-27 22:45:29 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:45:29 --> Hooks Class Initialized
INFO - 2020-05-27 22:45:29 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:45:29 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:45:29 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:45:29 --> Utf8 Class Initialized
INFO - 2020-05-27 22:45:29 --> URI Class Initialized
DEBUG - 2020-05-27 22:45:29 --> Validating request for /controllers/Register.php
INFO - 2020-05-27 22:45:29 --> Router Class Initialized
INFO - 2020-05-27 22:45:29 --> Plain_Router Class Initialized
INFO - 2020-05-27 22:45:30 --> Output Class Initialized
INFO - 2020-05-27 22:45:30 --> Security Class Initialized
DEBUG - 2020-05-27 22:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-27 22:45:30 --> Input Class Initialized
INFO - 2020-05-27 22:45:30 --> Language Class Initialized
INFO - 2020-05-27 22:45:30 --> Loader Class Initialized
INFO - 2020-05-27 22:45:30 --> Plain_Loader Class Initialized
DEBUG - 2020-05-27 22:45:30 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-27 22:45:30 --> Helper loaded: data_helper
INFO - 2020-05-27 22:45:30 --> Helper loaded: hash_helper
INFO - 2020-05-27 22:45:30 --> Helper loaded: validation_helper
INFO - 2020-05-27 22:45:30 --> Helper loaded: view_helper
INFO - 2020-05-27 22:45:30 --> Helper loaded: url_helper
INFO - 2020-05-27 22:45:30 --> Database Driver Class Initialized
INFO - 2020-05-27 22:45:30 --> Controller Class Initialized
INFO - 2020-05-27 22:45:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-27 22:45:30 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-05-27 22:45:30 --> The "english" language file has been loaded.
INFO - 2020-05-27 22:45:30 --> Plain_Model class loaded
INFO - 2020-05-27 22:45:30 --> Model "Users_model" initialized
ERROR - 2020-05-27 22:45:30 --> Query error: Table 'unmark.users' doesn't exist - Invalid query: 
            SELECT
            COUNT(users.user_id) AS total
            FROM `users` WHERE email = 'colin@cdevroe.com'
DEBUG - 2020-05-27 22:45:30 --> Language file loaded: language/english/db_lang.php
INFO - 2020-05-27 22:45:30 --> Plain_Exceptions Class Initialized
INFO - 2020-05-27 22:45:36 --> Config Class Initialized
INFO - 2020-05-27 22:45:36 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:45:36 --> Hooks Class Initialized
INFO - 2020-05-27 22:45:36 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:45:36 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:45:36 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:45:36 --> Utf8 Class Initialized
INFO - 2020-05-27 22:45:36 --> URI Class Initialized
DEBUG - 2020-05-27 22:45:36 --> No URI present. Default controller set.
INFO - 2020-05-27 22:45:36 --> Router Class Initialized
INFO - 2020-05-27 22:45:36 --> Plain_Router Class Initialized
INFO - 2020-05-27 22:45:36 --> Output Class Initialized
INFO - 2020-05-27 22:45:36 --> Security Class Initialized
DEBUG - 2020-05-27 22:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-27 22:45:36 --> Input Class Initialized
INFO - 2020-05-27 22:45:36 --> Language Class Initialized
INFO - 2020-05-27 22:45:36 --> Loader Class Initialized
INFO - 2020-05-27 22:45:36 --> Plain_Loader Class Initialized
DEBUG - 2020-05-27 22:45:36 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-27 22:45:36 --> Helper loaded: data_helper
INFO - 2020-05-27 22:45:36 --> Helper loaded: hash_helper
INFO - 2020-05-27 22:45:36 --> Helper loaded: validation_helper
INFO - 2020-05-27 22:45:36 --> Helper loaded: view_helper
INFO - 2020-05-27 22:45:36 --> Helper loaded: url_helper
INFO - 2020-05-27 22:45:36 --> Database Driver Class Initialized
INFO - 2020-05-27 22:45:36 --> Controller Class Initialized
INFO - 2020-05-27 22:45:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-27 22:45:36 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-05-27 22:45:36 --> The "english" language file has been loaded.
DEBUG - 2020-05-27 22:45:36 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-05-27 22:45:36 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-05-27 22:45:36 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-05-27 22:45:36 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-05-27 22:45:36 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-05-27 22:45:36 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-05-27 22:45:36 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-05-27 22:45:36 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-05-27 22:45:36 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-05-27 22:45:36 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-05-27 22:45:36 --> Final output sent to browser
DEBUG - 2020-05-27 22:45:36 --> Total execution time: 0.2116
INFO - 2020-05-27 22:45:36 --> Config Class Initialized
INFO - 2020-05-27 22:45:36 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:45:36 --> Hooks Class Initialized
INFO - 2020-05-27 22:45:36 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:45:36 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:45:36 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:45:36 --> Utf8 Class Initialized
INFO - 2020-05-27 22:45:36 --> URI Class Initialized
DEBUG - 2020-05-27 22:45:36 --> Validating request for /controllers/Custom.php
INFO - 2020-05-27 22:45:36 --> Plain_Exceptions Class Initialized
ERROR - 2020-05-27 22:45:36 --> 404 Page Not Found: custom
INFO - 2020-05-27 22:45:44 --> Config Class Initialized
INFO - 2020-05-27 22:45:44 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:45:44 --> Hooks Class Initialized
INFO - 2020-05-27 22:45:44 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:45:44 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:45:44 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:45:44 --> Utf8 Class Initialized
INFO - 2020-05-27 22:45:44 --> URI Class Initialized
DEBUG - 2020-05-27 22:45:44 --> Validating request for /controllers/Login.php
INFO - 2020-05-27 22:45:44 --> Router Class Initialized
INFO - 2020-05-27 22:45:44 --> Plain_Router Class Initialized
INFO - 2020-05-27 22:45:44 --> Output Class Initialized
INFO - 2020-05-27 22:45:44 --> Security Class Initialized
DEBUG - 2020-05-27 22:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-27 22:45:44 --> Input Class Initialized
INFO - 2020-05-27 22:45:44 --> Language Class Initialized
INFO - 2020-05-27 22:45:44 --> Loader Class Initialized
INFO - 2020-05-27 22:45:44 --> Plain_Loader Class Initialized
DEBUG - 2020-05-27 22:45:45 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-27 22:45:45 --> Helper loaded: data_helper
INFO - 2020-05-27 22:45:45 --> Helper loaded: hash_helper
INFO - 2020-05-27 22:45:45 --> Helper loaded: validation_helper
INFO - 2020-05-27 22:45:45 --> Helper loaded: view_helper
INFO - 2020-05-27 22:45:45 --> Helper loaded: url_helper
INFO - 2020-05-27 22:45:45 --> Database Driver Class Initialized
INFO - 2020-05-27 22:45:45 --> Controller Class Initialized
INFO - 2020-05-27 22:45:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-27 22:45:45 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-05-27 22:45:45 --> The "english" language file has been loaded.
INFO - 2020-05-27 22:45:45 --> Plain_Model class loaded
INFO - 2020-05-27 22:45:45 --> Model "Users_model" initialized
ERROR - 2020-05-27 22:45:45 --> Query error: Table 'unmark.users' doesn't exist - Invalid query: SELECT * FROM `users` WHERE email = 'colin@cdevroe.com' ORDER BY user_id DESC LIMIT 0,1
DEBUG - 2020-05-27 22:45:45 --> Language file loaded: language/english/db_lang.php
INFO - 2020-05-27 22:45:45 --> Plain_Exceptions Class Initialized
INFO - 2020-05-27 22:45:50 --> Config Class Initialized
INFO - 2020-05-27 22:45:50 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:45:50 --> Hooks Class Initialized
INFO - 2020-05-27 22:45:50 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:45:50 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:45:50 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:45:50 --> Utf8 Class Initialized
INFO - 2020-05-27 22:45:50 --> URI Class Initialized
DEBUG - 2020-05-27 22:45:50 --> Validating request for /controllers/Login.php
INFO - 2020-05-27 22:45:50 --> Router Class Initialized
INFO - 2020-05-27 22:45:50 --> Plain_Router Class Initialized
INFO - 2020-05-27 22:45:50 --> Output Class Initialized
INFO - 2020-05-27 22:45:50 --> Security Class Initialized
DEBUG - 2020-05-27 22:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-27 22:45:50 --> Input Class Initialized
INFO - 2020-05-27 22:45:50 --> Language Class Initialized
INFO - 2020-05-27 22:45:50 --> Loader Class Initialized
INFO - 2020-05-27 22:45:50 --> Plain_Loader Class Initialized
DEBUG - 2020-05-27 22:45:50 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-27 22:45:50 --> Helper loaded: data_helper
INFO - 2020-05-27 22:45:50 --> Helper loaded: hash_helper
INFO - 2020-05-27 22:45:50 --> Helper loaded: validation_helper
INFO - 2020-05-27 22:45:50 --> Helper loaded: view_helper
INFO - 2020-05-27 22:45:50 --> Helper loaded: url_helper
INFO - 2020-05-27 22:45:50 --> Database Driver Class Initialized
INFO - 2020-05-27 22:45:50 --> Controller Class Initialized
INFO - 2020-05-27 22:45:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-27 22:45:50 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-05-27 22:45:50 --> The "english" language file has been loaded.
INFO - 2020-05-27 22:45:50 --> Plain_Model class loaded
INFO - 2020-05-27 22:45:50 --> Model "Users_model" initialized
ERROR - 2020-05-27 22:45:50 --> Query error: Table 'unmark.users' doesn't exist - Invalid query: SELECT * FROM `users` WHERE email = 'colin@cdevroe.com' ORDER BY user_id DESC LIMIT 0,1
DEBUG - 2020-05-27 22:45:50 --> Language file loaded: language/english/db_lang.php
INFO - 2020-05-27 22:45:50 --> Plain_Exceptions Class Initialized
INFO - 2020-05-27 22:46:00 --> Config Class Initialized
INFO - 2020-05-27 22:46:00 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:46:00 --> Hooks Class Initialized
INFO - 2020-05-27 22:46:00 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:46:00 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:46:00 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:46:00 --> Utf8 Class Initialized
INFO - 2020-05-27 22:46:00 --> URI Class Initialized
DEBUG - 2020-05-27 22:46:00 --> Validating request for /controllers/Login.php
INFO - 2020-05-27 22:46:00 --> Router Class Initialized
INFO - 2020-05-27 22:46:00 --> Plain_Router Class Initialized
INFO - 2020-05-27 22:46:00 --> Output Class Initialized
INFO - 2020-05-27 22:46:00 --> Security Class Initialized
DEBUG - 2020-05-27 22:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-27 22:46:00 --> Input Class Initialized
INFO - 2020-05-27 22:46:00 --> Language Class Initialized
INFO - 2020-05-27 22:46:00 --> Loader Class Initialized
INFO - 2020-05-27 22:46:00 --> Plain_Loader Class Initialized
DEBUG - 2020-05-27 22:46:00 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-27 22:46:00 --> Helper loaded: data_helper
INFO - 2020-05-27 22:46:00 --> Helper loaded: hash_helper
INFO - 2020-05-27 22:46:00 --> Helper loaded: validation_helper
INFO - 2020-05-27 22:46:00 --> Helper loaded: view_helper
INFO - 2020-05-27 22:46:00 --> Helper loaded: url_helper
INFO - 2020-05-27 22:46:00 --> Database Driver Class Initialized
INFO - 2020-05-27 22:46:00 --> Controller Class Initialized
INFO - 2020-05-27 22:46:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-27 22:46:00 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-05-27 22:46:00 --> The "english" language file has been loaded.
INFO - 2020-05-27 22:46:00 --> Plain_Model class loaded
INFO - 2020-05-27 22:46:00 --> Model "Users_model" initialized
ERROR - 2020-05-27 22:46:00 --> Query error: Table 'unmark.users' doesn't exist - Invalid query: SELECT * FROM `users` WHERE email = 'colin@cdevroe.com' ORDER BY user_id DESC LIMIT 0,1
DEBUG - 2020-05-27 22:46:00 --> Language file loaded: language/english/db_lang.php
INFO - 2020-05-27 22:46:00 --> Plain_Exceptions Class Initialized
INFO - 2020-05-27 22:46:02 --> Config Class Initialized
INFO - 2020-05-27 22:46:02 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:46:02 --> Hooks Class Initialized
INFO - 2020-05-27 22:46:02 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:46:02 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:46:02 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:46:02 --> Utf8 Class Initialized
INFO - 2020-05-27 22:46:02 --> URI Class Initialized
DEBUG - 2020-05-27 22:46:02 --> Validating request for /controllers/Register.php
INFO - 2020-05-27 22:46:02 --> Router Class Initialized
INFO - 2020-05-27 22:46:02 --> Plain_Router Class Initialized
INFO - 2020-05-27 22:46:02 --> Output Class Initialized
INFO - 2020-05-27 22:46:02 --> Security Class Initialized
DEBUG - 2020-05-27 22:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-27 22:46:02 --> Input Class Initialized
INFO - 2020-05-27 22:46:02 --> Language Class Initialized
INFO - 2020-05-27 22:46:02 --> Loader Class Initialized
INFO - 2020-05-27 22:46:02 --> Plain_Loader Class Initialized
DEBUG - 2020-05-27 22:46:02 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-27 22:46:02 --> Helper loaded: data_helper
INFO - 2020-05-27 22:46:02 --> Helper loaded: hash_helper
INFO - 2020-05-27 22:46:02 --> Helper loaded: validation_helper
INFO - 2020-05-27 22:46:02 --> Helper loaded: view_helper
INFO - 2020-05-27 22:46:02 --> Helper loaded: url_helper
INFO - 2020-05-27 22:46:02 --> Database Driver Class Initialized
INFO - 2020-05-27 22:46:02 --> Controller Class Initialized
INFO - 2020-05-27 22:46:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-27 22:46:02 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-05-27 22:46:02 --> The "english" language file has been loaded.
DEBUG - 2020-05-27 22:46:02 --> The phrase "Unmark : User Registration" could not be found in the language file.
DEBUG - 2020-05-27 22:46:02 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-05-27 22:46:02 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-05-27 22:46:02 --> The phrase "Password Again" could not be found in the language file.
DEBUG - 2020-05-27 22:46:02 --> The phrase "Terms of Use" could not be found in the language file.
DEBUG - 2020-05-27 22:46:02 --> The phrase "Have An Account? Sign In Here" could not be found in the language file.
INFO - 2020-05-27 22:46:02 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-05-27 22:46:02 --> File loaded: /var/www/html/application/views/register/index.php
INFO - 2020-05-27 22:46:02 --> Final output sent to browser
DEBUG - 2020-05-27 22:46:02 --> Total execution time: 0.1516
INFO - 2020-05-27 22:46:02 --> Config Class Initialized
INFO - 2020-05-27 22:46:02 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:46:02 --> Hooks Class Initialized
INFO - 2020-05-27 22:46:02 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:46:02 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:46:02 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:46:02 --> Utf8 Class Initialized
INFO - 2020-05-27 22:46:02 --> URI Class Initialized
DEBUG - 2020-05-27 22:46:02 --> Validating request for /controllers/Custom.php
INFO - 2020-05-27 22:46:02 --> Plain_Exceptions Class Initialized
ERROR - 2020-05-27 22:46:02 --> 404 Page Not Found: custom
INFO - 2020-05-27 22:46:18 --> Config Class Initialized
INFO - 2020-05-27 22:46:18 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:46:18 --> Hooks Class Initialized
INFO - 2020-05-27 22:46:18 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:46:18 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:46:18 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:46:18 --> Utf8 Class Initialized
INFO - 2020-05-27 22:46:18 --> URI Class Initialized
DEBUG - 2020-05-27 22:46:18 --> Validating request for /controllers/Register.php
INFO - 2020-05-27 22:46:18 --> Router Class Initialized
INFO - 2020-05-27 22:46:18 --> Plain_Router Class Initialized
INFO - 2020-05-27 22:46:18 --> Output Class Initialized
INFO - 2020-05-27 22:46:18 --> Security Class Initialized
DEBUG - 2020-05-27 22:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-27 22:46:18 --> Input Class Initialized
INFO - 2020-05-27 22:46:18 --> Language Class Initialized
INFO - 2020-05-27 22:46:18 --> Loader Class Initialized
INFO - 2020-05-27 22:46:18 --> Plain_Loader Class Initialized
DEBUG - 2020-05-27 22:46:18 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-27 22:46:18 --> Helper loaded: data_helper
INFO - 2020-05-27 22:46:18 --> Helper loaded: hash_helper
INFO - 2020-05-27 22:46:18 --> Helper loaded: validation_helper
INFO - 2020-05-27 22:46:18 --> Helper loaded: view_helper
INFO - 2020-05-27 22:46:18 --> Helper loaded: url_helper
INFO - 2020-05-27 22:46:18 --> Database Driver Class Initialized
INFO - 2020-05-27 22:46:18 --> Controller Class Initialized
INFO - 2020-05-27 22:46:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-27 22:46:18 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-05-27 22:46:18 --> The "english" language file has been loaded.
INFO - 2020-05-27 22:46:18 --> Plain_Model class loaded
INFO - 2020-05-27 22:46:18 --> Model "Users_model" initialized
ERROR - 2020-05-27 22:46:18 --> Query error: Table 'unmark.users' doesn't exist - Invalid query: 
            SELECT
            COUNT(users.user_id) AS total
            FROM `users` WHERE email = 'colin+local@cdevroe.com'
DEBUG - 2020-05-27 22:46:18 --> Language file loaded: language/english/db_lang.php
INFO - 2020-05-27 22:46:18 --> Plain_Exceptions Class Initialized
INFO - 2020-05-27 22:46:25 --> Config Class Initialized
INFO - 2020-05-27 22:46:25 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:46:25 --> Hooks Class Initialized
INFO - 2020-05-27 22:46:25 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:46:25 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:46:25 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:46:25 --> Utf8 Class Initialized
INFO - 2020-05-27 22:46:25 --> URI Class Initialized
DEBUG - 2020-05-27 22:46:25 --> No URI present. Default controller set.
INFO - 2020-05-27 22:46:25 --> Router Class Initialized
INFO - 2020-05-27 22:46:25 --> Plain_Router Class Initialized
INFO - 2020-05-27 22:46:25 --> Output Class Initialized
INFO - 2020-05-27 22:46:25 --> Security Class Initialized
DEBUG - 2020-05-27 22:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-27 22:46:25 --> Input Class Initialized
INFO - 2020-05-27 22:46:25 --> Language Class Initialized
INFO - 2020-05-27 22:46:25 --> Loader Class Initialized
INFO - 2020-05-27 22:46:25 --> Plain_Loader Class Initialized
DEBUG - 2020-05-27 22:46:25 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-27 22:46:25 --> Helper loaded: data_helper
INFO - 2020-05-27 22:46:25 --> Helper loaded: hash_helper
INFO - 2020-05-27 22:46:25 --> Helper loaded: validation_helper
INFO - 2020-05-27 22:46:25 --> Helper loaded: view_helper
INFO - 2020-05-27 22:46:25 --> Helper loaded: url_helper
INFO - 2020-05-27 22:46:25 --> Database Driver Class Initialized
INFO - 2020-05-27 22:46:25 --> Controller Class Initialized
INFO - 2020-05-27 22:46:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-27 22:46:25 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-05-27 22:46:25 --> The "english" language file has been loaded.
DEBUG - 2020-05-27 22:46:25 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-05-27 22:46:25 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-05-27 22:46:25 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-05-27 22:46:25 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-05-27 22:46:25 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-05-27 22:46:25 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-05-27 22:46:25 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-05-27 22:46:25 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-05-27 22:46:25 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-05-27 22:46:25 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-05-27 22:46:25 --> Final output sent to browser
DEBUG - 2020-05-27 22:46:25 --> Total execution time: 0.1568
INFO - 2020-05-27 22:46:26 --> Config Class Initialized
INFO - 2020-05-27 22:46:26 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:46:26 --> Hooks Class Initialized
INFO - 2020-05-27 22:46:26 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:46:26 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:46:26 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:46:26 --> Utf8 Class Initialized
INFO - 2020-05-27 22:46:26 --> URI Class Initialized
DEBUG - 2020-05-27 22:46:26 --> Validating request for /controllers/Custom.php
INFO - 2020-05-27 22:46:26 --> Plain_Exceptions Class Initialized
ERROR - 2020-05-27 22:46:26 --> 404 Page Not Found: custom
INFO - 2020-05-27 22:46:39 --> Config Class Initialized
INFO - 2020-05-27 22:46:39 --> Plain_Config Class Initialized
INFO - 2020-05-27 22:46:39 --> Hooks Class Initialized
INFO - 2020-05-27 22:46:39 --> Plain_Hooks Class Constructed
INFO - 2020-05-27 22:46:39 --> Plain_Hooks Class Initialized
DEBUG - 2020-05-27 22:46:39 --> UTF-8 Support Disabled
INFO - 2020-05-27 22:46:39 --> Utf8 Class Initialized
INFO - 2020-05-27 22:46:39 --> URI Class Initialized
DEBUG - 2020-05-27 22:46:39 --> Validating request for /controllers/Login.php
INFO - 2020-05-27 22:46:39 --> Router Class Initialized
INFO - 2020-05-27 22:46:39 --> Plain_Router Class Initialized
INFO - 2020-05-27 22:46:39 --> Output Class Initialized
INFO - 2020-05-27 22:46:39 --> Security Class Initialized
DEBUG - 2020-05-27 22:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-05-27 22:46:39 --> Input Class Initialized
INFO - 2020-05-27 22:46:39 --> Language Class Initialized
INFO - 2020-05-27 22:46:39 --> Loader Class Initialized
INFO - 2020-05-27 22:46:39 --> Plain_Loader Class Initialized
DEBUG - 2020-05-27 22:46:39 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-05-27 22:46:39 --> Helper loaded: data_helper
INFO - 2020-05-27 22:46:39 --> Helper loaded: hash_helper
INFO - 2020-05-27 22:46:39 --> Helper loaded: validation_helper
INFO - 2020-05-27 22:46:39 --> Helper loaded: view_helper
INFO - 2020-05-27 22:46:39 --> Helper loaded: url_helper
INFO - 2020-05-27 22:46:39 --> Database Driver Class Initialized
INFO - 2020-05-27 22:46:39 --> Controller Class Initialized
INFO - 2020-05-27 22:46:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-05-27 22:46:39 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-05-27 22:46:39 --> The "english" language file has been loaded.
INFO - 2020-05-27 22:46:39 --> Plain_Model class loaded
INFO - 2020-05-27 22:46:39 --> Model "Users_model" initialized
ERROR - 2020-05-27 22:46:39 --> Query error: Table 'unmark.users' doesn't exist - Invalid query: SELECT * FROM `users` WHERE email = 'colin+local@cdevroe.com' ORDER BY user_id DESC LIMIT 0,1
DEBUG - 2020-05-27 22:46:39 --> Language file loaded: language/english/db_lang.php
INFO - 2020-05-27 22:46:39 --> Plain_Exceptions Class Initialized
