<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-06-25 13:53:28 --> Config Class Initialized
INFO - 2020-06-25 13:53:28 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:53:28 --> Hooks Class Initialized
INFO - 2020-06-25 13:53:28 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:53:28 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:53:28 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:53:28 --> Utf8 Class Initialized
INFO - 2020-06-25 13:53:28 --> URI Class Initialized
DEBUG - 2020-06-25 13:53:28 --> No URI present. Default controller set.
INFO - 2020-06-25 13:53:28 --> Router Class Initialized
INFO - 2020-06-25 13:53:28 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:53:28 --> Output Class Initialized
INFO - 2020-06-25 13:53:28 --> Security Class Initialized
DEBUG - 2020-06-25 13:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:53:28 --> Input Class Initialized
INFO - 2020-06-25 13:53:28 --> Language Class Initialized
INFO - 2020-06-25 13:53:28 --> Loader Class Initialized
INFO - 2020-06-25 13:53:28 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:53:28 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:53:28 --> Helper loaded: data_helper
INFO - 2020-06-25 13:53:28 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:53:28 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:53:28 --> Helper loaded: view_helper
INFO - 2020-06-25 13:53:28 --> Helper loaded: url_helper
INFO - 2020-06-25 13:53:28 --> Database Driver Class Initialized
INFO - 2020-06-25 13:53:28 --> Controller Class Initialized
INFO - 2020-06-25 13:53:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:53:28 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:53:28 --> The "english" language file has been loaded.
INFO - 2020-06-25 13:54:16 --> Config Class Initialized
INFO - 2020-06-25 13:54:16 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:54:16 --> Hooks Class Initialized
INFO - 2020-06-25 13:54:16 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:54:16 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:54:16 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:54:16 --> Utf8 Class Initialized
INFO - 2020-06-25 13:54:16 --> URI Class Initialized
DEBUG - 2020-06-25 13:54:16 --> No URI present. Default controller set.
INFO - 2020-06-25 13:54:16 --> Router Class Initialized
INFO - 2020-06-25 13:54:16 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:54:16 --> Output Class Initialized
INFO - 2020-06-25 13:54:16 --> Security Class Initialized
DEBUG - 2020-06-25 13:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:54:16 --> Input Class Initialized
INFO - 2020-06-25 13:54:16 --> Language Class Initialized
INFO - 2020-06-25 13:54:16 --> Loader Class Initialized
INFO - 2020-06-25 13:54:16 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:54:16 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:54:16 --> Helper loaded: data_helper
INFO - 2020-06-25 13:54:16 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:54:16 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:54:16 --> Helper loaded: view_helper
INFO - 2020-06-25 13:54:16 --> Helper loaded: url_helper
INFO - 2020-06-25 13:54:16 --> Database Driver Class Initialized
INFO - 2020-06-25 13:54:16 --> Controller Class Initialized
INFO - 2020-06-25 13:54:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:54:16 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:54:16 --> The "english" language file has been loaded.
INFO - 2020-06-25 13:54:21 --> Config Class Initialized
INFO - 2020-06-25 13:54:21 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:54:21 --> Hooks Class Initialized
INFO - 2020-06-25 13:54:21 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:54:21 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:54:21 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:54:21 --> Utf8 Class Initialized
INFO - 2020-06-25 13:54:21 --> URI Class Initialized
DEBUG - 2020-06-25 13:54:21 --> No URI present. Default controller set.
INFO - 2020-06-25 13:54:21 --> Router Class Initialized
INFO - 2020-06-25 13:54:21 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:54:21 --> Output Class Initialized
INFO - 2020-06-25 13:54:21 --> Security Class Initialized
DEBUG - 2020-06-25 13:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:54:21 --> Input Class Initialized
INFO - 2020-06-25 13:54:21 --> Language Class Initialized
INFO - 2020-06-25 13:54:21 --> Loader Class Initialized
INFO - 2020-06-25 13:54:21 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:54:21 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:54:21 --> Helper loaded: data_helper
INFO - 2020-06-25 13:54:21 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:54:21 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:54:21 --> Helper loaded: view_helper
INFO - 2020-06-25 13:54:21 --> Helper loaded: url_helper
INFO - 2020-06-25 13:54:21 --> Database Driver Class Initialized
INFO - 2020-06-25 13:54:21 --> Controller Class Initialized
INFO - 2020-06-25 13:54:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:54:21 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:54:21 --> The "english" language file has been loaded.
INFO - 2020-06-25 13:54:28 --> Config Class Initialized
INFO - 2020-06-25 13:54:28 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:54:28 --> Hooks Class Initialized
INFO - 2020-06-25 13:54:28 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:54:28 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:54:28 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:54:28 --> Utf8 Class Initialized
INFO - 2020-06-25 13:54:28 --> URI Class Initialized
DEBUG - 2020-06-25 13:54:28 --> No URI present. Default controller set.
INFO - 2020-06-25 13:54:28 --> Router Class Initialized
INFO - 2020-06-25 13:54:28 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:54:28 --> Output Class Initialized
INFO - 2020-06-25 13:54:28 --> Security Class Initialized
DEBUG - 2020-06-25 13:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:54:28 --> Input Class Initialized
INFO - 2020-06-25 13:54:28 --> Language Class Initialized
INFO - 2020-06-25 13:54:28 --> Loader Class Initialized
INFO - 2020-06-25 13:54:28 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:54:28 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:54:28 --> Helper loaded: data_helper
INFO - 2020-06-25 13:54:28 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:54:28 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:54:28 --> Helper loaded: view_helper
INFO - 2020-06-25 13:54:28 --> Helper loaded: url_helper
INFO - 2020-06-25 13:54:28 --> Database Driver Class Initialized
INFO - 2020-06-25 13:54:28 --> Controller Class Initialized
INFO - 2020-06-25 13:54:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:54:28 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:54:28 --> The "english" language file has been loaded.
DEBUG - 2020-06-25 13:54:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-25 13:54:28 --> Array
(
    [message] => Error: Cannot use object of type CI_DB_mysqli_result as array
    [type] => Error
    [backtrace] => /var/www/html/application/controllers/Welcome.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
        )

)

INFO - 2020-06-25 13:54:34 --> Config Class Initialized
INFO - 2020-06-25 13:54:34 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:54:34 --> Hooks Class Initialized
INFO - 2020-06-25 13:54:34 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:54:34 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:54:34 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:54:34 --> Utf8 Class Initialized
INFO - 2020-06-25 13:54:34 --> URI Class Initialized
DEBUG - 2020-06-25 13:54:34 --> No URI present. Default controller set.
INFO - 2020-06-25 13:54:34 --> Router Class Initialized
INFO - 2020-06-25 13:54:34 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:54:34 --> Output Class Initialized
INFO - 2020-06-25 13:54:34 --> Security Class Initialized
DEBUG - 2020-06-25 13:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:54:34 --> Input Class Initialized
INFO - 2020-06-25 13:54:34 --> Language Class Initialized
INFO - 2020-06-25 13:54:34 --> Loader Class Initialized
INFO - 2020-06-25 13:54:34 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:54:34 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:54:34 --> Helper loaded: data_helper
INFO - 2020-06-25 13:54:34 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:54:34 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:54:34 --> Helper loaded: view_helper
INFO - 2020-06-25 13:54:34 --> Helper loaded: url_helper
INFO - 2020-06-25 13:54:34 --> Database Driver Class Initialized
INFO - 2020-06-25 13:54:34 --> Controller Class Initialized
INFO - 2020-06-25 13:54:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:54:34 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:54:34 --> The "english" language file has been loaded.
INFO - 2020-06-25 13:54:51 --> Config Class Initialized
INFO - 2020-06-25 13:54:51 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:54:51 --> Hooks Class Initialized
INFO - 2020-06-25 13:54:51 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:54:51 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:54:51 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:54:51 --> Utf8 Class Initialized
INFO - 2020-06-25 13:54:51 --> URI Class Initialized
DEBUG - 2020-06-25 13:54:51 --> No URI present. Default controller set.
INFO - 2020-06-25 13:54:51 --> Router Class Initialized
INFO - 2020-06-25 13:54:51 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:54:51 --> Output Class Initialized
INFO - 2020-06-25 13:54:51 --> Security Class Initialized
DEBUG - 2020-06-25 13:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:54:51 --> Input Class Initialized
INFO - 2020-06-25 13:54:51 --> Language Class Initialized
INFO - 2020-06-25 13:54:51 --> Loader Class Initialized
INFO - 2020-06-25 13:54:51 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:54:51 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:54:51 --> Helper loaded: data_helper
INFO - 2020-06-25 13:54:51 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:54:51 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:54:51 --> Helper loaded: view_helper
INFO - 2020-06-25 13:54:51 --> Helper loaded: url_helper
INFO - 2020-06-25 13:54:51 --> Database Driver Class Initialized
INFO - 2020-06-25 13:54:51 --> Controller Class Initialized
INFO - 2020-06-25 13:54:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:54:51 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:54:51 --> The "english" language file has been loaded.
INFO - 2020-06-25 13:55:07 --> Config Class Initialized
INFO - 2020-06-25 13:55:07 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:55:07 --> Hooks Class Initialized
INFO - 2020-06-25 13:55:07 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:55:07 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:55:07 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:55:07 --> Utf8 Class Initialized
INFO - 2020-06-25 13:55:07 --> URI Class Initialized
DEBUG - 2020-06-25 13:55:07 --> No URI present. Default controller set.
INFO - 2020-06-25 13:55:07 --> Router Class Initialized
INFO - 2020-06-25 13:55:07 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:55:07 --> Output Class Initialized
INFO - 2020-06-25 13:55:07 --> Security Class Initialized
DEBUG - 2020-06-25 13:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:55:07 --> Input Class Initialized
INFO - 2020-06-25 13:55:07 --> Language Class Initialized
INFO - 2020-06-25 13:55:07 --> Loader Class Initialized
INFO - 2020-06-25 13:55:07 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:55:07 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:55:07 --> Helper loaded: data_helper
INFO - 2020-06-25 13:55:07 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:55:07 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:55:07 --> Helper loaded: view_helper
INFO - 2020-06-25 13:55:07 --> Helper loaded: url_helper
INFO - 2020-06-25 13:55:07 --> Database Driver Class Initialized
INFO - 2020-06-25 13:55:07 --> Controller Class Initialized
INFO - 2020-06-25 13:55:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:55:07 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:55:07 --> The "english" language file has been loaded.
DEBUG - 2020-06-25 13:55:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-25 13:55:07 --> Array
(
    [message] => Error: Cannot use object of type CI_DB_mysqli_result as array
    [type] => Error
    [backtrace] => /var/www/html/application/controllers/Welcome.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
        )

)

INFO - 2020-06-25 13:55:22 --> Config Class Initialized
INFO - 2020-06-25 13:55:22 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:55:22 --> Hooks Class Initialized
INFO - 2020-06-25 13:55:22 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:55:22 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:55:22 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:55:22 --> Utf8 Class Initialized
INFO - 2020-06-25 13:55:22 --> URI Class Initialized
DEBUG - 2020-06-25 13:55:22 --> No URI present. Default controller set.
INFO - 2020-06-25 13:55:22 --> Router Class Initialized
INFO - 2020-06-25 13:55:22 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:55:22 --> Output Class Initialized
INFO - 2020-06-25 13:55:22 --> Security Class Initialized
DEBUG - 2020-06-25 13:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:55:22 --> Input Class Initialized
INFO - 2020-06-25 13:55:22 --> Language Class Initialized
INFO - 2020-06-25 13:55:22 --> Loader Class Initialized
INFO - 2020-06-25 13:55:22 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:55:22 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:55:22 --> Helper loaded: data_helper
INFO - 2020-06-25 13:55:22 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:55:22 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:55:22 --> Helper loaded: view_helper
INFO - 2020-06-25 13:55:22 --> Helper loaded: url_helper
INFO - 2020-06-25 13:55:22 --> Database Driver Class Initialized
INFO - 2020-06-25 13:55:22 --> Controller Class Initialized
INFO - 2020-06-25 13:55:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:55:22 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:55:22 --> The "english" language file has been loaded.
INFO - 2020-06-25 13:55:25 --> Config Class Initialized
INFO - 2020-06-25 13:55:25 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:55:25 --> Hooks Class Initialized
INFO - 2020-06-25 13:55:25 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:55:25 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:55:25 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:55:25 --> Utf8 Class Initialized
INFO - 2020-06-25 13:55:25 --> URI Class Initialized
DEBUG - 2020-06-25 13:55:25 --> No URI present. Default controller set.
INFO - 2020-06-25 13:55:25 --> Router Class Initialized
INFO - 2020-06-25 13:55:25 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:55:25 --> Output Class Initialized
INFO - 2020-06-25 13:55:25 --> Security Class Initialized
DEBUG - 2020-06-25 13:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:55:25 --> Input Class Initialized
INFO - 2020-06-25 13:55:25 --> Language Class Initialized
INFO - 2020-06-25 13:55:25 --> Loader Class Initialized
INFO - 2020-06-25 13:55:25 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:55:25 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:55:25 --> Helper loaded: data_helper
INFO - 2020-06-25 13:55:25 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:55:25 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:55:25 --> Helper loaded: view_helper
INFO - 2020-06-25 13:55:25 --> Helper loaded: url_helper
INFO - 2020-06-25 13:55:25 --> Database Driver Class Initialized
INFO - 2020-06-25 13:55:25 --> Controller Class Initialized
INFO - 2020-06-25 13:55:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:55:25 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:55:25 --> The "english" language file has been loaded.
INFO - 2020-06-25 13:56:47 --> Config Class Initialized
INFO - 2020-06-25 13:56:47 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:56:47 --> Hooks Class Initialized
INFO - 2020-06-25 13:56:47 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:56:47 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:56:47 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:56:47 --> Utf8 Class Initialized
INFO - 2020-06-25 13:56:47 --> URI Class Initialized
DEBUG - 2020-06-25 13:56:47 --> No URI present. Default controller set.
INFO - 2020-06-25 13:56:47 --> Router Class Initialized
INFO - 2020-06-25 13:56:47 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:56:47 --> Output Class Initialized
INFO - 2020-06-25 13:56:47 --> Security Class Initialized
DEBUG - 2020-06-25 13:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:56:47 --> Input Class Initialized
INFO - 2020-06-25 13:56:47 --> Language Class Initialized
INFO - 2020-06-25 13:56:47 --> Loader Class Initialized
INFO - 2020-06-25 13:56:47 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:56:47 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:56:47 --> Helper loaded: data_helper
INFO - 2020-06-25 13:56:47 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:56:47 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:56:47 --> Helper loaded: view_helper
INFO - 2020-06-25 13:56:47 --> Helper loaded: url_helper
INFO - 2020-06-25 13:56:47 --> Database Driver Class Initialized
INFO - 2020-06-25 13:56:47 --> Controller Class Initialized
INFO - 2020-06-25 13:56:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:56:47 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:56:47 --> The "english" language file has been loaded.
DEBUG - 2020-06-25 13:56:47 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-25 13:56:47 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-25 13:56:47 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-25 13:56:47 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-25 13:56:47 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-25 13:56:47 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-25 13:56:47 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-25 13:56:47 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-25 13:56:47 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-25 13:56:47 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-25 13:56:47 --> Final output sent to browser
DEBUG - 2020-06-25 13:56:47 --> Total execution time: 0.1180
INFO - 2020-06-25 13:56:47 --> Config Class Initialized
INFO - 2020-06-25 13:56:47 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:56:47 --> Hooks Class Initialized
INFO - 2020-06-25 13:56:47 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:56:47 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:56:47 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:56:47 --> Utf8 Class Initialized
INFO - 2020-06-25 13:56:47 --> URI Class Initialized
DEBUG - 2020-06-25 13:56:47 --> Validating request for /controllers/Custom.php
INFO - 2020-06-25 13:56:47 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-25 13:56:47 --> 404 Page Not Found: custom
INFO - 2020-06-25 13:56:55 --> Config Class Initialized
INFO - 2020-06-25 13:56:55 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:56:55 --> Hooks Class Initialized
INFO - 2020-06-25 13:56:55 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:56:55 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:56:55 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:56:55 --> Utf8 Class Initialized
INFO - 2020-06-25 13:56:55 --> URI Class Initialized
DEBUG - 2020-06-25 13:56:55 --> Validating request for /controllers/Login.php
INFO - 2020-06-25 13:56:55 --> Router Class Initialized
INFO - 2020-06-25 13:56:55 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:56:55 --> Output Class Initialized
INFO - 2020-06-25 13:56:55 --> Security Class Initialized
DEBUG - 2020-06-25 13:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:56:55 --> Input Class Initialized
INFO - 2020-06-25 13:56:55 --> Language Class Initialized
INFO - 2020-06-25 13:56:55 --> Loader Class Initialized
INFO - 2020-06-25 13:56:55 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:56:55 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:56:55 --> Helper loaded: data_helper
INFO - 2020-06-25 13:56:55 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:56:55 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:56:55 --> Helper loaded: view_helper
INFO - 2020-06-25 13:56:55 --> Helper loaded: url_helper
INFO - 2020-06-25 13:56:55 --> Database Driver Class Initialized
INFO - 2020-06-25 13:56:55 --> Controller Class Initialized
INFO - 2020-06-25 13:56:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:56:55 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:56:55 --> The "english" language file has been loaded.
INFO - 2020-06-25 13:56:55 --> Plain_Model class loaded
INFO - 2020-06-25 13:56:55 --> Model "Users_model" initialized
INFO - 2020-06-25 13:56:55 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-06-25 13:56:55 --> Final output sent to browser
DEBUG - 2020-06-25 13:56:55 --> Total execution time: 0.1830
INFO - 2020-06-25 13:56:57 --> Config Class Initialized
INFO - 2020-06-25 13:56:57 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:56:57 --> Hooks Class Initialized
INFO - 2020-06-25 13:56:57 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:56:57 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:56:57 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:56:57 --> Utf8 Class Initialized
INFO - 2020-06-25 13:56:57 --> URI Class Initialized
DEBUG - 2020-06-25 13:56:57 --> Validating request for /controllers/Marks.php
INFO - 2020-06-25 13:56:57 --> Router Class Initialized
INFO - 2020-06-25 13:56:57 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:56:57 --> Output Class Initialized
INFO - 2020-06-25 13:56:57 --> Security Class Initialized
DEBUG - 2020-06-25 13:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:56:57 --> Input Class Initialized
INFO - 2020-06-25 13:56:57 --> Language Class Initialized
INFO - 2020-06-25 13:56:57 --> Loader Class Initialized
INFO - 2020-06-25 13:56:57 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:56:57 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:56:57 --> Helper loaded: data_helper
INFO - 2020-06-25 13:56:57 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:56:57 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:56:57 --> Helper loaded: view_helper
INFO - 2020-06-25 13:56:57 --> Helper loaded: url_helper
INFO - 2020-06-25 13:56:57 --> Database Driver Class Initialized
INFO - 2020-06-25 13:56:57 --> Controller Class Initialized
INFO - 2020-06-25 13:56:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:56:57 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-25 13:56:57 --> Plain_Model class loaded
INFO - 2020-06-25 13:56:57 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-25 13:56:57 --> The "english" language file has been loaded.
INFO - 2020-06-25 13:56:57 --> Model "Labels_model" initialized
INFO - 2020-06-25 13:56:57 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-25 13:56:57 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-25 13:56:57 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-25 13:56:57 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-25 13:56:57 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-25 13:56:57 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-25 13:56:57 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-25 13:56:57 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-25 13:56:57 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-25 13:56:57 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-25 13:56:57 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-25 13:56:57 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-25 13:56:57 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-25 13:56:57 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-25 13:56:57 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-25 13:56:57 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-25 13:56:57 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-25 13:56:57 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-25 13:56:57 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-25 13:56:57 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-25 13:56:57 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-25 13:56:57 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-25 13:56:57 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-25 13:56:57 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-25 13:56:57 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-25 13:56:57 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-25 13:56:57 --> Final output sent to browser
DEBUG - 2020-06-25 13:56:57 --> Total execution time: 0.2578
INFO - 2020-06-25 13:56:58 --> Config Class Initialized
INFO - 2020-06-25 13:56:58 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:56:58 --> Hooks Class Initialized
INFO - 2020-06-25 13:56:58 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:56:58 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:56:58 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:56:58 --> Utf8 Class Initialized
INFO - 2020-06-25 13:56:58 --> URI Class Initialized
DEBUG - 2020-06-25 13:56:58 --> Validating request for /controllers/Custom.php
INFO - 2020-06-25 13:56:58 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-25 13:56:58 --> 404 Page Not Found: custom
INFO - 2020-06-25 13:57:01 --> Config Class Initialized
INFO - 2020-06-25 13:57:01 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:57:01 --> Hooks Class Initialized
INFO - 2020-06-25 13:57:01 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:57:01 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:57:01 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:57:01 --> Utf8 Class Initialized
INFO - 2020-06-25 13:57:01 --> URI Class Initialized
DEBUG - 2020-06-25 13:57:01 --> Validating request for /controllers/Logout.php
INFO - 2020-06-25 13:57:01 --> Router Class Initialized
INFO - 2020-06-25 13:57:01 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:57:01 --> Output Class Initialized
INFO - 2020-06-25 13:57:01 --> Security Class Initialized
DEBUG - 2020-06-25 13:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:57:01 --> Input Class Initialized
INFO - 2020-06-25 13:57:01 --> Language Class Initialized
INFO - 2020-06-25 13:57:01 --> Loader Class Initialized
INFO - 2020-06-25 13:57:01 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:57:01 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:57:01 --> Helper loaded: data_helper
INFO - 2020-06-25 13:57:01 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:57:01 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:57:01 --> Helper loaded: view_helper
INFO - 2020-06-25 13:57:01 --> Helper loaded: url_helper
INFO - 2020-06-25 13:57:01 --> Database Driver Class Initialized
INFO - 2020-06-25 13:57:01 --> Controller Class Initialized
INFO - 2020-06-25 13:57:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:57:01 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:57:01 --> The "english" language file has been loaded.
INFO - 2020-06-25 13:57:01 --> Config Class Initialized
INFO - 2020-06-25 13:57:01 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:57:01 --> Hooks Class Initialized
INFO - 2020-06-25 13:57:01 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:57:01 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:57:01 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:57:01 --> Utf8 Class Initialized
INFO - 2020-06-25 13:57:01 --> URI Class Initialized
DEBUG - 2020-06-25 13:57:01 --> No URI present. Default controller set.
INFO - 2020-06-25 13:57:01 --> Router Class Initialized
INFO - 2020-06-25 13:57:01 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:57:01 --> Output Class Initialized
INFO - 2020-06-25 13:57:01 --> Security Class Initialized
DEBUG - 2020-06-25 13:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:57:01 --> Input Class Initialized
INFO - 2020-06-25 13:57:01 --> Language Class Initialized
INFO - 2020-06-25 13:57:01 --> Loader Class Initialized
INFO - 2020-06-25 13:57:01 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:57:01 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:57:01 --> Helper loaded: data_helper
INFO - 2020-06-25 13:57:01 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:57:01 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:57:01 --> Helper loaded: view_helper
INFO - 2020-06-25 13:57:01 --> Helper loaded: url_helper
INFO - 2020-06-25 13:57:01 --> Database Driver Class Initialized
INFO - 2020-06-25 13:57:01 --> Controller Class Initialized
INFO - 2020-06-25 13:57:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:57:01 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:57:01 --> The "english" language file has been loaded.
DEBUG - 2020-06-25 13:57:01 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-25 13:57:01 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-25 13:57:01 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-25 13:57:01 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-25 13:57:01 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-25 13:57:01 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-25 13:57:01 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-25 13:57:01 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-25 13:57:01 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-25 13:57:01 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-25 13:57:01 --> Final output sent to browser
DEBUG - 2020-06-25 13:57:01 --> Total execution time: 0.1288
INFO - 2020-06-25 13:57:01 --> Config Class Initialized
INFO - 2020-06-25 13:57:01 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:57:01 --> Hooks Class Initialized
INFO - 2020-06-25 13:57:01 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:57:01 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:57:01 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:57:01 --> Utf8 Class Initialized
INFO - 2020-06-25 13:57:01 --> URI Class Initialized
DEBUG - 2020-06-25 13:57:01 --> Validating request for /controllers/Custom.php
INFO - 2020-06-25 13:57:01 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-25 13:57:01 --> 404 Page Not Found: custom
INFO - 2020-06-25 13:57:27 --> Config Class Initialized
INFO - 2020-06-25 13:57:27 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:57:27 --> Hooks Class Initialized
INFO - 2020-06-25 13:57:27 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:57:27 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:57:27 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:57:27 --> Utf8 Class Initialized
INFO - 2020-06-25 13:57:27 --> URI Class Initialized
DEBUG - 2020-06-25 13:57:27 --> No URI present. Default controller set.
INFO - 2020-06-25 13:57:27 --> Router Class Initialized
INFO - 2020-06-25 13:57:27 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:57:27 --> Output Class Initialized
INFO - 2020-06-25 13:57:27 --> Security Class Initialized
DEBUG - 2020-06-25 13:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:57:27 --> Input Class Initialized
INFO - 2020-06-25 13:57:27 --> Language Class Initialized
INFO - 2020-06-25 13:57:27 --> Loader Class Initialized
INFO - 2020-06-25 13:57:27 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:57:27 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:57:27 --> Helper loaded: data_helper
INFO - 2020-06-25 13:57:27 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:57:27 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:57:27 --> Helper loaded: view_helper
INFO - 2020-06-25 13:57:27 --> Helper loaded: url_helper
INFO - 2020-06-25 13:57:27 --> Database Driver Class Initialized
INFO - 2020-06-25 13:57:27 --> Controller Class Initialized
INFO - 2020-06-25 13:57:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:57:27 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:57:27 --> The "english" language file has been loaded.
INFO - 2020-06-25 13:57:42 --> Config Class Initialized
INFO - 2020-06-25 13:57:42 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:57:42 --> Hooks Class Initialized
INFO - 2020-06-25 13:57:42 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:57:42 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:57:42 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:57:42 --> Utf8 Class Initialized
INFO - 2020-06-25 13:57:42 --> URI Class Initialized
DEBUG - 2020-06-25 13:57:42 --> No URI present. Default controller set.
INFO - 2020-06-25 13:57:42 --> Router Class Initialized
INFO - 2020-06-25 13:57:42 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:57:42 --> Output Class Initialized
INFO - 2020-06-25 13:57:42 --> Security Class Initialized
DEBUG - 2020-06-25 13:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:57:42 --> Input Class Initialized
INFO - 2020-06-25 13:57:42 --> Language Class Initialized
INFO - 2020-06-25 13:57:42 --> Loader Class Initialized
INFO - 2020-06-25 13:57:42 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:57:42 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:57:42 --> Helper loaded: data_helper
INFO - 2020-06-25 13:57:42 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:57:42 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:57:42 --> Helper loaded: view_helper
INFO - 2020-06-25 13:57:42 --> Helper loaded: url_helper
INFO - 2020-06-25 13:57:42 --> Database Driver Class Initialized
INFO - 2020-06-25 13:57:42 --> Controller Class Initialized
INFO - 2020-06-25 13:57:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:57:42 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:57:42 --> The "english" language file has been loaded.
INFO - 2020-06-25 13:57:55 --> Config Class Initialized
INFO - 2020-06-25 13:57:55 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:57:55 --> Hooks Class Initialized
INFO - 2020-06-25 13:57:55 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:57:55 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:57:55 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:57:55 --> Utf8 Class Initialized
INFO - 2020-06-25 13:57:55 --> URI Class Initialized
DEBUG - 2020-06-25 13:57:55 --> No URI present. Default controller set.
INFO - 2020-06-25 13:57:55 --> Router Class Initialized
INFO - 2020-06-25 13:57:55 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:57:55 --> Output Class Initialized
INFO - 2020-06-25 13:57:55 --> Security Class Initialized
DEBUG - 2020-06-25 13:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:57:55 --> Input Class Initialized
INFO - 2020-06-25 13:57:55 --> Language Class Initialized
INFO - 2020-06-25 13:57:55 --> Loader Class Initialized
INFO - 2020-06-25 13:57:55 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:57:55 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:57:55 --> Helper loaded: data_helper
INFO - 2020-06-25 13:57:55 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:57:55 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:57:55 --> Helper loaded: view_helper
INFO - 2020-06-25 13:57:55 --> Helper loaded: url_helper
INFO - 2020-06-25 13:57:55 --> Database Driver Class Initialized
INFO - 2020-06-25 13:57:55 --> Controller Class Initialized
INFO - 2020-06-25 13:57:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:57:55 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:57:55 --> The "english" language file has been loaded.
INFO - 2020-06-25 13:59:52 --> Config Class Initialized
INFO - 2020-06-25 13:59:52 --> Plain_Config Class Initialized
INFO - 2020-06-25 13:59:52 --> Hooks Class Initialized
INFO - 2020-06-25 13:59:52 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 13:59:52 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 13:59:52 --> UTF-8 Support Disabled
INFO - 2020-06-25 13:59:52 --> Utf8 Class Initialized
INFO - 2020-06-25 13:59:52 --> URI Class Initialized
DEBUG - 2020-06-25 13:59:52 --> No URI present. Default controller set.
INFO - 2020-06-25 13:59:52 --> Router Class Initialized
INFO - 2020-06-25 13:59:52 --> Plain_Router Class Initialized
INFO - 2020-06-25 13:59:52 --> Output Class Initialized
INFO - 2020-06-25 13:59:52 --> Security Class Initialized
DEBUG - 2020-06-25 13:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 13:59:52 --> Input Class Initialized
INFO - 2020-06-25 13:59:52 --> Language Class Initialized
INFO - 2020-06-25 13:59:52 --> Loader Class Initialized
INFO - 2020-06-25 13:59:52 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 13:59:52 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 13:59:52 --> Helper loaded: data_helper
INFO - 2020-06-25 13:59:52 --> Helper loaded: hash_helper
INFO - 2020-06-25 13:59:52 --> Helper loaded: validation_helper
INFO - 2020-06-25 13:59:52 --> Helper loaded: view_helper
INFO - 2020-06-25 13:59:52 --> Helper loaded: url_helper
INFO - 2020-06-25 13:59:52 --> Database Driver Class Initialized
INFO - 2020-06-25 13:59:52 --> Controller Class Initialized
INFO - 2020-06-25 13:59:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 13:59:52 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 13:59:52 --> The "english" language file has been loaded.
INFO - 2020-06-25 14:00:13 --> Config Class Initialized
INFO - 2020-06-25 14:00:13 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:00:13 --> Hooks Class Initialized
INFO - 2020-06-25 14:00:13 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:00:13 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:00:13 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:00:13 --> Utf8 Class Initialized
INFO - 2020-06-25 14:00:13 --> URI Class Initialized
DEBUG - 2020-06-25 14:00:13 --> No URI present. Default controller set.
INFO - 2020-06-25 14:00:13 --> Router Class Initialized
INFO - 2020-06-25 14:00:13 --> Plain_Router Class Initialized
INFO - 2020-06-25 14:00:13 --> Output Class Initialized
INFO - 2020-06-25 14:00:13 --> Security Class Initialized
DEBUG - 2020-06-25 14:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 14:00:13 --> Input Class Initialized
INFO - 2020-06-25 14:00:13 --> Language Class Initialized
INFO - 2020-06-25 14:00:13 --> Loader Class Initialized
INFO - 2020-06-25 14:00:13 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 14:00:13 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 14:00:13 --> Helper loaded: data_helper
INFO - 2020-06-25 14:00:13 --> Helper loaded: hash_helper
INFO - 2020-06-25 14:00:13 --> Helper loaded: validation_helper
INFO - 2020-06-25 14:00:13 --> Helper loaded: view_helper
INFO - 2020-06-25 14:00:13 --> Helper loaded: url_helper
INFO - 2020-06-25 14:00:13 --> Database Driver Class Initialized
INFO - 2020-06-25 14:00:13 --> Controller Class Initialized
INFO - 2020-06-25 14:00:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 14:00:13 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 14:00:13 --> The "english" language file has been loaded.
ERROR - 2020-06-25 14:00:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'users' at line 1 - Invalid query: SHOW TABLES LIKE users
DEBUG - 2020-06-25 14:00:13 --> Language file loaded: language/english/db_lang.php
INFO - 2020-06-25 14:00:13 --> Plain_Exceptions Class Initialized
INFO - 2020-06-25 14:00:26 --> Config Class Initialized
INFO - 2020-06-25 14:00:26 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:00:26 --> Hooks Class Initialized
INFO - 2020-06-25 14:00:26 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:00:26 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:00:26 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:00:26 --> Utf8 Class Initialized
INFO - 2020-06-25 14:00:26 --> URI Class Initialized
DEBUG - 2020-06-25 14:00:26 --> No URI present. Default controller set.
INFO - 2020-06-25 14:00:26 --> Router Class Initialized
INFO - 2020-06-25 14:00:26 --> Plain_Router Class Initialized
INFO - 2020-06-25 14:00:26 --> Output Class Initialized
INFO - 2020-06-25 14:00:26 --> Security Class Initialized
DEBUG - 2020-06-25 14:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 14:00:26 --> Input Class Initialized
INFO - 2020-06-25 14:00:26 --> Language Class Initialized
INFO - 2020-06-25 14:00:26 --> Loader Class Initialized
INFO - 2020-06-25 14:00:26 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 14:00:26 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 14:00:26 --> Helper loaded: data_helper
INFO - 2020-06-25 14:00:26 --> Helper loaded: hash_helper
INFO - 2020-06-25 14:00:26 --> Helper loaded: validation_helper
INFO - 2020-06-25 14:00:26 --> Helper loaded: view_helper
INFO - 2020-06-25 14:00:26 --> Helper loaded: url_helper
INFO - 2020-06-25 14:00:26 --> Database Driver Class Initialized
INFO - 2020-06-25 14:00:26 --> Controller Class Initialized
INFO - 2020-06-25 14:00:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 14:00:26 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 14:00:26 --> The "english" language file has been loaded.
INFO - 2020-06-25 14:01:37 --> Config Class Initialized
INFO - 2020-06-25 14:01:37 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:01:37 --> Hooks Class Initialized
INFO - 2020-06-25 14:01:37 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:01:37 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:01:37 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:01:37 --> Utf8 Class Initialized
INFO - 2020-06-25 14:01:37 --> URI Class Initialized
DEBUG - 2020-06-25 14:01:37 --> No URI present. Default controller set.
INFO - 2020-06-25 14:01:37 --> Router Class Initialized
INFO - 2020-06-25 14:01:37 --> Plain_Router Class Initialized
INFO - 2020-06-25 14:01:37 --> Output Class Initialized
INFO - 2020-06-25 14:01:37 --> Security Class Initialized
DEBUG - 2020-06-25 14:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 14:01:37 --> Input Class Initialized
INFO - 2020-06-25 14:01:37 --> Language Class Initialized
INFO - 2020-06-25 14:01:37 --> Loader Class Initialized
INFO - 2020-06-25 14:01:37 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 14:01:37 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 14:01:37 --> Helper loaded: data_helper
INFO - 2020-06-25 14:01:37 --> Helper loaded: hash_helper
INFO - 2020-06-25 14:01:37 --> Helper loaded: validation_helper
INFO - 2020-06-25 14:01:37 --> Helper loaded: view_helper
INFO - 2020-06-25 14:01:37 --> Helper loaded: url_helper
INFO - 2020-06-25 14:01:37 --> Database Driver Class Initialized
INFO - 2020-06-25 14:01:37 --> Controller Class Initialized
INFO - 2020-06-25 14:01:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 14:01:37 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 14:01:37 --> The "english" language file has been loaded.
INFO - 2020-06-25 14:02:06 --> Config Class Initialized
INFO - 2020-06-25 14:02:06 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:02:06 --> Hooks Class Initialized
INFO - 2020-06-25 14:02:06 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:02:06 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:02:06 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:02:06 --> Utf8 Class Initialized
INFO - 2020-06-25 14:02:06 --> URI Class Initialized
DEBUG - 2020-06-25 14:02:06 --> No URI present. Default controller set.
INFO - 2020-06-25 14:02:06 --> Router Class Initialized
INFO - 2020-06-25 14:02:06 --> Plain_Router Class Initialized
INFO - 2020-06-25 14:02:06 --> Output Class Initialized
INFO - 2020-06-25 14:02:06 --> Security Class Initialized
DEBUG - 2020-06-25 14:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 14:02:06 --> Input Class Initialized
INFO - 2020-06-25 14:02:06 --> Language Class Initialized
INFO - 2020-06-25 14:02:06 --> Loader Class Initialized
INFO - 2020-06-25 14:02:06 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 14:02:06 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 14:02:06 --> Helper loaded: data_helper
INFO - 2020-06-25 14:02:06 --> Helper loaded: hash_helper
INFO - 2020-06-25 14:02:06 --> Helper loaded: validation_helper
INFO - 2020-06-25 14:02:06 --> Helper loaded: view_helper
INFO - 2020-06-25 14:02:06 --> Helper loaded: url_helper
INFO - 2020-06-25 14:02:06 --> Database Driver Class Initialized
ERROR - 2020-06-25 14:02:06 --> Unable to connect to the database
DEBUG - 2020-06-25 14:02:06 --> Language file loaded: language/english/db_lang.php
INFO - 2020-06-25 14:02:06 --> Plain_Exceptions Class Initialized
INFO - 2020-06-25 14:02:42 --> Config Class Initialized
INFO - 2020-06-25 14:02:42 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:02:42 --> Hooks Class Initialized
INFO - 2020-06-25 14:02:42 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:02:42 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:02:42 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:02:42 --> Utf8 Class Initialized
INFO - 2020-06-25 14:02:42 --> URI Class Initialized
DEBUG - 2020-06-25 14:02:42 --> No URI present. Default controller set.
INFO - 2020-06-25 14:02:42 --> Router Class Initialized
INFO - 2020-06-25 14:02:42 --> Plain_Router Class Initialized
INFO - 2020-06-25 14:02:42 --> Output Class Initialized
INFO - 2020-06-25 14:02:42 --> Security Class Initialized
DEBUG - 2020-06-25 14:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 14:02:42 --> Input Class Initialized
INFO - 2020-06-25 14:02:42 --> Language Class Initialized
INFO - 2020-06-25 14:02:42 --> Loader Class Initialized
INFO - 2020-06-25 14:02:42 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 14:02:42 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 14:02:42 --> Helper loaded: data_helper
INFO - 2020-06-25 14:02:42 --> Helper loaded: hash_helper
INFO - 2020-06-25 14:02:42 --> Helper loaded: validation_helper
INFO - 2020-06-25 14:02:42 --> Helper loaded: view_helper
INFO - 2020-06-25 14:02:42 --> Helper loaded: url_helper
INFO - 2020-06-25 14:02:42 --> Database Driver Class Initialized
INFO - 2020-06-25 14:02:42 --> Controller Class Initialized
INFO - 2020-06-25 14:02:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 14:02:42 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 14:02:42 --> The "english" language file has been loaded.
DEBUG - 2020-06-25 14:02:42 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-25 14:02:42 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-25 14:02:42 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-25 14:02:42 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-25 14:02:42 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-25 14:02:42 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-25 14:02:42 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-25 14:02:42 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-25 14:02:42 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-25 14:02:42 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-25 14:02:42 --> Final output sent to browser
DEBUG - 2020-06-25 14:02:42 --> Total execution time: 0.1835
INFO - 2020-06-25 14:02:42 --> Config Class Initialized
INFO - 2020-06-25 14:02:42 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:02:42 --> Hooks Class Initialized
INFO - 2020-06-25 14:02:42 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:02:42 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:02:42 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:02:42 --> Utf8 Class Initialized
INFO - 2020-06-25 14:02:42 --> URI Class Initialized
DEBUG - 2020-06-25 14:02:42 --> Validating request for /controllers/Custom.php
INFO - 2020-06-25 14:02:42 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-25 14:02:42 --> 404 Page Not Found: custom
INFO - 2020-06-25 14:02:51 --> Config Class Initialized
INFO - 2020-06-25 14:02:51 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:02:51 --> Hooks Class Initialized
INFO - 2020-06-25 14:02:51 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:02:51 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:02:51 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:02:51 --> Utf8 Class Initialized
INFO - 2020-06-25 14:02:51 --> URI Class Initialized
DEBUG - 2020-06-25 14:02:51 --> No URI present. Default controller set.
INFO - 2020-06-25 14:02:51 --> Router Class Initialized
INFO - 2020-06-25 14:02:51 --> Plain_Router Class Initialized
INFO - 2020-06-25 14:02:51 --> Output Class Initialized
INFO - 2020-06-25 14:02:51 --> Security Class Initialized
DEBUG - 2020-06-25 14:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 14:02:51 --> Input Class Initialized
INFO - 2020-06-25 14:02:51 --> Language Class Initialized
INFO - 2020-06-25 14:02:51 --> Loader Class Initialized
INFO - 2020-06-25 14:02:51 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 14:02:51 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 14:02:51 --> Helper loaded: data_helper
INFO - 2020-06-25 14:02:51 --> Helper loaded: hash_helper
INFO - 2020-06-25 14:02:51 --> Helper loaded: validation_helper
INFO - 2020-06-25 14:02:51 --> Helper loaded: view_helper
INFO - 2020-06-25 14:02:51 --> Helper loaded: url_helper
INFO - 2020-06-25 14:02:51 --> Database Driver Class Initialized
INFO - 2020-06-25 14:02:51 --> Controller Class Initialized
INFO - 2020-06-25 14:02:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 14:02:51 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 14:02:51 --> The "english" language file has been loaded.
DEBUG - 2020-06-25 14:02:51 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-25 14:02:51 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-25 14:02:51 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-25 14:02:51 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-25 14:02:51 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-25 14:02:51 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-25 14:02:51 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-25 14:02:51 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-25 14:02:51 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-25 14:02:51 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-25 14:02:51 --> Final output sent to browser
DEBUG - 2020-06-25 14:02:51 --> Total execution time: 0.1811
INFO - 2020-06-25 14:02:51 --> Config Class Initialized
INFO - 2020-06-25 14:02:51 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:02:51 --> Hooks Class Initialized
INFO - 2020-06-25 14:02:51 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:02:51 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:02:51 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:02:51 --> Utf8 Class Initialized
INFO - 2020-06-25 14:02:51 --> URI Class Initialized
DEBUG - 2020-06-25 14:02:51 --> Validating request for /controllers/Custom.php
INFO - 2020-06-25 14:02:51 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-25 14:02:51 --> 404 Page Not Found: custom
INFO - 2020-06-25 14:02:52 --> Config Class Initialized
INFO - 2020-06-25 14:02:52 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:02:52 --> Hooks Class Initialized
INFO - 2020-06-25 14:02:52 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:02:52 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:02:52 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:02:52 --> Utf8 Class Initialized
INFO - 2020-06-25 14:02:52 --> URI Class Initialized
DEBUG - 2020-06-25 14:02:52 --> No URI present. Default controller set.
INFO - 2020-06-25 14:02:52 --> Router Class Initialized
INFO - 2020-06-25 14:02:52 --> Plain_Router Class Initialized
INFO - 2020-06-25 14:02:52 --> Output Class Initialized
INFO - 2020-06-25 14:02:52 --> Security Class Initialized
DEBUG - 2020-06-25 14:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 14:02:52 --> Input Class Initialized
INFO - 2020-06-25 14:02:52 --> Language Class Initialized
INFO - 2020-06-25 14:02:52 --> Loader Class Initialized
INFO - 2020-06-25 14:02:52 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 14:02:52 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 14:02:52 --> Helper loaded: data_helper
INFO - 2020-06-25 14:02:52 --> Helper loaded: hash_helper
INFO - 2020-06-25 14:02:52 --> Helper loaded: validation_helper
INFO - 2020-06-25 14:02:52 --> Helper loaded: view_helper
INFO - 2020-06-25 14:02:52 --> Helper loaded: url_helper
INFO - 2020-06-25 14:02:52 --> Database Driver Class Initialized
INFO - 2020-06-25 14:02:52 --> Controller Class Initialized
INFO - 2020-06-25 14:02:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 14:02:52 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 14:02:52 --> The "english" language file has been loaded.
DEBUG - 2020-06-25 14:02:52 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-25 14:02:52 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-25 14:02:52 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-25 14:02:52 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-25 14:02:52 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-25 14:02:52 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-25 14:02:52 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-25 14:02:52 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-25 14:02:52 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-25 14:02:52 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-25 14:02:52 --> Final output sent to browser
DEBUG - 2020-06-25 14:02:52 --> Total execution time: 0.2138
INFO - 2020-06-25 14:02:53 --> Config Class Initialized
INFO - 2020-06-25 14:02:53 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:02:53 --> Hooks Class Initialized
INFO - 2020-06-25 14:02:53 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:02:53 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:02:53 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:02:53 --> Utf8 Class Initialized
INFO - 2020-06-25 14:02:53 --> URI Class Initialized
DEBUG - 2020-06-25 14:02:53 --> Validating request for /controllers/Custom.php
INFO - 2020-06-25 14:02:53 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-25 14:02:53 --> 404 Page Not Found: custom
INFO - 2020-06-25 14:02:59 --> Config Class Initialized
INFO - 2020-06-25 14:02:59 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:02:59 --> Hooks Class Initialized
INFO - 2020-06-25 14:02:59 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:02:59 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:02:59 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:02:59 --> Utf8 Class Initialized
INFO - 2020-06-25 14:02:59 --> URI Class Initialized
DEBUG - 2020-06-25 14:02:59 --> No URI present. Default controller set.
INFO - 2020-06-25 14:02:59 --> Router Class Initialized
INFO - 2020-06-25 14:02:59 --> Plain_Router Class Initialized
INFO - 2020-06-25 14:02:59 --> Output Class Initialized
INFO - 2020-06-25 14:02:59 --> Security Class Initialized
DEBUG - 2020-06-25 14:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 14:02:59 --> Input Class Initialized
INFO - 2020-06-25 14:02:59 --> Language Class Initialized
INFO - 2020-06-25 14:02:59 --> Loader Class Initialized
INFO - 2020-06-25 14:02:59 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 14:02:59 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 14:02:59 --> Helper loaded: data_helper
INFO - 2020-06-25 14:02:59 --> Helper loaded: hash_helper
INFO - 2020-06-25 14:02:59 --> Helper loaded: validation_helper
INFO - 2020-06-25 14:02:59 --> Helper loaded: view_helper
INFO - 2020-06-25 14:02:59 --> Helper loaded: url_helper
INFO - 2020-06-25 14:02:59 --> Database Driver Class Initialized
INFO - 2020-06-25 14:02:59 --> Controller Class Initialized
INFO - 2020-06-25 14:02:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 14:02:59 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 14:02:59 --> The "english" language file has been loaded.
DEBUG - 2020-06-25 14:02:59 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-25 14:02:59 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-25 14:02:59 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-25 14:02:59 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-25 14:02:59 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-25 14:02:59 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-25 14:02:59 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-25 14:02:59 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-25 14:02:59 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-25 14:02:59 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-25 14:02:59 --> Final output sent to browser
DEBUG - 2020-06-25 14:02:59 --> Total execution time: 0.2339
INFO - 2020-06-25 14:02:59 --> Config Class Initialized
INFO - 2020-06-25 14:02:59 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:02:59 --> Hooks Class Initialized
INFO - 2020-06-25 14:02:59 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:02:59 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:02:59 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:02:59 --> Utf8 Class Initialized
INFO - 2020-06-25 14:02:59 --> URI Class Initialized
DEBUG - 2020-06-25 14:02:59 --> Validating request for /controllers/Custom.php
INFO - 2020-06-25 14:03:00 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-25 14:03:00 --> 404 Page Not Found: custom
INFO - 2020-06-25 14:03:06 --> Config Class Initialized
INFO - 2020-06-25 14:03:06 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:03:06 --> Hooks Class Initialized
INFO - 2020-06-25 14:03:06 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:03:06 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:03:06 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:03:06 --> Utf8 Class Initialized
INFO - 2020-06-25 14:03:06 --> URI Class Initialized
DEBUG - 2020-06-25 14:03:06 --> No URI present. Default controller set.
INFO - 2020-06-25 14:03:06 --> Router Class Initialized
INFO - 2020-06-25 14:03:06 --> Plain_Router Class Initialized
INFO - 2020-06-25 14:03:06 --> Output Class Initialized
INFO - 2020-06-25 14:03:06 --> Security Class Initialized
DEBUG - 2020-06-25 14:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 14:03:06 --> Input Class Initialized
INFO - 2020-06-25 14:03:06 --> Language Class Initialized
INFO - 2020-06-25 14:03:06 --> Loader Class Initialized
INFO - 2020-06-25 14:03:06 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 14:03:06 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 14:03:06 --> Helper loaded: data_helper
INFO - 2020-06-25 14:03:06 --> Helper loaded: hash_helper
INFO - 2020-06-25 14:03:06 --> Helper loaded: validation_helper
INFO - 2020-06-25 14:03:06 --> Helper loaded: view_helper
INFO - 2020-06-25 14:03:06 --> Helper loaded: url_helper
INFO - 2020-06-25 14:03:06 --> Database Driver Class Initialized
INFO - 2020-06-25 14:03:06 --> Controller Class Initialized
INFO - 2020-06-25 14:03:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 14:03:06 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 14:03:06 --> The "english" language file has been loaded.
DEBUG - 2020-06-25 14:03:06 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-25 14:03:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-25 14:03:06 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-25 14:03:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-25 14:03:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-25 14:03:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-25 14:03:06 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-25 14:03:06 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-25 14:03:06 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-25 14:03:06 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-25 14:03:06 --> Final output sent to browser
DEBUG - 2020-06-25 14:03:06 --> Total execution time: 0.2225
INFO - 2020-06-25 14:03:07 --> Config Class Initialized
INFO - 2020-06-25 14:03:07 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:03:07 --> Hooks Class Initialized
INFO - 2020-06-25 14:03:07 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:03:07 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:03:07 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:03:07 --> Utf8 Class Initialized
INFO - 2020-06-25 14:03:07 --> URI Class Initialized
DEBUG - 2020-06-25 14:03:07 --> Validating request for /controllers/Custom.php
INFO - 2020-06-25 14:03:07 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-25 14:03:07 --> 404 Page Not Found: custom
INFO - 2020-06-25 14:03:32 --> Config Class Initialized
INFO - 2020-06-25 14:03:32 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:03:32 --> Hooks Class Initialized
INFO - 2020-06-25 14:03:32 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:03:32 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:03:32 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:03:32 --> Utf8 Class Initialized
INFO - 2020-06-25 14:03:32 --> URI Class Initialized
DEBUG - 2020-06-25 14:03:32 --> No URI present. Default controller set.
INFO - 2020-06-25 14:03:32 --> Router Class Initialized
INFO - 2020-06-25 14:03:32 --> Plain_Router Class Initialized
INFO - 2020-06-25 14:03:32 --> Output Class Initialized
INFO - 2020-06-25 14:03:32 --> Security Class Initialized
DEBUG - 2020-06-25 14:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 14:03:32 --> Input Class Initialized
INFO - 2020-06-25 14:03:32 --> Language Class Initialized
INFO - 2020-06-25 14:03:32 --> Loader Class Initialized
INFO - 2020-06-25 14:03:32 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 14:03:32 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 14:03:32 --> Helper loaded: data_helper
INFO - 2020-06-25 14:03:32 --> Helper loaded: hash_helper
INFO - 2020-06-25 14:03:32 --> Helper loaded: validation_helper
INFO - 2020-06-25 14:03:32 --> Helper loaded: view_helper
INFO - 2020-06-25 14:03:32 --> Helper loaded: url_helper
INFO - 2020-06-25 14:03:32 --> Database Driver Class Initialized
INFO - 2020-06-25 14:03:32 --> Controller Class Initialized
INFO - 2020-06-25 14:03:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 14:03:32 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 14:03:32 --> The "english" language file has been loaded.
INFO - 2020-06-25 14:03:34 --> Config Class Initialized
INFO - 2020-06-25 14:03:34 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:03:34 --> Hooks Class Initialized
INFO - 2020-06-25 14:03:34 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:03:34 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:03:34 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:03:34 --> Utf8 Class Initialized
INFO - 2020-06-25 14:03:34 --> URI Class Initialized
DEBUG - 2020-06-25 14:03:34 --> No URI present. Default controller set.
INFO - 2020-06-25 14:03:34 --> Router Class Initialized
INFO - 2020-06-25 14:03:34 --> Plain_Router Class Initialized
INFO - 2020-06-25 14:03:34 --> Output Class Initialized
INFO - 2020-06-25 14:03:34 --> Security Class Initialized
DEBUG - 2020-06-25 14:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 14:03:34 --> Input Class Initialized
INFO - 2020-06-25 14:03:34 --> Language Class Initialized
INFO - 2020-06-25 14:03:34 --> Loader Class Initialized
INFO - 2020-06-25 14:03:34 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 14:03:34 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 14:03:34 --> Helper loaded: data_helper
INFO - 2020-06-25 14:03:34 --> Helper loaded: hash_helper
INFO - 2020-06-25 14:03:34 --> Helper loaded: validation_helper
INFO - 2020-06-25 14:03:34 --> Helper loaded: view_helper
INFO - 2020-06-25 14:03:34 --> Helper loaded: url_helper
INFO - 2020-06-25 14:03:34 --> Database Driver Class Initialized
INFO - 2020-06-25 14:03:34 --> Controller Class Initialized
INFO - 2020-06-25 14:03:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 14:03:34 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 14:03:34 --> The "english" language file has been loaded.
INFO - 2020-06-25 14:07:07 --> Config Class Initialized
INFO - 2020-06-25 14:07:07 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:07:07 --> Hooks Class Initialized
INFO - 2020-06-25 14:07:07 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:07:07 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:07:07 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:07:07 --> Utf8 Class Initialized
INFO - 2020-06-25 14:07:07 --> URI Class Initialized
DEBUG - 2020-06-25 14:07:07 --> No URI present. Default controller set.
INFO - 2020-06-25 14:07:07 --> Router Class Initialized
INFO - 2020-06-25 14:07:07 --> Plain_Router Class Initialized
INFO - 2020-06-25 14:07:07 --> Output Class Initialized
INFO - 2020-06-25 14:07:07 --> Security Class Initialized
DEBUG - 2020-06-25 14:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 14:07:07 --> Input Class Initialized
INFO - 2020-06-25 14:07:07 --> Language Class Initialized
INFO - 2020-06-25 14:07:07 --> Loader Class Initialized
INFO - 2020-06-25 14:07:07 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 14:07:07 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 14:07:07 --> Helper loaded: data_helper
INFO - 2020-06-25 14:07:07 --> Helper loaded: hash_helper
INFO - 2020-06-25 14:07:07 --> Helper loaded: validation_helper
INFO - 2020-06-25 14:07:07 --> Helper loaded: view_helper
INFO - 2020-06-25 14:07:07 --> Helper loaded: url_helper
INFO - 2020-06-25 14:07:07 --> Database Driver Class Initialized
INFO - 2020-06-25 14:07:07 --> Controller Class Initialized
INFO - 2020-06-25 14:07:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-25 14:07:07 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-25 14:07:07 --> The "english" language file has been loaded.
INFO - 2020-06-25 14:07:07 --> Config Class Initialized
INFO - 2020-06-25 14:07:07 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:07:07 --> Hooks Class Initialized
INFO - 2020-06-25 14:07:07 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:07:07 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:07:07 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:07:07 --> Utf8 Class Initialized
INFO - 2020-06-25 14:07:07 --> URI Class Initialized
DEBUG - 2020-06-25 14:07:07 --> Validating request for /controllers/Install.php
INFO - 2020-06-25 14:07:07 --> Router Class Initialized
INFO - 2020-06-25 14:07:07 --> Plain_Router Class Initialized
INFO - 2020-06-25 14:07:07 --> Output Class Initialized
INFO - 2020-06-25 14:07:07 --> Security Class Initialized
DEBUG - 2020-06-25 14:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-25 14:07:07 --> Input Class Initialized
INFO - 2020-06-25 14:07:07 --> Language Class Initialized
INFO - 2020-06-25 14:07:07 --> Loader Class Initialized
INFO - 2020-06-25 14:07:07 --> Plain_Loader Class Initialized
DEBUG - 2020-06-25 14:07:07 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-25 14:07:07 --> Helper loaded: data_helper
INFO - 2020-06-25 14:07:07 --> Helper loaded: hash_helper
INFO - 2020-06-25 14:07:07 --> Helper loaded: validation_helper
INFO - 2020-06-25 14:07:07 --> Helper loaded: view_helper
INFO - 2020-06-25 14:07:07 --> Helper loaded: url_helper
INFO - 2020-06-25 14:07:07 --> Database Driver Class Initialized
INFO - 2020-06-25 14:07:07 --> Controller Class Initialized
DEBUG - 2020-06-25 14:07:07 --> The "english" language file has been loaded.
DEBUG - 2020-06-25 14:07:07 --> The phrase "Unmark: Setup" could not be found in the language file.
DEBUG - 2020-06-25 14:07:07 --> The phrase "Welcome to Unmark, the to-do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-25 14:07:07 --> The phrase "You're about to install version 2020.1 of the app.</p><p>Please <a href="https://github.com/plainmade/unmark/blob/master/readme.md">read the installation instructions</a> first." could not be found in the language file.
DEBUG - 2020-06-25 14:07:07 --> The phrase "Click to Install" could not be found in the language file.
INFO - 2020-06-25 14:07:07 --> File loaded: /var/www/html/application/views/setup.php
INFO - 2020-06-25 14:07:07 --> Final output sent to browser
DEBUG - 2020-06-25 14:07:07 --> Total execution time: 0.1118
INFO - 2020-06-25 14:07:07 --> Config Class Initialized
INFO - 2020-06-25 14:07:07 --> Plain_Config Class Initialized
INFO - 2020-06-25 14:07:07 --> Hooks Class Initialized
INFO - 2020-06-25 14:07:07 --> Plain_Hooks Class Constructed
INFO - 2020-06-25 14:07:07 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-25 14:07:07 --> UTF-8 Support Disabled
INFO - 2020-06-25 14:07:07 --> Utf8 Class Initialized
INFO - 2020-06-25 14:07:07 --> URI Class Initialized
DEBUG - 2020-06-25 14:07:07 --> Validating request for /controllers/Custom.php
INFO - 2020-06-25 14:07:07 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-25 14:07:07 --> 404 Page Not Found: custom
