<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-06-24 12:32:48 --> Config Class Initialized
INFO - 2020-06-24 12:32:48 --> Plain_Config Class Initialized
INFO - 2020-06-24 12:32:48 --> Hooks Class Initialized
INFO - 2020-06-24 12:32:48 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 12:32:48 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 12:32:48 --> UTF-8 Support Disabled
INFO - 2020-06-24 12:32:48 --> Utf8 Class Initialized
INFO - 2020-06-24 12:32:48 --> URI Class Initialized
DEBUG - 2020-06-24 12:32:48 --> No URI present. Default controller set.
INFO - 2020-06-24 12:32:48 --> Router Class Initialized
INFO - 2020-06-24 12:32:48 --> Plain_Router Class Initialized
INFO - 2020-06-24 12:32:48 --> Output Class Initialized
INFO - 2020-06-24 12:32:48 --> Security Class Initialized
DEBUG - 2020-06-24 12:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 12:32:48 --> Input Class Initialized
INFO - 2020-06-24 12:32:48 --> Language Class Initialized
INFO - 2020-06-24 12:32:48 --> Loader Class Initialized
INFO - 2020-06-24 12:32:48 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 12:32:48 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 12:32:48 --> Helper loaded: data_helper
INFO - 2020-06-24 12:32:48 --> Helper loaded: hash_helper
INFO - 2020-06-24 12:32:48 --> Helper loaded: validation_helper
INFO - 2020-06-24 12:32:48 --> Helper loaded: view_helper
INFO - 2020-06-24 12:32:48 --> Helper loaded: url_helper
INFO - 2020-06-24 12:32:48 --> Database Driver Class Initialized
INFO - 2020-06-24 12:32:48 --> Controller Class Initialized
INFO - 2020-06-24 12:32:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 12:32:48 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 12:32:48 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 12:32:48 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 12:32:48 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 12:32:48 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 12:32:48 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 12:32:48 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 12:32:48 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 12:32:48 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 12:32:48 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 12:32:48 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 12:32:48 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 12:32:48 --> Final output sent to browser
DEBUG - 2020-06-24 12:32:48 --> Total execution time: 0.2571
INFO - 2020-06-24 12:37:48 --> Config Class Initialized
INFO - 2020-06-24 12:37:48 --> Plain_Config Class Initialized
INFO - 2020-06-24 12:37:48 --> Hooks Class Initialized
INFO - 2020-06-24 12:37:48 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 12:37:48 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 12:37:48 --> UTF-8 Support Disabled
INFO - 2020-06-24 12:37:48 --> Utf8 Class Initialized
INFO - 2020-06-24 12:37:48 --> URI Class Initialized
DEBUG - 2020-06-24 12:37:48 --> No URI present. Default controller set.
INFO - 2020-06-24 12:37:48 --> Router Class Initialized
INFO - 2020-06-24 12:37:48 --> Plain_Router Class Initialized
INFO - 2020-06-24 12:37:48 --> Output Class Initialized
INFO - 2020-06-24 12:37:48 --> Security Class Initialized
DEBUG - 2020-06-24 12:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 12:37:48 --> Input Class Initialized
INFO - 2020-06-24 12:37:48 --> Language Class Initialized
INFO - 2020-06-24 12:37:48 --> Loader Class Initialized
INFO - 2020-06-24 12:37:48 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 12:37:48 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 12:37:48 --> Helper loaded: data_helper
INFO - 2020-06-24 12:37:48 --> Helper loaded: hash_helper
INFO - 2020-06-24 12:37:48 --> Helper loaded: validation_helper
INFO - 2020-06-24 12:37:48 --> Helper loaded: view_helper
INFO - 2020-06-24 12:37:48 --> Helper loaded: url_helper
INFO - 2020-06-24 12:37:48 --> Database Driver Class Initialized
INFO - 2020-06-24 12:37:48 --> Controller Class Initialized
INFO - 2020-06-24 12:37:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 12:37:48 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 12:37:48 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 12:37:49 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 12:37:49 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 12:37:49 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 12:37:49 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 12:37:49 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 12:37:49 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 12:37:49 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 12:37:49 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 12:37:49 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 12:37:49 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 12:37:49 --> Final output sent to browser
DEBUG - 2020-06-24 12:37:49 --> Total execution time: 0.1908
INFO - 2020-06-24 12:42:49 --> Config Class Initialized
INFO - 2020-06-24 12:42:49 --> Plain_Config Class Initialized
INFO - 2020-06-24 12:42:49 --> Hooks Class Initialized
INFO - 2020-06-24 12:42:49 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 12:42:49 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 12:42:49 --> UTF-8 Support Disabled
INFO - 2020-06-24 12:42:49 --> Utf8 Class Initialized
INFO - 2020-06-24 12:42:49 --> URI Class Initialized
DEBUG - 2020-06-24 12:42:49 --> No URI present. Default controller set.
INFO - 2020-06-24 12:42:49 --> Router Class Initialized
INFO - 2020-06-24 12:42:49 --> Plain_Router Class Initialized
INFO - 2020-06-24 12:42:49 --> Output Class Initialized
INFO - 2020-06-24 12:42:49 --> Security Class Initialized
DEBUG - 2020-06-24 12:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 12:42:49 --> Input Class Initialized
INFO - 2020-06-24 12:42:49 --> Language Class Initialized
INFO - 2020-06-24 12:42:49 --> Loader Class Initialized
INFO - 2020-06-24 12:42:49 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 12:42:49 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 12:42:49 --> Helper loaded: data_helper
INFO - 2020-06-24 12:42:49 --> Helper loaded: hash_helper
INFO - 2020-06-24 12:42:49 --> Helper loaded: validation_helper
INFO - 2020-06-24 12:42:49 --> Helper loaded: view_helper
INFO - 2020-06-24 12:42:49 --> Helper loaded: url_helper
INFO - 2020-06-24 12:42:49 --> Database Driver Class Initialized
INFO - 2020-06-24 12:42:49 --> Controller Class Initialized
INFO - 2020-06-24 12:42:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 12:42:49 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 12:42:49 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 12:42:49 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 12:42:49 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 12:42:49 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 12:42:49 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 12:42:49 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 12:42:49 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 12:42:49 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 12:42:49 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 12:42:49 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 12:42:49 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 12:42:49 --> Final output sent to browser
DEBUG - 2020-06-24 12:42:49 --> Total execution time: 0.1699
INFO - 2020-06-24 12:47:49 --> Config Class Initialized
INFO - 2020-06-24 12:47:49 --> Plain_Config Class Initialized
INFO - 2020-06-24 12:47:49 --> Hooks Class Initialized
INFO - 2020-06-24 12:47:49 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 12:47:49 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 12:47:49 --> UTF-8 Support Disabled
INFO - 2020-06-24 12:47:49 --> Utf8 Class Initialized
INFO - 2020-06-24 12:47:49 --> URI Class Initialized
DEBUG - 2020-06-24 12:47:49 --> No URI present. Default controller set.
INFO - 2020-06-24 12:47:49 --> Router Class Initialized
INFO - 2020-06-24 12:47:49 --> Plain_Router Class Initialized
INFO - 2020-06-24 12:47:49 --> Output Class Initialized
INFO - 2020-06-24 12:47:49 --> Security Class Initialized
DEBUG - 2020-06-24 12:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 12:47:49 --> Input Class Initialized
INFO - 2020-06-24 12:47:49 --> Language Class Initialized
INFO - 2020-06-24 12:47:49 --> Loader Class Initialized
INFO - 2020-06-24 12:47:49 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 12:47:49 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 12:47:49 --> Helper loaded: data_helper
INFO - 2020-06-24 12:47:49 --> Helper loaded: hash_helper
INFO - 2020-06-24 12:47:49 --> Helper loaded: validation_helper
INFO - 2020-06-24 12:47:49 --> Helper loaded: view_helper
INFO - 2020-06-24 12:47:49 --> Helper loaded: url_helper
INFO - 2020-06-24 12:47:49 --> Database Driver Class Initialized
INFO - 2020-06-24 12:47:49 --> Controller Class Initialized
INFO - 2020-06-24 12:47:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 12:47:49 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 12:47:49 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 12:47:49 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 12:47:49 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 12:47:49 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 12:47:49 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 12:47:49 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 12:47:49 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 12:47:49 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 12:47:49 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 12:47:49 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 12:47:49 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 12:47:49 --> Final output sent to browser
DEBUG - 2020-06-24 12:47:49 --> Total execution time: 0.1674
INFO - 2020-06-24 12:52:50 --> Config Class Initialized
INFO - 2020-06-24 12:52:50 --> Plain_Config Class Initialized
INFO - 2020-06-24 12:52:50 --> Hooks Class Initialized
INFO - 2020-06-24 12:52:50 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 12:52:50 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 12:52:50 --> UTF-8 Support Disabled
INFO - 2020-06-24 12:52:50 --> Utf8 Class Initialized
INFO - 2020-06-24 12:52:50 --> URI Class Initialized
DEBUG - 2020-06-24 12:52:50 --> No URI present. Default controller set.
INFO - 2020-06-24 12:52:50 --> Router Class Initialized
INFO - 2020-06-24 12:52:50 --> Plain_Router Class Initialized
INFO - 2020-06-24 12:52:50 --> Output Class Initialized
INFO - 2020-06-24 12:52:50 --> Security Class Initialized
DEBUG - 2020-06-24 12:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 12:52:50 --> Input Class Initialized
INFO - 2020-06-24 12:52:50 --> Language Class Initialized
INFO - 2020-06-24 12:52:50 --> Loader Class Initialized
INFO - 2020-06-24 12:52:50 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 12:52:50 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 12:52:50 --> Helper loaded: data_helper
INFO - 2020-06-24 12:52:50 --> Helper loaded: hash_helper
INFO - 2020-06-24 12:52:50 --> Helper loaded: validation_helper
INFO - 2020-06-24 12:52:50 --> Helper loaded: view_helper
INFO - 2020-06-24 12:52:50 --> Helper loaded: url_helper
INFO - 2020-06-24 12:52:50 --> Database Driver Class Initialized
INFO - 2020-06-24 12:52:50 --> Controller Class Initialized
INFO - 2020-06-24 12:52:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 12:52:50 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 12:52:50 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 12:52:50 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 12:52:50 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 12:52:50 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 12:52:50 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 12:52:50 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 12:52:50 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 12:52:50 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 12:52:50 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 12:52:50 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 12:52:50 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 12:52:50 --> Final output sent to browser
DEBUG - 2020-06-24 12:52:50 --> Total execution time: 0.1748
INFO - 2020-06-24 12:57:50 --> Config Class Initialized
INFO - 2020-06-24 12:57:50 --> Plain_Config Class Initialized
INFO - 2020-06-24 12:57:50 --> Hooks Class Initialized
INFO - 2020-06-24 12:57:50 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 12:57:50 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 12:57:50 --> UTF-8 Support Disabled
INFO - 2020-06-24 12:57:50 --> Utf8 Class Initialized
INFO - 2020-06-24 12:57:50 --> URI Class Initialized
DEBUG - 2020-06-24 12:57:50 --> No URI present. Default controller set.
INFO - 2020-06-24 12:57:50 --> Router Class Initialized
INFO - 2020-06-24 12:57:50 --> Plain_Router Class Initialized
INFO - 2020-06-24 12:57:50 --> Output Class Initialized
INFO - 2020-06-24 12:57:50 --> Security Class Initialized
DEBUG - 2020-06-24 12:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 12:57:50 --> Input Class Initialized
INFO - 2020-06-24 12:57:50 --> Language Class Initialized
INFO - 2020-06-24 12:57:50 --> Loader Class Initialized
INFO - 2020-06-24 12:57:50 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 12:57:50 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 12:57:50 --> Helper loaded: data_helper
INFO - 2020-06-24 12:57:50 --> Helper loaded: hash_helper
INFO - 2020-06-24 12:57:50 --> Helper loaded: validation_helper
INFO - 2020-06-24 12:57:50 --> Helper loaded: view_helper
INFO - 2020-06-24 12:57:50 --> Helper loaded: url_helper
INFO - 2020-06-24 12:57:50 --> Database Driver Class Initialized
INFO - 2020-06-24 12:57:50 --> Controller Class Initialized
INFO - 2020-06-24 12:57:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 12:57:50 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 12:57:50 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 12:57:50 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 12:57:50 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 12:57:50 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 12:57:50 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 12:57:50 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 12:57:50 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 12:57:50 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 12:57:50 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 12:57:50 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 12:57:50 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 12:57:50 --> Final output sent to browser
DEBUG - 2020-06-24 12:57:50 --> Total execution time: 0.1642
INFO - 2020-06-24 13:02:51 --> Config Class Initialized
INFO - 2020-06-24 13:02:51 --> Plain_Config Class Initialized
INFO - 2020-06-24 13:02:51 --> Hooks Class Initialized
INFO - 2020-06-24 13:02:51 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 13:02:51 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 13:02:51 --> UTF-8 Support Disabled
INFO - 2020-06-24 13:02:51 --> Utf8 Class Initialized
INFO - 2020-06-24 13:02:51 --> URI Class Initialized
DEBUG - 2020-06-24 13:02:51 --> No URI present. Default controller set.
INFO - 2020-06-24 13:02:51 --> Router Class Initialized
INFO - 2020-06-24 13:02:51 --> Plain_Router Class Initialized
INFO - 2020-06-24 13:02:51 --> Output Class Initialized
INFO - 2020-06-24 13:02:51 --> Security Class Initialized
DEBUG - 2020-06-24 13:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 13:02:51 --> Input Class Initialized
INFO - 2020-06-24 13:02:51 --> Language Class Initialized
INFO - 2020-06-24 13:02:51 --> Loader Class Initialized
INFO - 2020-06-24 13:02:51 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 13:02:51 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 13:02:51 --> Helper loaded: data_helper
INFO - 2020-06-24 13:02:51 --> Helper loaded: hash_helper
INFO - 2020-06-24 13:02:51 --> Helper loaded: validation_helper
INFO - 2020-06-24 13:02:51 --> Helper loaded: view_helper
INFO - 2020-06-24 13:02:51 --> Helper loaded: url_helper
INFO - 2020-06-24 13:02:52 --> Database Driver Class Initialized
INFO - 2020-06-24 13:02:52 --> Controller Class Initialized
INFO - 2020-06-24 13:02:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 13:02:52 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 13:02:52 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 13:02:52 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 13:02:52 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:02:52 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 13:02:52 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:02:52 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:02:52 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:02:52 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 13:02:52 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 13:02:52 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 13:02:52 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 13:02:52 --> Final output sent to browser
DEBUG - 2020-06-24 13:02:52 --> Total execution time: 0.1741
INFO - 2020-06-24 13:07:52 --> Config Class Initialized
INFO - 2020-06-24 13:07:52 --> Plain_Config Class Initialized
INFO - 2020-06-24 13:07:52 --> Hooks Class Initialized
INFO - 2020-06-24 13:07:52 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 13:07:52 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 13:07:52 --> UTF-8 Support Disabled
INFO - 2020-06-24 13:07:52 --> Utf8 Class Initialized
INFO - 2020-06-24 13:07:52 --> URI Class Initialized
DEBUG - 2020-06-24 13:07:52 --> No URI present. Default controller set.
INFO - 2020-06-24 13:07:52 --> Router Class Initialized
INFO - 2020-06-24 13:07:52 --> Plain_Router Class Initialized
INFO - 2020-06-24 13:07:52 --> Output Class Initialized
INFO - 2020-06-24 13:07:52 --> Security Class Initialized
DEBUG - 2020-06-24 13:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 13:07:52 --> Input Class Initialized
INFO - 2020-06-24 13:07:52 --> Language Class Initialized
INFO - 2020-06-24 13:07:52 --> Loader Class Initialized
INFO - 2020-06-24 13:07:52 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 13:07:52 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 13:07:52 --> Helper loaded: data_helper
INFO - 2020-06-24 13:07:52 --> Helper loaded: hash_helper
INFO - 2020-06-24 13:07:52 --> Helper loaded: validation_helper
INFO - 2020-06-24 13:07:52 --> Helper loaded: view_helper
INFO - 2020-06-24 13:07:52 --> Helper loaded: url_helper
INFO - 2020-06-24 13:07:52 --> Database Driver Class Initialized
INFO - 2020-06-24 13:07:52 --> Controller Class Initialized
INFO - 2020-06-24 13:07:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 13:07:52 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 13:07:52 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 13:07:52 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 13:07:52 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:07:52 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 13:07:52 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:07:52 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:07:52 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:07:52 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 13:07:52 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 13:07:52 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 13:07:52 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 13:07:52 --> Final output sent to browser
DEBUG - 2020-06-24 13:07:52 --> Total execution time: 0.1713
INFO - 2020-06-24 13:12:53 --> Config Class Initialized
INFO - 2020-06-24 13:12:53 --> Plain_Config Class Initialized
INFO - 2020-06-24 13:12:53 --> Hooks Class Initialized
INFO - 2020-06-24 13:12:53 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 13:12:53 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 13:12:53 --> UTF-8 Support Disabled
INFO - 2020-06-24 13:12:53 --> Utf8 Class Initialized
INFO - 2020-06-24 13:12:53 --> URI Class Initialized
DEBUG - 2020-06-24 13:12:53 --> No URI present. Default controller set.
INFO - 2020-06-24 13:12:53 --> Router Class Initialized
INFO - 2020-06-24 13:12:53 --> Plain_Router Class Initialized
INFO - 2020-06-24 13:12:53 --> Output Class Initialized
INFO - 2020-06-24 13:12:53 --> Security Class Initialized
DEBUG - 2020-06-24 13:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 13:12:53 --> Input Class Initialized
INFO - 2020-06-24 13:12:53 --> Language Class Initialized
INFO - 2020-06-24 13:12:53 --> Loader Class Initialized
INFO - 2020-06-24 13:12:53 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 13:12:53 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 13:12:53 --> Helper loaded: data_helper
INFO - 2020-06-24 13:12:53 --> Helper loaded: hash_helper
INFO - 2020-06-24 13:12:53 --> Helper loaded: validation_helper
INFO - 2020-06-24 13:12:53 --> Helper loaded: view_helper
INFO - 2020-06-24 13:12:53 --> Helper loaded: url_helper
INFO - 2020-06-24 13:12:53 --> Database Driver Class Initialized
INFO - 2020-06-24 13:12:53 --> Controller Class Initialized
INFO - 2020-06-24 13:12:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 13:12:53 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 13:12:53 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 13:12:53 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 13:12:53 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:12:53 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 13:12:53 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:12:53 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:12:53 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:12:53 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 13:12:53 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 13:12:53 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 13:12:53 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 13:12:53 --> Final output sent to browser
DEBUG - 2020-06-24 13:12:53 --> Total execution time: 0.1850
INFO - 2020-06-24 13:17:53 --> Config Class Initialized
INFO - 2020-06-24 13:17:53 --> Plain_Config Class Initialized
INFO - 2020-06-24 13:17:53 --> Hooks Class Initialized
INFO - 2020-06-24 13:17:53 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 13:17:53 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 13:17:53 --> UTF-8 Support Disabled
INFO - 2020-06-24 13:17:53 --> Utf8 Class Initialized
INFO - 2020-06-24 13:17:53 --> URI Class Initialized
DEBUG - 2020-06-24 13:17:53 --> No URI present. Default controller set.
INFO - 2020-06-24 13:17:53 --> Router Class Initialized
INFO - 2020-06-24 13:17:53 --> Plain_Router Class Initialized
INFO - 2020-06-24 13:17:53 --> Output Class Initialized
INFO - 2020-06-24 13:17:53 --> Security Class Initialized
DEBUG - 2020-06-24 13:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 13:17:53 --> Input Class Initialized
INFO - 2020-06-24 13:17:53 --> Language Class Initialized
INFO - 2020-06-24 13:17:53 --> Loader Class Initialized
INFO - 2020-06-24 13:17:53 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 13:17:53 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 13:17:53 --> Helper loaded: data_helper
INFO - 2020-06-24 13:17:53 --> Helper loaded: hash_helper
INFO - 2020-06-24 13:17:53 --> Helper loaded: validation_helper
INFO - 2020-06-24 13:17:53 --> Helper loaded: view_helper
INFO - 2020-06-24 13:17:53 --> Helper loaded: url_helper
INFO - 2020-06-24 13:17:53 --> Database Driver Class Initialized
INFO - 2020-06-24 13:17:53 --> Controller Class Initialized
INFO - 2020-06-24 13:17:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 13:17:53 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 13:17:53 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 13:17:53 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 13:17:53 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:17:53 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 13:17:53 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:17:53 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:17:53 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:17:53 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 13:17:53 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 13:17:53 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 13:17:53 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 13:17:53 --> Final output sent to browser
DEBUG - 2020-06-24 13:17:53 --> Total execution time: 0.1501
INFO - 2020-06-24 13:22:53 --> Config Class Initialized
INFO - 2020-06-24 13:22:53 --> Plain_Config Class Initialized
INFO - 2020-06-24 13:22:53 --> Hooks Class Initialized
INFO - 2020-06-24 13:22:53 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 13:22:53 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 13:22:53 --> UTF-8 Support Disabled
INFO - 2020-06-24 13:22:53 --> Utf8 Class Initialized
INFO - 2020-06-24 13:22:53 --> URI Class Initialized
DEBUG - 2020-06-24 13:22:53 --> No URI present. Default controller set.
INFO - 2020-06-24 13:22:53 --> Router Class Initialized
INFO - 2020-06-24 13:22:53 --> Plain_Router Class Initialized
INFO - 2020-06-24 13:22:53 --> Output Class Initialized
INFO - 2020-06-24 13:22:53 --> Security Class Initialized
DEBUG - 2020-06-24 13:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 13:22:53 --> Input Class Initialized
INFO - 2020-06-24 13:22:53 --> Language Class Initialized
INFO - 2020-06-24 13:22:53 --> Loader Class Initialized
INFO - 2020-06-24 13:22:53 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 13:22:53 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 13:22:53 --> Helper loaded: data_helper
INFO - 2020-06-24 13:22:53 --> Helper loaded: hash_helper
INFO - 2020-06-24 13:22:53 --> Helper loaded: validation_helper
INFO - 2020-06-24 13:22:53 --> Helper loaded: view_helper
INFO - 2020-06-24 13:22:53 --> Helper loaded: url_helper
INFO - 2020-06-24 13:22:53 --> Database Driver Class Initialized
INFO - 2020-06-24 13:22:53 --> Controller Class Initialized
INFO - 2020-06-24 13:22:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 13:22:53 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 13:22:53 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 13:22:53 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 13:22:53 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:22:53 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 13:22:53 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:22:53 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:22:53 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:22:53 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 13:22:53 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 13:22:53 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 13:22:53 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 13:22:53 --> Final output sent to browser
DEBUG - 2020-06-24 13:22:53 --> Total execution time: 0.1647
INFO - 2020-06-24 13:27:57 --> Config Class Initialized
INFO - 2020-06-24 13:27:57 --> Plain_Config Class Initialized
INFO - 2020-06-24 13:27:57 --> Hooks Class Initialized
INFO - 2020-06-24 13:27:57 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 13:27:57 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 13:27:57 --> UTF-8 Support Disabled
INFO - 2020-06-24 13:27:57 --> Utf8 Class Initialized
INFO - 2020-06-24 13:27:57 --> URI Class Initialized
DEBUG - 2020-06-24 13:27:57 --> No URI present. Default controller set.
INFO - 2020-06-24 13:27:57 --> Router Class Initialized
INFO - 2020-06-24 13:27:57 --> Plain_Router Class Initialized
INFO - 2020-06-24 13:27:57 --> Output Class Initialized
INFO - 2020-06-24 13:27:57 --> Security Class Initialized
DEBUG - 2020-06-24 13:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 13:27:57 --> Input Class Initialized
INFO - 2020-06-24 13:27:57 --> Language Class Initialized
INFO - 2020-06-24 13:27:57 --> Loader Class Initialized
INFO - 2020-06-24 13:27:57 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 13:27:57 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 13:27:57 --> Helper loaded: data_helper
INFO - 2020-06-24 13:27:57 --> Helper loaded: hash_helper
INFO - 2020-06-24 13:27:57 --> Helper loaded: validation_helper
INFO - 2020-06-24 13:27:57 --> Helper loaded: view_helper
INFO - 2020-06-24 13:27:57 --> Helper loaded: url_helper
INFO - 2020-06-24 13:27:57 --> Database Driver Class Initialized
INFO - 2020-06-24 13:27:57 --> Controller Class Initialized
INFO - 2020-06-24 13:27:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 13:27:57 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 13:27:57 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 13:27:57 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 13:27:57 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:27:57 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 13:27:57 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:27:57 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:27:57 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:27:57 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 13:27:57 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 13:27:57 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 13:27:57 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 13:27:57 --> Final output sent to browser
DEBUG - 2020-06-24 13:27:57 --> Total execution time: 0.1575
INFO - 2020-06-24 13:32:57 --> Config Class Initialized
INFO - 2020-06-24 13:32:57 --> Plain_Config Class Initialized
INFO - 2020-06-24 13:32:57 --> Hooks Class Initialized
INFO - 2020-06-24 13:32:57 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 13:32:57 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 13:32:57 --> UTF-8 Support Disabled
INFO - 2020-06-24 13:32:57 --> Utf8 Class Initialized
INFO - 2020-06-24 13:32:57 --> URI Class Initialized
DEBUG - 2020-06-24 13:32:57 --> No URI present. Default controller set.
INFO - 2020-06-24 13:32:57 --> Router Class Initialized
INFO - 2020-06-24 13:32:57 --> Plain_Router Class Initialized
INFO - 2020-06-24 13:32:57 --> Output Class Initialized
INFO - 2020-06-24 13:32:57 --> Security Class Initialized
DEBUG - 2020-06-24 13:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 13:32:57 --> Input Class Initialized
INFO - 2020-06-24 13:32:57 --> Language Class Initialized
INFO - 2020-06-24 13:32:57 --> Loader Class Initialized
INFO - 2020-06-24 13:32:57 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 13:32:58 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 13:32:58 --> Helper loaded: data_helper
INFO - 2020-06-24 13:32:58 --> Helper loaded: hash_helper
INFO - 2020-06-24 13:32:58 --> Helper loaded: validation_helper
INFO - 2020-06-24 13:32:58 --> Helper loaded: view_helper
INFO - 2020-06-24 13:32:58 --> Helper loaded: url_helper
INFO - 2020-06-24 13:32:58 --> Database Driver Class Initialized
INFO - 2020-06-24 13:32:58 --> Controller Class Initialized
INFO - 2020-06-24 13:32:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 13:32:58 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 13:32:58 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 13:32:58 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 13:32:58 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:32:58 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 13:32:58 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:32:58 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:32:58 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:32:58 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 13:32:58 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 13:32:58 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 13:32:58 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 13:32:58 --> Final output sent to browser
DEBUG - 2020-06-24 13:32:58 --> Total execution time: 0.1656
INFO - 2020-06-24 13:37:58 --> Config Class Initialized
INFO - 2020-06-24 13:37:58 --> Plain_Config Class Initialized
INFO - 2020-06-24 13:37:58 --> Hooks Class Initialized
INFO - 2020-06-24 13:37:58 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 13:37:58 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 13:37:58 --> UTF-8 Support Disabled
INFO - 2020-06-24 13:37:58 --> Utf8 Class Initialized
INFO - 2020-06-24 13:37:58 --> URI Class Initialized
DEBUG - 2020-06-24 13:37:58 --> No URI present. Default controller set.
INFO - 2020-06-24 13:37:58 --> Router Class Initialized
INFO - 2020-06-24 13:37:58 --> Plain_Router Class Initialized
INFO - 2020-06-24 13:37:58 --> Output Class Initialized
INFO - 2020-06-24 13:37:58 --> Security Class Initialized
DEBUG - 2020-06-24 13:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 13:37:58 --> Input Class Initialized
INFO - 2020-06-24 13:37:58 --> Language Class Initialized
INFO - 2020-06-24 13:37:58 --> Loader Class Initialized
INFO - 2020-06-24 13:37:58 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 13:37:58 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 13:37:58 --> Helper loaded: data_helper
INFO - 2020-06-24 13:37:58 --> Helper loaded: hash_helper
INFO - 2020-06-24 13:37:58 --> Helper loaded: validation_helper
INFO - 2020-06-24 13:37:58 --> Helper loaded: view_helper
INFO - 2020-06-24 13:37:58 --> Helper loaded: url_helper
INFO - 2020-06-24 13:37:58 --> Database Driver Class Initialized
INFO - 2020-06-24 13:37:58 --> Controller Class Initialized
INFO - 2020-06-24 13:37:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 13:37:58 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 13:37:58 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 13:37:58 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 13:37:58 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:37:58 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 13:37:58 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:37:58 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:37:58 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:37:58 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 13:37:58 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 13:37:58 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 13:37:58 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 13:37:58 --> Final output sent to browser
DEBUG - 2020-06-24 13:37:58 --> Total execution time: 0.1825
INFO - 2020-06-24 13:42:59 --> Config Class Initialized
INFO - 2020-06-24 13:42:59 --> Plain_Config Class Initialized
INFO - 2020-06-24 13:42:59 --> Hooks Class Initialized
INFO - 2020-06-24 13:42:59 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 13:42:59 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 13:42:59 --> UTF-8 Support Disabled
INFO - 2020-06-24 13:42:59 --> Utf8 Class Initialized
INFO - 2020-06-24 13:42:59 --> URI Class Initialized
DEBUG - 2020-06-24 13:42:59 --> No URI present. Default controller set.
INFO - 2020-06-24 13:42:59 --> Router Class Initialized
INFO - 2020-06-24 13:42:59 --> Plain_Router Class Initialized
INFO - 2020-06-24 13:42:59 --> Output Class Initialized
INFO - 2020-06-24 13:42:59 --> Security Class Initialized
DEBUG - 2020-06-24 13:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 13:42:59 --> Input Class Initialized
INFO - 2020-06-24 13:42:59 --> Language Class Initialized
INFO - 2020-06-24 13:42:59 --> Loader Class Initialized
INFO - 2020-06-24 13:42:59 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 13:42:59 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 13:42:59 --> Helper loaded: data_helper
INFO - 2020-06-24 13:42:59 --> Helper loaded: hash_helper
INFO - 2020-06-24 13:42:59 --> Helper loaded: validation_helper
INFO - 2020-06-24 13:42:59 --> Helper loaded: view_helper
INFO - 2020-06-24 13:42:59 --> Helper loaded: url_helper
INFO - 2020-06-24 13:42:59 --> Database Driver Class Initialized
INFO - 2020-06-24 13:42:59 --> Controller Class Initialized
INFO - 2020-06-24 13:42:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 13:42:59 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 13:42:59 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 13:42:59 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 13:42:59 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:42:59 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 13:42:59 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:42:59 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:42:59 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:42:59 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 13:42:59 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 13:42:59 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 13:42:59 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 13:42:59 --> Final output sent to browser
DEBUG - 2020-06-24 13:42:59 --> Total execution time: 0.2577
INFO - 2020-06-24 13:48:00 --> Config Class Initialized
INFO - 2020-06-24 13:48:00 --> Plain_Config Class Initialized
INFO - 2020-06-24 13:48:00 --> Hooks Class Initialized
INFO - 2020-06-24 13:48:00 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 13:48:00 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 13:48:00 --> UTF-8 Support Disabled
INFO - 2020-06-24 13:48:00 --> Utf8 Class Initialized
INFO - 2020-06-24 13:48:00 --> URI Class Initialized
DEBUG - 2020-06-24 13:48:00 --> No URI present. Default controller set.
INFO - 2020-06-24 13:48:00 --> Router Class Initialized
INFO - 2020-06-24 13:48:00 --> Plain_Router Class Initialized
INFO - 2020-06-24 13:48:00 --> Output Class Initialized
INFO - 2020-06-24 13:48:00 --> Security Class Initialized
DEBUG - 2020-06-24 13:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 13:48:00 --> Input Class Initialized
INFO - 2020-06-24 13:48:00 --> Language Class Initialized
INFO - 2020-06-24 13:48:00 --> Loader Class Initialized
INFO - 2020-06-24 13:48:00 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 13:48:00 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 13:48:00 --> Helper loaded: data_helper
INFO - 2020-06-24 13:48:00 --> Helper loaded: hash_helper
INFO - 2020-06-24 13:48:00 --> Helper loaded: validation_helper
INFO - 2020-06-24 13:48:00 --> Helper loaded: view_helper
INFO - 2020-06-24 13:48:00 --> Helper loaded: url_helper
INFO - 2020-06-24 13:48:00 --> Database Driver Class Initialized
INFO - 2020-06-24 13:48:00 --> Controller Class Initialized
INFO - 2020-06-24 13:48:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 13:48:00 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 13:48:00 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 13:48:00 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 13:48:00 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:48:00 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 13:48:00 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:48:00 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:48:00 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:48:00 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 13:48:00 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 13:48:00 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 13:48:00 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 13:48:00 --> Final output sent to browser
DEBUG - 2020-06-24 13:48:00 --> Total execution time: 0.2029
INFO - 2020-06-24 13:53:00 --> Config Class Initialized
INFO - 2020-06-24 13:53:00 --> Plain_Config Class Initialized
INFO - 2020-06-24 13:53:00 --> Hooks Class Initialized
INFO - 2020-06-24 13:53:00 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 13:53:00 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 13:53:00 --> UTF-8 Support Disabled
INFO - 2020-06-24 13:53:00 --> Utf8 Class Initialized
INFO - 2020-06-24 13:53:00 --> URI Class Initialized
DEBUG - 2020-06-24 13:53:00 --> No URI present. Default controller set.
INFO - 2020-06-24 13:53:00 --> Router Class Initialized
INFO - 2020-06-24 13:53:00 --> Plain_Router Class Initialized
INFO - 2020-06-24 13:53:00 --> Output Class Initialized
INFO - 2020-06-24 13:53:00 --> Security Class Initialized
DEBUG - 2020-06-24 13:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 13:53:00 --> Input Class Initialized
INFO - 2020-06-24 13:53:00 --> Language Class Initialized
INFO - 2020-06-24 13:53:00 --> Loader Class Initialized
INFO - 2020-06-24 13:53:00 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 13:53:00 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 13:53:00 --> Helper loaded: data_helper
INFO - 2020-06-24 13:53:00 --> Helper loaded: hash_helper
INFO - 2020-06-24 13:53:00 --> Helper loaded: validation_helper
INFO - 2020-06-24 13:53:00 --> Helper loaded: view_helper
INFO - 2020-06-24 13:53:00 --> Helper loaded: url_helper
INFO - 2020-06-24 13:53:00 --> Database Driver Class Initialized
INFO - 2020-06-24 13:53:00 --> Controller Class Initialized
INFO - 2020-06-24 13:53:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 13:53:00 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 13:53:00 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 13:53:00 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 13:53:00 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:53:00 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 13:53:00 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:53:00 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:53:00 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:53:00 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 13:53:00 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 13:53:00 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 13:53:00 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 13:53:00 --> Final output sent to browser
DEBUG - 2020-06-24 13:53:00 --> Total execution time: 0.2138
INFO - 2020-06-24 13:58:01 --> Config Class Initialized
INFO - 2020-06-24 13:58:01 --> Plain_Config Class Initialized
INFO - 2020-06-24 13:58:01 --> Hooks Class Initialized
INFO - 2020-06-24 13:58:01 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 13:58:01 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 13:58:01 --> UTF-8 Support Disabled
INFO - 2020-06-24 13:58:01 --> Utf8 Class Initialized
INFO - 2020-06-24 13:58:01 --> URI Class Initialized
DEBUG - 2020-06-24 13:58:01 --> No URI present. Default controller set.
INFO - 2020-06-24 13:58:01 --> Router Class Initialized
INFO - 2020-06-24 13:58:01 --> Plain_Router Class Initialized
INFO - 2020-06-24 13:58:01 --> Output Class Initialized
INFO - 2020-06-24 13:58:01 --> Security Class Initialized
DEBUG - 2020-06-24 13:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 13:58:01 --> Input Class Initialized
INFO - 2020-06-24 13:58:01 --> Language Class Initialized
INFO - 2020-06-24 13:58:01 --> Loader Class Initialized
INFO - 2020-06-24 13:58:01 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 13:58:01 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 13:58:01 --> Helper loaded: data_helper
INFO - 2020-06-24 13:58:01 --> Helper loaded: hash_helper
INFO - 2020-06-24 13:58:01 --> Helper loaded: validation_helper
INFO - 2020-06-24 13:58:02 --> Helper loaded: view_helper
INFO - 2020-06-24 13:58:02 --> Helper loaded: url_helper
INFO - 2020-06-24 13:58:02 --> Database Driver Class Initialized
INFO - 2020-06-24 13:58:02 --> Controller Class Initialized
INFO - 2020-06-24 13:58:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 13:58:02 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 13:58:02 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 13:58:02 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 13:58:02 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:58:02 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 13:58:02 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:58:02 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 13:58:02 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 13:58:02 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 13:58:02 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 13:58:02 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 13:58:02 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 13:58:02 --> Final output sent to browser
DEBUG - 2020-06-24 13:58:02 --> Total execution time: 0.2208
INFO - 2020-06-24 14:03:02 --> Config Class Initialized
INFO - 2020-06-24 14:03:02 --> Plain_Config Class Initialized
INFO - 2020-06-24 14:03:02 --> Hooks Class Initialized
INFO - 2020-06-24 14:03:02 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 14:03:02 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 14:03:02 --> UTF-8 Support Disabled
INFO - 2020-06-24 14:03:02 --> Utf8 Class Initialized
INFO - 2020-06-24 14:03:02 --> URI Class Initialized
DEBUG - 2020-06-24 14:03:02 --> No URI present. Default controller set.
INFO - 2020-06-24 14:03:02 --> Router Class Initialized
INFO - 2020-06-24 14:03:02 --> Plain_Router Class Initialized
INFO - 2020-06-24 14:03:02 --> Output Class Initialized
INFO - 2020-06-24 14:03:02 --> Security Class Initialized
DEBUG - 2020-06-24 14:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 14:03:02 --> Input Class Initialized
INFO - 2020-06-24 14:03:02 --> Language Class Initialized
INFO - 2020-06-24 14:03:02 --> Loader Class Initialized
INFO - 2020-06-24 14:03:02 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 14:03:02 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 14:03:02 --> Helper loaded: data_helper
INFO - 2020-06-24 14:03:02 --> Helper loaded: hash_helper
INFO - 2020-06-24 14:03:02 --> Helper loaded: validation_helper
INFO - 2020-06-24 14:03:02 --> Helper loaded: view_helper
INFO - 2020-06-24 14:03:02 --> Helper loaded: url_helper
INFO - 2020-06-24 14:03:02 --> Database Driver Class Initialized
INFO - 2020-06-24 14:03:02 --> Controller Class Initialized
INFO - 2020-06-24 14:03:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 14:03:03 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 14:03:03 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 14:03:03 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 14:03:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:03:03 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 14:03:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:03:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:03:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:03:03 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 14:03:03 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 14:03:03 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 14:03:03 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 14:03:03 --> Final output sent to browser
DEBUG - 2020-06-24 14:03:03 --> Total execution time: 0.2376
INFO - 2020-06-24 14:08:03 --> Config Class Initialized
INFO - 2020-06-24 14:08:03 --> Plain_Config Class Initialized
INFO - 2020-06-24 14:08:03 --> Hooks Class Initialized
INFO - 2020-06-24 14:08:03 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 14:08:03 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 14:08:03 --> UTF-8 Support Disabled
INFO - 2020-06-24 14:08:03 --> Utf8 Class Initialized
INFO - 2020-06-24 14:08:03 --> URI Class Initialized
DEBUG - 2020-06-24 14:08:03 --> No URI present. Default controller set.
INFO - 2020-06-24 14:08:03 --> Router Class Initialized
INFO - 2020-06-24 14:08:03 --> Plain_Router Class Initialized
INFO - 2020-06-24 14:08:03 --> Output Class Initialized
INFO - 2020-06-24 14:08:03 --> Security Class Initialized
DEBUG - 2020-06-24 14:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 14:08:03 --> Input Class Initialized
INFO - 2020-06-24 14:08:03 --> Language Class Initialized
INFO - 2020-06-24 14:08:03 --> Loader Class Initialized
INFO - 2020-06-24 14:08:03 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 14:08:03 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 14:08:03 --> Helper loaded: data_helper
INFO - 2020-06-24 14:08:03 --> Helper loaded: hash_helper
INFO - 2020-06-24 14:08:03 --> Helper loaded: validation_helper
INFO - 2020-06-24 14:08:03 --> Helper loaded: view_helper
INFO - 2020-06-24 14:08:03 --> Helper loaded: url_helper
INFO - 2020-06-24 14:08:03 --> Database Driver Class Initialized
INFO - 2020-06-24 14:08:03 --> Controller Class Initialized
INFO - 2020-06-24 14:08:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 14:08:03 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 14:08:03 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 14:08:03 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 14:08:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:08:03 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 14:08:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:08:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:08:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:08:03 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 14:08:03 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 14:08:03 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 14:08:03 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 14:08:03 --> Final output sent to browser
DEBUG - 2020-06-24 14:08:03 --> Total execution time: 0.2183
INFO - 2020-06-24 14:13:04 --> Config Class Initialized
INFO - 2020-06-24 14:13:04 --> Plain_Config Class Initialized
INFO - 2020-06-24 14:13:04 --> Hooks Class Initialized
INFO - 2020-06-24 14:13:04 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 14:13:04 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 14:13:04 --> UTF-8 Support Disabled
INFO - 2020-06-24 14:13:04 --> Utf8 Class Initialized
INFO - 2020-06-24 14:13:04 --> URI Class Initialized
DEBUG - 2020-06-24 14:13:04 --> No URI present. Default controller set.
INFO - 2020-06-24 14:13:04 --> Router Class Initialized
INFO - 2020-06-24 14:13:04 --> Plain_Router Class Initialized
INFO - 2020-06-24 14:13:04 --> Output Class Initialized
INFO - 2020-06-24 14:13:04 --> Security Class Initialized
DEBUG - 2020-06-24 14:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 14:13:04 --> Input Class Initialized
INFO - 2020-06-24 14:13:04 --> Language Class Initialized
INFO - 2020-06-24 14:13:04 --> Loader Class Initialized
INFO - 2020-06-24 14:13:04 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 14:13:04 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 14:13:04 --> Helper loaded: data_helper
INFO - 2020-06-24 14:13:04 --> Helper loaded: hash_helper
INFO - 2020-06-24 14:13:04 --> Helper loaded: validation_helper
INFO - 2020-06-24 14:13:04 --> Helper loaded: view_helper
INFO - 2020-06-24 14:13:04 --> Helper loaded: url_helper
INFO - 2020-06-24 14:13:04 --> Database Driver Class Initialized
INFO - 2020-06-24 14:13:04 --> Controller Class Initialized
INFO - 2020-06-24 14:13:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 14:13:04 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 14:13:04 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 14:13:04 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 14:13:04 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:13:04 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 14:13:04 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:13:04 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:13:04 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:13:04 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 14:13:04 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 14:13:04 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 14:13:04 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 14:13:04 --> Final output sent to browser
DEBUG - 2020-06-24 14:13:04 --> Total execution time: 0.2322
INFO - 2020-06-24 14:18:05 --> Config Class Initialized
INFO - 2020-06-24 14:18:05 --> Plain_Config Class Initialized
INFO - 2020-06-24 14:18:05 --> Hooks Class Initialized
INFO - 2020-06-24 14:18:05 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 14:18:05 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 14:18:05 --> UTF-8 Support Disabled
INFO - 2020-06-24 14:18:05 --> Utf8 Class Initialized
INFO - 2020-06-24 14:18:05 --> URI Class Initialized
DEBUG - 2020-06-24 14:18:05 --> No URI present. Default controller set.
INFO - 2020-06-24 14:18:05 --> Router Class Initialized
INFO - 2020-06-24 14:18:05 --> Plain_Router Class Initialized
INFO - 2020-06-24 14:18:05 --> Output Class Initialized
INFO - 2020-06-24 14:18:05 --> Security Class Initialized
DEBUG - 2020-06-24 14:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 14:18:05 --> Input Class Initialized
INFO - 2020-06-24 14:18:05 --> Language Class Initialized
INFO - 2020-06-24 14:18:05 --> Loader Class Initialized
INFO - 2020-06-24 14:18:05 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 14:18:05 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 14:18:05 --> Helper loaded: data_helper
INFO - 2020-06-24 14:18:05 --> Helper loaded: hash_helper
INFO - 2020-06-24 14:18:05 --> Helper loaded: validation_helper
INFO - 2020-06-24 14:18:05 --> Helper loaded: view_helper
INFO - 2020-06-24 14:18:05 --> Helper loaded: url_helper
INFO - 2020-06-24 14:18:05 --> Database Driver Class Initialized
INFO - 2020-06-24 14:18:05 --> Controller Class Initialized
INFO - 2020-06-24 14:18:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 14:18:05 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 14:18:05 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 14:18:05 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 14:18:05 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:18:05 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 14:18:05 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:18:05 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:18:05 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:18:05 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 14:18:05 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 14:18:05 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 14:18:05 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 14:18:05 --> Final output sent to browser
DEBUG - 2020-06-24 14:18:05 --> Total execution time: 0.2031
INFO - 2020-06-24 14:23:05 --> Config Class Initialized
INFO - 2020-06-24 14:23:05 --> Plain_Config Class Initialized
INFO - 2020-06-24 14:23:05 --> Hooks Class Initialized
INFO - 2020-06-24 14:23:05 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 14:23:05 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 14:23:05 --> UTF-8 Support Disabled
INFO - 2020-06-24 14:23:05 --> Utf8 Class Initialized
INFO - 2020-06-24 14:23:05 --> URI Class Initialized
DEBUG - 2020-06-24 14:23:05 --> No URI present. Default controller set.
INFO - 2020-06-24 14:23:05 --> Router Class Initialized
INFO - 2020-06-24 14:23:05 --> Plain_Router Class Initialized
INFO - 2020-06-24 14:23:05 --> Output Class Initialized
INFO - 2020-06-24 14:23:05 --> Security Class Initialized
DEBUG - 2020-06-24 14:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 14:23:05 --> Input Class Initialized
INFO - 2020-06-24 14:23:05 --> Language Class Initialized
INFO - 2020-06-24 14:23:05 --> Loader Class Initialized
INFO - 2020-06-24 14:23:05 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 14:23:05 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 14:23:05 --> Helper loaded: data_helper
INFO - 2020-06-24 14:23:05 --> Helper loaded: hash_helper
INFO - 2020-06-24 14:23:05 --> Helper loaded: validation_helper
INFO - 2020-06-24 14:23:06 --> Helper loaded: view_helper
INFO - 2020-06-24 14:23:06 --> Helper loaded: url_helper
INFO - 2020-06-24 14:23:06 --> Database Driver Class Initialized
INFO - 2020-06-24 14:23:06 --> Controller Class Initialized
INFO - 2020-06-24 14:23:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 14:23:06 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 14:23:06 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 14:23:06 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 14:23:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:23:06 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 14:23:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:23:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:23:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:23:06 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 14:23:06 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 14:23:06 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 14:23:06 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 14:23:06 --> Final output sent to browser
DEBUG - 2020-06-24 14:23:06 --> Total execution time: 0.2039
INFO - 2020-06-24 14:28:06 --> Config Class Initialized
INFO - 2020-06-24 14:28:06 --> Plain_Config Class Initialized
INFO - 2020-06-24 14:28:06 --> Hooks Class Initialized
INFO - 2020-06-24 14:28:06 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 14:28:06 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 14:28:06 --> UTF-8 Support Disabled
INFO - 2020-06-24 14:28:06 --> Utf8 Class Initialized
INFO - 2020-06-24 14:28:06 --> URI Class Initialized
DEBUG - 2020-06-24 14:28:06 --> No URI present. Default controller set.
INFO - 2020-06-24 14:28:06 --> Router Class Initialized
INFO - 2020-06-24 14:28:06 --> Plain_Router Class Initialized
INFO - 2020-06-24 14:28:06 --> Output Class Initialized
INFO - 2020-06-24 14:28:06 --> Security Class Initialized
DEBUG - 2020-06-24 14:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 14:28:06 --> Input Class Initialized
INFO - 2020-06-24 14:28:06 --> Language Class Initialized
INFO - 2020-06-24 14:28:06 --> Loader Class Initialized
INFO - 2020-06-24 14:28:06 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 14:28:06 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 14:28:06 --> Helper loaded: data_helper
INFO - 2020-06-24 14:28:06 --> Helper loaded: hash_helper
INFO - 2020-06-24 14:28:06 --> Helper loaded: validation_helper
INFO - 2020-06-24 14:28:06 --> Helper loaded: view_helper
INFO - 2020-06-24 14:28:06 --> Helper loaded: url_helper
INFO - 2020-06-24 14:28:06 --> Database Driver Class Initialized
INFO - 2020-06-24 14:28:06 --> Controller Class Initialized
INFO - 2020-06-24 14:28:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 14:28:06 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 14:28:06 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 14:28:06 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 14:28:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:28:06 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 14:28:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:28:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:28:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:28:06 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 14:28:06 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 14:28:06 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 14:28:06 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 14:28:06 --> Final output sent to browser
DEBUG - 2020-06-24 14:28:06 --> Total execution time: 0.2097
INFO - 2020-06-24 14:33:06 --> Config Class Initialized
INFO - 2020-06-24 14:33:06 --> Plain_Config Class Initialized
INFO - 2020-06-24 14:33:06 --> Hooks Class Initialized
INFO - 2020-06-24 14:33:06 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 14:33:06 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 14:33:06 --> UTF-8 Support Disabled
INFO - 2020-06-24 14:33:06 --> Utf8 Class Initialized
INFO - 2020-06-24 14:33:06 --> URI Class Initialized
DEBUG - 2020-06-24 14:33:06 --> No URI present. Default controller set.
INFO - 2020-06-24 14:33:06 --> Router Class Initialized
INFO - 2020-06-24 14:33:06 --> Plain_Router Class Initialized
INFO - 2020-06-24 14:33:06 --> Output Class Initialized
INFO - 2020-06-24 14:33:07 --> Security Class Initialized
DEBUG - 2020-06-24 14:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 14:33:07 --> Input Class Initialized
INFO - 2020-06-24 14:33:07 --> Language Class Initialized
INFO - 2020-06-24 14:33:07 --> Loader Class Initialized
INFO - 2020-06-24 14:33:07 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 14:33:07 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 14:33:07 --> Helper loaded: data_helper
INFO - 2020-06-24 14:33:07 --> Helper loaded: hash_helper
INFO - 2020-06-24 14:33:07 --> Helper loaded: validation_helper
INFO - 2020-06-24 14:33:07 --> Helper loaded: view_helper
INFO - 2020-06-24 14:33:07 --> Helper loaded: url_helper
INFO - 2020-06-24 14:33:07 --> Database Driver Class Initialized
INFO - 2020-06-24 14:33:07 --> Controller Class Initialized
INFO - 2020-06-24 14:33:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 14:33:07 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 14:33:07 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 14:33:07 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 14:33:07 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:33:07 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 14:33:07 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:33:07 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:33:07 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:33:07 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 14:33:07 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 14:33:07 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 14:33:07 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 14:33:07 --> Final output sent to browser
DEBUG - 2020-06-24 14:33:07 --> Total execution time: 0.1975
INFO - 2020-06-24 14:38:08 --> Config Class Initialized
INFO - 2020-06-24 14:38:08 --> Plain_Config Class Initialized
INFO - 2020-06-24 14:38:08 --> Hooks Class Initialized
INFO - 2020-06-24 14:38:08 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 14:38:08 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 14:38:08 --> UTF-8 Support Disabled
INFO - 2020-06-24 14:38:08 --> Utf8 Class Initialized
INFO - 2020-06-24 14:38:08 --> URI Class Initialized
DEBUG - 2020-06-24 14:38:08 --> No URI present. Default controller set.
INFO - 2020-06-24 14:38:08 --> Router Class Initialized
INFO - 2020-06-24 14:38:08 --> Plain_Router Class Initialized
INFO - 2020-06-24 14:38:08 --> Output Class Initialized
INFO - 2020-06-24 14:38:08 --> Security Class Initialized
DEBUG - 2020-06-24 14:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 14:38:08 --> Input Class Initialized
INFO - 2020-06-24 14:38:08 --> Language Class Initialized
INFO - 2020-06-24 14:38:08 --> Loader Class Initialized
INFO - 2020-06-24 14:38:08 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 14:38:08 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 14:38:08 --> Helper loaded: data_helper
INFO - 2020-06-24 14:38:08 --> Helper loaded: hash_helper
INFO - 2020-06-24 14:38:08 --> Helper loaded: validation_helper
INFO - 2020-06-24 14:38:08 --> Helper loaded: view_helper
INFO - 2020-06-24 14:38:08 --> Helper loaded: url_helper
INFO - 2020-06-24 14:38:08 --> Database Driver Class Initialized
INFO - 2020-06-24 14:38:08 --> Controller Class Initialized
INFO - 2020-06-24 14:38:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 14:38:08 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 14:38:08 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 14:38:08 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 14:38:08 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:38:08 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 14:38:08 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:38:08 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:38:08 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:38:08 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 14:38:08 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 14:38:08 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 14:38:08 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 14:38:08 --> Final output sent to browser
DEBUG - 2020-06-24 14:38:08 --> Total execution time: 0.2037
INFO - 2020-06-24 14:43:16 --> Config Class Initialized
INFO - 2020-06-24 14:43:16 --> Plain_Config Class Initialized
INFO - 2020-06-24 14:43:16 --> Hooks Class Initialized
INFO - 2020-06-24 14:43:16 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 14:43:16 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 14:43:16 --> UTF-8 Support Disabled
INFO - 2020-06-24 14:43:16 --> Utf8 Class Initialized
INFO - 2020-06-24 14:43:16 --> URI Class Initialized
DEBUG - 2020-06-24 14:43:16 --> No URI present. Default controller set.
INFO - 2020-06-24 14:43:16 --> Router Class Initialized
INFO - 2020-06-24 14:43:16 --> Plain_Router Class Initialized
INFO - 2020-06-24 14:43:16 --> Output Class Initialized
INFO - 2020-06-24 14:43:16 --> Security Class Initialized
DEBUG - 2020-06-24 14:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 14:43:16 --> Input Class Initialized
INFO - 2020-06-24 14:43:16 --> Language Class Initialized
INFO - 2020-06-24 14:43:16 --> Loader Class Initialized
INFO - 2020-06-24 14:43:16 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 14:43:16 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 14:43:16 --> Helper loaded: data_helper
INFO - 2020-06-24 14:43:16 --> Helper loaded: hash_helper
INFO - 2020-06-24 14:43:16 --> Helper loaded: validation_helper
INFO - 2020-06-24 14:43:16 --> Helper loaded: view_helper
INFO - 2020-06-24 14:43:16 --> Helper loaded: url_helper
INFO - 2020-06-24 14:43:16 --> Database Driver Class Initialized
INFO - 2020-06-24 14:43:16 --> Controller Class Initialized
INFO - 2020-06-24 14:43:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 14:43:16 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 14:43:16 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 14:43:16 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 14:43:16 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:43:16 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 14:43:16 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:43:16 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:43:16 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:43:16 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 14:43:16 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 14:43:16 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 14:43:16 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 14:43:16 --> Final output sent to browser
DEBUG - 2020-06-24 14:43:16 --> Total execution time: 0.2226
INFO - 2020-06-24 14:48:17 --> Config Class Initialized
INFO - 2020-06-24 14:48:17 --> Plain_Config Class Initialized
INFO - 2020-06-24 14:48:17 --> Hooks Class Initialized
INFO - 2020-06-24 14:48:17 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 14:48:17 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 14:48:17 --> UTF-8 Support Disabled
INFO - 2020-06-24 14:48:17 --> Utf8 Class Initialized
INFO - 2020-06-24 14:48:17 --> URI Class Initialized
DEBUG - 2020-06-24 14:48:17 --> No URI present. Default controller set.
INFO - 2020-06-24 14:48:17 --> Router Class Initialized
INFO - 2020-06-24 14:48:17 --> Plain_Router Class Initialized
INFO - 2020-06-24 14:48:17 --> Output Class Initialized
INFO - 2020-06-24 14:48:17 --> Security Class Initialized
DEBUG - 2020-06-24 14:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 14:48:17 --> Input Class Initialized
INFO - 2020-06-24 14:48:17 --> Language Class Initialized
INFO - 2020-06-24 14:48:17 --> Loader Class Initialized
INFO - 2020-06-24 14:48:17 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 14:48:17 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 14:48:17 --> Helper loaded: data_helper
INFO - 2020-06-24 14:48:17 --> Helper loaded: hash_helper
INFO - 2020-06-24 14:48:17 --> Helper loaded: validation_helper
INFO - 2020-06-24 14:48:17 --> Helper loaded: view_helper
INFO - 2020-06-24 14:48:17 --> Helper loaded: url_helper
INFO - 2020-06-24 14:48:17 --> Database Driver Class Initialized
INFO - 2020-06-24 14:48:17 --> Controller Class Initialized
INFO - 2020-06-24 14:48:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 14:48:17 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 14:48:17 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 14:48:17 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 14:48:17 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:48:17 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 14:48:17 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:48:17 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:48:17 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:48:17 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 14:48:17 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 14:48:17 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 14:48:17 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 14:48:17 --> Final output sent to browser
DEBUG - 2020-06-24 14:48:17 --> Total execution time: 0.1198
INFO - 2020-06-24 14:53:17 --> Config Class Initialized
INFO - 2020-06-24 14:53:17 --> Plain_Config Class Initialized
INFO - 2020-06-24 14:53:17 --> Hooks Class Initialized
INFO - 2020-06-24 14:53:17 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 14:53:17 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 14:53:17 --> UTF-8 Support Disabled
INFO - 2020-06-24 14:53:17 --> Utf8 Class Initialized
INFO - 2020-06-24 14:53:17 --> URI Class Initialized
DEBUG - 2020-06-24 14:53:17 --> No URI present. Default controller set.
INFO - 2020-06-24 14:53:17 --> Router Class Initialized
INFO - 2020-06-24 14:53:17 --> Plain_Router Class Initialized
INFO - 2020-06-24 14:53:17 --> Output Class Initialized
INFO - 2020-06-24 14:53:17 --> Security Class Initialized
DEBUG - 2020-06-24 14:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 14:53:17 --> Input Class Initialized
INFO - 2020-06-24 14:53:17 --> Language Class Initialized
INFO - 2020-06-24 14:53:17 --> Loader Class Initialized
INFO - 2020-06-24 14:53:17 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 14:53:17 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 14:53:17 --> Helper loaded: data_helper
INFO - 2020-06-24 14:53:17 --> Helper loaded: hash_helper
INFO - 2020-06-24 14:53:17 --> Helper loaded: validation_helper
INFO - 2020-06-24 14:53:17 --> Helper loaded: view_helper
INFO - 2020-06-24 14:53:17 --> Helper loaded: url_helper
INFO - 2020-06-24 14:53:17 --> Database Driver Class Initialized
INFO - 2020-06-24 14:53:17 --> Controller Class Initialized
INFO - 2020-06-24 14:53:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 14:53:17 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 14:53:17 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 14:53:17 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 14:53:17 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:53:17 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 14:53:17 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:53:17 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:53:17 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:53:17 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 14:53:17 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 14:53:17 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 14:53:17 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 14:53:17 --> Final output sent to browser
DEBUG - 2020-06-24 14:53:17 --> Total execution time: 0.1277
INFO - 2020-06-24 14:58:18 --> Config Class Initialized
INFO - 2020-06-24 14:58:18 --> Plain_Config Class Initialized
INFO - 2020-06-24 14:58:18 --> Hooks Class Initialized
INFO - 2020-06-24 14:58:18 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 14:58:18 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 14:58:18 --> UTF-8 Support Disabled
INFO - 2020-06-24 14:58:18 --> Utf8 Class Initialized
INFO - 2020-06-24 14:58:18 --> URI Class Initialized
DEBUG - 2020-06-24 14:58:18 --> No URI present. Default controller set.
INFO - 2020-06-24 14:58:18 --> Router Class Initialized
INFO - 2020-06-24 14:58:18 --> Plain_Router Class Initialized
INFO - 2020-06-24 14:58:18 --> Output Class Initialized
INFO - 2020-06-24 14:58:18 --> Security Class Initialized
DEBUG - 2020-06-24 14:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 14:58:18 --> Input Class Initialized
INFO - 2020-06-24 14:58:18 --> Language Class Initialized
INFO - 2020-06-24 14:58:18 --> Loader Class Initialized
INFO - 2020-06-24 14:58:18 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 14:58:18 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 14:58:18 --> Helper loaded: data_helper
INFO - 2020-06-24 14:58:18 --> Helper loaded: hash_helper
INFO - 2020-06-24 14:58:18 --> Helper loaded: validation_helper
INFO - 2020-06-24 14:58:18 --> Helper loaded: view_helper
INFO - 2020-06-24 14:58:18 --> Helper loaded: url_helper
INFO - 2020-06-24 14:58:18 --> Database Driver Class Initialized
INFO - 2020-06-24 14:58:18 --> Controller Class Initialized
INFO - 2020-06-24 14:58:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 14:58:18 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 14:58:18 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 14:58:18 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 14:58:18 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:58:18 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 14:58:18 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:58:18 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 14:58:18 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 14:58:18 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 14:58:18 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 14:58:18 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 14:58:18 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 14:58:18 --> Final output sent to browser
DEBUG - 2020-06-24 14:58:18 --> Total execution time: 0.1918
INFO - 2020-06-24 15:03:19 --> Config Class Initialized
INFO - 2020-06-24 15:03:19 --> Plain_Config Class Initialized
INFO - 2020-06-24 15:03:19 --> Hooks Class Initialized
INFO - 2020-06-24 15:03:19 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 15:03:19 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 15:03:19 --> UTF-8 Support Disabled
INFO - 2020-06-24 15:03:19 --> Utf8 Class Initialized
INFO - 2020-06-24 15:03:19 --> URI Class Initialized
DEBUG - 2020-06-24 15:03:19 --> No URI present. Default controller set.
INFO - 2020-06-24 15:03:19 --> Router Class Initialized
INFO - 2020-06-24 15:03:19 --> Plain_Router Class Initialized
INFO - 2020-06-24 15:03:19 --> Output Class Initialized
INFO - 2020-06-24 15:03:19 --> Security Class Initialized
DEBUG - 2020-06-24 15:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 15:03:19 --> Input Class Initialized
INFO - 2020-06-24 15:03:19 --> Language Class Initialized
INFO - 2020-06-24 15:03:19 --> Loader Class Initialized
INFO - 2020-06-24 15:03:19 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 15:03:19 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 15:03:19 --> Helper loaded: data_helper
INFO - 2020-06-24 15:03:19 --> Helper loaded: hash_helper
INFO - 2020-06-24 15:03:19 --> Helper loaded: validation_helper
INFO - 2020-06-24 15:03:19 --> Helper loaded: view_helper
INFO - 2020-06-24 15:03:19 --> Helper loaded: url_helper
INFO - 2020-06-24 15:03:19 --> Database Driver Class Initialized
INFO - 2020-06-24 15:03:19 --> Controller Class Initialized
INFO - 2020-06-24 15:03:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 15:03:19 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 15:03:19 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 15:03:19 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 15:03:19 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:03:19 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 15:03:19 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:03:19 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:03:19 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:03:19 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 15:03:19 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 15:03:19 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 15:03:19 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 15:03:19 --> Final output sent to browser
DEBUG - 2020-06-24 15:03:19 --> Total execution time: 0.1908
INFO - 2020-06-24 15:08:20 --> Config Class Initialized
INFO - 2020-06-24 15:08:20 --> Plain_Config Class Initialized
INFO - 2020-06-24 15:08:20 --> Hooks Class Initialized
INFO - 2020-06-24 15:08:20 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 15:08:20 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 15:08:20 --> UTF-8 Support Disabled
INFO - 2020-06-24 15:08:20 --> Utf8 Class Initialized
INFO - 2020-06-24 15:08:20 --> URI Class Initialized
DEBUG - 2020-06-24 15:08:20 --> No URI present. Default controller set.
INFO - 2020-06-24 15:08:20 --> Router Class Initialized
INFO - 2020-06-24 15:08:20 --> Plain_Router Class Initialized
INFO - 2020-06-24 15:08:20 --> Output Class Initialized
INFO - 2020-06-24 15:08:20 --> Security Class Initialized
DEBUG - 2020-06-24 15:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 15:08:20 --> Input Class Initialized
INFO - 2020-06-24 15:08:20 --> Language Class Initialized
INFO - 2020-06-24 15:08:20 --> Loader Class Initialized
INFO - 2020-06-24 15:08:20 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 15:08:20 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 15:08:20 --> Helper loaded: data_helper
INFO - 2020-06-24 15:08:20 --> Helper loaded: hash_helper
INFO - 2020-06-24 15:08:20 --> Helper loaded: validation_helper
INFO - 2020-06-24 15:08:20 --> Helper loaded: view_helper
INFO - 2020-06-24 15:08:20 --> Helper loaded: url_helper
INFO - 2020-06-24 15:08:20 --> Database Driver Class Initialized
INFO - 2020-06-24 15:08:20 --> Controller Class Initialized
INFO - 2020-06-24 15:08:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 15:08:20 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 15:08:20 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 15:08:20 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 15:08:20 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:08:20 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 15:08:20 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:08:20 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:08:20 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:08:20 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 15:08:20 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 15:08:20 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 15:08:20 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 15:08:20 --> Final output sent to browser
DEBUG - 2020-06-24 15:08:20 --> Total execution time: 0.1905
INFO - 2020-06-24 15:13:21 --> Config Class Initialized
INFO - 2020-06-24 15:13:21 --> Plain_Config Class Initialized
INFO - 2020-06-24 15:13:21 --> Hooks Class Initialized
INFO - 2020-06-24 15:13:21 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 15:13:21 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 15:13:21 --> UTF-8 Support Disabled
INFO - 2020-06-24 15:13:21 --> Utf8 Class Initialized
INFO - 2020-06-24 15:13:21 --> URI Class Initialized
DEBUG - 2020-06-24 15:13:21 --> No URI present. Default controller set.
INFO - 2020-06-24 15:13:21 --> Router Class Initialized
INFO - 2020-06-24 15:13:21 --> Plain_Router Class Initialized
INFO - 2020-06-24 15:13:21 --> Output Class Initialized
INFO - 2020-06-24 15:13:21 --> Security Class Initialized
DEBUG - 2020-06-24 15:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 15:13:21 --> Input Class Initialized
INFO - 2020-06-24 15:13:21 --> Language Class Initialized
INFO - 2020-06-24 15:13:21 --> Loader Class Initialized
INFO - 2020-06-24 15:13:21 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 15:13:21 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 15:13:21 --> Helper loaded: data_helper
INFO - 2020-06-24 15:13:21 --> Helper loaded: hash_helper
INFO - 2020-06-24 15:13:21 --> Helper loaded: validation_helper
INFO - 2020-06-24 15:13:21 --> Helper loaded: view_helper
INFO - 2020-06-24 15:13:21 --> Helper loaded: url_helper
INFO - 2020-06-24 15:13:21 --> Database Driver Class Initialized
INFO - 2020-06-24 15:13:21 --> Controller Class Initialized
INFO - 2020-06-24 15:13:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 15:13:21 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 15:13:21 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 15:13:21 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 15:13:21 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:13:21 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 15:13:21 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:13:21 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:13:21 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:13:21 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 15:13:21 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 15:13:21 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 15:13:21 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 15:13:21 --> Final output sent to browser
DEBUG - 2020-06-24 15:13:21 --> Total execution time: 0.2221
INFO - 2020-06-24 15:18:22 --> Config Class Initialized
INFO - 2020-06-24 15:18:22 --> Plain_Config Class Initialized
INFO - 2020-06-24 15:18:22 --> Hooks Class Initialized
INFO - 2020-06-24 15:18:22 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 15:18:22 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 15:18:22 --> UTF-8 Support Disabled
INFO - 2020-06-24 15:18:22 --> Utf8 Class Initialized
INFO - 2020-06-24 15:18:22 --> URI Class Initialized
DEBUG - 2020-06-24 15:18:22 --> No URI present. Default controller set.
INFO - 2020-06-24 15:18:22 --> Router Class Initialized
INFO - 2020-06-24 15:18:22 --> Plain_Router Class Initialized
INFO - 2020-06-24 15:18:22 --> Output Class Initialized
INFO - 2020-06-24 15:18:22 --> Security Class Initialized
DEBUG - 2020-06-24 15:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 15:18:22 --> Input Class Initialized
INFO - 2020-06-24 15:18:22 --> Language Class Initialized
INFO - 2020-06-24 15:18:22 --> Loader Class Initialized
INFO - 2020-06-24 15:18:22 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 15:18:22 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 15:18:22 --> Helper loaded: data_helper
INFO - 2020-06-24 15:18:22 --> Helper loaded: hash_helper
INFO - 2020-06-24 15:18:22 --> Helper loaded: validation_helper
INFO - 2020-06-24 15:18:22 --> Helper loaded: view_helper
INFO - 2020-06-24 15:18:22 --> Helper loaded: url_helper
INFO - 2020-06-24 15:18:22 --> Database Driver Class Initialized
INFO - 2020-06-24 15:18:22 --> Controller Class Initialized
INFO - 2020-06-24 15:18:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 15:18:22 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 15:18:22 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 15:18:22 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 15:18:22 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:18:22 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 15:18:22 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:18:22 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:18:22 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:18:22 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 15:18:22 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 15:18:22 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 15:18:22 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 15:18:22 --> Final output sent to browser
DEBUG - 2020-06-24 15:18:22 --> Total execution time: 0.2082
INFO - 2020-06-24 15:23:22 --> Config Class Initialized
INFO - 2020-06-24 15:23:22 --> Plain_Config Class Initialized
INFO - 2020-06-24 15:23:22 --> Hooks Class Initialized
INFO - 2020-06-24 15:23:22 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 15:23:22 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 15:23:22 --> UTF-8 Support Disabled
INFO - 2020-06-24 15:23:22 --> Utf8 Class Initialized
INFO - 2020-06-24 15:23:22 --> URI Class Initialized
DEBUG - 2020-06-24 15:23:22 --> No URI present. Default controller set.
INFO - 2020-06-24 15:23:22 --> Router Class Initialized
INFO - 2020-06-24 15:23:22 --> Plain_Router Class Initialized
INFO - 2020-06-24 15:23:22 --> Output Class Initialized
INFO - 2020-06-24 15:23:22 --> Security Class Initialized
DEBUG - 2020-06-24 15:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 15:23:22 --> Input Class Initialized
INFO - 2020-06-24 15:23:22 --> Language Class Initialized
INFO - 2020-06-24 15:23:22 --> Loader Class Initialized
INFO - 2020-06-24 15:23:22 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 15:23:22 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 15:23:22 --> Helper loaded: data_helper
INFO - 2020-06-24 15:23:22 --> Helper loaded: hash_helper
INFO - 2020-06-24 15:23:22 --> Helper loaded: validation_helper
INFO - 2020-06-24 15:23:22 --> Helper loaded: view_helper
INFO - 2020-06-24 15:23:22 --> Helper loaded: url_helper
INFO - 2020-06-24 15:23:22 --> Database Driver Class Initialized
INFO - 2020-06-24 15:23:22 --> Controller Class Initialized
INFO - 2020-06-24 15:23:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 15:23:22 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 15:23:22 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 15:23:22 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 15:23:22 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:23:22 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 15:23:22 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:23:22 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:23:22 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:23:22 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 15:23:22 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 15:23:22 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 15:23:22 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 15:23:22 --> Final output sent to browser
DEBUG - 2020-06-24 15:23:22 --> Total execution time: 0.2206
INFO - 2020-06-24 15:28:23 --> Config Class Initialized
INFO - 2020-06-24 15:28:23 --> Plain_Config Class Initialized
INFO - 2020-06-24 15:28:23 --> Hooks Class Initialized
INFO - 2020-06-24 15:28:23 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 15:28:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 15:28:23 --> UTF-8 Support Disabled
INFO - 2020-06-24 15:28:23 --> Utf8 Class Initialized
INFO - 2020-06-24 15:28:23 --> URI Class Initialized
DEBUG - 2020-06-24 15:28:23 --> No URI present. Default controller set.
INFO - 2020-06-24 15:28:23 --> Router Class Initialized
INFO - 2020-06-24 15:28:23 --> Plain_Router Class Initialized
INFO - 2020-06-24 15:28:23 --> Output Class Initialized
INFO - 2020-06-24 15:28:23 --> Security Class Initialized
DEBUG - 2020-06-24 15:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 15:28:23 --> Input Class Initialized
INFO - 2020-06-24 15:28:23 --> Language Class Initialized
INFO - 2020-06-24 15:28:24 --> Loader Class Initialized
INFO - 2020-06-24 15:28:24 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 15:28:24 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 15:28:24 --> Helper loaded: data_helper
INFO - 2020-06-24 15:28:24 --> Helper loaded: hash_helper
INFO - 2020-06-24 15:28:24 --> Helper loaded: validation_helper
INFO - 2020-06-24 15:28:24 --> Helper loaded: view_helper
INFO - 2020-06-24 15:28:24 --> Helper loaded: url_helper
INFO - 2020-06-24 15:28:24 --> Database Driver Class Initialized
INFO - 2020-06-24 15:28:24 --> Controller Class Initialized
INFO - 2020-06-24 15:28:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 15:28:24 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 15:28:24 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 15:28:24 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 15:28:24 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:28:24 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 15:28:24 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:28:24 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:28:24 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:28:24 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 15:28:24 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 15:28:24 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 15:28:24 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 15:28:24 --> Final output sent to browser
DEBUG - 2020-06-24 15:28:24 --> Total execution time: 0.2126
INFO - 2020-06-24 15:33:24 --> Config Class Initialized
INFO - 2020-06-24 15:33:24 --> Plain_Config Class Initialized
INFO - 2020-06-24 15:33:24 --> Hooks Class Initialized
INFO - 2020-06-24 15:33:24 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 15:33:24 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 15:33:24 --> UTF-8 Support Disabled
INFO - 2020-06-24 15:33:24 --> Utf8 Class Initialized
INFO - 2020-06-24 15:33:24 --> URI Class Initialized
DEBUG - 2020-06-24 15:33:24 --> No URI present. Default controller set.
INFO - 2020-06-24 15:33:24 --> Router Class Initialized
INFO - 2020-06-24 15:33:24 --> Plain_Router Class Initialized
INFO - 2020-06-24 15:33:24 --> Output Class Initialized
INFO - 2020-06-24 15:33:24 --> Security Class Initialized
DEBUG - 2020-06-24 15:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 15:33:24 --> Input Class Initialized
INFO - 2020-06-24 15:33:24 --> Language Class Initialized
INFO - 2020-06-24 15:33:24 --> Loader Class Initialized
INFO - 2020-06-24 15:33:24 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 15:33:24 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 15:33:24 --> Helper loaded: data_helper
INFO - 2020-06-24 15:33:24 --> Helper loaded: hash_helper
INFO - 2020-06-24 15:33:24 --> Helper loaded: validation_helper
INFO - 2020-06-24 15:33:24 --> Helper loaded: view_helper
INFO - 2020-06-24 15:33:24 --> Helper loaded: url_helper
INFO - 2020-06-24 15:33:24 --> Database Driver Class Initialized
INFO - 2020-06-24 15:33:24 --> Controller Class Initialized
INFO - 2020-06-24 15:33:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 15:33:24 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 15:33:24 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 15:33:24 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 15:33:24 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:33:24 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 15:33:24 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:33:24 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:33:24 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:33:24 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 15:33:24 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 15:33:24 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 15:33:24 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 15:33:24 --> Final output sent to browser
DEBUG - 2020-06-24 15:33:24 --> Total execution time: 0.1940
INFO - 2020-06-24 15:38:25 --> Config Class Initialized
INFO - 2020-06-24 15:38:25 --> Plain_Config Class Initialized
INFO - 2020-06-24 15:38:25 --> Hooks Class Initialized
INFO - 2020-06-24 15:38:25 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 15:38:25 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 15:38:25 --> UTF-8 Support Disabled
INFO - 2020-06-24 15:38:25 --> Utf8 Class Initialized
INFO - 2020-06-24 15:38:25 --> URI Class Initialized
DEBUG - 2020-06-24 15:38:25 --> No URI present. Default controller set.
INFO - 2020-06-24 15:38:25 --> Router Class Initialized
INFO - 2020-06-24 15:38:25 --> Plain_Router Class Initialized
INFO - 2020-06-24 15:38:25 --> Output Class Initialized
INFO - 2020-06-24 15:38:25 --> Security Class Initialized
DEBUG - 2020-06-24 15:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 15:38:25 --> Input Class Initialized
INFO - 2020-06-24 15:38:25 --> Language Class Initialized
INFO - 2020-06-24 15:38:25 --> Loader Class Initialized
INFO - 2020-06-24 15:38:25 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 15:38:25 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 15:38:25 --> Helper loaded: data_helper
INFO - 2020-06-24 15:38:25 --> Helper loaded: hash_helper
INFO - 2020-06-24 15:38:25 --> Helper loaded: validation_helper
INFO - 2020-06-24 15:38:25 --> Helper loaded: view_helper
INFO - 2020-06-24 15:38:25 --> Helper loaded: url_helper
INFO - 2020-06-24 15:38:25 --> Database Driver Class Initialized
INFO - 2020-06-24 15:38:25 --> Controller Class Initialized
INFO - 2020-06-24 15:38:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 15:38:25 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 15:38:25 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 15:38:25 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 15:38:25 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:38:25 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 15:38:25 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:38:25 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:38:25 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:38:25 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 15:38:25 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 15:38:25 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 15:38:25 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 15:38:25 --> Final output sent to browser
DEBUG - 2020-06-24 15:38:25 --> Total execution time: 0.2086
INFO - 2020-06-24 15:43:25 --> Config Class Initialized
INFO - 2020-06-24 15:43:25 --> Plain_Config Class Initialized
INFO - 2020-06-24 15:43:25 --> Hooks Class Initialized
INFO - 2020-06-24 15:43:25 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 15:43:25 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 15:43:25 --> UTF-8 Support Disabled
INFO - 2020-06-24 15:43:25 --> Utf8 Class Initialized
INFO - 2020-06-24 15:43:25 --> URI Class Initialized
DEBUG - 2020-06-24 15:43:25 --> No URI present. Default controller set.
INFO - 2020-06-24 15:43:25 --> Router Class Initialized
INFO - 2020-06-24 15:43:25 --> Plain_Router Class Initialized
INFO - 2020-06-24 15:43:25 --> Output Class Initialized
INFO - 2020-06-24 15:43:26 --> Security Class Initialized
DEBUG - 2020-06-24 15:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 15:43:26 --> Input Class Initialized
INFO - 2020-06-24 15:43:26 --> Language Class Initialized
INFO - 2020-06-24 15:43:26 --> Loader Class Initialized
INFO - 2020-06-24 15:43:26 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 15:43:26 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 15:43:26 --> Helper loaded: data_helper
INFO - 2020-06-24 15:43:26 --> Helper loaded: hash_helper
INFO - 2020-06-24 15:43:26 --> Helper loaded: validation_helper
INFO - 2020-06-24 15:43:26 --> Helper loaded: view_helper
INFO - 2020-06-24 15:43:26 --> Helper loaded: url_helper
INFO - 2020-06-24 15:43:26 --> Database Driver Class Initialized
INFO - 2020-06-24 15:43:26 --> Controller Class Initialized
INFO - 2020-06-24 15:43:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 15:43:26 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 15:43:26 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 15:43:26 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 15:43:26 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:43:26 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 15:43:26 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:43:26 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:43:26 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:43:26 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 15:43:26 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 15:43:26 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 15:43:26 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 15:43:26 --> Final output sent to browser
DEBUG - 2020-06-24 15:43:26 --> Total execution time: 0.1911
INFO - 2020-06-24 15:48:43 --> Config Class Initialized
INFO - 2020-06-24 15:48:43 --> Plain_Config Class Initialized
INFO - 2020-06-24 15:48:43 --> Hooks Class Initialized
INFO - 2020-06-24 15:48:43 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 15:48:43 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 15:48:43 --> UTF-8 Support Disabled
INFO - 2020-06-24 15:48:43 --> Utf8 Class Initialized
INFO - 2020-06-24 15:48:43 --> URI Class Initialized
DEBUG - 2020-06-24 15:48:43 --> No URI present. Default controller set.
INFO - 2020-06-24 15:48:43 --> Router Class Initialized
INFO - 2020-06-24 15:48:43 --> Plain_Router Class Initialized
INFO - 2020-06-24 15:48:43 --> Output Class Initialized
INFO - 2020-06-24 15:48:43 --> Security Class Initialized
DEBUG - 2020-06-24 15:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 15:48:43 --> Input Class Initialized
INFO - 2020-06-24 15:48:43 --> Language Class Initialized
INFO - 2020-06-24 15:48:43 --> Loader Class Initialized
INFO - 2020-06-24 15:48:43 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 15:48:43 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 15:48:43 --> Helper loaded: data_helper
INFO - 2020-06-24 15:48:43 --> Helper loaded: hash_helper
INFO - 2020-06-24 15:48:43 --> Helper loaded: validation_helper
INFO - 2020-06-24 15:48:43 --> Helper loaded: view_helper
INFO - 2020-06-24 15:48:43 --> Helper loaded: url_helper
INFO - 2020-06-24 15:48:43 --> Database Driver Class Initialized
INFO - 2020-06-24 15:48:43 --> Controller Class Initialized
INFO - 2020-06-24 15:48:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 15:48:43 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 15:48:43 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 15:48:43 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 15:48:43 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:48:43 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 15:48:43 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:48:43 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:48:43 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:48:43 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 15:48:43 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 15:48:43 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 15:48:43 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 15:48:43 --> Final output sent to browser
DEBUG - 2020-06-24 15:48:43 --> Total execution time: 0.1885
INFO - 2020-06-24 15:53:44 --> Config Class Initialized
INFO - 2020-06-24 15:53:44 --> Plain_Config Class Initialized
INFO - 2020-06-24 15:53:44 --> Hooks Class Initialized
INFO - 2020-06-24 15:53:44 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 15:53:44 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 15:53:44 --> UTF-8 Support Disabled
INFO - 2020-06-24 15:53:44 --> Utf8 Class Initialized
INFO - 2020-06-24 15:53:44 --> URI Class Initialized
DEBUG - 2020-06-24 15:53:44 --> No URI present. Default controller set.
INFO - 2020-06-24 15:53:44 --> Router Class Initialized
INFO - 2020-06-24 15:53:44 --> Plain_Router Class Initialized
INFO - 2020-06-24 15:53:44 --> Output Class Initialized
INFO - 2020-06-24 15:53:44 --> Security Class Initialized
DEBUG - 2020-06-24 15:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 15:53:44 --> Input Class Initialized
INFO - 2020-06-24 15:53:44 --> Language Class Initialized
INFO - 2020-06-24 15:53:44 --> Loader Class Initialized
INFO - 2020-06-24 15:53:44 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 15:53:44 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 15:53:44 --> Helper loaded: data_helper
INFO - 2020-06-24 15:53:44 --> Helper loaded: hash_helper
INFO - 2020-06-24 15:53:44 --> Helper loaded: validation_helper
INFO - 2020-06-24 15:53:44 --> Helper loaded: view_helper
INFO - 2020-06-24 15:53:44 --> Helper loaded: url_helper
INFO - 2020-06-24 15:53:44 --> Database Driver Class Initialized
INFO - 2020-06-24 15:53:44 --> Controller Class Initialized
INFO - 2020-06-24 15:53:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 15:53:44 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 15:53:44 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 15:53:44 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 15:53:44 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:53:44 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 15:53:44 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:53:44 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:53:44 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:53:44 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 15:53:44 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 15:53:44 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 15:53:44 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 15:53:44 --> Final output sent to browser
DEBUG - 2020-06-24 15:53:44 --> Total execution time: 0.1752
INFO - 2020-06-24 15:58:44 --> Config Class Initialized
INFO - 2020-06-24 15:58:44 --> Plain_Config Class Initialized
INFO - 2020-06-24 15:58:44 --> Hooks Class Initialized
INFO - 2020-06-24 15:58:44 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 15:58:44 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 15:58:44 --> UTF-8 Support Disabled
INFO - 2020-06-24 15:58:44 --> Utf8 Class Initialized
INFO - 2020-06-24 15:58:44 --> URI Class Initialized
DEBUG - 2020-06-24 15:58:44 --> No URI present. Default controller set.
INFO - 2020-06-24 15:58:44 --> Router Class Initialized
INFO - 2020-06-24 15:58:44 --> Plain_Router Class Initialized
INFO - 2020-06-24 15:58:44 --> Output Class Initialized
INFO - 2020-06-24 15:58:44 --> Security Class Initialized
DEBUG - 2020-06-24 15:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 15:58:44 --> Input Class Initialized
INFO - 2020-06-24 15:58:44 --> Language Class Initialized
INFO - 2020-06-24 15:58:44 --> Loader Class Initialized
INFO - 2020-06-24 15:58:44 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 15:58:44 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 15:58:44 --> Helper loaded: data_helper
INFO - 2020-06-24 15:58:44 --> Helper loaded: hash_helper
INFO - 2020-06-24 15:58:44 --> Helper loaded: validation_helper
INFO - 2020-06-24 15:58:44 --> Helper loaded: view_helper
INFO - 2020-06-24 15:58:44 --> Helper loaded: url_helper
INFO - 2020-06-24 15:58:44 --> Database Driver Class Initialized
INFO - 2020-06-24 15:58:44 --> Controller Class Initialized
INFO - 2020-06-24 15:58:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 15:58:44 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 15:58:44 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 15:58:44 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 15:58:44 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:58:44 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 15:58:44 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:58:44 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 15:58:44 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 15:58:44 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 15:58:44 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 15:58:44 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 15:58:44 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 15:58:44 --> Final output sent to browser
DEBUG - 2020-06-24 15:58:44 --> Total execution time: 0.1974
INFO - 2020-06-24 16:04:01 --> Config Class Initialized
INFO - 2020-06-24 16:04:01 --> Plain_Config Class Initialized
INFO - 2020-06-24 16:04:01 --> Hooks Class Initialized
INFO - 2020-06-24 16:04:01 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 16:04:01 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 16:04:01 --> UTF-8 Support Disabled
INFO - 2020-06-24 16:04:01 --> Utf8 Class Initialized
INFO - 2020-06-24 16:04:02 --> URI Class Initialized
DEBUG - 2020-06-24 16:04:02 --> No URI present. Default controller set.
INFO - 2020-06-24 16:04:02 --> Router Class Initialized
INFO - 2020-06-24 16:04:02 --> Plain_Router Class Initialized
INFO - 2020-06-24 16:04:02 --> Output Class Initialized
INFO - 2020-06-24 16:04:02 --> Security Class Initialized
DEBUG - 2020-06-24 16:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 16:04:02 --> Input Class Initialized
INFO - 2020-06-24 16:04:02 --> Language Class Initialized
INFO - 2020-06-24 16:04:02 --> Loader Class Initialized
INFO - 2020-06-24 16:04:02 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 16:04:02 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 16:04:02 --> Helper loaded: data_helper
INFO - 2020-06-24 16:04:02 --> Helper loaded: hash_helper
INFO - 2020-06-24 16:04:02 --> Helper loaded: validation_helper
INFO - 2020-06-24 16:04:02 --> Helper loaded: view_helper
INFO - 2020-06-24 16:04:02 --> Helper loaded: url_helper
INFO - 2020-06-24 16:04:02 --> Database Driver Class Initialized
INFO - 2020-06-24 16:04:02 --> Controller Class Initialized
INFO - 2020-06-24 16:04:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 16:04:02 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 16:04:02 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 16:04:02 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 16:04:02 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:04:02 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 16:04:02 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:04:02 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:04:02 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:04:02 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 16:04:02 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 16:04:02 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 16:04:02 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 16:04:02 --> Final output sent to browser
DEBUG - 2020-06-24 16:04:02 --> Total execution time: 0.1852
INFO - 2020-06-24 16:09:02 --> Config Class Initialized
INFO - 2020-06-24 16:09:02 --> Plain_Config Class Initialized
INFO - 2020-06-24 16:09:02 --> Hooks Class Initialized
INFO - 2020-06-24 16:09:02 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 16:09:02 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 16:09:02 --> UTF-8 Support Disabled
INFO - 2020-06-24 16:09:02 --> Utf8 Class Initialized
INFO - 2020-06-24 16:09:02 --> URI Class Initialized
DEBUG - 2020-06-24 16:09:02 --> No URI present. Default controller set.
INFO - 2020-06-24 16:09:02 --> Router Class Initialized
INFO - 2020-06-24 16:09:02 --> Plain_Router Class Initialized
INFO - 2020-06-24 16:09:02 --> Output Class Initialized
INFO - 2020-06-24 16:09:02 --> Security Class Initialized
DEBUG - 2020-06-24 16:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 16:09:02 --> Input Class Initialized
INFO - 2020-06-24 16:09:02 --> Language Class Initialized
INFO - 2020-06-24 16:09:02 --> Loader Class Initialized
INFO - 2020-06-24 16:09:02 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 16:09:02 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 16:09:02 --> Helper loaded: data_helper
INFO - 2020-06-24 16:09:02 --> Helper loaded: hash_helper
INFO - 2020-06-24 16:09:02 --> Helper loaded: validation_helper
INFO - 2020-06-24 16:09:03 --> Helper loaded: view_helper
INFO - 2020-06-24 16:09:03 --> Helper loaded: url_helper
INFO - 2020-06-24 16:09:03 --> Database Driver Class Initialized
INFO - 2020-06-24 16:09:03 --> Controller Class Initialized
INFO - 2020-06-24 16:09:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 16:09:03 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 16:09:03 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 16:09:03 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 16:09:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:09:03 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 16:09:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:09:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:09:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:09:03 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 16:09:03 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 16:09:03 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 16:09:03 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 16:09:03 --> Final output sent to browser
DEBUG - 2020-06-24 16:09:03 --> Total execution time: 0.2102
INFO - 2020-06-24 16:14:03 --> Config Class Initialized
INFO - 2020-06-24 16:14:03 --> Plain_Config Class Initialized
INFO - 2020-06-24 16:14:03 --> Hooks Class Initialized
INFO - 2020-06-24 16:14:03 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 16:14:03 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 16:14:03 --> UTF-8 Support Disabled
INFO - 2020-06-24 16:14:03 --> Utf8 Class Initialized
INFO - 2020-06-24 16:14:03 --> URI Class Initialized
DEBUG - 2020-06-24 16:14:03 --> No URI present. Default controller set.
INFO - 2020-06-24 16:14:03 --> Router Class Initialized
INFO - 2020-06-24 16:14:03 --> Plain_Router Class Initialized
INFO - 2020-06-24 16:14:03 --> Output Class Initialized
INFO - 2020-06-24 16:14:03 --> Security Class Initialized
DEBUG - 2020-06-24 16:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 16:14:03 --> Input Class Initialized
INFO - 2020-06-24 16:14:03 --> Language Class Initialized
INFO - 2020-06-24 16:14:03 --> Loader Class Initialized
INFO - 2020-06-24 16:14:03 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 16:14:03 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 16:14:03 --> Helper loaded: data_helper
INFO - 2020-06-24 16:14:03 --> Helper loaded: hash_helper
INFO - 2020-06-24 16:14:03 --> Helper loaded: validation_helper
INFO - 2020-06-24 16:14:03 --> Helper loaded: view_helper
INFO - 2020-06-24 16:14:03 --> Helper loaded: url_helper
INFO - 2020-06-24 16:14:03 --> Database Driver Class Initialized
INFO - 2020-06-24 16:14:03 --> Controller Class Initialized
INFO - 2020-06-24 16:14:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 16:14:03 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 16:14:03 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 16:14:03 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 16:14:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:14:03 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 16:14:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:14:03 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:14:03 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:14:03 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 16:14:03 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 16:14:03 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 16:14:03 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 16:14:03 --> Final output sent to browser
DEBUG - 2020-06-24 16:14:03 --> Total execution time: 0.2049
INFO - 2020-06-24 16:19:04 --> Config Class Initialized
INFO - 2020-06-24 16:19:04 --> Plain_Config Class Initialized
INFO - 2020-06-24 16:19:04 --> Hooks Class Initialized
INFO - 2020-06-24 16:19:04 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 16:19:04 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 16:19:04 --> UTF-8 Support Disabled
INFO - 2020-06-24 16:19:04 --> Utf8 Class Initialized
INFO - 2020-06-24 16:19:04 --> URI Class Initialized
DEBUG - 2020-06-24 16:19:04 --> No URI present. Default controller set.
INFO - 2020-06-24 16:19:04 --> Router Class Initialized
INFO - 2020-06-24 16:19:04 --> Plain_Router Class Initialized
INFO - 2020-06-24 16:19:04 --> Output Class Initialized
INFO - 2020-06-24 16:19:04 --> Security Class Initialized
DEBUG - 2020-06-24 16:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 16:19:04 --> Input Class Initialized
INFO - 2020-06-24 16:19:04 --> Language Class Initialized
INFO - 2020-06-24 16:19:04 --> Loader Class Initialized
INFO - 2020-06-24 16:19:04 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 16:19:04 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 16:19:04 --> Helper loaded: data_helper
INFO - 2020-06-24 16:19:04 --> Helper loaded: hash_helper
INFO - 2020-06-24 16:19:04 --> Helper loaded: validation_helper
INFO - 2020-06-24 16:19:04 --> Helper loaded: view_helper
INFO - 2020-06-24 16:19:04 --> Helper loaded: url_helper
INFO - 2020-06-24 16:19:04 --> Database Driver Class Initialized
INFO - 2020-06-24 16:19:04 --> Controller Class Initialized
INFO - 2020-06-24 16:19:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 16:19:04 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 16:19:04 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 16:19:04 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 16:19:04 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:19:04 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 16:19:04 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:19:04 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:19:04 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:19:04 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 16:19:04 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 16:19:04 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 16:19:04 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 16:19:04 --> Final output sent to browser
DEBUG - 2020-06-24 16:19:04 --> Total execution time: 0.2205
INFO - 2020-06-24 16:24:04 --> Config Class Initialized
INFO - 2020-06-24 16:24:04 --> Plain_Config Class Initialized
INFO - 2020-06-24 16:24:04 --> Hooks Class Initialized
INFO - 2020-06-24 16:24:04 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 16:24:04 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 16:24:04 --> UTF-8 Support Disabled
INFO - 2020-06-24 16:24:04 --> Utf8 Class Initialized
INFO - 2020-06-24 16:24:04 --> URI Class Initialized
DEBUG - 2020-06-24 16:24:04 --> No URI present. Default controller set.
INFO - 2020-06-24 16:24:04 --> Router Class Initialized
INFO - 2020-06-24 16:24:04 --> Plain_Router Class Initialized
INFO - 2020-06-24 16:24:04 --> Output Class Initialized
INFO - 2020-06-24 16:24:04 --> Security Class Initialized
DEBUG - 2020-06-24 16:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 16:24:04 --> Input Class Initialized
INFO - 2020-06-24 16:24:04 --> Language Class Initialized
INFO - 2020-06-24 16:24:05 --> Loader Class Initialized
INFO - 2020-06-24 16:24:05 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 16:24:05 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 16:24:05 --> Helper loaded: data_helper
INFO - 2020-06-24 16:24:05 --> Helper loaded: hash_helper
INFO - 2020-06-24 16:24:05 --> Helper loaded: validation_helper
INFO - 2020-06-24 16:24:05 --> Helper loaded: view_helper
INFO - 2020-06-24 16:24:05 --> Helper loaded: url_helper
INFO - 2020-06-24 16:24:05 --> Database Driver Class Initialized
INFO - 2020-06-24 16:24:05 --> Controller Class Initialized
INFO - 2020-06-24 16:24:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 16:24:05 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 16:24:05 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 16:24:05 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 16:24:05 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:24:05 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 16:24:05 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:24:05 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:24:05 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:24:05 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 16:24:05 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 16:24:05 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 16:24:05 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 16:24:05 --> Final output sent to browser
DEBUG - 2020-06-24 16:24:05 --> Total execution time: 0.2147
INFO - 2020-06-24 16:29:05 --> Config Class Initialized
INFO - 2020-06-24 16:29:05 --> Plain_Config Class Initialized
INFO - 2020-06-24 16:29:05 --> Hooks Class Initialized
INFO - 2020-06-24 16:29:05 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 16:29:05 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 16:29:05 --> UTF-8 Support Disabled
INFO - 2020-06-24 16:29:05 --> Utf8 Class Initialized
INFO - 2020-06-24 16:29:05 --> URI Class Initialized
DEBUG - 2020-06-24 16:29:05 --> No URI present. Default controller set.
INFO - 2020-06-24 16:29:05 --> Router Class Initialized
INFO - 2020-06-24 16:29:05 --> Plain_Router Class Initialized
INFO - 2020-06-24 16:29:05 --> Output Class Initialized
INFO - 2020-06-24 16:29:05 --> Security Class Initialized
DEBUG - 2020-06-24 16:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 16:29:05 --> Input Class Initialized
INFO - 2020-06-24 16:29:05 --> Language Class Initialized
INFO - 2020-06-24 16:29:05 --> Loader Class Initialized
INFO - 2020-06-24 16:29:05 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 16:29:05 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 16:29:05 --> Helper loaded: data_helper
INFO - 2020-06-24 16:29:05 --> Helper loaded: hash_helper
INFO - 2020-06-24 16:29:05 --> Helper loaded: validation_helper
INFO - 2020-06-24 16:29:05 --> Helper loaded: view_helper
INFO - 2020-06-24 16:29:06 --> Helper loaded: url_helper
INFO - 2020-06-24 16:29:06 --> Database Driver Class Initialized
INFO - 2020-06-24 16:29:06 --> Controller Class Initialized
INFO - 2020-06-24 16:29:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 16:29:06 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 16:29:06 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 16:29:06 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 16:29:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:29:06 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 16:29:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:29:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:29:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:29:06 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 16:29:06 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 16:29:06 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 16:29:06 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 16:29:06 --> Final output sent to browser
DEBUG - 2020-06-24 16:29:06 --> Total execution time: 0.2442
INFO - 2020-06-24 16:34:06 --> Config Class Initialized
INFO - 2020-06-24 16:34:06 --> Plain_Config Class Initialized
INFO - 2020-06-24 16:34:06 --> Hooks Class Initialized
INFO - 2020-06-24 16:34:06 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 16:34:06 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 16:34:06 --> UTF-8 Support Disabled
INFO - 2020-06-24 16:34:06 --> Utf8 Class Initialized
INFO - 2020-06-24 16:34:06 --> URI Class Initialized
DEBUG - 2020-06-24 16:34:06 --> No URI present. Default controller set.
INFO - 2020-06-24 16:34:06 --> Router Class Initialized
INFO - 2020-06-24 16:34:06 --> Plain_Router Class Initialized
INFO - 2020-06-24 16:34:06 --> Output Class Initialized
INFO - 2020-06-24 16:34:06 --> Security Class Initialized
DEBUG - 2020-06-24 16:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 16:34:06 --> Input Class Initialized
INFO - 2020-06-24 16:34:06 --> Language Class Initialized
INFO - 2020-06-24 16:34:06 --> Loader Class Initialized
INFO - 2020-06-24 16:34:06 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 16:34:06 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 16:34:06 --> Helper loaded: data_helper
INFO - 2020-06-24 16:34:06 --> Helper loaded: hash_helper
INFO - 2020-06-24 16:34:06 --> Helper loaded: validation_helper
INFO - 2020-06-24 16:34:06 --> Helper loaded: view_helper
INFO - 2020-06-24 16:34:06 --> Helper loaded: url_helper
INFO - 2020-06-24 16:34:06 --> Database Driver Class Initialized
INFO - 2020-06-24 16:34:06 --> Controller Class Initialized
INFO - 2020-06-24 16:34:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 16:34:06 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 16:34:06 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 16:34:06 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 16:34:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:34:06 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 16:34:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:34:06 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:34:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:34:06 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 16:34:06 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 16:34:06 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 16:34:06 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 16:34:06 --> Final output sent to browser
DEBUG - 2020-06-24 16:34:06 --> Total execution time: 0.2437
INFO - 2020-06-24 16:39:07 --> Config Class Initialized
INFO - 2020-06-24 16:39:07 --> Plain_Config Class Initialized
INFO - 2020-06-24 16:39:07 --> Hooks Class Initialized
INFO - 2020-06-24 16:39:07 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 16:39:07 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 16:39:07 --> UTF-8 Support Disabled
INFO - 2020-06-24 16:39:07 --> Utf8 Class Initialized
INFO - 2020-06-24 16:39:07 --> URI Class Initialized
DEBUG - 2020-06-24 16:39:07 --> No URI present. Default controller set.
INFO - 2020-06-24 16:39:07 --> Router Class Initialized
INFO - 2020-06-24 16:39:07 --> Plain_Router Class Initialized
INFO - 2020-06-24 16:39:07 --> Output Class Initialized
INFO - 2020-06-24 16:39:07 --> Security Class Initialized
DEBUG - 2020-06-24 16:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 16:39:07 --> Input Class Initialized
INFO - 2020-06-24 16:39:07 --> Language Class Initialized
INFO - 2020-06-24 16:39:07 --> Loader Class Initialized
INFO - 2020-06-24 16:39:07 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 16:39:07 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 16:39:07 --> Helper loaded: data_helper
INFO - 2020-06-24 16:39:07 --> Helper loaded: hash_helper
INFO - 2020-06-24 16:39:07 --> Helper loaded: validation_helper
INFO - 2020-06-24 16:39:07 --> Helper loaded: view_helper
INFO - 2020-06-24 16:39:07 --> Helper loaded: url_helper
INFO - 2020-06-24 16:39:07 --> Database Driver Class Initialized
INFO - 2020-06-24 16:39:07 --> Controller Class Initialized
INFO - 2020-06-24 16:39:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 16:39:07 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 16:39:07 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 16:39:07 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 16:39:07 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:39:07 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 16:39:07 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:39:07 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:39:07 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:39:07 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 16:39:07 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 16:39:07 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 16:39:07 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 16:39:07 --> Final output sent to browser
DEBUG - 2020-06-24 16:39:07 --> Total execution time: 0.1890
INFO - 2020-06-24 16:44:07 --> Config Class Initialized
INFO - 2020-06-24 16:44:07 --> Plain_Config Class Initialized
INFO - 2020-06-24 16:44:07 --> Hooks Class Initialized
INFO - 2020-06-24 16:44:07 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 16:44:07 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 16:44:07 --> UTF-8 Support Disabled
INFO - 2020-06-24 16:44:07 --> Utf8 Class Initialized
INFO - 2020-06-24 16:44:07 --> URI Class Initialized
DEBUG - 2020-06-24 16:44:07 --> No URI present. Default controller set.
INFO - 2020-06-24 16:44:07 --> Router Class Initialized
INFO - 2020-06-24 16:44:07 --> Plain_Router Class Initialized
INFO - 2020-06-24 16:44:07 --> Output Class Initialized
INFO - 2020-06-24 16:44:07 --> Security Class Initialized
DEBUG - 2020-06-24 16:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 16:44:07 --> Input Class Initialized
INFO - 2020-06-24 16:44:07 --> Language Class Initialized
INFO - 2020-06-24 16:44:07 --> Loader Class Initialized
INFO - 2020-06-24 16:44:07 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 16:44:07 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 16:44:07 --> Helper loaded: data_helper
INFO - 2020-06-24 16:44:07 --> Helper loaded: hash_helper
INFO - 2020-06-24 16:44:07 --> Helper loaded: validation_helper
INFO - 2020-06-24 16:44:07 --> Helper loaded: view_helper
INFO - 2020-06-24 16:44:07 --> Helper loaded: url_helper
INFO - 2020-06-24 16:44:07 --> Database Driver Class Initialized
INFO - 2020-06-24 16:44:07 --> Controller Class Initialized
INFO - 2020-06-24 16:44:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 16:44:07 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 16:44:07 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 16:44:07 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 16:44:07 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:44:07 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 16:44:07 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:44:07 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:44:07 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:44:07 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 16:44:07 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 16:44:07 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 16:44:07 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 16:44:07 --> Final output sent to browser
DEBUG - 2020-06-24 16:44:07 --> Total execution time: 0.1864
INFO - 2020-06-24 16:49:09 --> Config Class Initialized
INFO - 2020-06-24 16:49:09 --> Plain_Config Class Initialized
INFO - 2020-06-24 16:49:09 --> Hooks Class Initialized
INFO - 2020-06-24 16:49:09 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 16:49:09 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 16:49:10 --> UTF-8 Support Disabled
INFO - 2020-06-24 16:49:10 --> Utf8 Class Initialized
INFO - 2020-06-24 16:49:10 --> URI Class Initialized
DEBUG - 2020-06-24 16:49:10 --> No URI present. Default controller set.
INFO - 2020-06-24 16:49:10 --> Router Class Initialized
INFO - 2020-06-24 16:49:10 --> Plain_Router Class Initialized
INFO - 2020-06-24 16:49:10 --> Output Class Initialized
INFO - 2020-06-24 16:49:10 --> Security Class Initialized
DEBUG - 2020-06-24 16:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 16:49:10 --> Input Class Initialized
INFO - 2020-06-24 16:49:10 --> Language Class Initialized
INFO - 2020-06-24 16:49:10 --> Loader Class Initialized
INFO - 2020-06-24 16:49:10 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 16:49:10 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 16:49:10 --> Helper loaded: data_helper
INFO - 2020-06-24 16:49:10 --> Helper loaded: hash_helper
INFO - 2020-06-24 16:49:10 --> Helper loaded: validation_helper
INFO - 2020-06-24 16:49:10 --> Helper loaded: view_helper
INFO - 2020-06-24 16:49:10 --> Helper loaded: url_helper
INFO - 2020-06-24 16:49:10 --> Database Driver Class Initialized
INFO - 2020-06-24 16:49:10 --> Controller Class Initialized
INFO - 2020-06-24 16:49:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 16:49:10 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 16:49:10 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 16:49:10 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 16:49:10 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:49:10 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 16:49:10 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:49:10 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:49:10 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:49:10 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 16:49:10 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 16:49:10 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 16:49:10 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 16:49:10 --> Final output sent to browser
DEBUG - 2020-06-24 16:49:10 --> Total execution time: 0.2455
INFO - 2020-06-24 16:54:10 --> Config Class Initialized
INFO - 2020-06-24 16:54:10 --> Plain_Config Class Initialized
INFO - 2020-06-24 16:54:10 --> Hooks Class Initialized
INFO - 2020-06-24 16:54:10 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 16:54:10 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 16:54:10 --> UTF-8 Support Disabled
INFO - 2020-06-24 16:54:10 --> Utf8 Class Initialized
INFO - 2020-06-24 16:54:10 --> URI Class Initialized
DEBUG - 2020-06-24 16:54:10 --> No URI present. Default controller set.
INFO - 2020-06-24 16:54:10 --> Router Class Initialized
INFO - 2020-06-24 16:54:10 --> Plain_Router Class Initialized
INFO - 2020-06-24 16:54:10 --> Output Class Initialized
INFO - 2020-06-24 16:54:10 --> Security Class Initialized
DEBUG - 2020-06-24 16:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 16:54:10 --> Input Class Initialized
INFO - 2020-06-24 16:54:10 --> Language Class Initialized
INFO - 2020-06-24 16:54:10 --> Loader Class Initialized
INFO - 2020-06-24 16:54:10 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 16:54:10 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 16:54:10 --> Helper loaded: data_helper
INFO - 2020-06-24 16:54:10 --> Helper loaded: hash_helper
INFO - 2020-06-24 16:54:10 --> Helper loaded: validation_helper
INFO - 2020-06-24 16:54:10 --> Helper loaded: view_helper
INFO - 2020-06-24 16:54:10 --> Helper loaded: url_helper
INFO - 2020-06-24 16:54:10 --> Database Driver Class Initialized
INFO - 2020-06-24 16:54:10 --> Controller Class Initialized
INFO - 2020-06-24 16:54:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 16:54:10 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 16:54:10 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 16:54:10 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 16:54:10 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:54:10 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 16:54:10 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:54:10 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:54:10 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:54:10 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 16:54:10 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 16:54:10 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 16:54:10 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 16:54:10 --> Final output sent to browser
DEBUG - 2020-06-24 16:54:10 --> Total execution time: 0.2303
INFO - 2020-06-24 16:59:11 --> Config Class Initialized
INFO - 2020-06-24 16:59:11 --> Plain_Config Class Initialized
INFO - 2020-06-24 16:59:11 --> Hooks Class Initialized
INFO - 2020-06-24 16:59:11 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 16:59:11 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 16:59:11 --> UTF-8 Support Disabled
INFO - 2020-06-24 16:59:11 --> Utf8 Class Initialized
INFO - 2020-06-24 16:59:11 --> URI Class Initialized
DEBUG - 2020-06-24 16:59:11 --> No URI present. Default controller set.
INFO - 2020-06-24 16:59:11 --> Router Class Initialized
INFO - 2020-06-24 16:59:11 --> Plain_Router Class Initialized
INFO - 2020-06-24 16:59:11 --> Output Class Initialized
INFO - 2020-06-24 16:59:11 --> Security Class Initialized
DEBUG - 2020-06-24 16:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 16:59:11 --> Input Class Initialized
INFO - 2020-06-24 16:59:11 --> Language Class Initialized
INFO - 2020-06-24 16:59:11 --> Loader Class Initialized
INFO - 2020-06-24 16:59:11 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 16:59:11 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 16:59:11 --> Helper loaded: data_helper
INFO - 2020-06-24 16:59:11 --> Helper loaded: hash_helper
INFO - 2020-06-24 16:59:11 --> Helper loaded: validation_helper
INFO - 2020-06-24 16:59:11 --> Helper loaded: view_helper
INFO - 2020-06-24 16:59:11 --> Helper loaded: url_helper
INFO - 2020-06-24 16:59:11 --> Database Driver Class Initialized
INFO - 2020-06-24 16:59:11 --> Controller Class Initialized
INFO - 2020-06-24 16:59:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 16:59:11 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 16:59:11 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 16:59:11 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 16:59:11 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:59:11 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 16:59:11 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:59:11 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 16:59:11 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 16:59:11 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 16:59:11 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 16:59:11 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 16:59:11 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 16:59:11 --> Final output sent to browser
DEBUG - 2020-06-24 16:59:11 --> Total execution time: 0.2254
INFO - 2020-06-24 17:04:13 --> Config Class Initialized
INFO - 2020-06-24 17:04:13 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:04:13 --> Hooks Class Initialized
INFO - 2020-06-24 17:04:13 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:04:13 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:04:13 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:04:13 --> Utf8 Class Initialized
INFO - 2020-06-24 17:04:13 --> URI Class Initialized
DEBUG - 2020-06-24 17:04:13 --> No URI present. Default controller set.
INFO - 2020-06-24 17:04:13 --> Router Class Initialized
INFO - 2020-06-24 17:04:13 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:04:13 --> Output Class Initialized
INFO - 2020-06-24 17:04:13 --> Security Class Initialized
DEBUG - 2020-06-24 17:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:04:13 --> Input Class Initialized
INFO - 2020-06-24 17:04:13 --> Language Class Initialized
INFO - 2020-06-24 17:04:13 --> Loader Class Initialized
INFO - 2020-06-24 17:04:13 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:04:13 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:04:13 --> Helper loaded: data_helper
INFO - 2020-06-24 17:04:13 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:04:13 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:04:13 --> Helper loaded: view_helper
INFO - 2020-06-24 17:04:13 --> Helper loaded: url_helper
INFO - 2020-06-24 17:04:13 --> Database Driver Class Initialized
INFO - 2020-06-24 17:04:13 --> Controller Class Initialized
INFO - 2020-06-24 17:04:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:04:13 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 17:04:13 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 17:04:13 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 17:04:13 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:04:13 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 17:04:13 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:04:13 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:04:13 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:04:13 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 17:04:13 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 17:04:13 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 17:04:13 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 17:04:13 --> Final output sent to browser
DEBUG - 2020-06-24 17:04:13 --> Total execution time: 0.2195
INFO - 2020-06-24 17:09:13 --> Config Class Initialized
INFO - 2020-06-24 17:09:13 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:09:13 --> Hooks Class Initialized
INFO - 2020-06-24 17:09:13 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:09:13 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:09:13 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:09:13 --> Utf8 Class Initialized
INFO - 2020-06-24 17:09:13 --> URI Class Initialized
DEBUG - 2020-06-24 17:09:13 --> No URI present. Default controller set.
INFO - 2020-06-24 17:09:13 --> Router Class Initialized
INFO - 2020-06-24 17:09:13 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:09:13 --> Output Class Initialized
INFO - 2020-06-24 17:09:13 --> Security Class Initialized
DEBUG - 2020-06-24 17:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:09:13 --> Input Class Initialized
INFO - 2020-06-24 17:09:13 --> Language Class Initialized
INFO - 2020-06-24 17:09:13 --> Loader Class Initialized
INFO - 2020-06-24 17:09:13 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:09:13 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:09:13 --> Helper loaded: data_helper
INFO - 2020-06-24 17:09:13 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:09:13 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:09:13 --> Helper loaded: view_helper
INFO - 2020-06-24 17:09:13 --> Helper loaded: url_helper
INFO - 2020-06-24 17:09:13 --> Database Driver Class Initialized
INFO - 2020-06-24 17:09:13 --> Controller Class Initialized
INFO - 2020-06-24 17:09:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:09:13 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 17:09:13 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 17:09:13 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 17:09:13 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:09:13 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 17:09:13 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:09:13 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:09:13 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:09:13 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 17:09:13 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 17:09:13 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 17:09:13 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 17:09:13 --> Final output sent to browser
DEBUG - 2020-06-24 17:09:13 --> Total execution time: 0.2188
INFO - 2020-06-24 17:14:14 --> Config Class Initialized
INFO - 2020-06-24 17:14:14 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:14:14 --> Hooks Class Initialized
INFO - 2020-06-24 17:14:14 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:14:14 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:14:14 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:14:14 --> Utf8 Class Initialized
INFO - 2020-06-24 17:14:14 --> URI Class Initialized
DEBUG - 2020-06-24 17:14:14 --> No URI present. Default controller set.
INFO - 2020-06-24 17:14:14 --> Router Class Initialized
INFO - 2020-06-24 17:14:14 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:14:14 --> Output Class Initialized
INFO - 2020-06-24 17:14:14 --> Security Class Initialized
DEBUG - 2020-06-24 17:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:14:14 --> Input Class Initialized
INFO - 2020-06-24 17:14:14 --> Language Class Initialized
INFO - 2020-06-24 17:14:14 --> Loader Class Initialized
INFO - 2020-06-24 17:14:14 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:14:14 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:14:14 --> Helper loaded: data_helper
INFO - 2020-06-24 17:14:14 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:14:14 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:14:14 --> Helper loaded: view_helper
INFO - 2020-06-24 17:14:14 --> Helper loaded: url_helper
INFO - 2020-06-24 17:14:14 --> Database Driver Class Initialized
INFO - 2020-06-24 17:14:14 --> Controller Class Initialized
INFO - 2020-06-24 17:14:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:14:15 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 17:14:15 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 17:14:15 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 17:14:15 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:14:15 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 17:14:15 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:14:15 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:14:15 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:14:15 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 17:14:15 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 17:14:15 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 17:14:15 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 17:14:15 --> Final output sent to browser
DEBUG - 2020-06-24 17:14:15 --> Total execution time: 0.2128
INFO - 2020-06-24 17:19:15 --> Config Class Initialized
INFO - 2020-06-24 17:19:15 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:19:15 --> Hooks Class Initialized
INFO - 2020-06-24 17:19:15 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:19:15 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:19:15 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:19:15 --> Utf8 Class Initialized
INFO - 2020-06-24 17:19:15 --> URI Class Initialized
DEBUG - 2020-06-24 17:19:15 --> No URI present. Default controller set.
INFO - 2020-06-24 17:19:15 --> Router Class Initialized
INFO - 2020-06-24 17:19:15 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:19:15 --> Output Class Initialized
INFO - 2020-06-24 17:19:15 --> Security Class Initialized
DEBUG - 2020-06-24 17:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:19:15 --> Input Class Initialized
INFO - 2020-06-24 17:19:15 --> Language Class Initialized
INFO - 2020-06-24 17:19:15 --> Loader Class Initialized
INFO - 2020-06-24 17:19:15 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:19:15 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:19:15 --> Helper loaded: data_helper
INFO - 2020-06-24 17:19:15 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:19:15 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:19:15 --> Helper loaded: view_helper
INFO - 2020-06-24 17:19:15 --> Helper loaded: url_helper
INFO - 2020-06-24 17:19:15 --> Database Driver Class Initialized
INFO - 2020-06-24 17:19:15 --> Controller Class Initialized
INFO - 2020-06-24 17:19:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:19:15 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 17:19:15 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 17:19:15 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 17:19:15 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:19:15 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 17:19:15 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:19:15 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:19:15 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:19:15 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 17:19:15 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 17:19:15 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 17:19:15 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 17:19:15 --> Final output sent to browser
DEBUG - 2020-06-24 17:19:15 --> Total execution time: 0.2109
INFO - 2020-06-24 17:24:16 --> Config Class Initialized
INFO - 2020-06-24 17:24:16 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:24:16 --> Hooks Class Initialized
INFO - 2020-06-24 17:24:16 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:24:16 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:24:16 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:24:16 --> Utf8 Class Initialized
INFO - 2020-06-24 17:24:16 --> URI Class Initialized
DEBUG - 2020-06-24 17:24:16 --> No URI present. Default controller set.
INFO - 2020-06-24 17:24:16 --> Router Class Initialized
INFO - 2020-06-24 17:24:16 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:24:16 --> Output Class Initialized
INFO - 2020-06-24 17:24:16 --> Security Class Initialized
DEBUG - 2020-06-24 17:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:24:16 --> Input Class Initialized
INFO - 2020-06-24 17:24:16 --> Language Class Initialized
INFO - 2020-06-24 17:24:16 --> Loader Class Initialized
INFO - 2020-06-24 17:24:16 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:24:16 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:24:16 --> Helper loaded: data_helper
INFO - 2020-06-24 17:24:16 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:24:16 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:24:16 --> Helper loaded: view_helper
INFO - 2020-06-24 17:24:16 --> Helper loaded: url_helper
INFO - 2020-06-24 17:24:16 --> Database Driver Class Initialized
INFO - 2020-06-24 17:24:16 --> Controller Class Initialized
INFO - 2020-06-24 17:24:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:24:16 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 17:24:16 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 17:24:16 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 17:24:16 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:24:16 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 17:24:16 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:24:16 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:24:16 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:24:16 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 17:24:16 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 17:24:16 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 17:24:16 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 17:24:16 --> Final output sent to browser
DEBUG - 2020-06-24 17:24:16 --> Total execution time: 0.1899
INFO - 2020-06-24 17:29:16 --> Config Class Initialized
INFO - 2020-06-24 17:29:16 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:29:16 --> Hooks Class Initialized
INFO - 2020-06-24 17:29:16 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:29:16 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:29:16 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:29:16 --> Utf8 Class Initialized
INFO - 2020-06-24 17:29:16 --> URI Class Initialized
DEBUG - 2020-06-24 17:29:16 --> No URI present. Default controller set.
INFO - 2020-06-24 17:29:16 --> Router Class Initialized
INFO - 2020-06-24 17:29:16 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:29:16 --> Output Class Initialized
INFO - 2020-06-24 17:29:16 --> Security Class Initialized
DEBUG - 2020-06-24 17:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:29:16 --> Input Class Initialized
INFO - 2020-06-24 17:29:16 --> Language Class Initialized
INFO - 2020-06-24 17:29:16 --> Loader Class Initialized
INFO - 2020-06-24 17:29:16 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:29:16 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:29:16 --> Helper loaded: data_helper
INFO - 2020-06-24 17:29:16 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:29:16 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:29:16 --> Helper loaded: view_helper
INFO - 2020-06-24 17:29:16 --> Helper loaded: url_helper
INFO - 2020-06-24 17:29:16 --> Database Driver Class Initialized
INFO - 2020-06-24 17:29:16 --> Controller Class Initialized
INFO - 2020-06-24 17:29:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:29:16 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 17:29:16 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 17:29:16 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 17:29:16 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:29:16 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 17:29:16 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:29:16 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:29:16 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:29:16 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 17:29:16 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 17:29:16 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 17:29:16 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 17:29:16 --> Final output sent to browser
DEBUG - 2020-06-24 17:29:16 --> Total execution time: 0.1881
INFO - 2020-06-24 17:34:18 --> Config Class Initialized
INFO - 2020-06-24 17:34:18 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:34:18 --> Hooks Class Initialized
INFO - 2020-06-24 17:34:18 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:34:18 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:34:18 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:34:18 --> Utf8 Class Initialized
INFO - 2020-06-24 17:34:18 --> URI Class Initialized
DEBUG - 2020-06-24 17:34:18 --> No URI present. Default controller set.
INFO - 2020-06-24 17:34:18 --> Router Class Initialized
INFO - 2020-06-24 17:34:18 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:34:18 --> Output Class Initialized
INFO - 2020-06-24 17:34:18 --> Security Class Initialized
DEBUG - 2020-06-24 17:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:34:18 --> Input Class Initialized
INFO - 2020-06-24 17:34:18 --> Language Class Initialized
INFO - 2020-06-24 17:34:18 --> Loader Class Initialized
INFO - 2020-06-24 17:34:18 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:34:18 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:34:18 --> Helper loaded: data_helper
INFO - 2020-06-24 17:34:18 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:34:18 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:34:18 --> Helper loaded: view_helper
INFO - 2020-06-24 17:34:18 --> Helper loaded: url_helper
INFO - 2020-06-24 17:34:18 --> Database Driver Class Initialized
INFO - 2020-06-24 17:34:18 --> Controller Class Initialized
INFO - 2020-06-24 17:34:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:34:18 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 17:34:18 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 17:34:18 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 17:34:18 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:34:18 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 17:34:18 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:34:18 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:34:18 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:34:18 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 17:34:18 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 17:34:18 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 17:34:18 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 17:34:18 --> Final output sent to browser
DEBUG - 2020-06-24 17:34:18 --> Total execution time: 0.1217
INFO - 2020-06-24 17:39:19 --> Config Class Initialized
INFO - 2020-06-24 17:39:19 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:39:19 --> Hooks Class Initialized
INFO - 2020-06-24 17:39:19 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:39:19 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:39:19 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:39:19 --> Utf8 Class Initialized
INFO - 2020-06-24 17:39:19 --> URI Class Initialized
DEBUG - 2020-06-24 17:39:19 --> No URI present. Default controller set.
INFO - 2020-06-24 17:39:19 --> Router Class Initialized
INFO - 2020-06-24 17:39:19 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:39:19 --> Output Class Initialized
INFO - 2020-06-24 17:39:19 --> Security Class Initialized
DEBUG - 2020-06-24 17:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:39:19 --> Input Class Initialized
INFO - 2020-06-24 17:39:19 --> Language Class Initialized
INFO - 2020-06-24 17:39:19 --> Loader Class Initialized
INFO - 2020-06-24 17:39:19 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:39:19 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:39:19 --> Helper loaded: data_helper
INFO - 2020-06-24 17:39:19 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:39:19 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:39:19 --> Helper loaded: view_helper
INFO - 2020-06-24 17:39:19 --> Helper loaded: url_helper
INFO - 2020-06-24 17:39:19 --> Database Driver Class Initialized
INFO - 2020-06-24 17:39:19 --> Controller Class Initialized
INFO - 2020-06-24 17:39:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:39:19 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 17:39:19 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 17:39:19 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 17:39:19 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:39:19 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 17:39:19 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:39:19 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:39:19 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:39:19 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 17:39:19 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 17:39:19 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 17:39:19 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 17:39:19 --> Final output sent to browser
DEBUG - 2020-06-24 17:39:19 --> Total execution time: 0.2138
INFO - 2020-06-24 17:44:20 --> Config Class Initialized
INFO - 2020-06-24 17:44:20 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:44:20 --> Hooks Class Initialized
INFO - 2020-06-24 17:44:20 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:44:20 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:44:20 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:44:20 --> Utf8 Class Initialized
INFO - 2020-06-24 17:44:20 --> URI Class Initialized
DEBUG - 2020-06-24 17:44:20 --> No URI present. Default controller set.
INFO - 2020-06-24 17:44:20 --> Router Class Initialized
INFO - 2020-06-24 17:44:20 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:44:20 --> Output Class Initialized
INFO - 2020-06-24 17:44:20 --> Security Class Initialized
DEBUG - 2020-06-24 17:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:44:20 --> Input Class Initialized
INFO - 2020-06-24 17:44:20 --> Language Class Initialized
INFO - 2020-06-24 17:44:20 --> Loader Class Initialized
INFO - 2020-06-24 17:44:20 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:44:20 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:44:20 --> Helper loaded: data_helper
INFO - 2020-06-24 17:44:20 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:44:20 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:44:20 --> Helper loaded: view_helper
INFO - 2020-06-24 17:44:20 --> Helper loaded: url_helper
INFO - 2020-06-24 17:44:20 --> Database Driver Class Initialized
INFO - 2020-06-24 17:44:20 --> Controller Class Initialized
INFO - 2020-06-24 17:44:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:44:20 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 17:44:20 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 17:44:20 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 17:44:20 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:44:20 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 17:44:20 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:44:20 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:44:20 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:44:20 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 17:44:20 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 17:44:20 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 17:44:20 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 17:44:20 --> Final output sent to browser
DEBUG - 2020-06-24 17:44:20 --> Total execution time: 0.1211
INFO - 2020-06-24 17:49:20 --> Config Class Initialized
INFO - 2020-06-24 17:49:20 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:49:20 --> Hooks Class Initialized
INFO - 2020-06-24 17:49:20 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:49:20 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:49:20 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:49:20 --> Utf8 Class Initialized
INFO - 2020-06-24 17:49:20 --> URI Class Initialized
DEBUG - 2020-06-24 17:49:20 --> No URI present. Default controller set.
INFO - 2020-06-24 17:49:20 --> Router Class Initialized
INFO - 2020-06-24 17:49:20 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:49:20 --> Output Class Initialized
INFO - 2020-06-24 17:49:20 --> Security Class Initialized
DEBUG - 2020-06-24 17:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:49:20 --> Input Class Initialized
INFO - 2020-06-24 17:49:20 --> Language Class Initialized
INFO - 2020-06-24 17:49:20 --> Loader Class Initialized
INFO - 2020-06-24 17:49:20 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:49:20 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:49:20 --> Helper loaded: data_helper
INFO - 2020-06-24 17:49:20 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:49:20 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:49:20 --> Helper loaded: view_helper
INFO - 2020-06-24 17:49:20 --> Helper loaded: url_helper
INFO - 2020-06-24 17:49:20 --> Database Driver Class Initialized
INFO - 2020-06-24 17:49:20 --> Controller Class Initialized
INFO - 2020-06-24 17:49:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:49:20 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 17:49:20 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 17:49:20 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 17:49:20 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:49:20 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 17:49:20 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:49:20 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:49:20 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:49:20 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 17:49:20 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 17:49:20 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 17:49:20 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 17:49:20 --> Final output sent to browser
DEBUG - 2020-06-24 17:49:20 --> Total execution time: 0.1288
INFO - 2020-06-24 17:53:32 --> Config Class Initialized
INFO - 2020-06-24 17:53:32 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:53:32 --> Hooks Class Initialized
INFO - 2020-06-24 17:53:32 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:53:32 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:53:32 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:53:32 --> Utf8 Class Initialized
INFO - 2020-06-24 17:53:32 --> URI Class Initialized
DEBUG - 2020-06-24 17:53:32 --> No URI present. Default controller set.
INFO - 2020-06-24 17:53:32 --> Router Class Initialized
INFO - 2020-06-24 17:53:32 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:53:32 --> Output Class Initialized
INFO - 2020-06-24 17:53:32 --> Security Class Initialized
DEBUG - 2020-06-24 17:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:53:32 --> Input Class Initialized
INFO - 2020-06-24 17:53:32 --> Language Class Initialized
INFO - 2020-06-24 17:53:32 --> Loader Class Initialized
INFO - 2020-06-24 17:53:32 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:53:32 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:53:32 --> Helper loaded: data_helper
INFO - 2020-06-24 17:53:32 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:53:32 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:53:32 --> Helper loaded: view_helper
INFO - 2020-06-24 17:53:32 --> Helper loaded: url_helper
INFO - 2020-06-24 17:53:32 --> Database Driver Class Initialized
INFO - 2020-06-24 17:53:32 --> Controller Class Initialized
INFO - 2020-06-24 17:53:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:53:32 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 17:53:32 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 17:53:32 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 17:53:32 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:53:32 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 17:53:32 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:53:32 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:53:32 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:53:32 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 17:53:32 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 17:53:32 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 17:53:32 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 17:53:32 --> Final output sent to browser
DEBUG - 2020-06-24 17:53:32 --> Total execution time: 0.1198
INFO - 2020-06-24 17:53:33 --> Config Class Initialized
INFO - 2020-06-24 17:53:33 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:53:33 --> Hooks Class Initialized
INFO - 2020-06-24 17:53:33 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:53:33 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:53:33 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:53:33 --> Utf8 Class Initialized
INFO - 2020-06-24 17:53:33 --> URI Class Initialized
DEBUG - 2020-06-24 17:53:33 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 17:53:33 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 17:53:33 --> 404 Page Not Found: custom
INFO - 2020-06-24 17:53:45 --> Config Class Initialized
INFO - 2020-06-24 17:53:45 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:53:45 --> Hooks Class Initialized
INFO - 2020-06-24 17:53:45 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:53:45 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:53:45 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:53:45 --> Utf8 Class Initialized
INFO - 2020-06-24 17:53:45 --> URI Class Initialized
DEBUG - 2020-06-24 17:53:45 --> Validating request for /controllers/Login.php
INFO - 2020-06-24 17:53:45 --> Router Class Initialized
INFO - 2020-06-24 17:53:45 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:53:45 --> Output Class Initialized
INFO - 2020-06-24 17:53:45 --> Security Class Initialized
DEBUG - 2020-06-24 17:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:53:45 --> Input Class Initialized
INFO - 2020-06-24 17:53:45 --> Language Class Initialized
INFO - 2020-06-24 17:53:45 --> Loader Class Initialized
INFO - 2020-06-24 17:53:45 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:53:45 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:53:45 --> Helper loaded: data_helper
INFO - 2020-06-24 17:53:45 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:53:45 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:53:45 --> Helper loaded: view_helper
INFO - 2020-06-24 17:53:45 --> Helper loaded: url_helper
INFO - 2020-06-24 17:53:45 --> Database Driver Class Initialized
INFO - 2020-06-24 17:53:45 --> Controller Class Initialized
INFO - 2020-06-24 17:53:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:53:45 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 17:53:45 --> The "english" language file has been loaded.
INFO - 2020-06-24 17:53:45 --> Plain_Model class loaded
INFO - 2020-06-24 17:53:45 --> Model "Users_model" initialized
DEBUG - 2020-06-24 17:53:45 --> The phrase "Your password is incorrect. Please try again." could not be found in the language file.
INFO - 2020-06-24 17:53:45 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-06-24 17:53:45 --> Final output sent to browser
DEBUG - 2020-06-24 17:53:45 --> Total execution time: 0.2349
INFO - 2020-06-24 17:53:50 --> Config Class Initialized
INFO - 2020-06-24 17:53:50 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:53:50 --> Hooks Class Initialized
INFO - 2020-06-24 17:53:50 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:53:50 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:53:50 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:53:50 --> Utf8 Class Initialized
INFO - 2020-06-24 17:53:50 --> URI Class Initialized
DEBUG - 2020-06-24 17:53:50 --> Validating request for /controllers/Login.php
INFO - 2020-06-24 17:53:50 --> Router Class Initialized
INFO - 2020-06-24 17:53:50 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:53:50 --> Output Class Initialized
INFO - 2020-06-24 17:53:50 --> Security Class Initialized
DEBUG - 2020-06-24 17:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:53:50 --> Input Class Initialized
INFO - 2020-06-24 17:53:50 --> Language Class Initialized
INFO - 2020-06-24 17:53:50 --> Loader Class Initialized
INFO - 2020-06-24 17:53:50 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:53:50 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:53:50 --> Helper loaded: data_helper
INFO - 2020-06-24 17:53:50 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:53:50 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:53:50 --> Helper loaded: view_helper
INFO - 2020-06-24 17:53:50 --> Helper loaded: url_helper
INFO - 2020-06-24 17:53:50 --> Database Driver Class Initialized
INFO - 2020-06-24 17:53:50 --> Controller Class Initialized
INFO - 2020-06-24 17:53:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:53:50 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 17:53:50 --> The "english" language file has been loaded.
INFO - 2020-06-24 17:53:50 --> Plain_Model class loaded
INFO - 2020-06-24 17:53:50 --> Model "Users_model" initialized
INFO - 2020-06-24 17:53:50 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-06-24 17:53:50 --> Final output sent to browser
DEBUG - 2020-06-24 17:53:50 --> Total execution time: 0.2287
INFO - 2020-06-24 17:53:52 --> Config Class Initialized
INFO - 2020-06-24 17:53:52 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:53:52 --> Hooks Class Initialized
INFO - 2020-06-24 17:53:52 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:53:52 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:53:52 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:53:52 --> Utf8 Class Initialized
INFO - 2020-06-24 17:53:52 --> URI Class Initialized
DEBUG - 2020-06-24 17:53:52 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 17:53:52 --> Router Class Initialized
INFO - 2020-06-24 17:53:52 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:53:52 --> Output Class Initialized
INFO - 2020-06-24 17:53:52 --> Security Class Initialized
DEBUG - 2020-06-24 17:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:53:52 --> Input Class Initialized
INFO - 2020-06-24 17:53:52 --> Language Class Initialized
INFO - 2020-06-24 17:53:52 --> Loader Class Initialized
INFO - 2020-06-24 17:53:52 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:53:52 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:53:52 --> Helper loaded: data_helper
INFO - 2020-06-24 17:53:52 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:53:52 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:53:52 --> Helper loaded: view_helper
INFO - 2020-06-24 17:53:52 --> Helper loaded: url_helper
INFO - 2020-06-24 17:53:52 --> Database Driver Class Initialized
INFO - 2020-06-24 17:53:52 --> Controller Class Initialized
INFO - 2020-06-24 17:53:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:53:52 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 17:53:52 --> Plain_Model class loaded
INFO - 2020-06-24 17:53:52 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 17:53:52 --> The "english" language file has been loaded.
INFO - 2020-06-24 17:53:52 --> Model "Labels_model" initialized
INFO - 2020-06-24 17:53:52 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-24 17:53:52 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-24 17:53:52 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-24 17:53:52 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-24 17:53:52 --> The phrase "Recently-Used Tags" could not be found in the language file.
INFO - 2020-06-24 17:53:52 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-24 17:53:52 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-24 17:53:52 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-24 17:53:52 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-24 17:53:52 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-24 17:53:52 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-24 17:53:52 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-24 17:53:52 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 17:53:52 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 17:53:52 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 17:53:52 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 17:53:52 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 17:53:52 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-24 17:53:52 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-24 17:53:52 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-24 17:53:52 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-24 17:53:52 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-24 17:53:52 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-24 17:53:52 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-24 17:53:52 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-24 17:53:52 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-24 17:53:52 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-24 17:53:52 --> Final output sent to browser
DEBUG - 2020-06-24 17:53:52 --> Total execution time: 0.2925
INFO - 2020-06-24 17:53:53 --> Config Class Initialized
INFO - 2020-06-24 17:53:53 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:53:53 --> Hooks Class Initialized
INFO - 2020-06-24 17:53:53 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:53:53 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:53:53 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:53:53 --> Utf8 Class Initialized
INFO - 2020-06-24 17:53:53 --> URI Class Initialized
DEBUG - 2020-06-24 17:53:53 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 17:53:53 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 17:53:53 --> 404 Page Not Found: custom
INFO - 2020-06-24 17:54:21 --> Config Class Initialized
INFO - 2020-06-24 17:54:21 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:54:21 --> Hooks Class Initialized
INFO - 2020-06-24 17:54:21 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:54:21 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:54:21 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:54:21 --> Utf8 Class Initialized
INFO - 2020-06-24 17:54:21 --> URI Class Initialized
DEBUG - 2020-06-24 17:54:21 --> No URI present. Default controller set.
INFO - 2020-06-24 17:54:21 --> Router Class Initialized
INFO - 2020-06-24 17:54:21 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:54:21 --> Output Class Initialized
INFO - 2020-06-24 17:54:21 --> Security Class Initialized
DEBUG - 2020-06-24 17:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:54:21 --> Input Class Initialized
INFO - 2020-06-24 17:54:21 --> Language Class Initialized
INFO - 2020-06-24 17:54:21 --> Loader Class Initialized
INFO - 2020-06-24 17:54:21 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:54:21 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:54:21 --> Helper loaded: data_helper
INFO - 2020-06-24 17:54:21 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:54:21 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:54:21 --> Helper loaded: view_helper
INFO - 2020-06-24 17:54:21 --> Helper loaded: url_helper
INFO - 2020-06-24 17:54:21 --> Database Driver Class Initialized
INFO - 2020-06-24 17:54:21 --> Controller Class Initialized
INFO - 2020-06-24 17:54:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:54:21 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 17:54:21 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 17:54:21 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 17:54:21 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:54:21 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 17:54:21 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:54:21 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:54:21 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:54:21 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 17:54:21 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 17:54:21 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 17:54:21 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 17:54:21 --> Final output sent to browser
DEBUG - 2020-06-24 17:54:21 --> Total execution time: 0.1858
INFO - 2020-06-24 17:59:22 --> Config Class Initialized
INFO - 2020-06-24 17:59:22 --> Plain_Config Class Initialized
INFO - 2020-06-24 17:59:22 --> Hooks Class Initialized
INFO - 2020-06-24 17:59:22 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 17:59:22 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 17:59:22 --> UTF-8 Support Disabled
INFO - 2020-06-24 17:59:22 --> Utf8 Class Initialized
INFO - 2020-06-24 17:59:22 --> URI Class Initialized
DEBUG - 2020-06-24 17:59:22 --> No URI present. Default controller set.
INFO - 2020-06-24 17:59:22 --> Router Class Initialized
INFO - 2020-06-24 17:59:22 --> Plain_Router Class Initialized
INFO - 2020-06-24 17:59:22 --> Output Class Initialized
INFO - 2020-06-24 17:59:22 --> Security Class Initialized
DEBUG - 2020-06-24 17:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 17:59:22 --> Input Class Initialized
INFO - 2020-06-24 17:59:22 --> Language Class Initialized
INFO - 2020-06-24 17:59:22 --> Loader Class Initialized
INFO - 2020-06-24 17:59:22 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 17:59:22 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 17:59:22 --> Helper loaded: data_helper
INFO - 2020-06-24 17:59:22 --> Helper loaded: hash_helper
INFO - 2020-06-24 17:59:22 --> Helper loaded: validation_helper
INFO - 2020-06-24 17:59:22 --> Helper loaded: view_helper
INFO - 2020-06-24 17:59:22 --> Helper loaded: url_helper
INFO - 2020-06-24 17:59:22 --> Database Driver Class Initialized
INFO - 2020-06-24 17:59:22 --> Controller Class Initialized
INFO - 2020-06-24 17:59:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 17:59:22 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 17:59:22 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 17:59:22 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 17:59:22 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:59:22 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 17:59:22 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:59:22 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 17:59:22 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 17:59:22 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 17:59:22 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 17:59:22 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 17:59:22 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 17:59:22 --> Final output sent to browser
DEBUG - 2020-06-24 17:59:22 --> Total execution time: 0.1116
INFO - 2020-06-24 18:01:17 --> Config Class Initialized
INFO - 2020-06-24 18:01:17 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:01:17 --> Hooks Class Initialized
INFO - 2020-06-24 18:01:17 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:01:17 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:01:17 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:01:17 --> Utf8 Class Initialized
INFO - 2020-06-24 18:01:17 --> URI Class Initialized
DEBUG - 2020-06-24 18:01:17 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:01:17 --> Router Class Initialized
INFO - 2020-06-24 18:01:17 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:01:17 --> Output Class Initialized
INFO - 2020-06-24 18:01:17 --> Security Class Initialized
DEBUG - 2020-06-24 18:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:01:17 --> Input Class Initialized
INFO - 2020-06-24 18:01:17 --> Language Class Initialized
INFO - 2020-06-24 18:01:17 --> Loader Class Initialized
INFO - 2020-06-24 18:01:17 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:01:17 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:01:17 --> Helper loaded: data_helper
INFO - 2020-06-24 18:01:17 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:01:17 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:01:17 --> Helper loaded: view_helper
INFO - 2020-06-24 18:01:17 --> Helper loaded: url_helper
INFO - 2020-06-24 18:01:17 --> Database Driver Class Initialized
INFO - 2020-06-24 18:01:17 --> Controller Class Initialized
INFO - 2020-06-24 18:01:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:01:17 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:01:17 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:01:17 --> Plain_Model class loaded
INFO - 2020-06-24 18:01:17 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-24 18:04:23 --> Config Class Initialized
INFO - 2020-06-24 18:04:23 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:04:23 --> Hooks Class Initialized
INFO - 2020-06-24 18:04:23 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:04:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:04:23 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:04:23 --> Utf8 Class Initialized
INFO - 2020-06-24 18:04:23 --> URI Class Initialized
DEBUG - 2020-06-24 18:04:23 --> No URI present. Default controller set.
INFO - 2020-06-24 18:04:23 --> Router Class Initialized
INFO - 2020-06-24 18:04:23 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:04:23 --> Output Class Initialized
INFO - 2020-06-24 18:04:23 --> Security Class Initialized
DEBUG - 2020-06-24 18:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:04:23 --> Input Class Initialized
INFO - 2020-06-24 18:04:23 --> Language Class Initialized
INFO - 2020-06-24 18:04:23 --> Loader Class Initialized
INFO - 2020-06-24 18:04:23 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:04:23 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:04:23 --> Helper loaded: data_helper
INFO - 2020-06-24 18:04:23 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:04:23 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:04:23 --> Helper loaded: view_helper
INFO - 2020-06-24 18:04:23 --> Helper loaded: url_helper
INFO - 2020-06-24 18:04:23 --> Database Driver Class Initialized
INFO - 2020-06-24 18:04:23 --> Controller Class Initialized
INFO - 2020-06-24 18:04:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:04:23 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:04:23 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:04:23 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:04:23 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:04:23 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:04:23 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:04:23 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:04:23 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:04:23 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:04:23 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:04:23 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:04:23 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:04:23 --> Final output sent to browser
DEBUG - 2020-06-24 18:04:23 --> Total execution time: 0.2125
INFO - 2020-06-24 18:04:55 --> Config Class Initialized
INFO - 2020-06-24 18:04:55 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:04:55 --> Hooks Class Initialized
INFO - 2020-06-24 18:04:55 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:04:55 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:04:55 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:04:55 --> Utf8 Class Initialized
INFO - 2020-06-24 18:04:55 --> URI Class Initialized
DEBUG - 2020-06-24 18:04:55 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:04:55 --> Router Class Initialized
INFO - 2020-06-24 18:04:55 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:04:55 --> Output Class Initialized
INFO - 2020-06-24 18:04:55 --> Security Class Initialized
DEBUG - 2020-06-24 18:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:04:55 --> Input Class Initialized
INFO - 2020-06-24 18:04:55 --> Language Class Initialized
INFO - 2020-06-24 18:04:55 --> Loader Class Initialized
INFO - 2020-06-24 18:04:55 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:04:55 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:04:55 --> Helper loaded: data_helper
INFO - 2020-06-24 18:04:55 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:04:55 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:04:55 --> Helper loaded: view_helper
INFO - 2020-06-24 18:04:55 --> Helper loaded: url_helper
INFO - 2020-06-24 18:04:55 --> Database Driver Class Initialized
INFO - 2020-06-24 18:04:55 --> Controller Class Initialized
INFO - 2020-06-24 18:04:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:04:55 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:04:55 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:04:55 --> Plain_Model class loaded
INFO - 2020-06-24 18:04:55 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:04:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-24 18:04:55 --> Array
(
    [message] => Notice: Array to string conversion
    [type] => Notice
    [backtrace] => /var/www/html/application/controllers/Export.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-24 18:05:07 --> Config Class Initialized
INFO - 2020-06-24 18:05:07 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:05:07 --> Hooks Class Initialized
INFO - 2020-06-24 18:05:07 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:05:07 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:05:07 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:05:07 --> Utf8 Class Initialized
INFO - 2020-06-24 18:05:07 --> URI Class Initialized
DEBUG - 2020-06-24 18:05:07 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:05:07 --> Router Class Initialized
INFO - 2020-06-24 18:05:07 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:05:07 --> Output Class Initialized
INFO - 2020-06-24 18:05:07 --> Security Class Initialized
DEBUG - 2020-06-24 18:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:05:07 --> Input Class Initialized
INFO - 2020-06-24 18:05:07 --> Language Class Initialized
INFO - 2020-06-24 18:05:07 --> Loader Class Initialized
INFO - 2020-06-24 18:05:07 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:05:07 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:05:07 --> Helper loaded: data_helper
INFO - 2020-06-24 18:05:07 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:05:07 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:05:07 --> Helper loaded: view_helper
INFO - 2020-06-24 18:05:07 --> Helper loaded: url_helper
INFO - 2020-06-24 18:05:07 --> Database Driver Class Initialized
INFO - 2020-06-24 18:05:07 --> Controller Class Initialized
INFO - 2020-06-24 18:05:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:05:07 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:05:07 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:05:07 --> Plain_Model class loaded
INFO - 2020-06-24 18:05:07 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:05:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-24 18:05:08 --> Array
(
    [message] => Notice: Array to string conversion
    [type] => Notice
    [backtrace] => /var/www/html/application/controllers/Export.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-24 18:05:42 --> Config Class Initialized
INFO - 2020-06-24 18:05:42 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:05:42 --> Hooks Class Initialized
INFO - 2020-06-24 18:05:42 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:05:42 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:05:42 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:05:42 --> Utf8 Class Initialized
INFO - 2020-06-24 18:05:42 --> URI Class Initialized
DEBUG - 2020-06-24 18:05:42 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:05:42 --> Router Class Initialized
INFO - 2020-06-24 18:05:42 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:05:42 --> Output Class Initialized
INFO - 2020-06-24 18:05:42 --> Security Class Initialized
DEBUG - 2020-06-24 18:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:05:42 --> Input Class Initialized
INFO - 2020-06-24 18:05:42 --> Language Class Initialized
INFO - 2020-06-24 18:05:42 --> Loader Class Initialized
INFO - 2020-06-24 18:05:42 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:05:42 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:05:42 --> Helper loaded: data_helper
INFO - 2020-06-24 18:05:42 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:05:42 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:05:42 --> Helper loaded: view_helper
INFO - 2020-06-24 18:05:42 --> Helper loaded: url_helper
INFO - 2020-06-24 18:05:42 --> Database Driver Class Initialized
INFO - 2020-06-24 18:05:42 --> Controller Class Initialized
INFO - 2020-06-24 18:05:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:05:42 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:05:42 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:05:42 --> Plain_Model class loaded
INFO - 2020-06-24 18:05:42 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:05:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-24 18:05:42 --> Array
(
    [message] => Notice: Array to string conversion
    [type] => Notice
    [backtrace] => /var/www/html/application/controllers/Export.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-24 18:07:01 --> Config Class Initialized
INFO - 2020-06-24 18:07:01 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:07:01 --> Hooks Class Initialized
INFO - 2020-06-24 18:07:01 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:07:01 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:07:01 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:07:01 --> Utf8 Class Initialized
INFO - 2020-06-24 18:07:01 --> URI Class Initialized
DEBUG - 2020-06-24 18:07:01 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:07:01 --> Router Class Initialized
INFO - 2020-06-24 18:07:01 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:07:01 --> Output Class Initialized
INFO - 2020-06-24 18:07:01 --> Security Class Initialized
DEBUG - 2020-06-24 18:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:07:01 --> Input Class Initialized
INFO - 2020-06-24 18:07:01 --> Language Class Initialized
INFO - 2020-06-24 18:07:01 --> Loader Class Initialized
INFO - 2020-06-24 18:07:01 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:07:01 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:07:01 --> Helper loaded: data_helper
INFO - 2020-06-24 18:07:01 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:07:01 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:07:01 --> Helper loaded: view_helper
INFO - 2020-06-24 18:07:01 --> Helper loaded: url_helper
INFO - 2020-06-24 18:07:01 --> Database Driver Class Initialized
INFO - 2020-06-24 18:07:01 --> Controller Class Initialized
INFO - 2020-06-24 18:07:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:07:01 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:07:01 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:07:01 --> Plain_Model class loaded
INFO - 2020-06-24 18:07:01 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:07:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-24 18:07:01 --> Array
(
    [message] => Notice: Array to string conversion
    [type] => Notice
    [backtrace] => /var/www/html/application/controllers/Export.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-24 18:07:26 --> Config Class Initialized
INFO - 2020-06-24 18:07:26 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:07:26 --> Hooks Class Initialized
INFO - 2020-06-24 18:07:26 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:07:26 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:07:26 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:07:26 --> Utf8 Class Initialized
INFO - 2020-06-24 18:07:26 --> URI Class Initialized
DEBUG - 2020-06-24 18:07:26 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:07:26 --> Router Class Initialized
INFO - 2020-06-24 18:07:26 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:07:26 --> Output Class Initialized
INFO - 2020-06-24 18:07:26 --> Security Class Initialized
DEBUG - 2020-06-24 18:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:07:26 --> Input Class Initialized
INFO - 2020-06-24 18:07:26 --> Language Class Initialized
INFO - 2020-06-24 18:07:26 --> Loader Class Initialized
INFO - 2020-06-24 18:07:26 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:07:26 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:07:26 --> Helper loaded: data_helper
INFO - 2020-06-24 18:07:26 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:07:26 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:07:26 --> Helper loaded: view_helper
INFO - 2020-06-24 18:07:26 --> Helper loaded: url_helper
INFO - 2020-06-24 18:07:26 --> Database Driver Class Initialized
INFO - 2020-06-24 18:07:26 --> Controller Class Initialized
INFO - 2020-06-24 18:07:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:07:26 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:07:26 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:07:26 --> Plain_Model class loaded
INFO - 2020-06-24 18:07:26 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:07:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-24 18:07:26 --> Array
(
    [message] => Notice: Array to string conversion
    [type] => Notice
    [backtrace] => /var/www/html/application/controllers/Export.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-24 18:09:23 --> Config Class Initialized
INFO - 2020-06-24 18:09:23 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:09:23 --> Hooks Class Initialized
INFO - 2020-06-24 18:09:23 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:09:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:09:23 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:09:23 --> Utf8 Class Initialized
INFO - 2020-06-24 18:09:23 --> URI Class Initialized
DEBUG - 2020-06-24 18:09:23 --> No URI present. Default controller set.
INFO - 2020-06-24 18:09:23 --> Router Class Initialized
INFO - 2020-06-24 18:09:23 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:09:23 --> Output Class Initialized
INFO - 2020-06-24 18:09:23 --> Security Class Initialized
DEBUG - 2020-06-24 18:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:09:23 --> Input Class Initialized
INFO - 2020-06-24 18:09:23 --> Language Class Initialized
INFO - 2020-06-24 18:09:23 --> Loader Class Initialized
INFO - 2020-06-24 18:09:23 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:09:23 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:09:23 --> Helper loaded: data_helper
INFO - 2020-06-24 18:09:23 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:09:23 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:09:23 --> Helper loaded: view_helper
INFO - 2020-06-24 18:09:23 --> Helper loaded: url_helper
INFO - 2020-06-24 18:09:23 --> Database Driver Class Initialized
INFO - 2020-06-24 18:09:23 --> Controller Class Initialized
INFO - 2020-06-24 18:09:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:09:23 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:09:23 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:09:23 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:09:23 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:09:23 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:09:23 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:09:23 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:09:23 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:09:23 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:09:23 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:09:23 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:09:23 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:09:23 --> Final output sent to browser
DEBUG - 2020-06-24 18:09:23 --> Total execution time: 0.2076
INFO - 2020-06-24 18:14:24 --> Config Class Initialized
INFO - 2020-06-24 18:14:24 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:14:24 --> Hooks Class Initialized
INFO - 2020-06-24 18:14:24 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:14:24 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:14:24 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:14:24 --> Utf8 Class Initialized
INFO - 2020-06-24 18:14:24 --> URI Class Initialized
DEBUG - 2020-06-24 18:14:24 --> No URI present. Default controller set.
INFO - 2020-06-24 18:14:24 --> Router Class Initialized
INFO - 2020-06-24 18:14:24 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:14:24 --> Output Class Initialized
INFO - 2020-06-24 18:14:24 --> Security Class Initialized
DEBUG - 2020-06-24 18:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:14:24 --> Input Class Initialized
INFO - 2020-06-24 18:14:24 --> Language Class Initialized
INFO - 2020-06-24 18:14:24 --> Loader Class Initialized
INFO - 2020-06-24 18:14:24 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:14:24 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:14:24 --> Helper loaded: data_helper
INFO - 2020-06-24 18:14:24 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:14:24 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:14:24 --> Helper loaded: view_helper
INFO - 2020-06-24 18:14:24 --> Helper loaded: url_helper
INFO - 2020-06-24 18:14:24 --> Database Driver Class Initialized
INFO - 2020-06-24 18:14:24 --> Controller Class Initialized
INFO - 2020-06-24 18:14:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:14:24 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:14:24 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:14:24 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:14:24 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:14:24 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:14:24 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:14:24 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:14:24 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:14:24 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:14:24 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:14:24 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:14:24 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:14:24 --> Final output sent to browser
DEBUG - 2020-06-24 18:14:24 --> Total execution time: 0.2273
INFO - 2020-06-24 18:17:15 --> Config Class Initialized
INFO - 2020-06-24 18:17:15 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:17:15 --> Hooks Class Initialized
INFO - 2020-06-24 18:17:15 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:17:15 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:17:15 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:17:15 --> Utf8 Class Initialized
INFO - 2020-06-24 18:17:15 --> URI Class Initialized
DEBUG - 2020-06-24 18:17:15 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:17:15 --> Router Class Initialized
INFO - 2020-06-24 18:17:15 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:17:15 --> Output Class Initialized
INFO - 2020-06-24 18:17:15 --> Security Class Initialized
DEBUG - 2020-06-24 18:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:17:15 --> Input Class Initialized
INFO - 2020-06-24 18:17:15 --> Language Class Initialized
INFO - 2020-06-24 18:17:15 --> Loader Class Initialized
INFO - 2020-06-24 18:17:15 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:17:15 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:17:15 --> Helper loaded: data_helper
INFO - 2020-06-24 18:17:15 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:17:15 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:17:15 --> Helper loaded: view_helper
INFO - 2020-06-24 18:17:15 --> Helper loaded: url_helper
INFO - 2020-06-24 18:17:15 --> Database Driver Class Initialized
INFO - 2020-06-24 18:17:15 --> Controller Class Initialized
INFO - 2020-06-24 18:17:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:17:15 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:17:15 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:17:15 --> Plain_Model class loaded
INFO - 2020-06-24 18:17:15 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:17:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-24 18:17:15 --> Array
(
    [message] => Notice: Array to string conversion
    [type] => Notice
    [backtrace] => /var/www/html/application/controllers/Export.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-24 18:18:33 --> Config Class Initialized
INFO - 2020-06-24 18:18:33 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:18:33 --> Hooks Class Initialized
INFO - 2020-06-24 18:18:33 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:18:33 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:18:33 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:18:33 --> Utf8 Class Initialized
INFO - 2020-06-24 18:18:33 --> URI Class Initialized
DEBUG - 2020-06-24 18:18:33 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:18:33 --> Router Class Initialized
INFO - 2020-06-24 18:18:33 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:18:33 --> Output Class Initialized
INFO - 2020-06-24 18:18:33 --> Security Class Initialized
DEBUG - 2020-06-24 18:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:18:33 --> Input Class Initialized
INFO - 2020-06-24 18:18:33 --> Language Class Initialized
INFO - 2020-06-24 18:18:33 --> Loader Class Initialized
INFO - 2020-06-24 18:18:33 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:18:33 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:18:33 --> Helper loaded: data_helper
INFO - 2020-06-24 18:18:33 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:18:33 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:18:33 --> Helper loaded: view_helper
INFO - 2020-06-24 18:18:33 --> Helper loaded: url_helper
INFO - 2020-06-24 18:18:33 --> Database Driver Class Initialized
INFO - 2020-06-24 18:18:33 --> Controller Class Initialized
INFO - 2020-06-24 18:18:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:18:33 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:18:33 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:18:33 --> Plain_Model class loaded
INFO - 2020-06-24 18:18:33 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:18:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-24 18:18:33 --> Array
(
    [message] => Notice: Array to string conversion
    [type] => Notice
    [backtrace] => /var/www/html/application/controllers/Export.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-24 18:19:03 --> Config Class Initialized
INFO - 2020-06-24 18:19:03 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:19:03 --> Hooks Class Initialized
INFO - 2020-06-24 18:19:03 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:19:03 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:19:03 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:19:03 --> Utf8 Class Initialized
INFO - 2020-06-24 18:19:03 --> URI Class Initialized
DEBUG - 2020-06-24 18:19:03 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:19:03 --> Router Class Initialized
INFO - 2020-06-24 18:19:03 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:19:03 --> Output Class Initialized
INFO - 2020-06-24 18:19:03 --> Security Class Initialized
DEBUG - 2020-06-24 18:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:19:03 --> Input Class Initialized
INFO - 2020-06-24 18:19:03 --> Language Class Initialized
INFO - 2020-06-24 18:19:03 --> Loader Class Initialized
INFO - 2020-06-24 18:19:03 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:19:03 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:19:03 --> Helper loaded: data_helper
INFO - 2020-06-24 18:19:03 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:19:03 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:19:03 --> Helper loaded: view_helper
INFO - 2020-06-24 18:19:03 --> Helper loaded: url_helper
INFO - 2020-06-24 18:19:03 --> Database Driver Class Initialized
INFO - 2020-06-24 18:19:03 --> Controller Class Initialized
INFO - 2020-06-24 18:19:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:19:03 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:19:03 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:19:03 --> Plain_Model class loaded
INFO - 2020-06-24 18:19:03 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:19:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-24 18:19:04 --> Array
(
    [message] => Notice: Array to string conversion
    [type] => Notice
    [backtrace] => /var/www/html/application/controllers/Export.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-24 18:19:24 --> Config Class Initialized
INFO - 2020-06-24 18:19:24 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:19:24 --> Hooks Class Initialized
INFO - 2020-06-24 18:19:25 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:19:25 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:19:25 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:19:25 --> Utf8 Class Initialized
INFO - 2020-06-24 18:19:25 --> URI Class Initialized
DEBUG - 2020-06-24 18:19:25 --> No URI present. Default controller set.
INFO - 2020-06-24 18:19:25 --> Router Class Initialized
INFO - 2020-06-24 18:19:25 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:19:25 --> Output Class Initialized
INFO - 2020-06-24 18:19:25 --> Security Class Initialized
DEBUG - 2020-06-24 18:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:19:25 --> Input Class Initialized
INFO - 2020-06-24 18:19:25 --> Language Class Initialized
INFO - 2020-06-24 18:19:25 --> Loader Class Initialized
INFO - 2020-06-24 18:19:25 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:19:25 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:19:25 --> Helper loaded: data_helper
INFO - 2020-06-24 18:19:25 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:19:25 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:19:25 --> Helper loaded: view_helper
INFO - 2020-06-24 18:19:25 --> Helper loaded: url_helper
INFO - 2020-06-24 18:19:25 --> Database Driver Class Initialized
INFO - 2020-06-24 18:19:25 --> Controller Class Initialized
INFO - 2020-06-24 18:19:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:19:25 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:19:25 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:19:25 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:19:25 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:19:25 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:19:25 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:19:25 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:19:25 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:19:25 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:19:25 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:19:25 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:19:25 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:19:25 --> Final output sent to browser
DEBUG - 2020-06-24 18:19:25 --> Total execution time: 0.1890
INFO - 2020-06-24 18:21:11 --> Config Class Initialized
INFO - 2020-06-24 18:21:11 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:21:11 --> Hooks Class Initialized
INFO - 2020-06-24 18:21:11 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:21:11 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:21:11 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:21:11 --> Utf8 Class Initialized
INFO - 2020-06-24 18:21:11 --> URI Class Initialized
DEBUG - 2020-06-24 18:21:11 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:21:11 --> Router Class Initialized
INFO - 2020-06-24 18:21:11 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:21:11 --> Output Class Initialized
INFO - 2020-06-24 18:21:11 --> Security Class Initialized
DEBUG - 2020-06-24 18:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:21:11 --> Input Class Initialized
INFO - 2020-06-24 18:21:11 --> Language Class Initialized
INFO - 2020-06-24 18:21:11 --> Loader Class Initialized
INFO - 2020-06-24 18:21:11 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:21:11 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:21:11 --> Helper loaded: data_helper
INFO - 2020-06-24 18:21:11 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:21:11 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:21:11 --> Helper loaded: view_helper
INFO - 2020-06-24 18:21:11 --> Helper loaded: url_helper
INFO - 2020-06-24 18:21:11 --> Database Driver Class Initialized
INFO - 2020-06-24 18:21:11 --> Controller Class Initialized
INFO - 2020-06-24 18:21:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:21:11 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:21:11 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:21:11 --> Plain_Model class loaded
INFO - 2020-06-24 18:21:11 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:21:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-24 18:21:11 --> Array
(
    [message] => Notice: Array to string conversion
    [type] => Notice
    [backtrace] => /var/www/html/application/controllers/Export.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-24 18:24:17 --> Config Class Initialized
INFO - 2020-06-24 18:24:17 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:24:17 --> Hooks Class Initialized
INFO - 2020-06-24 18:24:17 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:24:17 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:24:17 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:24:17 --> Utf8 Class Initialized
INFO - 2020-06-24 18:24:17 --> URI Class Initialized
DEBUG - 2020-06-24 18:24:17 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:24:17 --> Router Class Initialized
INFO - 2020-06-24 18:24:17 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:24:17 --> Output Class Initialized
INFO - 2020-06-24 18:24:17 --> Security Class Initialized
DEBUG - 2020-06-24 18:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:24:17 --> Input Class Initialized
INFO - 2020-06-24 18:24:17 --> Language Class Initialized
INFO - 2020-06-24 18:24:17 --> Loader Class Initialized
INFO - 2020-06-24 18:24:17 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:24:17 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:24:17 --> Helper loaded: data_helper
INFO - 2020-06-24 18:24:17 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:24:17 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:24:17 --> Helper loaded: view_helper
INFO - 2020-06-24 18:24:17 --> Helper loaded: url_helper
INFO - 2020-06-24 18:24:17 --> Database Driver Class Initialized
INFO - 2020-06-24 18:24:17 --> Controller Class Initialized
INFO - 2020-06-24 18:24:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:24:17 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:24:17 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:24:17 --> Plain_Model class loaded
INFO - 2020-06-24 18:24:17 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:24:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-24 18:24:17 --> Array
(
    [message] => Notice: Array to string conversion
    [type] => Notice
    [backtrace] => /var/www/html/application/controllers/Export.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-24 18:24:25 --> Config Class Initialized
INFO - 2020-06-24 18:24:25 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:24:25 --> Hooks Class Initialized
INFO - 2020-06-24 18:24:25 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:24:25 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:24:25 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:24:25 --> Utf8 Class Initialized
INFO - 2020-06-24 18:24:25 --> URI Class Initialized
DEBUG - 2020-06-24 18:24:25 --> No URI present. Default controller set.
INFO - 2020-06-24 18:24:25 --> Router Class Initialized
INFO - 2020-06-24 18:24:25 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:24:25 --> Output Class Initialized
INFO - 2020-06-24 18:24:25 --> Security Class Initialized
DEBUG - 2020-06-24 18:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:24:25 --> Input Class Initialized
INFO - 2020-06-24 18:24:25 --> Language Class Initialized
INFO - 2020-06-24 18:24:25 --> Loader Class Initialized
INFO - 2020-06-24 18:24:25 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:24:25 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:24:25 --> Helper loaded: data_helper
INFO - 2020-06-24 18:24:25 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:24:25 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:24:25 --> Helper loaded: view_helper
INFO - 2020-06-24 18:24:25 --> Helper loaded: url_helper
INFO - 2020-06-24 18:24:25 --> Database Driver Class Initialized
INFO - 2020-06-24 18:24:25 --> Controller Class Initialized
INFO - 2020-06-24 18:24:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:24:25 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:24:25 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:24:25 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:24:25 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:24:25 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:24:25 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:24:25 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:24:25 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:24:25 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:24:25 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:24:25 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:24:25 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:24:25 --> Final output sent to browser
DEBUG - 2020-06-24 18:24:25 --> Total execution time: 0.1536
INFO - 2020-06-24 18:24:55 --> Config Class Initialized
INFO - 2020-06-24 18:24:55 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:24:55 --> Hooks Class Initialized
INFO - 2020-06-24 18:24:55 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:24:55 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:24:55 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:24:55 --> Utf8 Class Initialized
INFO - 2020-06-24 18:24:55 --> URI Class Initialized
DEBUG - 2020-06-24 18:24:55 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:24:55 --> Router Class Initialized
INFO - 2020-06-24 18:24:55 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:24:55 --> Output Class Initialized
INFO - 2020-06-24 18:24:55 --> Security Class Initialized
DEBUG - 2020-06-24 18:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:24:55 --> Input Class Initialized
INFO - 2020-06-24 18:24:55 --> Language Class Initialized
INFO - 2020-06-24 18:24:55 --> Loader Class Initialized
INFO - 2020-06-24 18:24:55 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:24:55 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:24:55 --> Helper loaded: data_helper
INFO - 2020-06-24 18:24:55 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:24:55 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:24:55 --> Helper loaded: view_helper
INFO - 2020-06-24 18:24:55 --> Helper loaded: url_helper
INFO - 2020-06-24 18:24:55 --> Database Driver Class Initialized
INFO - 2020-06-24 18:24:55 --> Controller Class Initialized
INFO - 2020-06-24 18:24:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:24:55 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:24:55 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:24:55 --> Plain_Model class loaded
INFO - 2020-06-24 18:24:55 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:24:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-24 18:24:55 --> Array
(
    [message] => Warning: implode(): Invalid arguments passed
    [type] => Warning
    [backtrace] => /var/www/html/application/controllers/Export.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-24 18:25:21 --> Config Class Initialized
INFO - 2020-06-24 18:25:21 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:25:21 --> Hooks Class Initialized
INFO - 2020-06-24 18:25:21 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:25:21 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:25:21 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:25:21 --> Utf8 Class Initialized
INFO - 2020-06-24 18:25:21 --> URI Class Initialized
DEBUG - 2020-06-24 18:25:21 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:25:21 --> Router Class Initialized
INFO - 2020-06-24 18:25:21 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:25:21 --> Output Class Initialized
INFO - 2020-06-24 18:25:21 --> Security Class Initialized
DEBUG - 2020-06-24 18:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:25:21 --> Input Class Initialized
INFO - 2020-06-24 18:25:21 --> Language Class Initialized
INFO - 2020-06-24 18:25:21 --> Loader Class Initialized
INFO - 2020-06-24 18:25:21 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:25:21 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:25:21 --> Helper loaded: data_helper
INFO - 2020-06-24 18:25:21 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:25:21 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:25:21 --> Helper loaded: view_helper
INFO - 2020-06-24 18:25:21 --> Helper loaded: url_helper
INFO - 2020-06-24 18:25:21 --> Database Driver Class Initialized
INFO - 2020-06-24 18:25:21 --> Controller Class Initialized
INFO - 2020-06-24 18:25:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:25:21 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:25:21 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:25:21 --> Plain_Model class loaded
INFO - 2020-06-24 18:25:21 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:25:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-24 18:25:21 --> Array
(
    [message] => Warning: implode(): Invalid arguments passed
    [type] => Warning
    [backtrace] => /var/www/html/application/controllers/Export.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-24 18:25:41 --> Config Class Initialized
INFO - 2020-06-24 18:25:41 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:25:41 --> Hooks Class Initialized
INFO - 2020-06-24 18:25:41 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:25:41 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:25:41 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:25:41 --> Utf8 Class Initialized
INFO - 2020-06-24 18:25:41 --> URI Class Initialized
DEBUG - 2020-06-24 18:25:41 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:25:41 --> Router Class Initialized
INFO - 2020-06-24 18:25:41 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:25:41 --> Output Class Initialized
INFO - 2020-06-24 18:25:41 --> Security Class Initialized
DEBUG - 2020-06-24 18:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:25:41 --> Input Class Initialized
INFO - 2020-06-24 18:25:41 --> Language Class Initialized
INFO - 2020-06-24 18:25:41 --> Loader Class Initialized
INFO - 2020-06-24 18:25:41 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:25:41 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:25:41 --> Helper loaded: data_helper
INFO - 2020-06-24 18:25:41 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:25:41 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:25:41 --> Helper loaded: view_helper
INFO - 2020-06-24 18:25:41 --> Helper loaded: url_helper
INFO - 2020-06-24 18:25:41 --> Database Driver Class Initialized
INFO - 2020-06-24 18:25:41 --> Controller Class Initialized
INFO - 2020-06-24 18:25:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:25:41 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:25:41 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:25:41 --> Plain_Model class loaded
INFO - 2020-06-24 18:25:41 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:25:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-24 18:25:41 --> Array
(
    [message] => Warning: implode(): Invalid arguments passed
    [type] => Warning
    [backtrace] => /var/www/html/application/controllers/Export.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => N4qmnD7pKci9OsCxPshaVI7hSCB7dn0d1faf44816d17c2f15fd1b3c49b64f1
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-23 19:19:05
            [last_updated] => 2020-06-23 19:19:05
        )

)

INFO - 2020-06-24 18:26:56 --> Config Class Initialized
INFO - 2020-06-24 18:26:56 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:26:56 --> Hooks Class Initialized
INFO - 2020-06-24 18:26:56 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:26:56 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:26:56 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:26:56 --> Utf8 Class Initialized
INFO - 2020-06-24 18:26:56 --> URI Class Initialized
DEBUG - 2020-06-24 18:26:56 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:26:56 --> Router Class Initialized
INFO - 2020-06-24 18:26:56 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:26:56 --> Output Class Initialized
INFO - 2020-06-24 18:26:56 --> Security Class Initialized
DEBUG - 2020-06-24 18:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:26:56 --> Input Class Initialized
INFO - 2020-06-24 18:26:56 --> Language Class Initialized
INFO - 2020-06-24 18:26:56 --> Loader Class Initialized
INFO - 2020-06-24 18:26:56 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:26:56 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:26:56 --> Helper loaded: data_helper
INFO - 2020-06-24 18:26:56 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:26:56 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:26:56 --> Helper loaded: view_helper
INFO - 2020-06-24 18:26:56 --> Helper loaded: url_helper
INFO - 2020-06-24 18:26:56 --> Database Driver Class Initialized
INFO - 2020-06-24 18:26:56 --> Controller Class Initialized
INFO - 2020-06-24 18:26:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:26:56 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:26:56 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:26:57 --> Plain_Model class loaded
INFO - 2020-06-24 18:26:57 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-24 18:28:36 --> Config Class Initialized
INFO - 2020-06-24 18:28:36 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:28:36 --> Hooks Class Initialized
INFO - 2020-06-24 18:28:36 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:28:36 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:28:36 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:28:36 --> Utf8 Class Initialized
INFO - 2020-06-24 18:28:36 --> URI Class Initialized
DEBUG - 2020-06-24 18:28:36 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:28:36 --> Router Class Initialized
INFO - 2020-06-24 18:28:36 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:28:36 --> Output Class Initialized
INFO - 2020-06-24 18:28:36 --> Security Class Initialized
DEBUG - 2020-06-24 18:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:28:36 --> Input Class Initialized
INFO - 2020-06-24 18:28:36 --> Language Class Initialized
INFO - 2020-06-24 18:28:36 --> Loader Class Initialized
INFO - 2020-06-24 18:28:36 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:28:36 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:28:36 --> Helper loaded: data_helper
INFO - 2020-06-24 18:28:36 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:28:36 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:28:36 --> Helper loaded: view_helper
INFO - 2020-06-24 18:28:36 --> Helper loaded: url_helper
INFO - 2020-06-24 18:28:36 --> Database Driver Class Initialized
INFO - 2020-06-24 18:28:36 --> Controller Class Initialized
INFO - 2020-06-24 18:28:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:28:36 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:28:36 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:28:36 --> Plain_Model class loaded
INFO - 2020-06-24 18:28:36 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-24 18:29:25 --> Config Class Initialized
INFO - 2020-06-24 18:29:25 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:29:25 --> Hooks Class Initialized
INFO - 2020-06-24 18:29:25 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:29:25 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:29:25 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:29:25 --> Utf8 Class Initialized
INFO - 2020-06-24 18:29:25 --> URI Class Initialized
DEBUG - 2020-06-24 18:29:25 --> No URI present. Default controller set.
INFO - 2020-06-24 18:29:25 --> Router Class Initialized
INFO - 2020-06-24 18:29:25 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:29:25 --> Output Class Initialized
INFO - 2020-06-24 18:29:25 --> Security Class Initialized
DEBUG - 2020-06-24 18:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:29:25 --> Input Class Initialized
INFO - 2020-06-24 18:29:25 --> Language Class Initialized
INFO - 2020-06-24 18:29:25 --> Loader Class Initialized
INFO - 2020-06-24 18:29:25 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:29:25 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:29:25 --> Helper loaded: data_helper
INFO - 2020-06-24 18:29:25 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:29:25 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:29:25 --> Helper loaded: view_helper
INFO - 2020-06-24 18:29:25 --> Helper loaded: url_helper
INFO - 2020-06-24 18:29:25 --> Database Driver Class Initialized
INFO - 2020-06-24 18:29:25 --> Controller Class Initialized
INFO - 2020-06-24 18:29:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:29:25 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:29:25 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:29:25 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:29:25 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:29:25 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:29:25 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:29:25 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:29:25 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:29:25 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:29:25 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:29:25 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:29:25 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:29:25 --> Final output sent to browser
DEBUG - 2020-06-24 18:29:25 --> Total execution time: 0.1154
INFO - 2020-06-24 18:31:39 --> Config Class Initialized
INFO - 2020-06-24 18:31:39 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:31:39 --> Hooks Class Initialized
INFO - 2020-06-24 18:31:39 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:31:39 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:31:39 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:31:39 --> Utf8 Class Initialized
INFO - 2020-06-24 18:31:39 --> URI Class Initialized
DEBUG - 2020-06-24 18:31:39 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:31:39 --> Router Class Initialized
INFO - 2020-06-24 18:31:39 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:31:39 --> Output Class Initialized
INFO - 2020-06-24 18:31:39 --> Security Class Initialized
DEBUG - 2020-06-24 18:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:31:39 --> Input Class Initialized
INFO - 2020-06-24 18:31:39 --> Language Class Initialized
INFO - 2020-06-24 18:31:39 --> Loader Class Initialized
INFO - 2020-06-24 18:31:39 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:31:39 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:31:39 --> Helper loaded: data_helper
INFO - 2020-06-24 18:31:39 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:31:39 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:31:39 --> Helper loaded: view_helper
INFO - 2020-06-24 18:31:39 --> Helper loaded: url_helper
INFO - 2020-06-24 18:31:39 --> Database Driver Class Initialized
INFO - 2020-06-24 18:31:39 --> Controller Class Initialized
INFO - 2020-06-24 18:31:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:31:39 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:31:39 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:31:39 --> Plain_Model class loaded
INFO - 2020-06-24 18:31:40 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-24 18:34:26 --> Config Class Initialized
INFO - 2020-06-24 18:34:26 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:34:26 --> Hooks Class Initialized
INFO - 2020-06-24 18:34:26 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:34:26 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:34:26 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:34:26 --> Utf8 Class Initialized
INFO - 2020-06-24 18:34:26 --> URI Class Initialized
DEBUG - 2020-06-24 18:34:26 --> No URI present. Default controller set.
INFO - 2020-06-24 18:34:26 --> Router Class Initialized
INFO - 2020-06-24 18:34:26 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:34:26 --> Output Class Initialized
INFO - 2020-06-24 18:34:26 --> Security Class Initialized
DEBUG - 2020-06-24 18:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:34:26 --> Input Class Initialized
INFO - 2020-06-24 18:34:26 --> Language Class Initialized
INFO - 2020-06-24 18:34:26 --> Loader Class Initialized
INFO - 2020-06-24 18:34:26 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:34:26 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:34:26 --> Helper loaded: data_helper
INFO - 2020-06-24 18:34:26 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:34:26 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:34:26 --> Helper loaded: view_helper
INFO - 2020-06-24 18:34:26 --> Helper loaded: url_helper
INFO - 2020-06-24 18:34:26 --> Database Driver Class Initialized
INFO - 2020-06-24 18:34:26 --> Controller Class Initialized
INFO - 2020-06-24 18:34:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:34:26 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:34:26 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:34:26 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:34:26 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:34:26 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:34:26 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:34:26 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:34:26 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:34:26 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:34:26 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:34:26 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:34:26 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:34:26 --> Final output sent to browser
DEBUG - 2020-06-24 18:34:26 --> Total execution time: 0.1603
INFO - 2020-06-24 18:38:37 --> Config Class Initialized
INFO - 2020-06-24 18:38:37 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:38:37 --> Hooks Class Initialized
INFO - 2020-06-24 18:38:37 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:38:37 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:38:37 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:38:37 --> Utf8 Class Initialized
INFO - 2020-06-24 18:38:37 --> URI Class Initialized
DEBUG - 2020-06-24 18:38:37 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:38:37 --> Router Class Initialized
INFO - 2020-06-24 18:38:37 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:38:37 --> Output Class Initialized
INFO - 2020-06-24 18:38:37 --> Security Class Initialized
DEBUG - 2020-06-24 18:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:38:37 --> Input Class Initialized
INFO - 2020-06-24 18:38:37 --> Language Class Initialized
INFO - 2020-06-24 18:38:37 --> Loader Class Initialized
INFO - 2020-06-24 18:38:37 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:38:37 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:38:37 --> Helper loaded: data_helper
INFO - 2020-06-24 18:38:37 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:38:37 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:38:37 --> Helper loaded: view_helper
INFO - 2020-06-24 18:38:37 --> Helper loaded: url_helper
INFO - 2020-06-24 18:38:37 --> Database Driver Class Initialized
INFO - 2020-06-24 18:38:37 --> Controller Class Initialized
INFO - 2020-06-24 18:38:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:38:37 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:38:37 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:38:37 --> Plain_Model class loaded
INFO - 2020-06-24 18:38:37 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-24 18:39:27 --> Config Class Initialized
INFO - 2020-06-24 18:39:27 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:39:27 --> Hooks Class Initialized
INFO - 2020-06-24 18:39:27 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:39:27 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:39:27 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:39:27 --> Utf8 Class Initialized
INFO - 2020-06-24 18:39:27 --> URI Class Initialized
DEBUG - 2020-06-24 18:39:27 --> No URI present. Default controller set.
INFO - 2020-06-24 18:39:27 --> Router Class Initialized
INFO - 2020-06-24 18:39:27 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:39:27 --> Output Class Initialized
INFO - 2020-06-24 18:39:27 --> Security Class Initialized
DEBUG - 2020-06-24 18:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:39:27 --> Input Class Initialized
INFO - 2020-06-24 18:39:27 --> Language Class Initialized
INFO - 2020-06-24 18:39:27 --> Loader Class Initialized
INFO - 2020-06-24 18:39:27 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:39:27 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:39:27 --> Helper loaded: data_helper
INFO - 2020-06-24 18:39:27 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:39:27 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:39:27 --> Helper loaded: view_helper
INFO - 2020-06-24 18:39:27 --> Helper loaded: url_helper
INFO - 2020-06-24 18:39:27 --> Database Driver Class Initialized
INFO - 2020-06-24 18:39:27 --> Controller Class Initialized
INFO - 2020-06-24 18:39:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:39:27 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:39:27 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:39:27 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:39:27 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:39:27 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:39:27 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:39:27 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:39:27 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:39:27 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:39:27 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:39:27 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:39:27 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:39:27 --> Final output sent to browser
DEBUG - 2020-06-24 18:39:27 --> Total execution time: 0.1519
INFO - 2020-06-24 18:44:27 --> Config Class Initialized
INFO - 2020-06-24 18:44:27 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:44:27 --> Hooks Class Initialized
INFO - 2020-06-24 18:44:27 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:44:27 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:44:27 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:44:27 --> Utf8 Class Initialized
INFO - 2020-06-24 18:44:27 --> URI Class Initialized
DEBUG - 2020-06-24 18:44:27 --> No URI present. Default controller set.
INFO - 2020-06-24 18:44:27 --> Router Class Initialized
INFO - 2020-06-24 18:44:27 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:44:27 --> Output Class Initialized
INFO - 2020-06-24 18:44:27 --> Security Class Initialized
DEBUG - 2020-06-24 18:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:44:27 --> Input Class Initialized
INFO - 2020-06-24 18:44:27 --> Language Class Initialized
INFO - 2020-06-24 18:44:27 --> Loader Class Initialized
INFO - 2020-06-24 18:44:27 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:44:27 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:44:27 --> Helper loaded: data_helper
INFO - 2020-06-24 18:44:27 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:44:27 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:44:27 --> Helper loaded: view_helper
INFO - 2020-06-24 18:44:27 --> Helper loaded: url_helper
INFO - 2020-06-24 18:44:27 --> Database Driver Class Initialized
INFO - 2020-06-24 18:44:27 --> Controller Class Initialized
INFO - 2020-06-24 18:44:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:44:27 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:44:27 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:44:27 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:44:27 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:44:27 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:44:27 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:44:27 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:44:27 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:44:27 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:44:27 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:44:27 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:44:27 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:44:27 --> Final output sent to browser
DEBUG - 2020-06-24 18:44:27 --> Total execution time: 0.1620
INFO - 2020-06-24 18:46:10 --> Config Class Initialized
INFO - 2020-06-24 18:46:10 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:46:10 --> Hooks Class Initialized
INFO - 2020-06-24 18:46:10 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:46:10 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:46:10 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:46:10 --> Utf8 Class Initialized
INFO - 2020-06-24 18:46:10 --> URI Class Initialized
DEBUG - 2020-06-24 18:46:10 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 18:46:10 --> Router Class Initialized
INFO - 2020-06-24 18:46:10 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:46:10 --> Output Class Initialized
INFO - 2020-06-24 18:46:10 --> Security Class Initialized
DEBUG - 2020-06-24 18:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:46:10 --> Input Class Initialized
INFO - 2020-06-24 18:46:10 --> Language Class Initialized
INFO - 2020-06-24 18:46:10 --> Loader Class Initialized
INFO - 2020-06-24 18:46:10 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:46:10 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:46:10 --> Helper loaded: data_helper
INFO - 2020-06-24 18:46:10 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:46:10 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:46:10 --> Helper loaded: view_helper
INFO - 2020-06-24 18:46:10 --> Helper loaded: url_helper
INFO - 2020-06-24 18:46:10 --> Database Driver Class Initialized
INFO - 2020-06-24 18:46:10 --> Controller Class Initialized
INFO - 2020-06-24 18:46:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:46:10 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 18:46:10 --> Plain_Model class loaded
INFO - 2020-06-24 18:46:10 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:46:10 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:46:10 --> Model "Labels_model" initialized
INFO - 2020-06-24 18:46:10 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-24 18:46:10 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-24 18:46:10 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-24 18:46:10 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-24 18:46:10 --> The phrase "Recently-Used Tags" could not be found in the language file.
INFO - 2020-06-24 18:46:10 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-24 18:46:10 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-24 18:46:10 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-24 18:46:10 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-24 18:46:10 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-24 18:46:10 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-24 18:46:10 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-24 18:46:10 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 18:46:10 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 18:46:10 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 18:46:10 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 18:46:10 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 18:46:10 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-24 18:46:10 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-24 18:46:10 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-24 18:46:10 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-24 18:46:10 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-24 18:46:10 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-24 18:46:10 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-24 18:46:10 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-24 18:46:10 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-24 18:46:10 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-24 18:46:10 --> Final output sent to browser
DEBUG - 2020-06-24 18:46:10 --> Total execution time: 0.2367
INFO - 2020-06-24 18:46:11 --> Config Class Initialized
INFO - 2020-06-24 18:46:11 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:46:11 --> Hooks Class Initialized
INFO - 2020-06-24 18:46:11 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:46:11 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:46:11 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:46:11 --> Utf8 Class Initialized
INFO - 2020-06-24 18:46:11 --> URI Class Initialized
DEBUG - 2020-06-24 18:46:11 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:46:11 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:46:11 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:46:12 --> Config Class Initialized
INFO - 2020-06-24 18:46:12 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:46:12 --> Hooks Class Initialized
INFO - 2020-06-24 18:46:12 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:46:12 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:46:12 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:46:12 --> Utf8 Class Initialized
INFO - 2020-06-24 18:46:12 --> URI Class Initialized
DEBUG - 2020-06-24 18:46:12 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 18:46:12 --> Router Class Initialized
INFO - 2020-06-24 18:46:12 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:46:12 --> Output Class Initialized
INFO - 2020-06-24 18:46:12 --> Security Class Initialized
DEBUG - 2020-06-24 18:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:46:12 --> Input Class Initialized
INFO - 2020-06-24 18:46:12 --> Language Class Initialized
INFO - 2020-06-24 18:46:12 --> Loader Class Initialized
INFO - 2020-06-24 18:46:12 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:46:12 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:46:12 --> Helper loaded: data_helper
INFO - 2020-06-24 18:46:12 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:46:12 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:46:12 --> Helper loaded: view_helper
INFO - 2020-06-24 18:46:12 --> Helper loaded: url_helper
INFO - 2020-06-24 18:46:12 --> Database Driver Class Initialized
INFO - 2020-06-24 18:46:12 --> Controller Class Initialized
INFO - 2020-06-24 18:46:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:46:12 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 18:46:12 --> Plain_Model class loaded
INFO - 2020-06-24 18:46:12 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:46:12 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:46:12 --> Model "Labels_model" initialized
INFO - 2020-06-24 18:46:12 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-24 18:46:12 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-24 18:46:12 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-24 18:46:12 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-24 18:46:12 --> The phrase "Recently-Used Tags" could not be found in the language file.
INFO - 2020-06-24 18:46:12 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-24 18:46:12 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-24 18:46:12 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-24 18:46:12 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-24 18:46:12 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-24 18:46:12 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-24 18:46:12 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-24 18:46:12 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 18:46:12 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 18:46:12 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 18:46:12 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 18:46:12 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 18:46:12 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-24 18:46:12 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-24 18:46:12 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-24 18:46:12 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-24 18:46:12 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-24 18:46:12 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-24 18:46:12 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-24 18:46:12 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-24 18:46:12 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-24 18:46:12 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-24 18:46:12 --> Final output sent to browser
DEBUG - 2020-06-24 18:46:12 --> Total execution time: 0.2267
INFO - 2020-06-24 18:46:13 --> Config Class Initialized
INFO - 2020-06-24 18:46:13 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:46:13 --> Hooks Class Initialized
INFO - 2020-06-24 18:46:13 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:46:13 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:46:13 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:46:13 --> Utf8 Class Initialized
INFO - 2020-06-24 18:46:13 --> URI Class Initialized
DEBUG - 2020-06-24 18:46:13 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:46:13 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:46:13 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:46:24 --> Config Class Initialized
INFO - 2020-06-24 18:46:24 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:46:24 --> Hooks Class Initialized
INFO - 2020-06-24 18:46:24 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:46:24 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:46:24 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:46:24 --> Utf8 Class Initialized
INFO - 2020-06-24 18:46:24 --> URI Class Initialized
DEBUG - 2020-06-24 18:46:24 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 18:46:24 --> Router Class Initialized
INFO - 2020-06-24 18:46:24 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:46:24 --> Output Class Initialized
INFO - 2020-06-24 18:46:24 --> Security Class Initialized
DEBUG - 2020-06-24 18:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:46:24 --> Input Class Initialized
INFO - 2020-06-24 18:46:24 --> Language Class Initialized
INFO - 2020-06-24 18:46:24 --> Loader Class Initialized
INFO - 2020-06-24 18:46:24 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:46:24 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:46:24 --> Helper loaded: data_helper
INFO - 2020-06-24 18:46:24 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:46:24 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:46:24 --> Helper loaded: view_helper
INFO - 2020-06-24 18:46:24 --> Helper loaded: url_helper
INFO - 2020-06-24 18:46:24 --> Database Driver Class Initialized
INFO - 2020-06-24 18:46:24 --> Controller Class Initialized
INFO - 2020-06-24 18:46:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:46:24 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:46:24 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:46:24 --> Plain_Model class loaded
INFO - 2020-06-24 18:46:24 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-24 18:46:24 --> Final output sent to browser
DEBUG - 2020-06-24 18:46:24 --> Total execution time: 0.3030
INFO - 2020-06-24 18:47:35 --> Config Class Initialized
INFO - 2020-06-24 18:47:35 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:47:35 --> Hooks Class Initialized
INFO - 2020-06-24 18:47:35 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:47:35 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:47:35 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:47:35 --> Utf8 Class Initialized
INFO - 2020-06-24 18:47:35 --> URI Class Initialized
DEBUG - 2020-06-24 18:47:35 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 18:47:35 --> Router Class Initialized
INFO - 2020-06-24 18:47:35 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:47:35 --> Output Class Initialized
INFO - 2020-06-24 18:47:35 --> Security Class Initialized
DEBUG - 2020-06-24 18:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:47:35 --> Input Class Initialized
INFO - 2020-06-24 18:47:35 --> Language Class Initialized
INFO - 2020-06-24 18:47:35 --> Loader Class Initialized
INFO - 2020-06-24 18:47:35 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:47:35 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:47:35 --> Helper loaded: data_helper
INFO - 2020-06-24 18:47:35 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:47:35 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:47:35 --> Helper loaded: view_helper
INFO - 2020-06-24 18:47:35 --> Helper loaded: url_helper
INFO - 2020-06-24 18:47:35 --> Database Driver Class Initialized
INFO - 2020-06-24 18:47:35 --> Controller Class Initialized
INFO - 2020-06-24 18:47:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:47:35 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 18:47:35 --> Config Class Initialized
INFO - 2020-06-24 18:47:35 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:47:35 --> Hooks Class Initialized
INFO - 2020-06-24 18:47:35 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:47:35 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:47:35 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:47:35 --> Utf8 Class Initialized
INFO - 2020-06-24 18:47:35 --> URI Class Initialized
DEBUG - 2020-06-24 18:47:35 --> No URI present. Default controller set.
INFO - 2020-06-24 18:47:35 --> Router Class Initialized
INFO - 2020-06-24 18:47:35 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:47:35 --> Output Class Initialized
INFO - 2020-06-24 18:47:35 --> Security Class Initialized
DEBUG - 2020-06-24 18:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:47:35 --> Input Class Initialized
INFO - 2020-06-24 18:47:35 --> Language Class Initialized
INFO - 2020-06-24 18:47:35 --> Loader Class Initialized
INFO - 2020-06-24 18:47:35 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:47:35 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:47:35 --> Helper loaded: data_helper
INFO - 2020-06-24 18:47:35 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:47:35 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:47:35 --> Helper loaded: view_helper
INFO - 2020-06-24 18:47:35 --> Helper loaded: url_helper
INFO - 2020-06-24 18:47:35 --> Database Driver Class Initialized
INFO - 2020-06-24 18:47:35 --> Controller Class Initialized
INFO - 2020-06-24 18:47:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:47:35 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:47:35 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:47:35 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:47:35 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:47:35 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:47:35 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:47:35 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:47:35 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:47:35 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:47:35 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:47:35 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:47:35 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:47:35 --> Final output sent to browser
DEBUG - 2020-06-24 18:47:35 --> Total execution time: 0.1113
INFO - 2020-06-24 18:47:36 --> Config Class Initialized
INFO - 2020-06-24 18:47:36 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:47:36 --> Hooks Class Initialized
INFO - 2020-06-24 18:47:36 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:47:36 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:47:36 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:47:36 --> Utf8 Class Initialized
INFO - 2020-06-24 18:47:36 --> URI Class Initialized
DEBUG - 2020-06-24 18:47:36 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:47:36 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:47:36 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:47:37 --> Config Class Initialized
INFO - 2020-06-24 18:47:37 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:47:37 --> Hooks Class Initialized
INFO - 2020-06-24 18:47:37 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:47:37 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:47:37 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:47:37 --> Utf8 Class Initialized
INFO - 2020-06-24 18:47:37 --> URI Class Initialized
DEBUG - 2020-06-24 18:47:37 --> Validating request for /controllers/Register.php
INFO - 2020-06-24 18:47:37 --> Router Class Initialized
INFO - 2020-06-24 18:47:37 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:47:37 --> Output Class Initialized
INFO - 2020-06-24 18:47:37 --> Security Class Initialized
DEBUG - 2020-06-24 18:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:47:37 --> Input Class Initialized
INFO - 2020-06-24 18:47:37 --> Language Class Initialized
INFO - 2020-06-24 18:47:37 --> Loader Class Initialized
INFO - 2020-06-24 18:47:37 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:47:38 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:47:38 --> Helper loaded: data_helper
INFO - 2020-06-24 18:47:38 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:47:38 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:47:38 --> Helper loaded: view_helper
INFO - 2020-06-24 18:47:38 --> Helper loaded: url_helper
INFO - 2020-06-24 18:47:38 --> Database Driver Class Initialized
INFO - 2020-06-24 18:47:38 --> Controller Class Initialized
INFO - 2020-06-24 18:47:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:47:38 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:47:38 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:47:38 --> The phrase "Unmark : User Registration" could not be found in the language file.
DEBUG - 2020-06-24 18:47:38 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:47:38 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:47:38 --> The phrase "Password Again" could not be found in the language file.
DEBUG - 2020-06-24 18:47:38 --> The phrase "Terms of Use" could not be found in the language file.
DEBUG - 2020-06-24 18:47:38 --> The phrase "Have An Account? Sign In Here" could not be found in the language file.
INFO - 2020-06-24 18:47:38 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:47:38 --> File loaded: /var/www/html/application/views/register/index.php
INFO - 2020-06-24 18:47:38 --> Final output sent to browser
DEBUG - 2020-06-24 18:47:38 --> Total execution time: 0.1082
INFO - 2020-06-24 18:47:38 --> Config Class Initialized
INFO - 2020-06-24 18:47:38 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:47:38 --> Hooks Class Initialized
INFO - 2020-06-24 18:47:38 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:47:38 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:47:38 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:47:38 --> Utf8 Class Initialized
INFO - 2020-06-24 18:47:38 --> URI Class Initialized
DEBUG - 2020-06-24 18:47:38 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:47:38 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:47:38 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:47:50 --> Config Class Initialized
INFO - 2020-06-24 18:47:50 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:47:50 --> Hooks Class Initialized
INFO - 2020-06-24 18:47:50 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:47:50 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:47:50 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:47:50 --> Utf8 Class Initialized
INFO - 2020-06-24 18:47:50 --> URI Class Initialized
DEBUG - 2020-06-24 18:47:50 --> Validating request for /controllers/Register.php
INFO - 2020-06-24 18:47:50 --> Router Class Initialized
INFO - 2020-06-24 18:47:50 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:47:50 --> Output Class Initialized
INFO - 2020-06-24 18:47:50 --> Security Class Initialized
DEBUG - 2020-06-24 18:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:47:50 --> Input Class Initialized
INFO - 2020-06-24 18:47:50 --> Language Class Initialized
INFO - 2020-06-24 18:47:50 --> Loader Class Initialized
INFO - 2020-06-24 18:47:50 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:47:50 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:47:50 --> Helper loaded: data_helper
INFO - 2020-06-24 18:47:50 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:47:50 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:47:50 --> Helper loaded: view_helper
INFO - 2020-06-24 18:47:50 --> Helper loaded: url_helper
INFO - 2020-06-24 18:47:50 --> Database Driver Class Initialized
INFO - 2020-06-24 18:47:50 --> Controller Class Initialized
INFO - 2020-06-24 18:47:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:47:50 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:47:50 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:47:50 --> Plain_Model class loaded
INFO - 2020-06-24 18:47:50 --> Model "Users_model" initialized
INFO - 2020-06-24 18:47:50 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-06-24 18:47:50 --> Final output sent to browser
DEBUG - 2020-06-24 18:47:50 --> Total execution time: 0.1380
INFO - 2020-06-24 18:47:55 --> Config Class Initialized
INFO - 2020-06-24 18:47:55 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:47:55 --> Hooks Class Initialized
INFO - 2020-06-24 18:47:55 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:47:55 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:47:55 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:47:55 --> Utf8 Class Initialized
INFO - 2020-06-24 18:47:55 --> URI Class Initialized
DEBUG - 2020-06-24 18:47:55 --> No URI present. Default controller set.
INFO - 2020-06-24 18:47:55 --> Router Class Initialized
INFO - 2020-06-24 18:47:55 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:47:55 --> Output Class Initialized
INFO - 2020-06-24 18:47:55 --> Security Class Initialized
DEBUG - 2020-06-24 18:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:47:55 --> Input Class Initialized
INFO - 2020-06-24 18:47:55 --> Language Class Initialized
INFO - 2020-06-24 18:47:55 --> Loader Class Initialized
INFO - 2020-06-24 18:47:55 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:47:55 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:47:55 --> Helper loaded: data_helper
INFO - 2020-06-24 18:47:55 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:47:55 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:47:55 --> Helper loaded: view_helper
INFO - 2020-06-24 18:47:55 --> Helper loaded: url_helper
INFO - 2020-06-24 18:47:55 --> Database Driver Class Initialized
INFO - 2020-06-24 18:47:55 --> Controller Class Initialized
INFO - 2020-06-24 18:47:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:47:55 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:47:55 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:47:55 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:47:55 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:47:55 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:47:55 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:47:55 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:47:55 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:47:55 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:47:55 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:47:55 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:47:55 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:47:55 --> Final output sent to browser
DEBUG - 2020-06-24 18:47:55 --> Total execution time: 0.1636
INFO - 2020-06-24 18:47:55 --> Config Class Initialized
INFO - 2020-06-24 18:47:55 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:47:55 --> Hooks Class Initialized
INFO - 2020-06-24 18:47:55 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:47:55 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:47:55 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:47:55 --> Utf8 Class Initialized
INFO - 2020-06-24 18:47:55 --> URI Class Initialized
DEBUG - 2020-06-24 18:47:55 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:47:55 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:47:55 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:48:04 --> Config Class Initialized
INFO - 2020-06-24 18:48:04 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:48:04 --> Hooks Class Initialized
INFO - 2020-06-24 18:48:04 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:48:04 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:48:04 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:48:04 --> Utf8 Class Initialized
INFO - 2020-06-24 18:48:04 --> URI Class Initialized
DEBUG - 2020-06-24 18:48:04 --> Validating request for /controllers/Login.php
INFO - 2020-06-24 18:48:04 --> Router Class Initialized
INFO - 2020-06-24 18:48:04 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:48:04 --> Output Class Initialized
INFO - 2020-06-24 18:48:04 --> Security Class Initialized
DEBUG - 2020-06-24 18:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:48:04 --> Input Class Initialized
INFO - 2020-06-24 18:48:04 --> Language Class Initialized
INFO - 2020-06-24 18:48:04 --> Loader Class Initialized
INFO - 2020-06-24 18:48:04 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:48:04 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:48:04 --> Helper loaded: data_helper
INFO - 2020-06-24 18:48:04 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:48:04 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:48:04 --> Helper loaded: view_helper
INFO - 2020-06-24 18:48:04 --> Helper loaded: url_helper
INFO - 2020-06-24 18:48:04 --> Database Driver Class Initialized
INFO - 2020-06-24 18:48:04 --> Controller Class Initialized
INFO - 2020-06-24 18:48:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:48:04 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:48:04 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:48:04 --> Plain_Model class loaded
INFO - 2020-06-24 18:48:04 --> Model "Users_model" initialized
INFO - 2020-06-24 18:48:04 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-06-24 18:48:04 --> Final output sent to browser
DEBUG - 2020-06-24 18:48:04 --> Total execution time: 0.1289
INFO - 2020-06-24 18:48:05 --> Config Class Initialized
INFO - 2020-06-24 18:48:05 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:48:05 --> Hooks Class Initialized
INFO - 2020-06-24 18:48:05 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:48:05 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:48:05 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:48:05 --> Utf8 Class Initialized
INFO - 2020-06-24 18:48:05 --> URI Class Initialized
DEBUG - 2020-06-24 18:48:05 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 18:48:05 --> Router Class Initialized
INFO - 2020-06-24 18:48:05 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:48:05 --> Output Class Initialized
INFO - 2020-06-24 18:48:05 --> Security Class Initialized
DEBUG - 2020-06-24 18:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:48:05 --> Input Class Initialized
INFO - 2020-06-24 18:48:05 --> Language Class Initialized
INFO - 2020-06-24 18:48:05 --> Loader Class Initialized
INFO - 2020-06-24 18:48:05 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:48:05 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:48:05 --> Helper loaded: data_helper
INFO - 2020-06-24 18:48:05 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:48:05 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:48:05 --> Helper loaded: view_helper
INFO - 2020-06-24 18:48:05 --> Helper loaded: url_helper
INFO - 2020-06-24 18:48:05 --> Database Driver Class Initialized
INFO - 2020-06-24 18:48:05 --> Controller Class Initialized
INFO - 2020-06-24 18:48:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:48:05 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 18:48:05 --> Plain_Model class loaded
INFO - 2020-06-24 18:48:05 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:48:05 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:48:06 --> Model "Labels_model" initialized
INFO - 2020-06-24 18:48:06 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-24 18:48:06 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-24 18:48:06 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-24 18:48:06 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-24 18:48:06 --> The phrase "Recently-Used Tags" could not be found in the language file.
INFO - 2020-06-24 18:48:06 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-24 18:48:06 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-24 18:48:06 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-24 18:48:06 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-24 18:48:06 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-24 18:48:06 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-24 18:48:06 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-24 18:48:06 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 18:48:06 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 18:48:06 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 18:48:06 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 18:48:06 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 18:48:06 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-24 18:48:06 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-24 18:48:06 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-24 18:48:06 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-24 18:48:06 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-24 18:48:06 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-24 18:48:06 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-24 18:48:06 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-24 18:48:06 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-24 18:48:06 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-24 18:48:06 --> Final output sent to browser
DEBUG - 2020-06-24 18:48:06 --> Total execution time: 0.1758
INFO - 2020-06-24 18:48:06 --> Config Class Initialized
INFO - 2020-06-24 18:48:06 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:48:06 --> Hooks Class Initialized
INFO - 2020-06-24 18:48:06 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:48:06 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:48:06 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:48:06 --> Utf8 Class Initialized
INFO - 2020-06-24 18:48:06 --> URI Class Initialized
DEBUG - 2020-06-24 18:48:06 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:48:06 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:48:06 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:48:12 --> Config Class Initialized
INFO - 2020-06-24 18:48:12 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:48:12 --> Hooks Class Initialized
INFO - 2020-06-24 18:48:12 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:48:12 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:48:12 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:48:12 --> Utf8 Class Initialized
INFO - 2020-06-24 18:48:12 --> URI Class Initialized
DEBUG - 2020-06-24 18:48:12 --> Validating request for /controllers/Logout.php
INFO - 2020-06-24 18:48:12 --> Router Class Initialized
INFO - 2020-06-24 18:48:12 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:48:12 --> Output Class Initialized
INFO - 2020-06-24 18:48:12 --> Security Class Initialized
DEBUG - 2020-06-24 18:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:48:12 --> Input Class Initialized
INFO - 2020-06-24 18:48:12 --> Language Class Initialized
INFO - 2020-06-24 18:48:12 --> Loader Class Initialized
INFO - 2020-06-24 18:48:12 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:48:12 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:48:12 --> Helper loaded: data_helper
INFO - 2020-06-24 18:48:12 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:48:12 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:48:12 --> Helper loaded: view_helper
INFO - 2020-06-24 18:48:12 --> Helper loaded: url_helper
INFO - 2020-06-24 18:48:12 --> Database Driver Class Initialized
INFO - 2020-06-24 18:48:12 --> Controller Class Initialized
INFO - 2020-06-24 18:48:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:48:12 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:48:12 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:48:12 --> Config Class Initialized
INFO - 2020-06-24 18:48:12 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:48:12 --> Hooks Class Initialized
INFO - 2020-06-24 18:48:12 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:48:12 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:48:12 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:48:12 --> Utf8 Class Initialized
INFO - 2020-06-24 18:48:12 --> URI Class Initialized
DEBUG - 2020-06-24 18:48:12 --> No URI present. Default controller set.
INFO - 2020-06-24 18:48:12 --> Router Class Initialized
INFO - 2020-06-24 18:48:12 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:48:12 --> Output Class Initialized
INFO - 2020-06-24 18:48:12 --> Security Class Initialized
DEBUG - 2020-06-24 18:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:48:12 --> Input Class Initialized
INFO - 2020-06-24 18:48:12 --> Language Class Initialized
INFO - 2020-06-24 18:48:13 --> Loader Class Initialized
INFO - 2020-06-24 18:48:13 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:48:13 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:48:13 --> Helper loaded: data_helper
INFO - 2020-06-24 18:48:13 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:48:13 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:48:13 --> Helper loaded: view_helper
INFO - 2020-06-24 18:48:13 --> Helper loaded: url_helper
INFO - 2020-06-24 18:48:13 --> Database Driver Class Initialized
INFO - 2020-06-24 18:48:13 --> Controller Class Initialized
INFO - 2020-06-24 18:48:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:48:13 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:48:13 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:48:13 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:48:13 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:48:13 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:48:13 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:48:13 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:48:13 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:48:13 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:48:13 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:48:13 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:48:13 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:48:13 --> Final output sent to browser
DEBUG - 2020-06-24 18:48:13 --> Total execution time: 0.1479
INFO - 2020-06-24 18:48:13 --> Config Class Initialized
INFO - 2020-06-24 18:48:13 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:48:13 --> Hooks Class Initialized
INFO - 2020-06-24 18:48:13 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:48:13 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:48:13 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:48:13 --> Utf8 Class Initialized
INFO - 2020-06-24 18:48:13 --> URI Class Initialized
DEBUG - 2020-06-24 18:48:13 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:48:13 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:48:13 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:49:28 --> Config Class Initialized
INFO - 2020-06-24 18:49:28 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:49:28 --> Hooks Class Initialized
INFO - 2020-06-24 18:49:28 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:49:28 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:49:28 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:49:28 --> Utf8 Class Initialized
INFO - 2020-06-24 18:49:28 --> URI Class Initialized
DEBUG - 2020-06-24 18:49:28 --> No URI present. Default controller set.
INFO - 2020-06-24 18:49:28 --> Router Class Initialized
INFO - 2020-06-24 18:49:28 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:49:28 --> Output Class Initialized
INFO - 2020-06-24 18:49:28 --> Security Class Initialized
DEBUG - 2020-06-24 18:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:49:28 --> Input Class Initialized
INFO - 2020-06-24 18:49:28 --> Language Class Initialized
INFO - 2020-06-24 18:49:28 --> Loader Class Initialized
INFO - 2020-06-24 18:49:28 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:49:28 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:49:28 --> Helper loaded: data_helper
INFO - 2020-06-24 18:49:28 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:49:28 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:49:28 --> Helper loaded: view_helper
INFO - 2020-06-24 18:49:28 --> Helper loaded: url_helper
INFO - 2020-06-24 18:49:28 --> Database Driver Class Initialized
INFO - 2020-06-24 18:49:28 --> Controller Class Initialized
INFO - 2020-06-24 18:49:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:49:28 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:49:28 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:49:28 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:49:28 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:49:28 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:49:28 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:49:28 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:49:28 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:49:28 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:49:28 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:49:28 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:49:28 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:49:28 --> Final output sent to browser
DEBUG - 2020-06-24 18:49:28 --> Total execution time: 0.1294
INFO - 2020-06-24 18:56:04 --> Config Class Initialized
INFO - 2020-06-24 18:56:04 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:56:04 --> Hooks Class Initialized
INFO - 2020-06-24 18:56:04 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:56:04 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:56:04 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:56:04 --> Utf8 Class Initialized
INFO - 2020-06-24 18:56:04 --> URI Class Initialized
DEBUG - 2020-06-24 18:56:04 --> No URI present. Default controller set.
INFO - 2020-06-24 18:56:04 --> Router Class Initialized
INFO - 2020-06-24 18:56:04 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:56:04 --> Output Class Initialized
INFO - 2020-06-24 18:56:04 --> Security Class Initialized
DEBUG - 2020-06-24 18:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:56:05 --> Input Class Initialized
INFO - 2020-06-24 18:56:05 --> Language Class Initialized
INFO - 2020-06-24 18:56:05 --> Loader Class Initialized
INFO - 2020-06-24 18:56:05 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:56:05 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:56:05 --> Helper loaded: data_helper
INFO - 2020-06-24 18:56:05 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:56:05 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:56:05 --> Helper loaded: view_helper
INFO - 2020-06-24 18:56:05 --> Helper loaded: url_helper
INFO - 2020-06-24 18:56:05 --> Database Driver Class Initialized
INFO - 2020-06-24 18:56:05 --> Controller Class Initialized
INFO - 2020-06-24 18:56:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:56:05 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:56:05 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:56:05 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:56:05 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:56:05 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:56:05 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:56:05 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:56:05 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:56:05 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:56:05 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:56:05 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:56:05 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:56:05 --> Final output sent to browser
DEBUG - 2020-06-24 18:56:05 --> Total execution time: 0.1778
INFO - 2020-06-24 18:56:05 --> Config Class Initialized
INFO - 2020-06-24 18:56:05 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:56:05 --> Hooks Class Initialized
INFO - 2020-06-24 18:56:05 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:56:05 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:56:05 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:56:05 --> Utf8 Class Initialized
INFO - 2020-06-24 18:56:05 --> URI Class Initialized
DEBUG - 2020-06-24 18:56:05 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:56:05 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:56:05 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:56:06 --> Config Class Initialized
INFO - 2020-06-24 18:56:06 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:56:06 --> Hooks Class Initialized
INFO - 2020-06-24 18:56:06 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:56:06 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:56:06 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:56:06 --> Utf8 Class Initialized
INFO - 2020-06-24 18:56:06 --> URI Class Initialized
DEBUG - 2020-06-24 18:56:06 --> Validating request for /controllers/Register.php
INFO - 2020-06-24 18:56:06 --> Router Class Initialized
INFO - 2020-06-24 18:56:06 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:56:06 --> Output Class Initialized
INFO - 2020-06-24 18:56:06 --> Security Class Initialized
DEBUG - 2020-06-24 18:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:56:06 --> Input Class Initialized
INFO - 2020-06-24 18:56:06 --> Language Class Initialized
INFO - 2020-06-24 18:56:06 --> Loader Class Initialized
INFO - 2020-06-24 18:56:06 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:56:06 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:56:06 --> Helper loaded: data_helper
INFO - 2020-06-24 18:56:06 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:56:06 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:56:06 --> Helper loaded: view_helper
INFO - 2020-06-24 18:56:06 --> Helper loaded: url_helper
INFO - 2020-06-24 18:56:06 --> Database Driver Class Initialized
INFO - 2020-06-24 18:56:06 --> Controller Class Initialized
INFO - 2020-06-24 18:56:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:56:06 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:56:06 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:56:06 --> The phrase "Unmark : User Registration" could not be found in the language file.
DEBUG - 2020-06-24 18:56:06 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:56:06 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:56:06 --> The phrase "Password Again" could not be found in the language file.
DEBUG - 2020-06-24 18:56:06 --> The phrase "Terms of Use" could not be found in the language file.
DEBUG - 2020-06-24 18:56:06 --> The phrase "Have An Account? Sign In Here" could not be found in the language file.
INFO - 2020-06-24 18:56:06 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:56:06 --> File loaded: /var/www/html/application/views/register/index.php
INFO - 2020-06-24 18:56:06 --> Final output sent to browser
DEBUG - 2020-06-24 18:56:06 --> Total execution time: 0.1597
INFO - 2020-06-24 18:56:07 --> Config Class Initialized
INFO - 2020-06-24 18:56:07 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:56:07 --> Hooks Class Initialized
INFO - 2020-06-24 18:56:07 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:56:07 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:56:07 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:56:07 --> Utf8 Class Initialized
INFO - 2020-06-24 18:56:07 --> URI Class Initialized
DEBUG - 2020-06-24 18:56:07 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:56:07 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:56:07 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:56:15 --> Config Class Initialized
INFO - 2020-06-24 18:56:15 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:56:15 --> Hooks Class Initialized
INFO - 2020-06-24 18:56:15 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:56:15 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:56:15 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:56:15 --> Utf8 Class Initialized
INFO - 2020-06-24 18:56:15 --> URI Class Initialized
DEBUG - 2020-06-24 18:56:15 --> Validating request for /controllers/Register.php
INFO - 2020-06-24 18:56:15 --> Router Class Initialized
INFO - 2020-06-24 18:56:15 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:56:15 --> Output Class Initialized
INFO - 2020-06-24 18:56:15 --> Security Class Initialized
DEBUG - 2020-06-24 18:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:56:15 --> Input Class Initialized
INFO - 2020-06-24 18:56:15 --> Language Class Initialized
INFO - 2020-06-24 18:56:15 --> Loader Class Initialized
INFO - 2020-06-24 18:56:15 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:56:15 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:56:15 --> Helper loaded: data_helper
INFO - 2020-06-24 18:56:15 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:56:15 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:56:15 --> Helper loaded: view_helper
INFO - 2020-06-24 18:56:15 --> Helper loaded: url_helper
INFO - 2020-06-24 18:56:15 --> Database Driver Class Initialized
INFO - 2020-06-24 18:56:15 --> Controller Class Initialized
INFO - 2020-06-24 18:56:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:56:15 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:56:15 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:56:15 --> Plain_Model class loaded
INFO - 2020-06-24 18:56:15 --> Model "Users_model" initialized
INFO - 2020-06-24 18:56:15 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-06-24 18:56:15 --> Final output sent to browser
DEBUG - 2020-06-24 18:56:15 --> Total execution time: 0.1407
INFO - 2020-06-24 18:56:54 --> Config Class Initialized
INFO - 2020-06-24 18:56:54 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:56:54 --> Hooks Class Initialized
INFO - 2020-06-24 18:56:54 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:56:54 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:56:54 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:56:54 --> Utf8 Class Initialized
INFO - 2020-06-24 18:56:54 --> URI Class Initialized
DEBUG - 2020-06-24 18:56:54 --> Validating request for /controllers/Register.php
INFO - 2020-06-24 18:56:54 --> Router Class Initialized
INFO - 2020-06-24 18:56:54 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:56:54 --> Output Class Initialized
INFO - 2020-06-24 18:56:54 --> Security Class Initialized
DEBUG - 2020-06-24 18:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:56:54 --> Input Class Initialized
INFO - 2020-06-24 18:56:54 --> Language Class Initialized
INFO - 2020-06-24 18:56:54 --> Loader Class Initialized
INFO - 2020-06-24 18:56:54 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:56:54 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:56:54 --> Helper loaded: data_helper
INFO - 2020-06-24 18:56:54 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:56:54 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:56:54 --> Helper loaded: view_helper
INFO - 2020-06-24 18:56:54 --> Helper loaded: url_helper
INFO - 2020-06-24 18:56:54 --> Database Driver Class Initialized
ERROR - 2020-06-24 18:56:54 --> Unable to connect to the database
DEBUG - 2020-06-24 18:56:54 --> Language file loaded: language/english/db_lang.php
INFO - 2020-06-24 18:56:54 --> Plain_Exceptions Class Initialized
INFO - 2020-06-24 18:56:59 --> Config Class Initialized
INFO - 2020-06-24 18:56:59 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:56:59 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:00 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:00 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:00 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:00 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:00 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:00 --> No URI present. Default controller set.
INFO - 2020-06-24 18:57:00 --> Router Class Initialized
INFO - 2020-06-24 18:57:00 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:57:00 --> Output Class Initialized
INFO - 2020-06-24 18:57:00 --> Security Class Initialized
DEBUG - 2020-06-24 18:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:57:00 --> Input Class Initialized
INFO - 2020-06-24 18:57:00 --> Language Class Initialized
INFO - 2020-06-24 18:57:00 --> Loader Class Initialized
INFO - 2020-06-24 18:57:00 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:57:00 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:57:00 --> Helper loaded: data_helper
INFO - 2020-06-24 18:57:00 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:57:00 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:57:00 --> Helper loaded: view_helper
INFO - 2020-06-24 18:57:00 --> Helper loaded: url_helper
INFO - 2020-06-24 18:57:00 --> Database Driver Class Initialized
INFO - 2020-06-24 18:57:00 --> Controller Class Initialized
INFO - 2020-06-24 18:57:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:57:00 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:57:00 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:57:00 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:57:00 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:57:00 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:57:00 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:57:00 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:57:00 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:57:00 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:57:00 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:57:00 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:57:00 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:57:00 --> Final output sent to browser
DEBUG - 2020-06-24 18:57:00 --> Total execution time: 0.1748
INFO - 2020-06-24 18:57:00 --> Config Class Initialized
INFO - 2020-06-24 18:57:00 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:00 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:00 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:00 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:00 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:00 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:00 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:00 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:57:00 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:57:00 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:57:01 --> Config Class Initialized
INFO - 2020-06-24 18:57:01 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:01 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:01 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:01 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:01 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:01 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:01 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:01 --> Validating request for /controllers/Register.php
INFO - 2020-06-24 18:57:01 --> Router Class Initialized
INFO - 2020-06-24 18:57:01 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:57:01 --> Output Class Initialized
INFO - 2020-06-24 18:57:01 --> Security Class Initialized
DEBUG - 2020-06-24 18:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:57:01 --> Input Class Initialized
INFO - 2020-06-24 18:57:01 --> Language Class Initialized
INFO - 2020-06-24 18:57:01 --> Loader Class Initialized
INFO - 2020-06-24 18:57:01 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:57:01 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:57:01 --> Helper loaded: data_helper
INFO - 2020-06-24 18:57:01 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:57:01 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:57:01 --> Helper loaded: view_helper
INFO - 2020-06-24 18:57:01 --> Helper loaded: url_helper
INFO - 2020-06-24 18:57:01 --> Database Driver Class Initialized
INFO - 2020-06-24 18:57:01 --> Controller Class Initialized
INFO - 2020-06-24 18:57:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:57:01 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:57:01 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:57:01 --> The phrase "Unmark : User Registration" could not be found in the language file.
DEBUG - 2020-06-24 18:57:01 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:57:01 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:57:01 --> The phrase "Password Again" could not be found in the language file.
DEBUG - 2020-06-24 18:57:01 --> The phrase "Terms of Use" could not be found in the language file.
DEBUG - 2020-06-24 18:57:01 --> The phrase "Have An Account? Sign In Here" could not be found in the language file.
INFO - 2020-06-24 18:57:01 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:57:01 --> File loaded: /var/www/html/application/views/register/index.php
INFO - 2020-06-24 18:57:01 --> Final output sent to browser
DEBUG - 2020-06-24 18:57:01 --> Total execution time: 0.1547
INFO - 2020-06-24 18:57:01 --> Config Class Initialized
INFO - 2020-06-24 18:57:01 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:01 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:01 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:01 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:01 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:01 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:01 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:01 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:57:01 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:57:01 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:57:11 --> Config Class Initialized
INFO - 2020-06-24 18:57:11 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:11 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:11 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:11 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:11 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:11 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:11 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:11 --> Validating request for /controllers/Register.php
INFO - 2020-06-24 18:57:11 --> Router Class Initialized
INFO - 2020-06-24 18:57:11 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:57:11 --> Output Class Initialized
INFO - 2020-06-24 18:57:11 --> Security Class Initialized
DEBUG - 2020-06-24 18:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:57:11 --> Input Class Initialized
INFO - 2020-06-24 18:57:11 --> Language Class Initialized
INFO - 2020-06-24 18:57:11 --> Loader Class Initialized
INFO - 2020-06-24 18:57:11 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:57:11 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:57:11 --> Helper loaded: data_helper
INFO - 2020-06-24 18:57:11 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:57:11 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:57:11 --> Helper loaded: view_helper
INFO - 2020-06-24 18:57:11 --> Helper loaded: url_helper
INFO - 2020-06-24 18:57:11 --> Database Driver Class Initialized
INFO - 2020-06-24 18:57:11 --> Controller Class Initialized
INFO - 2020-06-24 18:57:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:57:11 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:57:11 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:57:11 --> Plain_Model class loaded
INFO - 2020-06-24 18:57:11 --> Model "Users_model" initialized
ERROR - 2020-06-24 18:57:11 --> Query error: Table 'unmark.users' doesn't exist - Invalid query: 
            SELECT
            COUNT(users.user_id) AS total
            FROM `users` WHERE email = 'colin@cdevroe.com'
DEBUG - 2020-06-24 18:57:11 --> Language file loaded: language/english/db_lang.php
INFO - 2020-06-24 18:57:11 --> Plain_Exceptions Class Initialized
INFO - 2020-06-24 18:57:21 --> Config Class Initialized
INFO - 2020-06-24 18:57:21 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:21 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:21 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:21 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:21 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:21 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:21 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:21 --> Validating request for /controllers/Install.php
INFO - 2020-06-24 18:57:21 --> Router Class Initialized
INFO - 2020-06-24 18:57:21 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:57:21 --> Output Class Initialized
INFO - 2020-06-24 18:57:21 --> Security Class Initialized
DEBUG - 2020-06-24 18:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:57:21 --> Input Class Initialized
INFO - 2020-06-24 18:57:21 --> Language Class Initialized
INFO - 2020-06-24 18:57:21 --> Loader Class Initialized
INFO - 2020-06-24 18:57:21 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:57:21 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:57:21 --> Helper loaded: data_helper
INFO - 2020-06-24 18:57:21 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:57:21 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:57:21 --> Helper loaded: view_helper
INFO - 2020-06-24 18:57:21 --> Helper loaded: url_helper
INFO - 2020-06-24 18:57:21 --> Database Driver Class Initialized
INFO - 2020-06-24 18:57:21 --> Controller Class Initialized
DEBUG - 2020-06-24 18:57:21 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:57:21 --> The phrase "Unmark: Setup" could not be found in the language file.
DEBUG - 2020-06-24 18:57:21 --> The phrase "Welcome to Unmark, the to-do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:57:21 --> The phrase "You're about to install version 2020.1 of the app.</p><p>Please <a href="https://github.com/plainmade/unmark/blob/master/readme.md">read the installation instructions</a> first." could not be found in the language file.
DEBUG - 2020-06-24 18:57:21 --> The phrase "Click to Install" could not be found in the language file.
INFO - 2020-06-24 18:57:21 --> File loaded: /var/www/html/application/views/setup.php
INFO - 2020-06-24 18:57:21 --> Final output sent to browser
DEBUG - 2020-06-24 18:57:21 --> Total execution time: 0.1538
INFO - 2020-06-24 18:57:21 --> Config Class Initialized
INFO - 2020-06-24 18:57:21 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:21 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:21 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:21 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:21 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:21 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:21 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:21 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:57:21 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:57:21 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:57:23 --> Config Class Initialized
INFO - 2020-06-24 18:57:23 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:23 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:23 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:23 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:23 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:23 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:23 --> Validating request for /controllers/Install.php
INFO - 2020-06-24 18:57:23 --> Router Class Initialized
INFO - 2020-06-24 18:57:23 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:57:23 --> Output Class Initialized
INFO - 2020-06-24 18:57:23 --> Security Class Initialized
DEBUG - 2020-06-24 18:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:57:23 --> Input Class Initialized
INFO - 2020-06-24 18:57:23 --> Language Class Initialized
INFO - 2020-06-24 18:57:23 --> Loader Class Initialized
INFO - 2020-06-24 18:57:23 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:57:23 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:57:23 --> Helper loaded: data_helper
INFO - 2020-06-24 18:57:23 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:57:23 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:57:23 --> Helper loaded: view_helper
INFO - 2020-06-24 18:57:23 --> Helper loaded: url_helper
INFO - 2020-06-24 18:57:23 --> Database Driver Class Initialized
INFO - 2020-06-24 18:57:23 --> Controller Class Initialized
DEBUG - 2020-06-24 18:57:23 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:57:23 --> Plain Migrations class initialized
DEBUG - 2020-06-24 18:57:23 --> Language file loaded: language/english/migration_lang.php
INFO - 2020-06-24 18:57:23 --> Database Forge Class Initialized
DEBUG - 2020-06-24 18:57:23 --> Making backup before migrating failed.
DEBUG - 2020-06-24 18:57:23 --> Migrating up from version 0 to version 001
DEBUG - 2020-06-24 18:57:23 --> Migrating up from version 001 to version 002
DEBUG - 2020-06-24 18:57:23 --> Migrating up from version 002 to version 003
DEBUG - 2020-06-24 18:57:23 --> Migrating up from version 003 to version 004
DEBUG - 2020-06-24 18:57:23 --> Migrating up from version 004 to version 005
DEBUG - 2020-06-24 18:57:23 --> Migrating up from version 005 to version 006
DEBUG - 2020-06-24 18:57:23 --> Migrating up from version 006 to version 007
DEBUG - 2020-06-24 18:57:23 --> Migrating up from version 007 to version 008
DEBUG - 2020-06-24 18:57:23 --> Migrating up from version 008 to version 009
DEBUG - 2020-06-24 18:57:23 --> Migrating up from version 009 to version 010
DEBUG - 2020-06-24 18:57:23 --> Migrating up from version 010 to version 2014022801
DEBUG - 2020-06-24 18:57:23 --> Migrating up from version 2014022801 to version 2014112501
DEBUG - 2020-06-24 18:57:23 --> Finished migrating to 2014112501
DEBUG - 2020-06-24 18:57:23 --> Making backup before migrating failed.
INFO - 2020-06-24 18:57:23 --> Config Class Initialized
INFO - 2020-06-24 18:57:23 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:23 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:23 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:23 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:23 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:23 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:23 --> Validating request for /controllers/Register.php
INFO - 2020-06-24 18:57:23 --> Router Class Initialized
INFO - 2020-06-24 18:57:23 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:57:23 --> Output Class Initialized
INFO - 2020-06-24 18:57:23 --> Security Class Initialized
DEBUG - 2020-06-24 18:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:57:23 --> Input Class Initialized
INFO - 2020-06-24 18:57:23 --> Language Class Initialized
INFO - 2020-06-24 18:57:23 --> Loader Class Initialized
INFO - 2020-06-24 18:57:23 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:57:23 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:57:23 --> Helper loaded: data_helper
INFO - 2020-06-24 18:57:23 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:57:23 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:57:23 --> Helper loaded: view_helper
INFO - 2020-06-24 18:57:23 --> Helper loaded: url_helper
INFO - 2020-06-24 18:57:23 --> Database Driver Class Initialized
INFO - 2020-06-24 18:57:23 --> Controller Class Initialized
INFO - 2020-06-24 18:57:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:57:23 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:57:23 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:57:23 --> The phrase "Unmark : User Registration" could not be found in the language file.
DEBUG - 2020-06-24 18:57:23 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:57:23 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:57:23 --> The phrase "Password Again" could not be found in the language file.
DEBUG - 2020-06-24 18:57:23 --> The phrase "Terms of Use" could not be found in the language file.
DEBUG - 2020-06-24 18:57:23 --> The phrase "Have An Account? Sign In Here" could not be found in the language file.
INFO - 2020-06-24 18:57:23 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:57:23 --> File loaded: /var/www/html/application/views/register/index.php
INFO - 2020-06-24 18:57:23 --> Final output sent to browser
DEBUG - 2020-06-24 18:57:23 --> Total execution time: 0.1136
INFO - 2020-06-24 18:57:24 --> Config Class Initialized
INFO - 2020-06-24 18:57:24 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:24 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:24 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:24 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:24 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:24 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:24 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:24 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:57:24 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:57:24 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:57:33 --> Config Class Initialized
INFO - 2020-06-24 18:57:33 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:33 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:33 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:33 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:33 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:33 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:33 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:33 --> Validating request for /controllers/Register.php
INFO - 2020-06-24 18:57:33 --> Router Class Initialized
INFO - 2020-06-24 18:57:33 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:57:33 --> Output Class Initialized
INFO - 2020-06-24 18:57:33 --> Security Class Initialized
DEBUG - 2020-06-24 18:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:57:33 --> Input Class Initialized
INFO - 2020-06-24 18:57:33 --> Language Class Initialized
INFO - 2020-06-24 18:57:33 --> Loader Class Initialized
INFO - 2020-06-24 18:57:33 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:57:33 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:57:33 --> Helper loaded: data_helper
INFO - 2020-06-24 18:57:33 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:57:33 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:57:33 --> Helper loaded: view_helper
INFO - 2020-06-24 18:57:33 --> Helper loaded: url_helper
INFO - 2020-06-24 18:57:33 --> Database Driver Class Initialized
INFO - 2020-06-24 18:57:33 --> Controller Class Initialized
INFO - 2020-06-24 18:57:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:57:33 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:57:33 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:57:33 --> Plain_Model class loaded
INFO - 2020-06-24 18:57:33 --> Model "Users_model" initialized
INFO - 2020-06-24 18:57:33 --> Helper loaded: http_build_url_helper
INFO - 2020-06-24 18:57:33 --> Model "Marks_model" initialized
INFO - 2020-06-24 18:57:33 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:57:33 --> The phrase "Just Now" could not be found in the language file.
DEBUG - 2020-06-24 18:57:33 --> The phrase "Just Now" could not be found in the language file.
DEBUG - 2020-06-24 18:57:33 --> The phrase "Just Now" could not be found in the language file.
INFO - 2020-06-24 18:57:33 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-06-24 18:57:33 --> Final output sent to browser
DEBUG - 2020-06-24 18:57:33 --> Total execution time: 0.1905
INFO - 2020-06-24 18:57:36 --> Config Class Initialized
INFO - 2020-06-24 18:57:36 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:36 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:36 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:36 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:36 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:36 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:36 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:36 --> No URI present. Default controller set.
INFO - 2020-06-24 18:57:36 --> Router Class Initialized
INFO - 2020-06-24 18:57:36 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:57:36 --> Output Class Initialized
INFO - 2020-06-24 18:57:36 --> Security Class Initialized
DEBUG - 2020-06-24 18:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:57:36 --> Input Class Initialized
INFO - 2020-06-24 18:57:36 --> Language Class Initialized
INFO - 2020-06-24 18:57:36 --> Loader Class Initialized
INFO - 2020-06-24 18:57:36 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:57:36 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:57:36 --> Helper loaded: data_helper
INFO - 2020-06-24 18:57:36 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:57:36 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:57:36 --> Helper loaded: view_helper
INFO - 2020-06-24 18:57:36 --> Helper loaded: url_helper
INFO - 2020-06-24 18:57:36 --> Database Driver Class Initialized
INFO - 2020-06-24 18:57:36 --> Controller Class Initialized
INFO - 2020-06-24 18:57:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:57:36 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:57:36 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:57:36 --> Config Class Initialized
INFO - 2020-06-24 18:57:36 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:36 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:36 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:36 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:36 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:36 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:36 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:36 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 18:57:36 --> Router Class Initialized
INFO - 2020-06-24 18:57:36 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:57:36 --> Output Class Initialized
INFO - 2020-06-24 18:57:36 --> Security Class Initialized
DEBUG - 2020-06-24 18:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:57:36 --> Input Class Initialized
INFO - 2020-06-24 18:57:36 --> Language Class Initialized
INFO - 2020-06-24 18:57:36 --> Loader Class Initialized
INFO - 2020-06-24 18:57:36 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:57:36 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:57:36 --> Helper loaded: data_helper
INFO - 2020-06-24 18:57:36 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:57:36 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:57:36 --> Helper loaded: view_helper
INFO - 2020-06-24 18:57:36 --> Helper loaded: url_helper
INFO - 2020-06-24 18:57:36 --> Database Driver Class Initialized
INFO - 2020-06-24 18:57:36 --> Controller Class Initialized
INFO - 2020-06-24 18:57:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:57:36 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 18:57:36 --> Plain_Model class loaded
INFO - 2020-06-24 18:57:36 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:57:36 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:57:36 --> Model "Labels_model" initialized
INFO - 2020-06-24 18:57:36 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-24 18:57:36 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-24 18:57:36 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-24 18:57:36 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-24 18:57:36 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-24 18:57:36 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-24 18:57:36 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-24 18:57:36 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-24 18:57:36 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-24 18:57:36 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-24 18:57:36 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-24 18:57:36 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-24 18:57:36 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-24 18:57:36 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-24 18:57:36 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 18:57:36 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 18:57:36 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 18:57:36 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 18:57:36 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 18:57:36 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-24 18:57:36 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-24 18:57:36 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-24 18:57:36 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-24 18:57:36 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-24 18:57:36 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-24 18:57:36 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-24 18:57:36 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-24 18:57:36 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-24 18:57:36 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-24 18:57:36 --> Final output sent to browser
DEBUG - 2020-06-24 18:57:36 --> Total execution time: 0.2226
INFO - 2020-06-24 18:57:36 --> Config Class Initialized
INFO - 2020-06-24 18:57:36 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:36 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:36 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:36 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:36 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:36 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:36 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:36 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:57:36 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:57:36 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:57:50 --> Config Class Initialized
INFO - 2020-06-24 18:57:50 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:50 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:50 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:50 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:50 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:50 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:50 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:50 --> Validating request for /controllers/Import.php
INFO - 2020-06-24 18:57:50 --> Router Class Initialized
INFO - 2020-06-24 18:57:50 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:57:50 --> Output Class Initialized
INFO - 2020-06-24 18:57:50 --> Security Class Initialized
DEBUG - 2020-06-24 18:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:57:50 --> Input Class Initialized
INFO - 2020-06-24 18:57:50 --> Language Class Initialized
INFO - 2020-06-24 18:57:50 --> Loader Class Initialized
INFO - 2020-06-24 18:57:50 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:57:50 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:57:50 --> Helper loaded: data_helper
INFO - 2020-06-24 18:57:50 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:57:50 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:57:50 --> Helper loaded: view_helper
INFO - 2020-06-24 18:57:50 --> Helper loaded: url_helper
INFO - 2020-06-24 18:57:50 --> Database Driver Class Initialized
INFO - 2020-06-24 18:57:50 --> Controller Class Initialized
INFO - 2020-06-24 18:57:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:57:50 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:57:50 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:57:50 --> Importing bookmarks from an HTML file.
INFO - 2020-06-24 18:57:50 --> Plain_Model class loaded
INFO - 2020-06-24 18:57:50 --> Model "Marks_model" initialized
INFO - 2020-06-24 18:57:50 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-24 18:57:50 --> Model "Labels_model" initialized
DEBUG - 2020-06-24 18:57:54 --> Finished importing bookmarks from an HTML file.
DEBUG - 2020-06-24 18:57:54 --> The phrase "Unmark : Importer" could not be found in the language file.
DEBUG - 2020-06-24 18:57:54 --> The phrase "Successful Upload!" could not be found in the language file.
DEBUG - 2020-06-24 18:57:54 --> The phrase "%s marks added" could not be found in the language file.
DEBUG - 2020-06-24 18:57:54 --> The phrase "%s marks skipped" could not be found in the language file.
DEBUG - 2020-06-24 18:57:54 --> The phrase "%s marks failed" could not be found in the language file.
DEBUG - 2020-06-24 18:57:54 --> The phrase "%s marks total" could not be found in the language file.
DEBUG - 2020-06-24 18:57:54 --> The phrase "<a href='/' class="back-button"> Go back & see them</a>" could not be found in the language file.
INFO - 2020-06-24 18:57:54 --> File loaded: /var/www/html/application/views/import/index.php
INFO - 2020-06-24 18:57:54 --> Final output sent to browser
DEBUG - 2020-06-24 18:57:54 --> Total execution time: 4.6153
DEBUG - 2020-06-24 18:57:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-24 18:57:54 --> Array
(
    [message] => Warning: DOMDocument::loadHTML(): htmlParseEntityRef: expecting ';' in Entity, line: 4995
    [type] => Warning
    [backtrace] => /var/www/html/application/controllers/Import.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => Huwa33pXxfLMXAc7PY9MvpvWoJCmK62f07a20f9dc1740d2f4b274158b3fb62
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-24 18:57:33
            [last_updated] => 2020-06-24 18:57:33
        )

)

INFO - 2020-06-24 18:57:55 --> Config Class Initialized
INFO - 2020-06-24 18:57:55 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:55 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:55 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:55 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:55 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:55 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:55 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:55 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:57:55 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:57:55 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:57:58 --> Config Class Initialized
INFO - 2020-06-24 18:57:58 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:58 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:58 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:58 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:58 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:58 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:58 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:58 --> No URI present. Default controller set.
INFO - 2020-06-24 18:57:58 --> Router Class Initialized
INFO - 2020-06-24 18:57:58 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:57:58 --> Output Class Initialized
INFO - 2020-06-24 18:57:58 --> Security Class Initialized
DEBUG - 2020-06-24 18:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:57:58 --> Input Class Initialized
INFO - 2020-06-24 18:57:58 --> Language Class Initialized
INFO - 2020-06-24 18:57:58 --> Loader Class Initialized
INFO - 2020-06-24 18:57:58 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:57:58 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:57:58 --> Helper loaded: data_helper
INFO - 2020-06-24 18:57:58 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:57:58 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:57:58 --> Helper loaded: view_helper
INFO - 2020-06-24 18:57:58 --> Helper loaded: url_helper
INFO - 2020-06-24 18:57:58 --> Database Driver Class Initialized
INFO - 2020-06-24 18:57:58 --> Controller Class Initialized
INFO - 2020-06-24 18:57:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:57:58 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:57:58 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:57:58 --> Config Class Initialized
INFO - 2020-06-24 18:57:58 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:58 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:58 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:58 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:58 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:58 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:58 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:58 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 18:57:58 --> Router Class Initialized
INFO - 2020-06-24 18:57:58 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:57:58 --> Output Class Initialized
INFO - 2020-06-24 18:57:58 --> Security Class Initialized
DEBUG - 2020-06-24 18:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:57:58 --> Input Class Initialized
INFO - 2020-06-24 18:57:58 --> Language Class Initialized
INFO - 2020-06-24 18:57:58 --> Loader Class Initialized
INFO - 2020-06-24 18:57:58 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:57:58 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:57:58 --> Helper loaded: data_helper
INFO - 2020-06-24 18:57:58 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:57:58 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:57:58 --> Helper loaded: view_helper
INFO - 2020-06-24 18:57:58 --> Helper loaded: url_helper
INFO - 2020-06-24 18:57:58 --> Database Driver Class Initialized
INFO - 2020-06-24 18:57:58 --> Controller Class Initialized
INFO - 2020-06-24 18:57:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:57:58 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 18:57:58 --> Plain_Model class loaded
INFO - 2020-06-24 18:57:58 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:57:58 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:57:58 --> Model "Labels_model" initialized
INFO - 2020-06-24 18:57:58 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-24 18:57:58 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-24 18:57:58 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-24 18:57:58 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-24 18:57:58 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-24 18:57:58 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-24 18:57:58 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-24 18:57:58 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-24 18:57:58 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-24 18:57:58 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-24 18:57:58 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-24 18:57:58 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-24 18:57:58 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-24 18:57:58 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-24 18:57:58 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 18:57:58 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 18:57:58 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 18:57:58 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 18:57:58 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 18:57:58 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-24 18:57:58 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-24 18:57:58 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-24 18:57:58 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-24 18:57:58 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-24 18:57:58 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-24 18:57:58 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-24 18:57:58 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-24 18:57:58 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-24 18:57:58 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-24 18:57:58 --> Final output sent to browser
DEBUG - 2020-06-24 18:57:58 --> Total execution time: 0.2421
INFO - 2020-06-24 18:57:58 --> Config Class Initialized
INFO - 2020-06-24 18:57:58 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:57:58 --> Hooks Class Initialized
INFO - 2020-06-24 18:57:58 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:57:58 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:57:58 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:57:58 --> Utf8 Class Initialized
INFO - 2020-06-24 18:57:58 --> URI Class Initialized
DEBUG - 2020-06-24 18:57:59 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 18:57:59 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 18:57:59 --> 404 Page Not Found: custom
INFO - 2020-06-24 18:58:11 --> Config Class Initialized
INFO - 2020-06-24 18:58:11 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:58:11 --> Hooks Class Initialized
INFO - 2020-06-24 18:58:11 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:58:11 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:58:11 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:58:11 --> Utf8 Class Initialized
INFO - 2020-06-24 18:58:11 --> URI Class Initialized
DEBUG - 2020-06-24 18:58:11 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 18:58:11 --> Router Class Initialized
INFO - 2020-06-24 18:58:11 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:58:11 --> Output Class Initialized
INFO - 2020-06-24 18:58:11 --> Security Class Initialized
DEBUG - 2020-06-24 18:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:58:11 --> Input Class Initialized
INFO - 2020-06-24 18:58:11 --> Language Class Initialized
INFO - 2020-06-24 18:58:11 --> Loader Class Initialized
INFO - 2020-06-24 18:58:11 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:58:11 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:58:11 --> Helper loaded: data_helper
INFO - 2020-06-24 18:58:11 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:58:11 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:58:11 --> Helper loaded: view_helper
INFO - 2020-06-24 18:58:11 --> Helper loaded: url_helper
INFO - 2020-06-24 18:58:11 --> Database Driver Class Initialized
INFO - 2020-06-24 18:58:11 --> Controller Class Initialized
INFO - 2020-06-24 18:58:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:58:11 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 18:58:11 --> Plain_Model class loaded
INFO - 2020-06-24 18:58:11 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:58:11 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:58:11 --> Model "Labels_model" initialized
DEBUG - 2020-06-24 18:58:11 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 18:58:11 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 18:58:11 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 18:58:11 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 18:58:11 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 18:58:11 --> Final output sent to browser
DEBUG - 2020-06-24 18:58:11 --> Total execution time: 0.1574
INFO - 2020-06-24 18:58:12 --> Config Class Initialized
INFO - 2020-06-24 18:58:12 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:58:12 --> Hooks Class Initialized
INFO - 2020-06-24 18:58:12 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:58:12 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:58:12 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:58:12 --> Utf8 Class Initialized
INFO - 2020-06-24 18:58:12 --> URI Class Initialized
DEBUG - 2020-06-24 18:58:12 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 18:58:12 --> Router Class Initialized
INFO - 2020-06-24 18:58:12 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:58:12 --> Output Class Initialized
INFO - 2020-06-24 18:58:12 --> Security Class Initialized
DEBUG - 2020-06-24 18:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:58:12 --> Input Class Initialized
INFO - 2020-06-24 18:58:12 --> Language Class Initialized
INFO - 2020-06-24 18:58:12 --> Loader Class Initialized
INFO - 2020-06-24 18:58:12 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:58:12 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:58:12 --> Helper loaded: data_helper
INFO - 2020-06-24 18:58:12 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:58:12 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:58:12 --> Helper loaded: view_helper
INFO - 2020-06-24 18:58:12 --> Helper loaded: url_helper
INFO - 2020-06-24 18:58:12 --> Database Driver Class Initialized
INFO - 2020-06-24 18:58:12 --> Controller Class Initialized
INFO - 2020-06-24 18:58:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:58:12 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 18:58:12 --> Plain_Model class loaded
INFO - 2020-06-24 18:58:12 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:58:12 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:58:12 --> Model "Labels_model" initialized
DEBUG - 2020-06-24 18:58:12 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 18:58:12 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 18:58:12 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 18:58:12 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 18:58:12 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 18:58:12 --> Final output sent to browser
DEBUG - 2020-06-24 18:58:12 --> Total execution time: 0.1501
INFO - 2020-06-24 18:58:17 --> Config Class Initialized
INFO - 2020-06-24 18:58:17 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:58:17 --> Hooks Class Initialized
INFO - 2020-06-24 18:58:17 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:58:17 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:58:17 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:58:17 --> Utf8 Class Initialized
INFO - 2020-06-24 18:58:17 --> URI Class Initialized
DEBUG - 2020-06-24 18:58:17 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 18:58:17 --> Router Class Initialized
INFO - 2020-06-24 18:58:17 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:58:17 --> Output Class Initialized
INFO - 2020-06-24 18:58:17 --> Security Class Initialized
DEBUG - 2020-06-24 18:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:58:17 --> Input Class Initialized
INFO - 2020-06-24 18:58:17 --> Language Class Initialized
INFO - 2020-06-24 18:58:17 --> Loader Class Initialized
INFO - 2020-06-24 18:58:17 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:58:17 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:58:17 --> Helper loaded: data_helper
INFO - 2020-06-24 18:58:17 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:58:17 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:58:17 --> Helper loaded: view_helper
INFO - 2020-06-24 18:58:17 --> Helper loaded: url_helper
INFO - 2020-06-24 18:58:17 --> Database Driver Class Initialized
INFO - 2020-06-24 18:58:17 --> Controller Class Initialized
INFO - 2020-06-24 18:58:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:58:17 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 18:58:17 --> Plain_Model class loaded
INFO - 2020-06-24 18:58:17 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:58:17 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:58:17 --> Model "Labels_model" initialized
DEBUG - 2020-06-24 18:58:17 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 18:58:17 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 18:58:17 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 18:58:17 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 18:58:17 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 18:58:17 --> Final output sent to browser
DEBUG - 2020-06-24 18:58:17 --> Total execution time: 0.1424
INFO - 2020-06-24 18:58:22 --> Config Class Initialized
INFO - 2020-06-24 18:58:22 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:58:22 --> Hooks Class Initialized
INFO - 2020-06-24 18:58:22 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:58:22 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:58:22 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:58:22 --> Utf8 Class Initialized
INFO - 2020-06-24 18:58:22 --> URI Class Initialized
DEBUG - 2020-06-24 18:58:22 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 18:58:22 --> Router Class Initialized
INFO - 2020-06-24 18:58:22 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:58:22 --> Output Class Initialized
INFO - 2020-06-24 18:58:22 --> Security Class Initialized
DEBUG - 2020-06-24 18:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:58:22 --> Input Class Initialized
INFO - 2020-06-24 18:58:22 --> Language Class Initialized
INFO - 2020-06-24 18:58:22 --> Loader Class Initialized
INFO - 2020-06-24 18:58:22 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:58:22 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:58:22 --> Helper loaded: data_helper
INFO - 2020-06-24 18:58:22 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:58:22 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:58:22 --> Helper loaded: view_helper
INFO - 2020-06-24 18:58:22 --> Helper loaded: url_helper
INFO - 2020-06-24 18:58:22 --> Database Driver Class Initialized
INFO - 2020-06-24 18:58:22 --> Controller Class Initialized
INFO - 2020-06-24 18:58:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:58:22 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 18:58:22 --> Plain_Model class loaded
INFO - 2020-06-24 18:58:22 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:58:22 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:58:22 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 18:58:22 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 18:58:22 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 18:58:22 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 18:58:22 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 18:58:22 --> Final output sent to browser
DEBUG - 2020-06-24 18:58:22 --> Total execution time: 0.2375
INFO - 2020-06-24 18:58:25 --> Config Class Initialized
INFO - 2020-06-24 18:58:25 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:58:25 --> Hooks Class Initialized
INFO - 2020-06-24 18:58:25 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:58:25 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:58:25 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:58:25 --> Utf8 Class Initialized
INFO - 2020-06-24 18:58:25 --> URI Class Initialized
DEBUG - 2020-06-24 18:58:25 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 18:58:25 --> Router Class Initialized
INFO - 2020-06-24 18:58:25 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:58:25 --> Output Class Initialized
INFO - 2020-06-24 18:58:25 --> Security Class Initialized
DEBUG - 2020-06-24 18:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:58:25 --> Input Class Initialized
INFO - 2020-06-24 18:58:25 --> Language Class Initialized
INFO - 2020-06-24 18:58:25 --> Loader Class Initialized
INFO - 2020-06-24 18:58:25 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:58:25 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:58:25 --> Helper loaded: data_helper
INFO - 2020-06-24 18:58:25 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:58:25 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:58:25 --> Helper loaded: view_helper
INFO - 2020-06-24 18:58:25 --> Helper loaded: url_helper
INFO - 2020-06-24 18:58:25 --> Database Driver Class Initialized
INFO - 2020-06-24 18:58:25 --> Controller Class Initialized
INFO - 2020-06-24 18:58:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:58:25 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 18:58:25 --> Plain_Model class loaded
INFO - 2020-06-24 18:58:25 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:58:25 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:58:25 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 18:58:25 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 18:58:25 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 18:58:25 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 18:58:25 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 18:58:25 --> Final output sent to browser
DEBUG - 2020-06-24 18:58:25 --> Total execution time: 0.2180
INFO - 2020-06-24 18:58:34 --> Config Class Initialized
INFO - 2020-06-24 18:58:34 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:58:34 --> Hooks Class Initialized
INFO - 2020-06-24 18:58:34 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:58:34 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:58:34 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:58:34 --> Utf8 Class Initialized
INFO - 2020-06-24 18:58:34 --> URI Class Initialized
DEBUG - 2020-06-24 18:58:34 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 18:58:34 --> Router Class Initialized
INFO - 2020-06-24 18:58:34 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:58:34 --> Output Class Initialized
INFO - 2020-06-24 18:58:34 --> Security Class Initialized
DEBUG - 2020-06-24 18:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:58:34 --> Input Class Initialized
INFO - 2020-06-24 18:58:34 --> Language Class Initialized
INFO - 2020-06-24 18:58:34 --> Loader Class Initialized
INFO - 2020-06-24 18:58:34 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:58:34 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:58:34 --> Helper loaded: data_helper
INFO - 2020-06-24 18:58:34 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:58:34 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:58:34 --> Helper loaded: view_helper
INFO - 2020-06-24 18:58:34 --> Helper loaded: url_helper
INFO - 2020-06-24 18:58:34 --> Database Driver Class Initialized
INFO - 2020-06-24 18:58:34 --> Controller Class Initialized
INFO - 2020-06-24 18:58:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:58:34 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 18:58:34 --> Plain_Model class loaded
INFO - 2020-06-24 18:58:34 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 18:58:34 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:58:34 --> Running get method for labels
INFO - 2020-06-24 18:58:34 --> Model "Labels_model" initialized
INFO - 2020-06-24 18:58:34 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-06-24 18:58:34 --> Final output sent to browser
DEBUG - 2020-06-24 18:58:34 --> Total execution time: 0.1596
INFO - 2020-06-24 18:58:34 --> Config Class Initialized
INFO - 2020-06-24 18:58:34 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:58:34 --> Hooks Class Initialized
INFO - 2020-06-24 18:58:34 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:58:34 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:58:34 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:58:34 --> Utf8 Class Initialized
INFO - 2020-06-24 18:58:34 --> URI Class Initialized
DEBUG - 2020-06-24 18:58:34 --> Validating request for /controllers/Tags.php
INFO - 2020-06-24 18:58:34 --> Router Class Initialized
INFO - 2020-06-24 18:58:34 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:58:34 --> Output Class Initialized
INFO - 2020-06-24 18:58:34 --> Security Class Initialized
DEBUG - 2020-06-24 18:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:58:34 --> Input Class Initialized
INFO - 2020-06-24 18:58:34 --> Language Class Initialized
INFO - 2020-06-24 18:58:34 --> Loader Class Initialized
INFO - 2020-06-24 18:58:34 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:58:34 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:58:34 --> Helper loaded: data_helper
INFO - 2020-06-24 18:58:34 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:58:34 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:58:34 --> Helper loaded: view_helper
INFO - 2020-06-24 18:58:34 --> Helper loaded: url_helper
INFO - 2020-06-24 18:58:34 --> Database Driver Class Initialized
INFO - 2020-06-24 18:58:34 --> Controller Class Initialized
INFO - 2020-06-24 18:58:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:58:34 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 18:58:34 --> Plain_Model class loaded
INFO - 2020-06-24 18:58:34 --> Model "Tags_model" initialized
DEBUG - 2020-06-24 18:58:34 --> The "english" language file has been loaded.
INFO - 2020-06-24 18:58:34 --> Model "User_Marks_To_Tags_model" initialized
INFO - 2020-06-24 18:58:34 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-06-24 18:58:34 --> Final output sent to browser
DEBUG - 2020-06-24 18:58:34 --> Total execution time: 0.1924
INFO - 2020-06-24 18:59:29 --> Config Class Initialized
INFO - 2020-06-24 18:59:29 --> Plain_Config Class Initialized
INFO - 2020-06-24 18:59:29 --> Hooks Class Initialized
INFO - 2020-06-24 18:59:29 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 18:59:29 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 18:59:29 --> UTF-8 Support Disabled
INFO - 2020-06-24 18:59:29 --> Utf8 Class Initialized
INFO - 2020-06-24 18:59:29 --> URI Class Initialized
DEBUG - 2020-06-24 18:59:29 --> No URI present. Default controller set.
INFO - 2020-06-24 18:59:29 --> Router Class Initialized
INFO - 2020-06-24 18:59:29 --> Plain_Router Class Initialized
INFO - 2020-06-24 18:59:29 --> Output Class Initialized
INFO - 2020-06-24 18:59:29 --> Security Class Initialized
DEBUG - 2020-06-24 18:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 18:59:29 --> Input Class Initialized
INFO - 2020-06-24 18:59:29 --> Language Class Initialized
INFO - 2020-06-24 18:59:29 --> Loader Class Initialized
INFO - 2020-06-24 18:59:29 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 18:59:29 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 18:59:29 --> Helper loaded: data_helper
INFO - 2020-06-24 18:59:29 --> Helper loaded: hash_helper
INFO - 2020-06-24 18:59:29 --> Helper loaded: validation_helper
INFO - 2020-06-24 18:59:29 --> Helper loaded: view_helper
INFO - 2020-06-24 18:59:29 --> Helper loaded: url_helper
INFO - 2020-06-24 18:59:29 --> Database Driver Class Initialized
INFO - 2020-06-24 18:59:29 --> Controller Class Initialized
INFO - 2020-06-24 18:59:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 18:59:29 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 18:59:29 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 18:59:29 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 18:59:29 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:59:29 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 18:59:29 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:59:29 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 18:59:29 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 18:59:29 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 18:59:29 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 18:59:29 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 18:59:29 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 18:59:29 --> Final output sent to browser
DEBUG - 2020-06-24 18:59:29 --> Total execution time: 0.1680
INFO - 2020-06-24 19:03:04 --> Config Class Initialized
INFO - 2020-06-24 19:03:04 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:04 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:04 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:04 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:04 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:04 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:04 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:04 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:03:04 --> Router Class Initialized
INFO - 2020-06-24 19:03:04 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:03:04 --> Output Class Initialized
INFO - 2020-06-24 19:03:04 --> Security Class Initialized
DEBUG - 2020-06-24 19:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:03:04 --> Input Class Initialized
INFO - 2020-06-24 19:03:04 --> Language Class Initialized
INFO - 2020-06-24 19:03:04 --> Loader Class Initialized
INFO - 2020-06-24 19:03:04 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:03:04 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:03:04 --> Helper loaded: data_helper
INFO - 2020-06-24 19:03:04 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:03:04 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:03:04 --> Helper loaded: view_helper
INFO - 2020-06-24 19:03:04 --> Helper loaded: url_helper
INFO - 2020-06-24 19:03:04 --> Database Driver Class Initialized
INFO - 2020-06-24 19:03:04 --> Controller Class Initialized
INFO - 2020-06-24 19:03:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:03:04 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 19:03:04 --> Config Class Initialized
INFO - 2020-06-24 19:03:04 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:04 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:04 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:04 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:04 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:04 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:04 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:04 --> No URI present. Default controller set.
INFO - 2020-06-24 19:03:04 --> Router Class Initialized
INFO - 2020-06-24 19:03:04 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:03:04 --> Output Class Initialized
INFO - 2020-06-24 19:03:04 --> Security Class Initialized
DEBUG - 2020-06-24 19:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:03:04 --> Input Class Initialized
INFO - 2020-06-24 19:03:04 --> Language Class Initialized
INFO - 2020-06-24 19:03:04 --> Loader Class Initialized
INFO - 2020-06-24 19:03:04 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:03:04 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:03:04 --> Helper loaded: data_helper
INFO - 2020-06-24 19:03:04 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:03:04 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:03:04 --> Helper loaded: view_helper
INFO - 2020-06-24 19:03:04 --> Helper loaded: url_helper
INFO - 2020-06-24 19:03:04 --> Database Driver Class Initialized
INFO - 2020-06-24 19:03:04 --> Controller Class Initialized
INFO - 2020-06-24 19:03:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:03:04 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:03:04 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:03:04 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 19:03:04 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:03:04 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 19:03:04 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:03:04 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:03:04 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:03:04 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 19:03:04 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 19:03:04 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 19:03:04 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 19:03:04 --> Final output sent to browser
DEBUG - 2020-06-24 19:03:04 --> Total execution time: 0.1118
INFO - 2020-06-24 19:03:05 --> Config Class Initialized
INFO - 2020-06-24 19:03:05 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:05 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:05 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:05 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:05 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:05 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:05 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:05 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:03:05 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:03:05 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:03:08 --> Config Class Initialized
INFO - 2020-06-24 19:03:09 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:09 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:09 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:09 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:09 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:09 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:09 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:09 --> Validating request for /controllers/Install.php
INFO - 2020-06-24 19:03:09 --> Router Class Initialized
INFO - 2020-06-24 19:03:09 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:03:09 --> Output Class Initialized
INFO - 2020-06-24 19:03:09 --> Security Class Initialized
DEBUG - 2020-06-24 19:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:03:09 --> Input Class Initialized
INFO - 2020-06-24 19:03:09 --> Language Class Initialized
INFO - 2020-06-24 19:03:09 --> Loader Class Initialized
INFO - 2020-06-24 19:03:09 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:03:09 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:03:09 --> Helper loaded: data_helper
INFO - 2020-06-24 19:03:09 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:03:09 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:03:09 --> Helper loaded: view_helper
INFO - 2020-06-24 19:03:09 --> Helper loaded: url_helper
INFO - 2020-06-24 19:03:09 --> Database Driver Class Initialized
INFO - 2020-06-24 19:03:09 --> Controller Class Initialized
DEBUG - 2020-06-24 19:03:09 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:03:09 --> The phrase "Unmark: Setup" could not be found in the language file.
DEBUG - 2020-06-24 19:03:09 --> The phrase "Welcome to Unmark, the to-do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 19:03:09 --> The phrase "You're about to install version 2020.1 of the app.</p><p>Please <a href="https://github.com/plainmade/unmark/blob/master/readme.md">read the installation instructions</a> first." could not be found in the language file.
DEBUG - 2020-06-24 19:03:09 --> The phrase "Click to Install" could not be found in the language file.
INFO - 2020-06-24 19:03:09 --> File loaded: /var/www/html/application/views/setup.php
INFO - 2020-06-24 19:03:09 --> Final output sent to browser
DEBUG - 2020-06-24 19:03:09 --> Total execution time: 0.1577
INFO - 2020-06-24 19:03:09 --> Config Class Initialized
INFO - 2020-06-24 19:03:09 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:09 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:09 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:09 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:09 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:09 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:09 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:09 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:03:09 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:03:09 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:03:11 --> Config Class Initialized
INFO - 2020-06-24 19:03:11 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:11 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:11 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:11 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:11 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:11 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:11 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:11 --> Validating request for /controllers/Install.php
INFO - 2020-06-24 19:03:11 --> Router Class Initialized
INFO - 2020-06-24 19:03:11 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:03:11 --> Output Class Initialized
INFO - 2020-06-24 19:03:11 --> Security Class Initialized
DEBUG - 2020-06-24 19:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:03:11 --> Input Class Initialized
INFO - 2020-06-24 19:03:11 --> Language Class Initialized
INFO - 2020-06-24 19:03:11 --> Loader Class Initialized
INFO - 2020-06-24 19:03:11 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:03:11 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:03:11 --> Helper loaded: data_helper
INFO - 2020-06-24 19:03:11 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:03:11 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:03:11 --> Helper loaded: view_helper
INFO - 2020-06-24 19:03:11 --> Helper loaded: url_helper
INFO - 2020-06-24 19:03:11 --> Database Driver Class Initialized
INFO - 2020-06-24 19:03:11 --> Controller Class Initialized
DEBUG - 2020-06-24 19:03:11 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:03:11 --> Plain Migrations class initialized
DEBUG - 2020-06-24 19:03:11 --> Language file loaded: language/english/migration_lang.php
INFO - 2020-06-24 19:03:11 --> Database Forge Class Initialized
DEBUG - 2020-06-24 19:03:11 --> Making backup before migrating failed.
DEBUG - 2020-06-24 19:03:11 --> Migrating up from version 0 to version 001
DEBUG - 2020-06-24 19:03:11 --> Migrating up from version 001 to version 002
DEBUG - 2020-06-24 19:03:11 --> Migrating up from version 002 to version 003
DEBUG - 2020-06-24 19:03:11 --> Migrating up from version 003 to version 004
DEBUG - 2020-06-24 19:03:11 --> Migrating up from version 004 to version 005
DEBUG - 2020-06-24 19:03:11 --> Migrating up from version 005 to version 006
DEBUG - 2020-06-24 19:03:11 --> Migrating up from version 006 to version 007
DEBUG - 2020-06-24 19:03:11 --> Migrating up from version 007 to version 008
DEBUG - 2020-06-24 19:03:11 --> Migrating up from version 008 to version 009
DEBUG - 2020-06-24 19:03:11 --> Migrating up from version 009 to version 010
DEBUG - 2020-06-24 19:03:11 --> Migrating up from version 010 to version 2014022801
DEBUG - 2020-06-24 19:03:12 --> Migrating up from version 2014022801 to version 2014112501
DEBUG - 2020-06-24 19:03:12 --> Finished migrating to 2014112501
DEBUG - 2020-06-24 19:03:12 --> Making backup before migrating failed.
INFO - 2020-06-24 19:03:12 --> Config Class Initialized
INFO - 2020-06-24 19:03:12 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:12 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:12 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:12 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:12 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:12 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:12 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:12 --> Validating request for /controllers/Register.php
INFO - 2020-06-24 19:03:12 --> Router Class Initialized
INFO - 2020-06-24 19:03:12 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:03:12 --> Output Class Initialized
INFO - 2020-06-24 19:03:12 --> Security Class Initialized
DEBUG - 2020-06-24 19:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:03:12 --> Input Class Initialized
INFO - 2020-06-24 19:03:12 --> Language Class Initialized
INFO - 2020-06-24 19:03:12 --> Loader Class Initialized
INFO - 2020-06-24 19:03:12 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:03:12 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:03:12 --> Helper loaded: data_helper
INFO - 2020-06-24 19:03:12 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:03:12 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:03:12 --> Helper loaded: view_helper
INFO - 2020-06-24 19:03:12 --> Helper loaded: url_helper
INFO - 2020-06-24 19:03:12 --> Database Driver Class Initialized
INFO - 2020-06-24 19:03:12 --> Controller Class Initialized
INFO - 2020-06-24 19:03:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:03:12 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:03:12 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:03:12 --> The phrase "Unmark : User Registration" could not be found in the language file.
DEBUG - 2020-06-24 19:03:12 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:03:12 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 19:03:12 --> The phrase "Password Again" could not be found in the language file.
DEBUG - 2020-06-24 19:03:12 --> The phrase "Terms of Use" could not be found in the language file.
DEBUG - 2020-06-24 19:03:12 --> The phrase "Have An Account? Sign In Here" could not be found in the language file.
INFO - 2020-06-24 19:03:12 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 19:03:12 --> File loaded: /var/www/html/application/views/register/index.php
INFO - 2020-06-24 19:03:12 --> Final output sent to browser
DEBUG - 2020-06-24 19:03:12 --> Total execution time: 0.1937
INFO - 2020-06-24 19:03:12 --> Config Class Initialized
INFO - 2020-06-24 19:03:12 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:12 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:12 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:12 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:12 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:12 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:12 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:12 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:03:12 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:03:12 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:03:39 --> Config Class Initialized
INFO - 2020-06-24 19:03:39 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:39 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:39 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:39 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:39 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:39 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:39 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:39 --> Validating request for /controllers/Register.php
INFO - 2020-06-24 19:03:39 --> Router Class Initialized
INFO - 2020-06-24 19:03:39 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:03:39 --> Output Class Initialized
INFO - 2020-06-24 19:03:39 --> Security Class Initialized
DEBUG - 2020-06-24 19:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:03:39 --> Input Class Initialized
INFO - 2020-06-24 19:03:39 --> Language Class Initialized
INFO - 2020-06-24 19:03:39 --> Loader Class Initialized
INFO - 2020-06-24 19:03:39 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:03:39 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:03:39 --> Helper loaded: data_helper
INFO - 2020-06-24 19:03:39 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:03:39 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:03:39 --> Helper loaded: view_helper
INFO - 2020-06-24 19:03:39 --> Helper loaded: url_helper
INFO - 2020-06-24 19:03:39 --> Database Driver Class Initialized
INFO - 2020-06-24 19:03:39 --> Controller Class Initialized
INFO - 2020-06-24 19:03:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:03:39 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:03:39 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:03:39 --> Plain_Model class loaded
INFO - 2020-06-24 19:03:39 --> Model "Users_model" initialized
INFO - 2020-06-24 19:03:39 --> Helper loaded: http_build_url_helper
INFO - 2020-06-24 19:03:39 --> Model "Marks_model" initialized
INFO - 2020-06-24 19:03:39 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 19:03:39 --> The phrase "Just Now" could not be found in the language file.
DEBUG - 2020-06-24 19:03:39 --> The phrase "Just Now" could not be found in the language file.
DEBUG - 2020-06-24 19:03:39 --> The phrase "Just Now" could not be found in the language file.
INFO - 2020-06-24 19:03:39 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-06-24 19:03:39 --> Final output sent to browser
DEBUG - 2020-06-24 19:03:39 --> Total execution time: 0.1902
INFO - 2020-06-24 19:03:42 --> Config Class Initialized
INFO - 2020-06-24 19:03:42 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:42 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:42 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:42 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:42 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:42 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:42 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:42 --> No URI present. Default controller set.
INFO - 2020-06-24 19:03:42 --> Router Class Initialized
INFO - 2020-06-24 19:03:42 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:03:42 --> Output Class Initialized
INFO - 2020-06-24 19:03:42 --> Security Class Initialized
DEBUG - 2020-06-24 19:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:03:42 --> Input Class Initialized
INFO - 2020-06-24 19:03:42 --> Language Class Initialized
INFO - 2020-06-24 19:03:42 --> Loader Class Initialized
INFO - 2020-06-24 19:03:42 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:03:42 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:03:42 --> Helper loaded: data_helper
INFO - 2020-06-24 19:03:42 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:03:42 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:03:42 --> Helper loaded: view_helper
INFO - 2020-06-24 19:03:42 --> Helper loaded: url_helper
INFO - 2020-06-24 19:03:42 --> Database Driver Class Initialized
INFO - 2020-06-24 19:03:42 --> Controller Class Initialized
INFO - 2020-06-24 19:03:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:03:42 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:03:42 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:03:42 --> Config Class Initialized
INFO - 2020-06-24 19:03:42 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:42 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:42 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:42 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:42 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:42 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:42 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:42 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:03:42 --> Router Class Initialized
INFO - 2020-06-24 19:03:42 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:03:42 --> Output Class Initialized
INFO - 2020-06-24 19:03:42 --> Security Class Initialized
DEBUG - 2020-06-24 19:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:03:42 --> Input Class Initialized
INFO - 2020-06-24 19:03:42 --> Language Class Initialized
INFO - 2020-06-24 19:03:42 --> Loader Class Initialized
INFO - 2020-06-24 19:03:42 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:03:42 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:03:42 --> Helper loaded: data_helper
INFO - 2020-06-24 19:03:42 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:03:42 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:03:42 --> Helper loaded: view_helper
INFO - 2020-06-24 19:03:42 --> Helper loaded: url_helper
INFO - 2020-06-24 19:03:42 --> Database Driver Class Initialized
INFO - 2020-06-24 19:03:42 --> Controller Class Initialized
INFO - 2020-06-24 19:03:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:03:42 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 19:03:42 --> Plain_Model class loaded
INFO - 2020-06-24 19:03:42 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 19:03:42 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:03:42 --> Model "Labels_model" initialized
INFO - 2020-06-24 19:03:42 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-24 19:03:42 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-24 19:03:42 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-24 19:03:42 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-24 19:03:42 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-24 19:03:42 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-24 19:03:42 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-24 19:03:42 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-24 19:03:42 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-24 19:03:42 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-24 19:03:42 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-24 19:03:42 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-24 19:03:42 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-24 19:03:42 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-24 19:03:42 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 19:03:42 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 19:03:42 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 19:03:42 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 19:03:42 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 19:03:42 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-24 19:03:42 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-24 19:03:42 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-24 19:03:42 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-24 19:03:42 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-24 19:03:42 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-24 19:03:42 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-24 19:03:42 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-24 19:03:42 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-24 19:03:42 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-24 19:03:42 --> Final output sent to browser
DEBUG - 2020-06-24 19:03:42 --> Total execution time: 0.1991
INFO - 2020-06-24 19:03:43 --> Config Class Initialized
INFO - 2020-06-24 19:03:43 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:43 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:43 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:43 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:43 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:43 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:43 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:43 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:03:43 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:03:43 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:03:52 --> Config Class Initialized
INFO - 2020-06-24 19:03:52 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:52 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:52 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:52 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:52 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:52 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:52 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:52 --> Validating request for /controllers/Import.php
INFO - 2020-06-24 19:03:52 --> Router Class Initialized
INFO - 2020-06-24 19:03:52 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:03:52 --> Output Class Initialized
INFO - 2020-06-24 19:03:52 --> Security Class Initialized
DEBUG - 2020-06-24 19:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:03:52 --> Input Class Initialized
INFO - 2020-06-24 19:03:52 --> Language Class Initialized
INFO - 2020-06-24 19:03:52 --> Loader Class Initialized
INFO - 2020-06-24 19:03:52 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:03:52 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:03:52 --> Helper loaded: data_helper
INFO - 2020-06-24 19:03:52 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:03:52 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:03:52 --> Helper loaded: view_helper
INFO - 2020-06-24 19:03:52 --> Helper loaded: url_helper
INFO - 2020-06-24 19:03:52 --> Database Driver Class Initialized
INFO - 2020-06-24 19:03:52 --> Controller Class Initialized
INFO - 2020-06-24 19:03:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:03:53 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:03:53 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:03:53 --> Plain_Model class loaded
INFO - 2020-06-24 19:03:53 --> Model "Marks_model" initialized
INFO - 2020-06-24 19:03:53 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-24 19:03:53 --> Model "Labels_model" initialized
INFO - 2020-06-24 19:03:53 --> Model "Tags_model" initialized
INFO - 2020-06-24 19:03:53 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-24 19:03:57 --> The phrase "Unmark : Importer" could not be found in the language file.
DEBUG - 2020-06-24 19:03:57 --> The phrase "Successful Upload!" could not be found in the language file.
DEBUG - 2020-06-24 19:03:57 --> The phrase "%s marks added" could not be found in the language file.
DEBUG - 2020-06-24 19:03:57 --> The phrase "%s marks skipped" could not be found in the language file.
DEBUG - 2020-06-24 19:03:57 --> The phrase "%s marks failed" could not be found in the language file.
DEBUG - 2020-06-24 19:03:57 --> The phrase "%s marks total" could not be found in the language file.
DEBUG - 2020-06-24 19:03:57 --> The phrase "<a href='/' class="back-button"> Go back & see them</a>" could not be found in the language file.
INFO - 2020-06-24 19:03:57 --> File loaded: /var/www/html/application/views/import/index.php
INFO - 2020-06-24 19:03:57 --> Final output sent to browser
DEBUG - 2020-06-24 19:03:57 --> Total execution time: 4.2004
INFO - 2020-06-24 19:03:57 --> Config Class Initialized
INFO - 2020-06-24 19:03:57 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:57 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:57 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:57 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:57 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:57 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:57 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:57 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:03:57 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:03:57 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:03:59 --> Config Class Initialized
INFO - 2020-06-24 19:03:59 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:59 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:59 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:59 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:59 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:59 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:59 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:59 --> No URI present. Default controller set.
INFO - 2020-06-24 19:03:59 --> Router Class Initialized
INFO - 2020-06-24 19:03:59 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:03:59 --> Output Class Initialized
INFO - 2020-06-24 19:03:59 --> Security Class Initialized
DEBUG - 2020-06-24 19:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:03:59 --> Input Class Initialized
INFO - 2020-06-24 19:03:59 --> Language Class Initialized
INFO - 2020-06-24 19:03:59 --> Loader Class Initialized
INFO - 2020-06-24 19:03:59 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:03:59 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:03:59 --> Helper loaded: data_helper
INFO - 2020-06-24 19:03:59 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:03:59 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:03:59 --> Helper loaded: view_helper
INFO - 2020-06-24 19:03:59 --> Helper loaded: url_helper
INFO - 2020-06-24 19:03:59 --> Database Driver Class Initialized
INFO - 2020-06-24 19:03:59 --> Controller Class Initialized
INFO - 2020-06-24 19:03:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:03:59 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:03:59 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:03:59 --> Config Class Initialized
INFO - 2020-06-24 19:03:59 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:59 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:59 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:59 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:59 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:59 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:59 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:59 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:03:59 --> Router Class Initialized
INFO - 2020-06-24 19:03:59 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:03:59 --> Output Class Initialized
INFO - 2020-06-24 19:03:59 --> Security Class Initialized
DEBUG - 2020-06-24 19:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:03:59 --> Input Class Initialized
INFO - 2020-06-24 19:03:59 --> Language Class Initialized
INFO - 2020-06-24 19:03:59 --> Loader Class Initialized
INFO - 2020-06-24 19:03:59 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:03:59 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:03:59 --> Helper loaded: data_helper
INFO - 2020-06-24 19:03:59 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:03:59 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:03:59 --> Helper loaded: view_helper
INFO - 2020-06-24 19:03:59 --> Helper loaded: url_helper
INFO - 2020-06-24 19:03:59 --> Database Driver Class Initialized
INFO - 2020-06-24 19:03:59 --> Controller Class Initialized
INFO - 2020-06-24 19:03:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:03:59 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 19:03:59 --> Plain_Model class loaded
INFO - 2020-06-24 19:03:59 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 19:03:59 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:03:59 --> Model "Labels_model" initialized
INFO - 2020-06-24 19:03:59 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-24 19:03:59 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-24 19:03:59 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-24 19:03:59 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-24 19:03:59 --> The phrase "Recently-Used Tags" could not be found in the language file.
INFO - 2020-06-24 19:03:59 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-24 19:03:59 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-24 19:03:59 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-24 19:03:59 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-24 19:03:59 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-24 19:03:59 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-24 19:03:59 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-24 19:03:59 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 19:03:59 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 19:03:59 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 19:03:59 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 19:03:59 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 19:03:59 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-24 19:03:59 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-24 19:03:59 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-24 19:03:59 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-24 19:03:59 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-24 19:03:59 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-24 19:03:59 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-24 19:03:59 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-24 19:03:59 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-24 19:03:59 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-24 19:03:59 --> Final output sent to browser
DEBUG - 2020-06-24 19:03:59 --> Total execution time: 0.1737
INFO - 2020-06-24 19:03:59 --> Config Class Initialized
INFO - 2020-06-24 19:03:59 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:03:59 --> Hooks Class Initialized
INFO - 2020-06-24 19:03:59 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:03:59 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:03:59 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:03:59 --> Utf8 Class Initialized
INFO - 2020-06-24 19:03:59 --> URI Class Initialized
DEBUG - 2020-06-24 19:03:59 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:03:59 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:03:59 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:04:01 --> Config Class Initialized
INFO - 2020-06-24 19:04:01 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:04:01 --> Hooks Class Initialized
INFO - 2020-06-24 19:04:01 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:04:01 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:04:01 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:04:01 --> Utf8 Class Initialized
INFO - 2020-06-24 19:04:01 --> URI Class Initialized
DEBUG - 2020-06-24 19:04:01 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:04:01 --> Router Class Initialized
INFO - 2020-06-24 19:04:01 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:04:01 --> Output Class Initialized
INFO - 2020-06-24 19:04:01 --> Security Class Initialized
DEBUG - 2020-06-24 19:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:04:01 --> Input Class Initialized
INFO - 2020-06-24 19:04:01 --> Language Class Initialized
INFO - 2020-06-24 19:04:01 --> Loader Class Initialized
INFO - 2020-06-24 19:04:01 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:04:01 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:04:01 --> Helper loaded: data_helper
INFO - 2020-06-24 19:04:01 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:04:01 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:04:01 --> Helper loaded: view_helper
INFO - 2020-06-24 19:04:01 --> Helper loaded: url_helper
INFO - 2020-06-24 19:04:01 --> Database Driver Class Initialized
INFO - 2020-06-24 19:04:01 --> Controller Class Initialized
INFO - 2020-06-24 19:04:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:04:01 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 19:04:01 --> Plain_Model class loaded
INFO - 2020-06-24 19:04:01 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 19:04:01 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:04:01 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 19:04:01 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 19:04:01 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 19:04:01 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 19:04:01 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 19:04:01 --> Final output sent to browser
DEBUG - 2020-06-24 19:04:01 --> Total execution time: 0.1237
INFO - 2020-06-24 19:04:02 --> Config Class Initialized
INFO - 2020-06-24 19:04:02 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:04:02 --> Hooks Class Initialized
INFO - 2020-06-24 19:04:02 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:04:02 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:04:02 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:04:02 --> Utf8 Class Initialized
INFO - 2020-06-24 19:04:02 --> URI Class Initialized
DEBUG - 2020-06-24 19:04:02 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:04:02 --> Router Class Initialized
INFO - 2020-06-24 19:04:02 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:04:02 --> Output Class Initialized
INFO - 2020-06-24 19:04:02 --> Security Class Initialized
DEBUG - 2020-06-24 19:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:04:02 --> Input Class Initialized
INFO - 2020-06-24 19:04:02 --> Language Class Initialized
INFO - 2020-06-24 19:04:02 --> Loader Class Initialized
INFO - 2020-06-24 19:04:02 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:04:02 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:04:02 --> Helper loaded: data_helper
INFO - 2020-06-24 19:04:02 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:04:02 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:04:02 --> Helper loaded: view_helper
INFO - 2020-06-24 19:04:02 --> Helper loaded: url_helper
INFO - 2020-06-24 19:04:02 --> Database Driver Class Initialized
INFO - 2020-06-24 19:04:02 --> Controller Class Initialized
INFO - 2020-06-24 19:04:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:04:02 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 19:04:02 --> Plain_Model class loaded
INFO - 2020-06-24 19:04:02 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 19:04:02 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:04:02 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 19:04:02 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 19:04:02 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 19:04:02 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 19:04:02 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 19:04:02 --> Final output sent to browser
DEBUG - 2020-06-24 19:04:02 --> Total execution time: 0.1248
INFO - 2020-06-24 19:04:07 --> Config Class Initialized
INFO - 2020-06-24 19:04:07 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:04:07 --> Hooks Class Initialized
INFO - 2020-06-24 19:04:07 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:04:07 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:04:07 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:04:07 --> Utf8 Class Initialized
INFO - 2020-06-24 19:04:07 --> URI Class Initialized
DEBUG - 2020-06-24 19:04:07 --> Validating request for /controllers/Export.php
INFO - 2020-06-24 19:04:07 --> Router Class Initialized
INFO - 2020-06-24 19:04:07 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:04:07 --> Output Class Initialized
INFO - 2020-06-24 19:04:07 --> Security Class Initialized
DEBUG - 2020-06-24 19:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:04:07 --> Input Class Initialized
INFO - 2020-06-24 19:04:07 --> Language Class Initialized
INFO - 2020-06-24 19:04:07 --> Loader Class Initialized
INFO - 2020-06-24 19:04:07 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:04:07 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:04:07 --> Helper loaded: data_helper
INFO - 2020-06-24 19:04:07 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:04:07 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:04:07 --> Helper loaded: view_helper
INFO - 2020-06-24 19:04:07 --> Helper loaded: url_helper
INFO - 2020-06-24 19:04:07 --> Database Driver Class Initialized
INFO - 2020-06-24 19:04:07 --> Controller Class Initialized
INFO - 2020-06-24 19:04:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:04:07 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:04:07 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:04:07 --> Plain_Model class loaded
INFO - 2020-06-24 19:04:07 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-24 19:04:07 --> Final output sent to browser
DEBUG - 2020-06-24 19:04:07 --> Total execution time: 0.4118
INFO - 2020-06-24 19:05:11 --> Config Class Initialized
INFO - 2020-06-24 19:05:11 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:11 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:11 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:11 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:11 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:11 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:11 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:11 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:05:11 --> Router Class Initialized
INFO - 2020-06-24 19:05:11 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:05:11 --> Output Class Initialized
INFO - 2020-06-24 19:05:11 --> Security Class Initialized
DEBUG - 2020-06-24 19:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:05:11 --> Input Class Initialized
INFO - 2020-06-24 19:05:11 --> Language Class Initialized
INFO - 2020-06-24 19:05:11 --> Loader Class Initialized
INFO - 2020-06-24 19:05:11 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:05:11 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:05:11 --> Helper loaded: data_helper
INFO - 2020-06-24 19:05:11 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:05:11 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:05:11 --> Helper loaded: view_helper
INFO - 2020-06-24 19:05:11 --> Helper loaded: url_helper
INFO - 2020-06-24 19:05:11 --> Database Driver Class Initialized
ERROR - 2020-06-24 19:05:11 --> Unable to connect to the database
DEBUG - 2020-06-24 19:05:11 --> Language file loaded: language/english/db_lang.php
INFO - 2020-06-24 19:05:11 --> Plain_Exceptions Class Initialized
INFO - 2020-06-24 19:05:14 --> Config Class Initialized
INFO - 2020-06-24 19:05:14 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:14 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:14 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:14 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:14 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:14 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:14 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:14 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:05:14 --> Router Class Initialized
INFO - 2020-06-24 19:05:14 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:05:14 --> Output Class Initialized
INFO - 2020-06-24 19:05:14 --> Security Class Initialized
DEBUG - 2020-06-24 19:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:05:14 --> Input Class Initialized
INFO - 2020-06-24 19:05:14 --> Language Class Initialized
INFO - 2020-06-24 19:05:14 --> Loader Class Initialized
INFO - 2020-06-24 19:05:14 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:05:14 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:05:14 --> Helper loaded: data_helper
INFO - 2020-06-24 19:05:14 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:05:14 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:05:14 --> Helper loaded: view_helper
INFO - 2020-06-24 19:05:14 --> Helper loaded: url_helper
INFO - 2020-06-24 19:05:14 --> Database Driver Class Initialized
ERROR - 2020-06-24 19:05:14 --> Unable to connect to the database
DEBUG - 2020-06-24 19:05:14 --> Language file loaded: language/english/db_lang.php
INFO - 2020-06-24 19:05:14 --> Plain_Exceptions Class Initialized
INFO - 2020-06-24 19:05:17 --> Config Class Initialized
INFO - 2020-06-24 19:05:17 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:17 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:17 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:17 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:17 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:17 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:17 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:17 --> No URI present. Default controller set.
INFO - 2020-06-24 19:05:17 --> Router Class Initialized
INFO - 2020-06-24 19:05:17 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:05:17 --> Output Class Initialized
INFO - 2020-06-24 19:05:17 --> Security Class Initialized
DEBUG - 2020-06-24 19:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:05:17 --> Input Class Initialized
INFO - 2020-06-24 19:05:17 --> Language Class Initialized
INFO - 2020-06-24 19:05:17 --> Loader Class Initialized
INFO - 2020-06-24 19:05:17 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:05:17 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:05:17 --> Helper loaded: data_helper
INFO - 2020-06-24 19:05:17 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:05:17 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:05:17 --> Helper loaded: view_helper
INFO - 2020-06-24 19:05:17 --> Helper loaded: url_helper
INFO - 2020-06-24 19:05:17 --> Database Driver Class Initialized
INFO - 2020-06-24 19:05:17 --> Controller Class Initialized
INFO - 2020-06-24 19:05:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:05:17 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:05:17 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:05:17 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 19:05:17 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:05:17 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 19:05:17 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:05:17 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:05:17 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:05:17 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 19:05:17 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 19:05:17 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 19:05:17 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 19:05:17 --> Final output sent to browser
DEBUG - 2020-06-24 19:05:17 --> Total execution time: 0.1490
INFO - 2020-06-24 19:05:17 --> Config Class Initialized
INFO - 2020-06-24 19:05:17 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:17 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:17 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:17 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:17 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:17 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:17 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:17 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:05:17 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:05:17 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:05:23 --> Config Class Initialized
INFO - 2020-06-24 19:05:23 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:23 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:23 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:23 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:23 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:23 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:23 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:23 --> Validating request for /controllers/Install.php
INFO - 2020-06-24 19:05:23 --> Router Class Initialized
INFO - 2020-06-24 19:05:23 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:05:23 --> Output Class Initialized
INFO - 2020-06-24 19:05:23 --> Security Class Initialized
DEBUG - 2020-06-24 19:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:05:23 --> Input Class Initialized
INFO - 2020-06-24 19:05:23 --> Language Class Initialized
INFO - 2020-06-24 19:05:23 --> Loader Class Initialized
INFO - 2020-06-24 19:05:23 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:05:23 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:05:23 --> Helper loaded: data_helper
INFO - 2020-06-24 19:05:23 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:05:23 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:05:23 --> Helper loaded: view_helper
INFO - 2020-06-24 19:05:23 --> Helper loaded: url_helper
INFO - 2020-06-24 19:05:23 --> Database Driver Class Initialized
INFO - 2020-06-24 19:05:23 --> Controller Class Initialized
DEBUG - 2020-06-24 19:05:23 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:05:23 --> The phrase "Unmark: Setup" could not be found in the language file.
DEBUG - 2020-06-24 19:05:23 --> The phrase "Welcome to Unmark, the to-do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 19:05:23 --> The phrase "You're about to install version 2020.1 of the app.</p><p>Please <a href="https://github.com/plainmade/unmark/blob/master/readme.md">read the installation instructions</a> first." could not be found in the language file.
DEBUG - 2020-06-24 19:05:23 --> The phrase "Click to Install" could not be found in the language file.
INFO - 2020-06-24 19:05:23 --> File loaded: /var/www/html/application/views/setup.php
INFO - 2020-06-24 19:05:23 --> Final output sent to browser
DEBUG - 2020-06-24 19:05:23 --> Total execution time: 0.1900
INFO - 2020-06-24 19:05:24 --> Config Class Initialized
INFO - 2020-06-24 19:05:24 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:24 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:24 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:24 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:24 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:24 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:24 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:24 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:05:24 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:05:24 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:05:25 --> Config Class Initialized
INFO - 2020-06-24 19:05:25 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:25 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:25 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:25 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:25 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:25 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:25 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:25 --> Validating request for /controllers/Install.php
INFO - 2020-06-24 19:05:25 --> Router Class Initialized
INFO - 2020-06-24 19:05:25 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:05:25 --> Output Class Initialized
INFO - 2020-06-24 19:05:25 --> Security Class Initialized
DEBUG - 2020-06-24 19:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:05:25 --> Input Class Initialized
INFO - 2020-06-24 19:05:25 --> Language Class Initialized
INFO - 2020-06-24 19:05:25 --> Loader Class Initialized
INFO - 2020-06-24 19:05:25 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:05:25 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:05:25 --> Helper loaded: data_helper
INFO - 2020-06-24 19:05:25 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:05:25 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:05:25 --> Helper loaded: view_helper
INFO - 2020-06-24 19:05:25 --> Helper loaded: url_helper
INFO - 2020-06-24 19:05:25 --> Database Driver Class Initialized
INFO - 2020-06-24 19:05:25 --> Controller Class Initialized
DEBUG - 2020-06-24 19:05:25 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:05:25 --> Plain Migrations class initialized
DEBUG - 2020-06-24 19:05:25 --> Language file loaded: language/english/migration_lang.php
INFO - 2020-06-24 19:05:25 --> Database Forge Class Initialized
DEBUG - 2020-06-24 19:05:25 --> Making backup before migrating failed.
DEBUG - 2020-06-24 19:05:25 --> Migrating up from version 0 to version 001
DEBUG - 2020-06-24 19:05:25 --> Migrating up from version 001 to version 002
DEBUG - 2020-06-24 19:05:25 --> Migrating up from version 002 to version 003
DEBUG - 2020-06-24 19:05:25 --> Migrating up from version 003 to version 004
DEBUG - 2020-06-24 19:05:25 --> Migrating up from version 004 to version 005
DEBUG - 2020-06-24 19:05:25 --> Migrating up from version 005 to version 006
DEBUG - 2020-06-24 19:05:25 --> Migrating up from version 006 to version 007
DEBUG - 2020-06-24 19:05:26 --> Migrating up from version 007 to version 008
DEBUG - 2020-06-24 19:05:26 --> Migrating up from version 008 to version 009
DEBUG - 2020-06-24 19:05:26 --> Migrating up from version 009 to version 010
DEBUG - 2020-06-24 19:05:26 --> Migrating up from version 010 to version 2014022801
DEBUG - 2020-06-24 19:05:26 --> Migrating up from version 2014022801 to version 2014112501
DEBUG - 2020-06-24 19:05:26 --> Finished migrating to 2014112501
DEBUG - 2020-06-24 19:05:26 --> Making backup before migrating failed.
INFO - 2020-06-24 19:05:26 --> Config Class Initialized
INFO - 2020-06-24 19:05:26 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:26 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:26 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:26 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:26 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:26 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:26 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:26 --> Validating request for /controllers/Register.php
INFO - 2020-06-24 19:05:26 --> Router Class Initialized
INFO - 2020-06-24 19:05:26 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:05:26 --> Output Class Initialized
INFO - 2020-06-24 19:05:26 --> Security Class Initialized
DEBUG - 2020-06-24 19:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:05:26 --> Input Class Initialized
INFO - 2020-06-24 19:05:26 --> Language Class Initialized
INFO - 2020-06-24 19:05:26 --> Loader Class Initialized
INFO - 2020-06-24 19:05:26 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:05:26 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:05:26 --> Helper loaded: data_helper
INFO - 2020-06-24 19:05:26 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:05:26 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:05:26 --> Helper loaded: view_helper
INFO - 2020-06-24 19:05:26 --> Helper loaded: url_helper
INFO - 2020-06-24 19:05:26 --> Database Driver Class Initialized
INFO - 2020-06-24 19:05:26 --> Controller Class Initialized
INFO - 2020-06-24 19:05:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:05:26 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:05:26 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:05:26 --> The phrase "Unmark : User Registration" could not be found in the language file.
DEBUG - 2020-06-24 19:05:26 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:05:26 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 19:05:26 --> The phrase "Password Again" could not be found in the language file.
DEBUG - 2020-06-24 19:05:26 --> The phrase "Terms of Use" could not be found in the language file.
DEBUG - 2020-06-24 19:05:26 --> The phrase "Have An Account? Sign In Here" could not be found in the language file.
INFO - 2020-06-24 19:05:26 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 19:05:26 --> File loaded: /var/www/html/application/views/register/index.php
INFO - 2020-06-24 19:05:26 --> Final output sent to browser
DEBUG - 2020-06-24 19:05:26 --> Total execution time: 0.1390
INFO - 2020-06-24 19:05:26 --> Config Class Initialized
INFO - 2020-06-24 19:05:26 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:26 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:26 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:26 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:26 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:26 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:26 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:26 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:05:26 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:05:26 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:05:37 --> Config Class Initialized
INFO - 2020-06-24 19:05:37 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:37 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:37 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:37 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:37 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:37 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:37 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:37 --> Validating request for /controllers/Register.php
INFO - 2020-06-24 19:05:37 --> Router Class Initialized
INFO - 2020-06-24 19:05:37 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:05:37 --> Output Class Initialized
INFO - 2020-06-24 19:05:37 --> Security Class Initialized
DEBUG - 2020-06-24 19:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:05:37 --> Input Class Initialized
INFO - 2020-06-24 19:05:37 --> Language Class Initialized
INFO - 2020-06-24 19:05:37 --> Loader Class Initialized
INFO - 2020-06-24 19:05:37 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:05:37 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:05:37 --> Helper loaded: data_helper
INFO - 2020-06-24 19:05:37 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:05:37 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:05:37 --> Helper loaded: view_helper
INFO - 2020-06-24 19:05:37 --> Helper loaded: url_helper
INFO - 2020-06-24 19:05:37 --> Database Driver Class Initialized
INFO - 2020-06-24 19:05:37 --> Controller Class Initialized
INFO - 2020-06-24 19:05:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:05:37 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:05:37 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:05:37 --> Plain_Model class loaded
INFO - 2020-06-24 19:05:37 --> Model "Users_model" initialized
INFO - 2020-06-24 19:05:37 --> Helper loaded: http_build_url_helper
INFO - 2020-06-24 19:05:37 --> Model "Marks_model" initialized
INFO - 2020-06-24 19:05:37 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 19:05:37 --> The phrase "Just Now" could not be found in the language file.
DEBUG - 2020-06-24 19:05:37 --> The phrase "Just Now" could not be found in the language file.
DEBUG - 2020-06-24 19:05:37 --> The phrase "Just Now" could not be found in the language file.
INFO - 2020-06-24 19:05:37 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-06-24 19:05:37 --> Final output sent to browser
DEBUG - 2020-06-24 19:05:37 --> Total execution time: 0.2567
INFO - 2020-06-24 19:05:40 --> Config Class Initialized
INFO - 2020-06-24 19:05:40 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:40 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:40 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:40 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:40 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:40 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:40 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:40 --> No URI present. Default controller set.
INFO - 2020-06-24 19:05:40 --> Router Class Initialized
INFO - 2020-06-24 19:05:40 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:05:40 --> Output Class Initialized
INFO - 2020-06-24 19:05:40 --> Security Class Initialized
DEBUG - 2020-06-24 19:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:05:40 --> Input Class Initialized
INFO - 2020-06-24 19:05:40 --> Language Class Initialized
INFO - 2020-06-24 19:05:40 --> Loader Class Initialized
INFO - 2020-06-24 19:05:40 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:05:40 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:05:40 --> Helper loaded: data_helper
INFO - 2020-06-24 19:05:40 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:05:40 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:05:40 --> Helper loaded: view_helper
INFO - 2020-06-24 19:05:40 --> Helper loaded: url_helper
INFO - 2020-06-24 19:05:40 --> Database Driver Class Initialized
INFO - 2020-06-24 19:05:40 --> Controller Class Initialized
INFO - 2020-06-24 19:05:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:05:40 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:05:40 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:05:40 --> Config Class Initialized
INFO - 2020-06-24 19:05:40 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:40 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:40 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:40 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:40 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:40 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:40 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:40 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:05:40 --> Router Class Initialized
INFO - 2020-06-24 19:05:40 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:05:40 --> Output Class Initialized
INFO - 2020-06-24 19:05:40 --> Security Class Initialized
DEBUG - 2020-06-24 19:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:05:40 --> Input Class Initialized
INFO - 2020-06-24 19:05:40 --> Language Class Initialized
INFO - 2020-06-24 19:05:40 --> Loader Class Initialized
INFO - 2020-06-24 19:05:40 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:05:40 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:05:40 --> Helper loaded: data_helper
INFO - 2020-06-24 19:05:40 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:05:40 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:05:40 --> Helper loaded: view_helper
INFO - 2020-06-24 19:05:40 --> Helper loaded: url_helper
INFO - 2020-06-24 19:05:40 --> Database Driver Class Initialized
INFO - 2020-06-24 19:05:40 --> Controller Class Initialized
INFO - 2020-06-24 19:05:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:05:40 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 19:05:40 --> Plain_Model class loaded
INFO - 2020-06-24 19:05:40 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 19:05:40 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:05:40 --> Model "Labels_model" initialized
INFO - 2020-06-24 19:05:40 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-24 19:05:40 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-24 19:05:40 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-24 19:05:40 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-24 19:05:40 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-24 19:05:40 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-24 19:05:40 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-24 19:05:40 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-24 19:05:40 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-24 19:05:40 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-24 19:05:40 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-24 19:05:40 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-24 19:05:40 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-24 19:05:40 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-24 19:05:40 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 19:05:40 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 19:05:40 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 19:05:40 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 19:05:40 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 19:05:40 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-24 19:05:40 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-24 19:05:40 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-24 19:05:40 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-24 19:05:40 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-24 19:05:40 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-24 19:05:40 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-24 19:05:40 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-24 19:05:40 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-24 19:05:40 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-24 19:05:40 --> Final output sent to browser
DEBUG - 2020-06-24 19:05:40 --> Total execution time: 0.2381
INFO - 2020-06-24 19:05:40 --> Config Class Initialized
INFO - 2020-06-24 19:05:40 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:40 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:40 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:40 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:40 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:40 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:40 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:40 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:05:40 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:05:40 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:05:50 --> Config Class Initialized
INFO - 2020-06-24 19:05:50 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:50 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:50 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:50 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:50 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:50 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:50 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:50 --> Validating request for /controllers/Import.php
INFO - 2020-06-24 19:05:50 --> Router Class Initialized
INFO - 2020-06-24 19:05:50 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:05:50 --> Output Class Initialized
INFO - 2020-06-24 19:05:50 --> Security Class Initialized
DEBUG - 2020-06-24 19:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:05:50 --> Input Class Initialized
INFO - 2020-06-24 19:05:50 --> Language Class Initialized
INFO - 2020-06-24 19:05:50 --> Loader Class Initialized
INFO - 2020-06-24 19:05:50 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:05:50 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:05:50 --> Helper loaded: data_helper
INFO - 2020-06-24 19:05:50 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:05:50 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:05:50 --> Helper loaded: view_helper
INFO - 2020-06-24 19:05:50 --> Helper loaded: url_helper
INFO - 2020-06-24 19:05:50 --> Database Driver Class Initialized
INFO - 2020-06-24 19:05:50 --> Controller Class Initialized
INFO - 2020-06-24 19:05:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:05:50 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:05:50 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:05:50 --> Importing bookmarks from an HTML file.
INFO - 2020-06-24 19:05:50 --> Plain_Model class loaded
INFO - 2020-06-24 19:05:50 --> Model "Marks_model" initialized
INFO - 2020-06-24 19:05:50 --> Model "Users_To_Marks_model" initialized
INFO - 2020-06-24 19:05:50 --> Model "Labels_model" initialized
DEBUG - 2020-06-24 19:05:55 --> Finished importing bookmarks from an HTML file.
DEBUG - 2020-06-24 19:05:55 --> The phrase "Unmark : Importer" could not be found in the language file.
DEBUG - 2020-06-24 19:05:55 --> The phrase "Successful Upload!" could not be found in the language file.
DEBUG - 2020-06-24 19:05:55 --> The phrase "%s marks added" could not be found in the language file.
DEBUG - 2020-06-24 19:05:55 --> The phrase "%s marks skipped" could not be found in the language file.
DEBUG - 2020-06-24 19:05:55 --> The phrase "%s marks failed" could not be found in the language file.
DEBUG - 2020-06-24 19:05:55 --> The phrase "%s marks total" could not be found in the language file.
DEBUG - 2020-06-24 19:05:55 --> The phrase "<a href='/' class="back-button"> Go back & see them</a>" could not be found in the language file.
INFO - 2020-06-24 19:05:55 --> File loaded: /var/www/html/application/views/import/index.php
INFO - 2020-06-24 19:05:55 --> Final output sent to browser
DEBUG - 2020-06-24 19:05:55 --> Total execution time: 4.5816
DEBUG - 2020-06-24 19:05:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-06-24 19:05:55 --> Array
(
    [message] => Warning: DOMDocument::loadHTML(): htmlParseEntityRef: expecting ';' in Entity, line: 2566
    [type] => Warning
    [backtrace] => /var/www/html/application/controllers/Import.php
    [custom_data] => Array
        (
        )

    [environment] => development
    [user] => Array
        (
            [user_id] => 1
            [email] => colin@cdevroe.com
            [user_token] => KbpHMLkGUqW0pFjscwuYwTu7sVakAI78cb3148877b9c56fd20b6d81a2c53db
            [active] => 1
            [admin] => 0
            [created_on] => 2020-06-24 19:05:37
            [last_updated] => 2020-06-24 19:05:37
        )

)

INFO - 2020-06-24 19:05:55 --> Config Class Initialized
INFO - 2020-06-24 19:05:55 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:55 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:55 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:55 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:55 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:55 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:55 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:55 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:05:55 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:05:55 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:05:58 --> Config Class Initialized
INFO - 2020-06-24 19:05:58 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:58 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:58 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:58 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:58 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:58 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:58 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:58 --> No URI present. Default controller set.
INFO - 2020-06-24 19:05:58 --> Router Class Initialized
INFO - 2020-06-24 19:05:58 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:05:58 --> Output Class Initialized
INFO - 2020-06-24 19:05:58 --> Security Class Initialized
DEBUG - 2020-06-24 19:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:05:58 --> Input Class Initialized
INFO - 2020-06-24 19:05:58 --> Language Class Initialized
INFO - 2020-06-24 19:05:58 --> Loader Class Initialized
INFO - 2020-06-24 19:05:58 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:05:58 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:05:58 --> Helper loaded: data_helper
INFO - 2020-06-24 19:05:58 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:05:58 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:05:58 --> Helper loaded: view_helper
INFO - 2020-06-24 19:05:58 --> Helper loaded: url_helper
INFO - 2020-06-24 19:05:58 --> Database Driver Class Initialized
INFO - 2020-06-24 19:05:58 --> Controller Class Initialized
INFO - 2020-06-24 19:05:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:05:58 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:05:58 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:05:58 --> Config Class Initialized
INFO - 2020-06-24 19:05:58 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:58 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:58 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:58 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:58 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:58 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:58 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:58 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:05:58 --> Router Class Initialized
INFO - 2020-06-24 19:05:58 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:05:58 --> Output Class Initialized
INFO - 2020-06-24 19:05:58 --> Security Class Initialized
DEBUG - 2020-06-24 19:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:05:58 --> Input Class Initialized
INFO - 2020-06-24 19:05:58 --> Language Class Initialized
INFO - 2020-06-24 19:05:58 --> Loader Class Initialized
INFO - 2020-06-24 19:05:58 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:05:58 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:05:58 --> Helper loaded: data_helper
INFO - 2020-06-24 19:05:58 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:05:58 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:05:58 --> Helper loaded: view_helper
INFO - 2020-06-24 19:05:58 --> Helper loaded: url_helper
INFO - 2020-06-24 19:05:58 --> Database Driver Class Initialized
INFO - 2020-06-24 19:05:58 --> Controller Class Initialized
INFO - 2020-06-24 19:05:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:05:58 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 19:05:58 --> Plain_Model class loaded
INFO - 2020-06-24 19:05:58 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 19:05:58 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:05:58 --> Model "Labels_model" initialized
INFO - 2020-06-24 19:05:58 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-24 19:05:58 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-24 19:05:58 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-24 19:05:58 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-24 19:05:58 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-24 19:05:58 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-24 19:05:58 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-24 19:05:58 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-24 19:05:58 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-24 19:05:58 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-24 19:05:58 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-24 19:05:58 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-24 19:05:58 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-24 19:05:58 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-24 19:05:58 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 19:05:58 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 19:05:58 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 19:05:58 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 19:05:58 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 19:05:58 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-24 19:05:58 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-24 19:05:58 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-24 19:05:58 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-24 19:05:58 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-24 19:05:58 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-24 19:05:58 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-24 19:05:58 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-24 19:05:58 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-24 19:05:58 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-24 19:05:58 --> Final output sent to browser
DEBUG - 2020-06-24 19:05:58 --> Total execution time: 0.2144
INFO - 2020-06-24 19:05:58 --> Config Class Initialized
INFO - 2020-06-24 19:05:58 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:05:59 --> Hooks Class Initialized
INFO - 2020-06-24 19:05:59 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:05:59 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:05:59 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:05:59 --> Utf8 Class Initialized
INFO - 2020-06-24 19:05:59 --> URI Class Initialized
DEBUG - 2020-06-24 19:05:59 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:05:59 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:05:59 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:06:02 --> Config Class Initialized
INFO - 2020-06-24 19:06:02 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:06:02 --> Hooks Class Initialized
INFO - 2020-06-24 19:06:02 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:06:02 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:06:02 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:06:02 --> Utf8 Class Initialized
INFO - 2020-06-24 19:06:02 --> URI Class Initialized
DEBUG - 2020-06-24 19:06:02 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:06:02 --> Router Class Initialized
INFO - 2020-06-24 19:06:02 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:06:02 --> Output Class Initialized
INFO - 2020-06-24 19:06:02 --> Security Class Initialized
DEBUG - 2020-06-24 19:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:06:02 --> Input Class Initialized
INFO - 2020-06-24 19:06:02 --> Language Class Initialized
INFO - 2020-06-24 19:06:02 --> Loader Class Initialized
INFO - 2020-06-24 19:06:02 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:06:02 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:06:02 --> Helper loaded: data_helper
INFO - 2020-06-24 19:06:02 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:06:02 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:06:02 --> Helper loaded: view_helper
INFO - 2020-06-24 19:06:02 --> Helper loaded: url_helper
INFO - 2020-06-24 19:06:02 --> Database Driver Class Initialized
INFO - 2020-06-24 19:06:02 --> Controller Class Initialized
INFO - 2020-06-24 19:06:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:06:02 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 19:06:02 --> Plain_Model class loaded
INFO - 2020-06-24 19:06:02 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 19:06:02 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:06:02 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 19:06:02 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 19:06:02 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 19:06:02 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 19:06:02 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 19:06:02 --> Final output sent to browser
DEBUG - 2020-06-24 19:06:02 --> Total execution time: 0.1619
INFO - 2020-06-24 19:06:03 --> Config Class Initialized
INFO - 2020-06-24 19:06:03 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:06:03 --> Hooks Class Initialized
INFO - 2020-06-24 19:06:03 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:06:03 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:06:03 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:06:03 --> Utf8 Class Initialized
INFO - 2020-06-24 19:06:03 --> URI Class Initialized
DEBUG - 2020-06-24 19:06:03 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:06:03 --> Router Class Initialized
INFO - 2020-06-24 19:06:03 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:06:03 --> Output Class Initialized
INFO - 2020-06-24 19:06:03 --> Security Class Initialized
DEBUG - 2020-06-24 19:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:06:03 --> Input Class Initialized
INFO - 2020-06-24 19:06:03 --> Language Class Initialized
INFO - 2020-06-24 19:06:03 --> Loader Class Initialized
INFO - 2020-06-24 19:06:03 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:06:03 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:06:03 --> Helper loaded: data_helper
INFO - 2020-06-24 19:06:03 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:06:03 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:06:03 --> Helper loaded: view_helper
INFO - 2020-06-24 19:06:03 --> Helper loaded: url_helper
INFO - 2020-06-24 19:06:03 --> Database Driver Class Initialized
INFO - 2020-06-24 19:06:03 --> Controller Class Initialized
INFO - 2020-06-24 19:06:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:06:03 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 19:06:03 --> Plain_Model class loaded
INFO - 2020-06-24 19:06:03 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 19:06:03 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:06:03 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 19:06:03 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 19:06:03 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 19:06:03 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 19:06:03 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 19:06:03 --> Final output sent to browser
DEBUG - 2020-06-24 19:06:03 --> Total execution time: 0.1585
INFO - 2020-06-24 19:06:28 --> Config Class Initialized
INFO - 2020-06-24 19:06:28 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:06:28 --> Hooks Class Initialized
INFO - 2020-06-24 19:06:28 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:06:28 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:06:28 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:06:28 --> Utf8 Class Initialized
INFO - 2020-06-24 19:06:28 --> URI Class Initialized
DEBUG - 2020-06-24 19:06:28 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:06:28 --> Router Class Initialized
INFO - 2020-06-24 19:06:28 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:06:28 --> Output Class Initialized
INFO - 2020-06-24 19:06:28 --> Security Class Initialized
DEBUG - 2020-06-24 19:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:06:28 --> Input Class Initialized
INFO - 2020-06-24 19:06:28 --> Language Class Initialized
INFO - 2020-06-24 19:06:28 --> Loader Class Initialized
INFO - 2020-06-24 19:06:28 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:06:28 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:06:28 --> Helper loaded: data_helper
INFO - 2020-06-24 19:06:28 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:06:28 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:06:28 --> Helper loaded: view_helper
INFO - 2020-06-24 19:06:28 --> Helper loaded: url_helper
INFO - 2020-06-24 19:06:28 --> Database Driver Class Initialized
INFO - 2020-06-24 19:06:28 --> Controller Class Initialized
INFO - 2020-06-24 19:06:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:06:28 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 19:06:28 --> Plain_Model class loaded
INFO - 2020-06-24 19:06:28 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 19:06:28 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:06:28 --> File loaded: /var/www/html/application/views/json/index.php
INFO - 2020-06-24 19:06:28 --> Final output sent to browser
DEBUG - 2020-06-24 19:06:28 --> Total execution time: 0.1626
INFO - 2020-06-24 19:06:31 --> Config Class Initialized
INFO - 2020-06-24 19:06:31 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:06:31 --> Hooks Class Initialized
INFO - 2020-06-24 19:06:31 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:06:31 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:06:31 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:06:31 --> Utf8 Class Initialized
INFO - 2020-06-24 19:06:31 --> URI Class Initialized
DEBUG - 2020-06-24 19:06:31 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:06:31 --> Router Class Initialized
INFO - 2020-06-24 19:06:31 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:06:31 --> Output Class Initialized
INFO - 2020-06-24 19:06:31 --> Security Class Initialized
DEBUG - 2020-06-24 19:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:06:31 --> Input Class Initialized
INFO - 2020-06-24 19:06:31 --> Language Class Initialized
INFO - 2020-06-24 19:06:31 --> Loader Class Initialized
INFO - 2020-06-24 19:06:31 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:06:31 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:06:31 --> Helper loaded: data_helper
INFO - 2020-06-24 19:06:31 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:06:31 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:06:31 --> Helper loaded: view_helper
INFO - 2020-06-24 19:06:31 --> Helper loaded: url_helper
INFO - 2020-06-24 19:06:31 --> Database Driver Class Initialized
INFO - 2020-06-24 19:06:31 --> Controller Class Initialized
INFO - 2020-06-24 19:06:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:06:31 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 19:06:31 --> Plain_Model class loaded
INFO - 2020-06-24 19:06:31 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 19:06:31 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:06:31 --> Model "Labels_model" initialized
INFO - 2020-06-24 19:06:31 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-24 19:06:31 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-24 19:06:31 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-24 19:06:31 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-24 19:06:31 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-24 19:06:31 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-24 19:06:31 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-24 19:06:31 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-24 19:06:31 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-24 19:06:31 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-24 19:06:31 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-24 19:06:31 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-24 19:06:31 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-24 19:06:31 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-24 19:06:31 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 19:06:31 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 19:06:31 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 19:06:31 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 19:06:31 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 19:06:31 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-24 19:06:31 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-24 19:06:31 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-24 19:06:31 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-24 19:06:31 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-24 19:06:31 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-24 19:06:31 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-24 19:06:31 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-24 19:06:31 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-24 19:06:31 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-24 19:06:31 --> Final output sent to browser
DEBUG - 2020-06-24 19:06:31 --> Total execution time: 0.2150
INFO - 2020-06-24 19:06:32 --> Config Class Initialized
INFO - 2020-06-24 19:06:32 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:06:32 --> Hooks Class Initialized
INFO - 2020-06-24 19:06:32 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:06:32 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:06:32 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:06:32 --> Utf8 Class Initialized
INFO - 2020-06-24 19:06:32 --> URI Class Initialized
DEBUG - 2020-06-24 19:06:32 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:06:32 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:06:32 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:07:52 --> Config Class Initialized
INFO - 2020-06-24 19:07:52 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:07:52 --> Hooks Class Initialized
INFO - 2020-06-24 19:07:52 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:07:52 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:07:52 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:07:52 --> Utf8 Class Initialized
INFO - 2020-06-24 19:07:52 --> URI Class Initialized
DEBUG - 2020-06-24 19:07:52 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:07:52 --> Router Class Initialized
INFO - 2020-06-24 19:07:52 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:07:52 --> Output Class Initialized
INFO - 2020-06-24 19:07:52 --> Security Class Initialized
DEBUG - 2020-06-24 19:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:07:52 --> Input Class Initialized
INFO - 2020-06-24 19:07:52 --> Language Class Initialized
INFO - 2020-06-24 19:07:52 --> Loader Class Initialized
INFO - 2020-06-24 19:07:52 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:07:52 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:07:52 --> Helper loaded: data_helper
INFO - 2020-06-24 19:07:52 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:07:52 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:07:52 --> Helper loaded: view_helper
INFO - 2020-06-24 19:07:52 --> Helper loaded: url_helper
INFO - 2020-06-24 19:07:52 --> Database Driver Class Initialized
INFO - 2020-06-24 19:07:52 --> Controller Class Initialized
INFO - 2020-06-24 19:07:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:07:52 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 19:07:52 --> Plain_Model class loaded
INFO - 2020-06-24 19:07:52 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 19:07:52 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:07:52 --> Model "Labels_model" initialized
INFO - 2020-06-24 19:07:52 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-24 19:07:52 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-24 19:07:52 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-24 19:07:52 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-24 19:07:52 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-24 19:07:52 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-24 19:07:52 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-24 19:07:52 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-24 19:07:52 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-24 19:07:52 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-24 19:07:52 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-24 19:07:52 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-24 19:07:52 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-24 19:07:52 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-24 19:07:52 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 19:07:52 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 19:07:52 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 19:07:52 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 19:07:52 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 19:07:52 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-24 19:07:52 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-24 19:07:52 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-24 19:07:52 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-24 19:07:52 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-24 19:07:52 --> The phrase "Note: HTML export is compatible with Pocket, Delicious, Pinboard, and others." could not be found in the language file.
DEBUG - 2020-06-24 19:07:52 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-24 19:07:52 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-24 19:07:52 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-24 19:07:52 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-24 19:07:52 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-24 19:07:52 --> Final output sent to browser
DEBUG - 2020-06-24 19:07:52 --> Total execution time: 0.2796
INFO - 2020-06-24 19:07:53 --> Config Class Initialized
INFO - 2020-06-24 19:07:53 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:07:53 --> Hooks Class Initialized
INFO - 2020-06-24 19:07:53 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:07:53 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:07:53 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:07:53 --> Utf8 Class Initialized
INFO - 2020-06-24 19:07:53 --> URI Class Initialized
DEBUG - 2020-06-24 19:07:53 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:07:53 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:07:53 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:09:10 --> Config Class Initialized
INFO - 2020-06-24 19:09:10 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:09:10 --> Hooks Class Initialized
INFO - 2020-06-24 19:09:10 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:09:10 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:09:10 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:09:10 --> Utf8 Class Initialized
INFO - 2020-06-24 19:09:10 --> URI Class Initialized
DEBUG - 2020-06-24 19:09:10 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:09:10 --> Router Class Initialized
INFO - 2020-06-24 19:09:10 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:09:10 --> Output Class Initialized
INFO - 2020-06-24 19:09:10 --> Security Class Initialized
DEBUG - 2020-06-24 19:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:09:10 --> Input Class Initialized
INFO - 2020-06-24 19:09:10 --> Language Class Initialized
INFO - 2020-06-24 19:09:10 --> Loader Class Initialized
INFO - 2020-06-24 19:09:10 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:09:10 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:09:10 --> Helper loaded: data_helper
INFO - 2020-06-24 19:09:10 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:09:10 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:09:10 --> Helper loaded: view_helper
INFO - 2020-06-24 19:09:10 --> Helper loaded: url_helper
INFO - 2020-06-24 19:09:10 --> Database Driver Class Initialized
INFO - 2020-06-24 19:09:10 --> Controller Class Initialized
INFO - 2020-06-24 19:09:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:09:10 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 19:09:10 --> Plain_Model class loaded
INFO - 2020-06-24 19:09:10 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 19:09:10 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:09:10 --> Model "Labels_model" initialized
INFO - 2020-06-24 19:09:10 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-24 19:09:10 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-24 19:09:10 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-24 19:09:10 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-24 19:09:10 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-24 19:09:10 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-24 19:09:10 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-24 19:09:10 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-24 19:09:10 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-24 19:09:10 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-24 19:09:10 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-24 19:09:10 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-24 19:09:10 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-24 19:09:10 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-24 19:09:10 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 19:09:10 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 19:09:10 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 19:09:10 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 19:09:10 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 19:09:10 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-24 19:09:10 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-24 19:09:10 --> The phrase "Note: HTML export is compatible with Pocket, Delicious, Pinboard, and others." could not be found in the language file.
DEBUG - 2020-06-24 19:09:10 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-24 19:09:10 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-24 19:09:10 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-24 19:09:10 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-24 19:09:10 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-24 19:09:10 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-24 19:09:10 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-24 19:09:10 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-24 19:09:10 --> Final output sent to browser
DEBUG - 2020-06-24 19:09:10 --> Total execution time: 0.2041
INFO - 2020-06-24 19:09:10 --> Config Class Initialized
INFO - 2020-06-24 19:09:10 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:09:10 --> Hooks Class Initialized
INFO - 2020-06-24 19:09:10 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:09:10 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:09:10 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:09:10 --> Utf8 Class Initialized
INFO - 2020-06-24 19:09:10 --> URI Class Initialized
DEBUG - 2020-06-24 19:09:10 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:09:10 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:09:10 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:09:27 --> Config Class Initialized
INFO - 2020-06-24 19:09:27 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:09:27 --> Hooks Class Initialized
INFO - 2020-06-24 19:09:27 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:09:27 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:09:27 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:09:27 --> Utf8 Class Initialized
INFO - 2020-06-24 19:09:27 --> URI Class Initialized
DEBUG - 2020-06-24 19:09:27 --> Validating request for /controllers/Marks.php
INFO - 2020-06-24 19:09:27 --> Router Class Initialized
INFO - 2020-06-24 19:09:27 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:09:27 --> Output Class Initialized
INFO - 2020-06-24 19:09:27 --> Security Class Initialized
DEBUG - 2020-06-24 19:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:09:27 --> Input Class Initialized
INFO - 2020-06-24 19:09:27 --> Language Class Initialized
INFO - 2020-06-24 19:09:27 --> Loader Class Initialized
INFO - 2020-06-24 19:09:27 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:09:27 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:09:27 --> Helper loaded: data_helper
INFO - 2020-06-24 19:09:27 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:09:27 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:09:27 --> Helper loaded: view_helper
INFO - 2020-06-24 19:09:27 --> Helper loaded: url_helper
INFO - 2020-06-24 19:09:27 --> Database Driver Class Initialized
INFO - 2020-06-24 19:09:27 --> Controller Class Initialized
INFO - 2020-06-24 19:09:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:09:27 --> Config file loaded: /var/www/html/application/config/all/language.php
INFO - 2020-06-24 19:09:27 --> Plain_Model class loaded
INFO - 2020-06-24 19:09:27 --> Model "Users_To_Marks_model" initialized
DEBUG - 2020-06-24 19:09:27 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:09:27 --> Model "Labels_model" initialized
INFO - 2020-06-24 19:09:27 --> Model "User_Marks_To_Tags_model" initialized
DEBUG - 2020-06-24 19:09:27 --> The phrase "View Contexts" could not be found in the language file.
DEBUG - 2020-06-24 19:09:27 --> The phrase "View Tags" could not be found in the language file.
INFO - 2020-06-24 19:09:27 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_icons.php
DEBUG - 2020-06-24 19:09:27 --> The phrase "You haven't added any tags yet. When you do the ones you use most will be listed here." could not be found in the language file.
DEBUG - 2020-06-24 19:09:27 --> The phrase "Recently-Used Tags" could not be found in the language file.
DEBUG - 2020-06-24 19:09:27 --> The phrase "When saving a mark, add a tag, and the most recent ones you use will show up here." could not be found in the language file.
INFO - 2020-06-24 19:09:27 --> File loaded: /var/www/html/application/views/layouts/timeline.php
INFO - 2020-06-24 19:09:27 --> File loaded: /var/www/html/application/views/layouts/accountlinks.php
DEBUG - 2020-06-24 19:09:27 --> The phrase "Report Issue" could not be found in the language file.
DEBUG - 2020-06-24 19:09:27 --> The phrase "Archive" could not be found in the language file.
INFO - 2020-06-24 19:09:27 --> File loaded: /var/www/html/application/views/layouts/navigation/nav_panels.php
INFO - 2020-06-24 19:09:27 --> File loaded: /var/www/html/application/views/layouts/navigation.php
INFO - 2020-06-24 19:09:27 --> File loaded: /var/www/html/application/views/layouts/header.php
DEBUG - 2020-06-24 19:09:27 --> The phrase "Go" could not be found in the language file.
DEBUG - 2020-06-24 19:09:27 --> The phrase "Enter URL..." could not be found in the language file.
DEBUG - 2020-06-24 19:09:27 --> The phrase "Add<span> Mark</span>" could not be found in the language file.
INFO - 2020-06-24 19:09:27 --> File loaded: /var/www/html/application/views/layouts/topbar/searchform.php
INFO - 2020-06-24 19:09:27 --> File loaded: /var/www/html/application/views/marks/index.php
INFO - 2020-06-24 19:09:27 --> File loaded: /var/www/html/application/views/layouts/sidebar.php
DEBUG - 2020-06-24 19:09:27 --> The phrase "New Password Again..." could not be found in the language file.
DEBUG - 2020-06-24 19:09:27 --> The phrase "Note: HTML export is compatible with Pocket, Delicious, Pinboard, and others." could not be found in the language file.
DEBUG - 2020-06-24 19:09:27 --> The phrase "Exporting Marks" could not be found in the language file.
DEBUG - 2020-06-24 19:09:27 --> The phrase "Export Unmark File" could not be found in the language file.
DEBUG - 2020-06-24 19:09:27 --> The phrase "Export HTML File" could not be found in the language file.
DEBUG - 2020-06-24 19:09:27 --> The phrase "Note: HTML import supports Pocket, Delicious, Pinboard, and others." could not be found in the language file.
INFO - 2020-06-24 19:09:27 --> File loaded: /var/www/html/application/views/layouts/userforms.php
INFO - 2020-06-24 19:09:27 --> File loaded: /var/www/html/application/views/layouts/jsvars.php
INFO - 2020-06-24 19:09:27 --> File loaded: /var/www/html/application/views/layouts/footer_scripts.php
INFO - 2020-06-24 19:09:27 --> File loaded: /var/www/html/application/views/layouts/footer.php
INFO - 2020-06-24 19:09:27 --> Final output sent to browser
DEBUG - 2020-06-24 19:09:27 --> Total execution time: 0.2061
INFO - 2020-06-24 19:09:27 --> Config Class Initialized
INFO - 2020-06-24 19:09:27 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:09:27 --> Hooks Class Initialized
INFO - 2020-06-24 19:09:27 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:09:27 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:09:27 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:09:27 --> Utf8 Class Initialized
INFO - 2020-06-24 19:09:27 --> URI Class Initialized
DEBUG - 2020-06-24 19:09:27 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:09:27 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:09:27 --> 404 Page Not Found: custom
INFO - 2020-06-24 19:09:30 --> Config Class Initialized
INFO - 2020-06-24 19:09:30 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:09:30 --> Hooks Class Initialized
INFO - 2020-06-24 19:09:30 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:09:30 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:09:30 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:09:30 --> Utf8 Class Initialized
INFO - 2020-06-24 19:09:30 --> URI Class Initialized
DEBUG - 2020-06-24 19:09:30 --> No URI present. Default controller set.
INFO - 2020-06-24 19:09:30 --> Router Class Initialized
INFO - 2020-06-24 19:09:30 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:09:30 --> Output Class Initialized
INFO - 2020-06-24 19:09:30 --> Security Class Initialized
DEBUG - 2020-06-24 19:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:09:30 --> Input Class Initialized
INFO - 2020-06-24 19:09:30 --> Language Class Initialized
INFO - 2020-06-24 19:09:30 --> Loader Class Initialized
INFO - 2020-06-24 19:09:30 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:09:30 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:09:30 --> Helper loaded: data_helper
INFO - 2020-06-24 19:09:30 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:09:30 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:09:30 --> Helper loaded: view_helper
INFO - 2020-06-24 19:09:30 --> Helper loaded: url_helper
INFO - 2020-06-24 19:09:30 --> Database Driver Class Initialized
INFO - 2020-06-24 19:09:30 --> Controller Class Initialized
INFO - 2020-06-24 19:09:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:09:30 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:09:30 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:09:30 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 19:09:30 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:09:30 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 19:09:30 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:09:30 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:09:30 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:09:30 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 19:09:30 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 19:09:30 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 19:09:30 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 19:09:30 --> Final output sent to browser
DEBUG - 2020-06-24 19:09:30 --> Total execution time: 0.1821
INFO - 2020-06-24 19:14:31 --> Config Class Initialized
INFO - 2020-06-24 19:14:31 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:14:31 --> Hooks Class Initialized
INFO - 2020-06-24 19:14:31 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:14:31 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:14:31 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:14:31 --> Utf8 Class Initialized
INFO - 2020-06-24 19:14:31 --> URI Class Initialized
DEBUG - 2020-06-24 19:14:31 --> No URI present. Default controller set.
INFO - 2020-06-24 19:14:31 --> Router Class Initialized
INFO - 2020-06-24 19:14:31 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:14:31 --> Output Class Initialized
INFO - 2020-06-24 19:14:31 --> Security Class Initialized
DEBUG - 2020-06-24 19:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:14:31 --> Input Class Initialized
INFO - 2020-06-24 19:14:31 --> Language Class Initialized
INFO - 2020-06-24 19:14:31 --> Loader Class Initialized
INFO - 2020-06-24 19:14:31 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:14:31 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:14:31 --> Helper loaded: data_helper
INFO - 2020-06-24 19:14:31 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:14:31 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:14:31 --> Helper loaded: view_helper
INFO - 2020-06-24 19:14:31 --> Helper loaded: url_helper
INFO - 2020-06-24 19:14:31 --> Database Driver Class Initialized
INFO - 2020-06-24 19:14:31 --> Controller Class Initialized
INFO - 2020-06-24 19:14:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:14:31 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:14:31 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:14:31 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 19:14:31 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:14:31 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 19:14:31 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:14:31 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:14:31 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:14:31 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 19:14:31 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 19:14:31 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 19:14:31 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 19:14:31 --> Final output sent to browser
DEBUG - 2020-06-24 19:14:31 --> Total execution time: 0.1895
INFO - 2020-06-24 19:19:31 --> Config Class Initialized
INFO - 2020-06-24 19:19:31 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:19:31 --> Hooks Class Initialized
INFO - 2020-06-24 19:19:31 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:19:31 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:19:31 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:19:31 --> Utf8 Class Initialized
INFO - 2020-06-24 19:19:32 --> URI Class Initialized
DEBUG - 2020-06-24 19:19:32 --> No URI present. Default controller set.
INFO - 2020-06-24 19:19:32 --> Router Class Initialized
INFO - 2020-06-24 19:19:32 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:19:32 --> Output Class Initialized
INFO - 2020-06-24 19:19:32 --> Security Class Initialized
DEBUG - 2020-06-24 19:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:19:32 --> Input Class Initialized
INFO - 2020-06-24 19:19:32 --> Language Class Initialized
INFO - 2020-06-24 19:19:32 --> Loader Class Initialized
INFO - 2020-06-24 19:19:32 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:19:32 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:19:32 --> Helper loaded: data_helper
INFO - 2020-06-24 19:19:32 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:19:32 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:19:32 --> Helper loaded: view_helper
INFO - 2020-06-24 19:19:32 --> Helper loaded: url_helper
INFO - 2020-06-24 19:19:32 --> Database Driver Class Initialized
INFO - 2020-06-24 19:19:32 --> Controller Class Initialized
INFO - 2020-06-24 19:19:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:19:32 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:19:32 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:19:32 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 19:19:32 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:19:32 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 19:19:32 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:19:32 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:19:32 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:19:32 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 19:19:32 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 19:19:32 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 19:19:32 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 19:19:32 --> Final output sent to browser
DEBUG - 2020-06-24 19:19:32 --> Total execution time: 0.1996
INFO - 2020-06-24 19:24:32 --> Config Class Initialized
INFO - 2020-06-24 19:24:32 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:24:32 --> Hooks Class Initialized
INFO - 2020-06-24 19:24:32 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:24:32 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:24:32 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:24:32 --> Utf8 Class Initialized
INFO - 2020-06-24 19:24:32 --> URI Class Initialized
DEBUG - 2020-06-24 19:24:32 --> No URI present. Default controller set.
INFO - 2020-06-24 19:24:32 --> Router Class Initialized
INFO - 2020-06-24 19:24:32 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:24:32 --> Output Class Initialized
INFO - 2020-06-24 19:24:32 --> Security Class Initialized
DEBUG - 2020-06-24 19:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:24:32 --> Input Class Initialized
INFO - 2020-06-24 19:24:32 --> Language Class Initialized
INFO - 2020-06-24 19:24:32 --> Loader Class Initialized
INFO - 2020-06-24 19:24:32 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:24:32 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:24:32 --> Helper loaded: data_helper
INFO - 2020-06-24 19:24:32 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:24:32 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:24:32 --> Helper loaded: view_helper
INFO - 2020-06-24 19:24:32 --> Helper loaded: url_helper
INFO - 2020-06-24 19:24:32 --> Database Driver Class Initialized
INFO - 2020-06-24 19:24:32 --> Controller Class Initialized
INFO - 2020-06-24 19:24:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:24:32 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:24:32 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:24:32 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 19:24:32 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:24:32 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 19:24:32 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:24:32 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:24:32 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:24:32 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 19:24:32 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 19:24:32 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 19:24:32 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 19:24:32 --> Final output sent to browser
DEBUG - 2020-06-24 19:24:32 --> Total execution time: 0.1867
INFO - 2020-06-24 19:29:33 --> Config Class Initialized
INFO - 2020-06-24 19:29:33 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:29:33 --> Hooks Class Initialized
INFO - 2020-06-24 19:29:33 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:29:33 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:29:33 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:29:33 --> Utf8 Class Initialized
INFO - 2020-06-24 19:29:33 --> URI Class Initialized
DEBUG - 2020-06-24 19:29:33 --> No URI present. Default controller set.
INFO - 2020-06-24 19:29:33 --> Router Class Initialized
INFO - 2020-06-24 19:29:33 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:29:33 --> Output Class Initialized
INFO - 2020-06-24 19:29:33 --> Security Class Initialized
DEBUG - 2020-06-24 19:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:29:33 --> Input Class Initialized
INFO - 2020-06-24 19:29:33 --> Language Class Initialized
INFO - 2020-06-24 19:29:33 --> Loader Class Initialized
INFO - 2020-06-24 19:29:33 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:29:33 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:29:33 --> Helper loaded: data_helper
INFO - 2020-06-24 19:29:33 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:29:33 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:29:33 --> Helper loaded: view_helper
INFO - 2020-06-24 19:29:33 --> Helper loaded: url_helper
INFO - 2020-06-24 19:29:33 --> Database Driver Class Initialized
INFO - 2020-06-24 19:29:33 --> Controller Class Initialized
INFO - 2020-06-24 19:29:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:29:33 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:29:33 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:29:33 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 19:29:33 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:29:33 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 19:29:33 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:29:33 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:29:33 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:29:33 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 19:29:33 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 19:29:33 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 19:29:33 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 19:29:33 --> Final output sent to browser
DEBUG - 2020-06-24 19:29:33 --> Total execution time: 0.1722
INFO - 2020-06-24 19:34:33 --> Config Class Initialized
INFO - 2020-06-24 19:34:33 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:34:33 --> Hooks Class Initialized
INFO - 2020-06-24 19:34:33 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:34:33 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:34:33 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:34:33 --> Utf8 Class Initialized
INFO - 2020-06-24 19:34:33 --> URI Class Initialized
DEBUG - 2020-06-24 19:34:33 --> No URI present. Default controller set.
INFO - 2020-06-24 19:34:33 --> Router Class Initialized
INFO - 2020-06-24 19:34:33 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:34:33 --> Output Class Initialized
INFO - 2020-06-24 19:34:33 --> Security Class Initialized
DEBUG - 2020-06-24 19:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:34:33 --> Input Class Initialized
INFO - 2020-06-24 19:34:33 --> Language Class Initialized
INFO - 2020-06-24 19:34:33 --> Loader Class Initialized
INFO - 2020-06-24 19:34:33 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:34:34 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:34:34 --> Helper loaded: data_helper
INFO - 2020-06-24 19:34:34 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:34:34 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:34:34 --> Helper loaded: view_helper
INFO - 2020-06-24 19:34:34 --> Helper loaded: url_helper
INFO - 2020-06-24 19:34:34 --> Database Driver Class Initialized
INFO - 2020-06-24 19:34:34 --> Controller Class Initialized
INFO - 2020-06-24 19:34:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:34:34 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:34:34 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:34:34 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 19:34:34 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:34:34 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 19:34:34 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:34:34 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:34:34 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:34:34 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 19:34:34 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 19:34:34 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 19:34:34 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 19:34:34 --> Final output sent to browser
DEBUG - 2020-06-24 19:34:34 --> Total execution time: 0.1450
INFO - 2020-06-24 19:39:34 --> Config Class Initialized
INFO - 2020-06-24 19:39:34 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:39:34 --> Hooks Class Initialized
INFO - 2020-06-24 19:39:34 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:39:34 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:39:34 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:39:34 --> Utf8 Class Initialized
INFO - 2020-06-24 19:39:34 --> URI Class Initialized
DEBUG - 2020-06-24 19:39:34 --> No URI present. Default controller set.
INFO - 2020-06-24 19:39:34 --> Router Class Initialized
INFO - 2020-06-24 19:39:34 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:39:34 --> Output Class Initialized
INFO - 2020-06-24 19:39:34 --> Security Class Initialized
DEBUG - 2020-06-24 19:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:39:34 --> Input Class Initialized
INFO - 2020-06-24 19:39:34 --> Language Class Initialized
INFO - 2020-06-24 19:39:34 --> Loader Class Initialized
INFO - 2020-06-24 19:39:34 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:39:34 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:39:34 --> Helper loaded: data_helper
INFO - 2020-06-24 19:39:34 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:39:34 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:39:34 --> Helper loaded: view_helper
INFO - 2020-06-24 19:39:34 --> Helper loaded: url_helper
INFO - 2020-06-24 19:39:34 --> Database Driver Class Initialized
INFO - 2020-06-24 19:39:34 --> Controller Class Initialized
INFO - 2020-06-24 19:39:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:39:34 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:39:34 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:39:34 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 19:39:34 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:39:34 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 19:39:34 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:39:34 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:39:34 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:39:34 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 19:39:34 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 19:39:34 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 19:39:34 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 19:39:34 --> Final output sent to browser
DEBUG - 2020-06-24 19:39:34 --> Total execution time: 0.1402
INFO - 2020-06-24 19:44:35 --> Config Class Initialized
INFO - 2020-06-24 19:44:35 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:44:35 --> Hooks Class Initialized
INFO - 2020-06-24 19:44:35 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:44:35 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:44:35 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:44:35 --> Utf8 Class Initialized
INFO - 2020-06-24 19:44:35 --> URI Class Initialized
DEBUG - 2020-06-24 19:44:35 --> No URI present. Default controller set.
INFO - 2020-06-24 19:44:35 --> Router Class Initialized
INFO - 2020-06-24 19:44:35 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:44:35 --> Output Class Initialized
INFO - 2020-06-24 19:44:35 --> Security Class Initialized
DEBUG - 2020-06-24 19:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:44:35 --> Input Class Initialized
INFO - 2020-06-24 19:44:35 --> Language Class Initialized
INFO - 2020-06-24 19:44:35 --> Loader Class Initialized
INFO - 2020-06-24 19:44:35 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:44:35 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:44:35 --> Helper loaded: data_helper
INFO - 2020-06-24 19:44:35 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:44:35 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:44:35 --> Helper loaded: view_helper
INFO - 2020-06-24 19:44:35 --> Helper loaded: url_helper
INFO - 2020-06-24 19:44:35 --> Database Driver Class Initialized
INFO - 2020-06-24 19:44:35 --> Controller Class Initialized
INFO - 2020-06-24 19:44:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:44:35 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:44:35 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:44:35 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 19:44:35 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:44:35 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 19:44:35 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:44:35 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:44:35 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:44:35 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 19:44:35 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 19:44:35 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 19:44:35 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 19:44:35 --> Final output sent to browser
DEBUG - 2020-06-24 19:44:35 --> Total execution time: 0.1334
INFO - 2020-06-24 19:45:33 --> Config Class Initialized
INFO - 2020-06-24 19:45:33 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:45:33 --> Hooks Class Initialized
INFO - 2020-06-24 19:45:33 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:45:33 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:45:33 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:45:33 --> Utf8 Class Initialized
INFO - 2020-06-24 19:45:33 --> URI Class Initialized
DEBUG - 2020-06-24 19:45:33 --> Validating request for /controllers/Logout.php
INFO - 2020-06-24 19:45:33 --> Router Class Initialized
INFO - 2020-06-24 19:45:33 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:45:33 --> Output Class Initialized
INFO - 2020-06-24 19:45:33 --> Security Class Initialized
DEBUG - 2020-06-24 19:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:45:33 --> Input Class Initialized
INFO - 2020-06-24 19:45:33 --> Language Class Initialized
INFO - 2020-06-24 19:45:33 --> Loader Class Initialized
INFO - 2020-06-24 19:45:33 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:45:33 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:45:33 --> Helper loaded: data_helper
INFO - 2020-06-24 19:45:33 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:45:33 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:45:33 --> Helper loaded: view_helper
INFO - 2020-06-24 19:45:33 --> Helper loaded: url_helper
INFO - 2020-06-24 19:45:33 --> Database Driver Class Initialized
INFO - 2020-06-24 19:45:33 --> Controller Class Initialized
INFO - 2020-06-24 19:45:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:45:33 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:45:33 --> The "english" language file has been loaded.
INFO - 2020-06-24 19:45:33 --> Config Class Initialized
INFO - 2020-06-24 19:45:33 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:45:33 --> Hooks Class Initialized
INFO - 2020-06-24 19:45:33 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:45:33 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:45:33 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:45:33 --> Utf8 Class Initialized
INFO - 2020-06-24 19:45:33 --> URI Class Initialized
DEBUG - 2020-06-24 19:45:33 --> No URI present. Default controller set.
INFO - 2020-06-24 19:45:33 --> Router Class Initialized
INFO - 2020-06-24 19:45:33 --> Plain_Router Class Initialized
INFO - 2020-06-24 19:45:33 --> Output Class Initialized
INFO - 2020-06-24 19:45:33 --> Security Class Initialized
DEBUG - 2020-06-24 19:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-06-24 19:45:33 --> Input Class Initialized
INFO - 2020-06-24 19:45:33 --> Language Class Initialized
INFO - 2020-06-24 19:45:34 --> Loader Class Initialized
INFO - 2020-06-24 19:45:34 --> Plain_Loader Class Initialized
DEBUG - 2020-06-24 19:45:34 --> Config file loaded: /var/www/html/application/config/all/app.php
INFO - 2020-06-24 19:45:34 --> Helper loaded: data_helper
INFO - 2020-06-24 19:45:34 --> Helper loaded: hash_helper
INFO - 2020-06-24 19:45:34 --> Helper loaded: validation_helper
INFO - 2020-06-24 19:45:34 --> Helper loaded: view_helper
INFO - 2020-06-24 19:45:34 --> Helper loaded: url_helper
INFO - 2020-06-24 19:45:34 --> Database Driver Class Initialized
INFO - 2020-06-24 19:45:34 --> Controller Class Initialized
INFO - 2020-06-24 19:45:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-06-24 19:45:34 --> Config file loaded: /var/www/html/application/config/all/language.php
DEBUG - 2020-06-24 19:45:34 --> The "english" language file has been loaded.
DEBUG - 2020-06-24 19:45:34 --> The phrase "Unmark - The to do app for bookmarks." could not be found in the language file.
DEBUG - 2020-06-24 19:45:34 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:45:34 --> The phrase "Password" could not be found in the language file.
DEBUG - 2020-06-24 19:45:34 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:45:34 --> The phrase "Forgot Password?" could not be found in the language file.
DEBUG - 2020-06-24 19:45:34 --> The phrase "Email Address" could not be found in the language file.
DEBUG - 2020-06-24 19:45:34 --> The phrase "Sign into your account" could not be found in the language file.
DEBUG - 2020-06-24 19:45:34 --> The phrase "Need to Sign In?" could not be found in the language file.
INFO - 2020-06-24 19:45:34 --> File loaded: /var/www/html/application/views/layouts/footer_unlogged_scripts.php
INFO - 2020-06-24 19:45:34 --> File loaded: /var/www/html/application/views/welcome.php
INFO - 2020-06-24 19:45:34 --> Final output sent to browser
DEBUG - 2020-06-24 19:45:34 --> Total execution time: 0.1218
INFO - 2020-06-24 19:45:34 --> Config Class Initialized
INFO - 2020-06-24 19:45:34 --> Plain_Config Class Initialized
INFO - 2020-06-24 19:45:34 --> Hooks Class Initialized
INFO - 2020-06-24 19:45:34 --> Plain_Hooks Class Constructed
INFO - 2020-06-24 19:45:34 --> Plain_Hooks Class Initialized
DEBUG - 2020-06-24 19:45:34 --> UTF-8 Support Disabled
INFO - 2020-06-24 19:45:34 --> Utf8 Class Initialized
INFO - 2020-06-24 19:45:34 --> URI Class Initialized
DEBUG - 2020-06-24 19:45:34 --> Validating request for /controllers/Custom.php
INFO - 2020-06-24 19:45:34 --> Plain_Exceptions Class Initialized
ERROR - 2020-06-24 19:45:34 --> 404 Page Not Found: custom
